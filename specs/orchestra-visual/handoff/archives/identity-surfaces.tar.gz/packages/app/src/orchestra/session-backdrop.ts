/** Opt-in performance prototype. The caller owns mounting and disposal with the
 * session layout. Only the approved wallpaper and static shell paints enter the
 * picture; session, sidebar, and tab foreground content are never captured. */
export async function createSessionBackdrop(panel: HTMLElement, mode: "raster" | "css" | "css-crop" | "svg-crop" = "raster") {
  const workspace = panel.closest<HTMLElement>(".orchestra-workspace")
  const shell = panel.closest<HTMLElement>(".orchestra-shell")
  if (!workspace || !shell) throw new Error("Session backdrop requires the Orchestra workspace and shell")
  if (panel.hasAttribute("data-orchestra-static-backdrop")) throw new Error("Session backdrop already mounted")

  const wallpaper = await fetch(new URL("/orchestra/mtn-src.jpg", location.origin)).then((response) => {
    if (!response.ok) throw new Error(`Session wallpaper failed: ${response.status}`)
    return response.blob()
  })
  const bitmap = await createImageBitmap(wallpaper)
  const dimensions = { width: bitmap.width, height: bitmap.height }
  bitmap.close()
  if (dimensions.width !== 900 || dimensions.height !== 601) throw new Error("Session wallpaper dimensions changed")
  const wallpaperURL = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result))
    reader.onerror = () => reject(reader.error)
    reader.readAsDataURL(wallpaper)
  })
  const state = {
    key: "",
    pending: undefined as string | undefined,
    generation: 0,
    rasterizations: 0,
    frame: undefined as number | undefined,
    imageURL: undefined as string | undefined,
    decorator: undefined as HTMLElement | undefined,
    error: undefined as string | undefined,
    disposed: false,
  }

  const refresh = async () => {
    if (state.disposed) return
    const geometry = {
      viewport: { width: innerWidth, height: innerHeight, dpr: devicePixelRatio },
      panel: panel.getBoundingClientRect().toJSON() as { x: number; y: number; width: number; height: number },
      workspace: workspace.getBoundingClientRect().toJSON() as { x: number; y: number; width: number; height: number },
      shell: shell.getBoundingClientRect().toJSON() as { x: number; y: number; width: number; height: number },
    }
    const bodyStyle = getComputedStyle(document.body)
    const shellStyle = getComputedStyle(shell)
    const paints = {
      bodyImage: bodyStyle.backgroundImage,
      bodyColor: bodyStyle.backgroundColor,
      shellColor: shellStyle.backgroundColor,
      shellBorder: shellStyle.border,
      shellRadius: shellStyle.borderRadius,
      shellShadow: shellStyle.boxShadow,
      shellBorderWidth: parseFloat(shellStyle.borderLeftWidth),
      workspaceOverlay: getComputedStyle(workspace, "::before").backgroundImage,
      filter: getComputedStyle(panel).getPropertyValue("--orchestra-session-filter").trim(),
      scheme: document.documentElement.dataset.colorScheme,
      direction: document.documentElement.dir,
    }
    const key = JSON.stringify({ geometry, paints })
    if (key === state.key || key === state.pending) return
    if (!paints.filter || geometry.panel.width <= 0 || geometry.panel.height <= 0) return
    const generation = ++state.generation
    state.pending = key
    const scene = document.createElement("div")
    scene.style.cssText = `position:relative;width:${geometry.viewport.width}px;height:${geometry.viewport.height}px;background-image:${paints.bodyImage};background-color:${paints.bodyColor};`
    const frame = document.createElement("div")
    frame.style.cssText = `position:absolute;box-sizing:border-box;left:${geometry.shell.x}px;top:${geometry.shell.y}px;width:${geometry.shell.width}px;height:${geometry.shell.height}px;background-color:${paints.shellColor};border:${paints.shellBorder};border-radius:${paints.shellRadius};box-shadow:${paints.shellShadow};overflow:hidden;`
    const mountain = document.createElement("div")
    mountain.style.cssText = `position:absolute;left:${geometry.workspace.x - geometry.shell.x - paints.shellBorderWidth}px;top:${geometry.workspace.y - geometry.shell.y - paints.shellBorderWidth}px;width:${geometry.workspace.width}px;height:${geometry.workspace.height}px;background-image:url("${mode === "raster" ? wallpaperURL : new URL("/orchestra/mtn-src.jpg", location.origin).href}");background-size:cover;background-position:center;background-repeat:no-repeat;`
    const overlay = document.createElement("div")
    overlay.style.cssText = `position:absolute;inset:0;background-image:${paints.workspaceOverlay};pointer-events:none;`
    mountain.append(overlay)
    frame.append(mountain)
    scene.append(frame)

    if (mode !== "raster") {
      const decorator = document.createElement("div")
      decorator.dataset.slot = "orchestra-static-session-underlay"
      decorator.setAttribute("aria-hidden", "true")
      scene.style.position = "absolute"
      const filtered = mode === "css" ? scene : document.createElement("div")
      filtered.dataset.slot = "orchestra-static-session-scene"
      filtered.style.filter = paints.filter
      if (mode === "css") {
        scene.style.left = `${-geometry.panel.x}px`
        scene.style.top = `${-geometry.panel.y}px`
      }
      if (mode !== "css") {
        const padding = paints.scheme === "light" ? 54 : 48
        filtered.style.cssText += `position:absolute;left:${-padding}px;top:${-padding}px;width:${geometry.panel.width + padding * 2}px;height:${geometry.panel.height + padding * 2}px;overflow:hidden;`
        scene.style.left = `${-geometry.panel.x + padding}px`
        scene.style.top = `${-geometry.panel.y + padding}px`
        filtered.append(scene)
      }
      if (mode === "svg-crop") {
        const settings = paints.scheme === "light" ? { blur: 18, brightness: 1.02, saturation: 0.98 } : { blur: 16, brightness: 0.58, saturation: 0.86 }
        if (paints.filter !== `blur(${settings.blur}px) brightness(${settings.brightness}) saturate(${settings.saturation})`) throw new Error("Fused backdrop requires the frozen session filter tokens")
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg")
        svg.setAttribute("width", "0")
        svg.setAttribute("height", "0")
        svg.setAttribute("aria-hidden", "true")
        const filter = document.createElementNS(svg.namespaceURI, "filter")
        filter.id = `orchestra-static-${crypto.randomUUID()}`
        filter.setAttribute("color-interpolation-filters", "sRGB")
        filter.setAttribute("x", "-20%")
        filter.setAttribute("y", "-20%")
        filter.setAttribute("width", "140%")
        filter.setAttribute("height", "140%")
        const blur = document.createElementNS(svg.namespaceURI, "feGaussianBlur")
        blur.setAttribute("stdDeviation", String(settings.blur))
        const color = document.createElementNS(svg.namespaceURI, "feColorMatrix")
        color.setAttribute("type", "matrix")
        // Brightness and the SVG/CSS saturation matrix share one color pass.
        const s = settings.saturation
        color.setAttribute("values", [
          0.213 + 0.787 * s, 0.715 - 0.715 * s, 0.072 - 0.072 * s,
          0.213 - 0.213 * s, 0.715 + 0.285 * s, 0.072 - 0.072 * s,
          0.213 - 0.213 * s, 0.715 - 0.715 * s, 0.072 + 0.928 * s,
        ].map((value) => value * settings.brightness).flatMap((value, index) => index % 3 === 2 ? [value, 0, 0] : [value]).concat([0, 0, 0, 1, 0]).join(" "))
        filter.append(blur, color)
        svg.append(filter)
        decorator.append(svg)
        filtered.style.filter = `url("#${filter.id}")`
      }
      decorator.append(filtered)
      state.decorator?.remove()
      panel.prepend(decorator)
      state.decorator = decorator
      state.key = key
      state.pending = undefined
      panel.dataset.orchestraStaticBackdrop = mode
      return
    }

    // A Blob-backed SVG foreignObject taints Chromium's canvas. A self-contained
    // data image keeps only the approved, embedded wallpaper in this raster.
    scene.style.filter = paints.filter
    const sourceURL = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${geometry.viewport.width}" height="${geometry.viewport.height}"><foreignObject width="100%" height="100%">${new XMLSerializer().serializeToString(scene)}</foreignObject></svg>`)}`
    const image = new Image()
    image.src = sourceURL
    await image.decode()
    const filtered = document.createElement("canvas")
    filtered.width = Math.ceil(geometry.viewport.width * geometry.viewport.dpr)
    filtered.height = Math.ceil(geometry.viewport.height * geometry.viewport.dpr)
    const context = filtered.getContext("2d")
    if (!context) throw new Error("Session backdrop canvas unavailable")
    context.scale(geometry.viewport.dpr, geometry.viewport.dpr)
    context.drawImage(image, 0, 0)
    const tile = document.createElement("canvas")
    tile.width = Math.ceil(geometry.panel.width * geometry.viewport.dpr)
    tile.height = Math.ceil(geometry.panel.height * geometry.viewport.dpr)
    const output = tile.getContext("2d")
    if (!output) throw new Error("Session backdrop tile unavailable")
    output.drawImage(filtered, -geometry.panel.x * geometry.viewport.dpr, -geometry.panel.y * geometry.viewport.dpr)
    const blob = await new Promise<Blob>((resolve, reject) => tile.toBlob((blob) => {
      if (!blob) return reject(new Error("Session backdrop encoding failed"))
      resolve(blob)
    }))
    if (state.disposed || generation !== state.generation) return
    const previous = state.imageURL
    state.imageURL = URL.createObjectURL(blob)
    state.key = key
    state.pending = undefined
    state.rasterizations++
    panel.style.setProperty("--orchestra-static-session-image", `url("${state.imageURL}")`)
    panel.dataset.orchestraStaticBackdrop = mode
    if (previous) URL.revokeObjectURL(previous)
  }

  const schedule = () => {
    if (state.disposed || state.frame !== undefined) return
    state.frame = requestAnimationFrame(() => {
      state.frame = undefined
      void refresh().catch((error: unknown) => {
        state.error = error instanceof Error ? error.message : String(error)
        state.pending = undefined
        panel.removeAttribute("data-orchestra-static-backdrop")
      })
    })
  }
  await refresh()
  const resize = new ResizeObserver(schedule)
  ;[workspace, shell, panel, document.documentElement, ...Array.from(workspace.querySelectorAll<HTMLElement>("#orchestra-session-tabs"))].forEach((element) => resize.observe(element))
  const theme = new MutationObserver(schedule)
  theme.observe(document.documentElement, { attributes: true, attributeFilter: ["data-color-scheme", "dir"] })
  window.addEventListener("resize", schedule)
  return {
    refresh,
    snapshot: () => ({ key: state.key, generation: state.generation, rasterizations: state.rasterizations, error: state.error, mode, wallpaper: dimensions }),
    dispose() {
      state.disposed = true
      state.generation++
      resize.disconnect()
      theme.disconnect()
      window.removeEventListener("resize", schedule)
      if (state.frame !== undefined) cancelAnimationFrame(state.frame)
      if (state.imageURL) URL.revokeObjectURL(state.imageURL)
      state.decorator?.remove()
      panel.removeAttribute("data-orchestra-static-backdrop")
      panel.style.removeProperty("--orchestra-static-session-image")
    },
  }
}
