/** Opt-in performance prototype. The caller owns mounting and disposal with the
 * session layout. Only the approved wallpaper and static shell paints enter the
 * picture; session, sidebar, and tab foreground content are never captured. */
export declare function createSessionBackdrop(panel: HTMLElement, mode?: "raster" | "css" | "css-crop" | "svg-crop"): Promise<{
    refresh: () => Promise<void>;
    snapshot: () => {
        key: string;
        generation: number;
        rasterizations: number;
        error: string | undefined;
        mode: "css" | "css-crop" | "raster" | "svg-crop";
        wallpaper: {
            width: number;
            height: number;
        };
    };
    dispose(): void;
}>;
