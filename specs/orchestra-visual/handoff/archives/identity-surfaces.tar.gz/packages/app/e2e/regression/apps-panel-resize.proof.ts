import { strict } from "node:assert"
import { chromium, expect } from "@playwright/test"
import { createServer } from "vite"
import solid from "vite-plugin-solid"

// Standalone browser integration proof: the production component, CSS, RAF and
// ResizeObserver are real. Only Electron's unavailable preload bridge is recorded.
type Bounds = { x: number; y: number; width: number; height: number }
type Identity = { tabID: string; generation: number }
type Probe = {
  resizes: { tab: Identity | null; bounds: Bounds }[]
  selected: Identity | null
  closed: number
  windowEvents: number
  windowSettled: number
  roEvents: number
  roSettled: number
  mountMs: number
}
declare global {
  interface Window {
    dockResizeProbe: Probe
  }
}

const fixture = `
import { createComponent } from "solid-js";
import { render } from "solid-js/web";
import { AppsPanel } from "/src/pages/session/apps-panel.tsx";
localStorage.setItem("opencode.app-dock.sidebar-collapsed", "true");
const probe = { resizes: [], selected: null, closed: 0, windowEvents: 0,
  windowSettled: 0, roEvents: 0, roSettled: 0, mountMs: 0 };
Reflect.set(window, "dockResizeProbe", probe);
let nextID = 0;
Reflect.set(window, "api", {
  appDockGetManifest: async () => ({ version: 1, revision: 1,
    profiles: [{ id: "default", name: "Personal" }], activeProfileID: "default",
    tabs: {}, bookmarks: [], history: [] }),
  appDockUpdateManifest: async (_, manifest) => ({ status: "updated", manifest }),
  appDockEvent: () => () => {},
  appDockFindResult: () => () => {},
  appDockOpen: async (url) => {
    probe.selected = { tabID: "dock-" + ++nextID, generation: 1 };
    return { ...probe.selected, url };
  },
  appDockSelect: async (tabID) => { probe.selected = { tabID, generation: 1 }; },
  appDockResize: async (bounds) => {
    probe.resizes.push({ tab: probe.selected && { ...probe.selected }, bounds });
  },
  appDockClose: async () => { probe.closed++; probe.selected = null; },
});
const started = performance.now();
const dispose = render(() => createComponent(AppsPanel, {}), document.getElementById("panel"));
document.getElementById("unmount").onclick = dispose;
queueMicrotask(() => {
  probe.mountMs = performance.now() - started;
  const host = document.querySelector(".zen-browser-host");
  // Registered after AppsPanel's producers: these completion markers follow
  // its queued bridge callback, without sleeps or arbitrary frame-count waits.
  window.addEventListener("resize", () => {
    const event = ++probe.windowEvents;
    requestAnimationFrame(() => { probe.windowSettled = event; });
  });
  new ResizeObserver(() => {
    const event = ++probe.roEvents;
    requestAnimationFrame(() => { probe.roSettled = event; });
  }).observe(host);
});
`

const server = await createServer({
  configFile: false,
  root: process.cwd(),
  cacheDir: "e2e/test-results/apps-panel-resize-cache",
  optimizeDeps: { noDiscovery: true, include: ["solid-js", "solid-js/web"] },
  plugins: [
    solid(),
    {
      name: "apps-panel-resize-proof",
      resolveId: (id) => (id === "/__apps-panel-fixture.ts" ? id : undefined),
      load: (id) => (id === "/__apps-panel-fixture.ts" ? fixture : undefined),
      configureServer(server) {
        server.middlewares.use("/__apps-panel", (_, response) => {
          response.setHeader("Content-Type", "text/html")
          response.end(`<!doctype html><style>
            * { box-sizing: border-box; }
            #panel { position: absolute; right: 20px; top: 20px; width: 900px; height: 520px; }
            #unmount { position: fixed; left: 0; bottom: 0; }
          </style><div id="panel"></div><button id="unmount">Unmount Apps</button>
          <script type="module" src="/__apps-panel-fixture.ts"></script>`)
        })
      },
    },
  ],
  server: { host: "127.0.0.1", port: 0, hmr: false, watch: null },
})
await server.listen()
const address = server.httpServer?.address()
if (!address || typeof address === "string") throw new Error("Missing proof server address")
const browser = await chromium.launch({ headless: true })
try {
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 } })
  page.on("pageerror", (error) => console.error(error))
  await page.goto(`http://127.0.0.1:${address.port}/__apps-panel`)
  await expect(page.getByRole("button", { name: "Open", exact: true })).toBeEnabled()
  await page.waitForFunction(() => window.dockResizeProbe.roSettled > 0)
  const read = () => page.evaluate(() => window.dockResizeProbe)
  const cdp = await page.context().newCDPSession(page)
  const windowListeners = async () => {
    const result = await cdp.send("Runtime.evaluate", {
      expression: "getEventListeners(window).resize.length",
      includeCommandLineAPI: true,
      returnByValue: true,
    })
    strict.equal(result.exceptionDetails, undefined, "listener instrument failed")
    strict.equal(typeof result.result.value, "number", "listener instrument returned no count")
    return result.result.value as number
  }
  const settled = () =>
    page.waitForFunction(() => {
      const probe = window.dockResizeProbe
      return probe.windowEvents === probe.windowSettled && probe.roEvents === probe.roSettled
    })
  const windowResize = async (width: number) => {
    const previous = (await read()).windowEvents
    await page.setViewportSize({ width, height: 900 })
    await page.waitForFunction((previous) => {
      const probe = window.dockResizeProbe
      return probe.windowEvents > previous && probe.windowEvents === probe.windowSettled
    }, previous)
    await settled()
  }
  const host = page.locator(".zen-browser-host")
  const physical = () =>
    host.evaluate((element) => {
      const box = element.getBoundingClientRect()
      return {
        x: Math.round(box.x),
        y: Math.round(box.y),
        width: Math.round(box.width),
        height: Math.round(box.height),
      }
    })

  // Inactive component sees a real window resize but must not issue native IPC.
  await windowResize(1300)
  strict.equal((await read()).resizes.length, 0, "inactive resize issued IPC")
  await windowResize(1400)
  await page.getByRole("button", { name: "Open", exact: true }).click()
  await expect(page.getByRole("tab", { selected: true })).toHaveCount(1)
  await expect.poll(async () => (await read()).selected).toEqual({ tabID: "dock-1", generation: 1 })

  // Positive control and production-component benchmark: one width burst, one IPC.
  const beforeWidth = await physical()
  const beforeRO = await read()
  const started = performance.now()
  await page.locator("#panel").evaluate((element) => {
    Array.from({ length: 100 }, (_, index) => ((element as HTMLElement).style.width = `${901 + index}px`))
  })
  const afterWidth = await physical()
  strict.equal(afterWidth.width - beforeWidth.width, 100, "width control did not change host")
  await expect.poll(async () => (await read()).resizes.at(-1)?.bounds).toEqual(afterWidth)
  await settled()
  strict.equal((await read()).resizes.length - beforeRO.resizes.length, 1, "RO width burst was not coalesced")
  console.log("AppsPanel production width-burst baseline", {
    mountMs: (await read()).mountMs,
    elapsedMs: performance.now() - started,
    ipc: (await read()).resizes.length - beforeRO.resizes.length,
  })

  const beforeMove = await read()
  await windowResize(1500)
  const moved = await physical()
  strict.deepEqual(moved, { ...afterWidth, x: afterWidth.x + 100 }, "resize was not position-only")
  strict.equal((await read()).roEvents, beforeMove.roEvents, "position-only move unexpectedly triggered RO")
  strict.deepEqual((await read()).resizes.at(-1)?.bounds, moved, "window resize left native x stale")
  strict.equal((await read()).resizes.length - beforeMove.resizes.length, 1, "position-only move IPC count")

  const beforeDuplicate = await read()
  await page.evaluate(() => {
    Array.from({ length: 100 }, () => window.dispatchEvent(new Event("resize")))
  })
  await settled()
  strict.equal((await read()).resizes.length, beforeDuplicate.resizes.length, "unchanged bounds sent duplicate IPC")

  // Same geometry, different active native identity must not be deduplicated.
  await page.getByRole("button", { name: "Open", exact: true }).focus()
  await page.keyboard.press("Control+t")
  await expect.poll(async () => (await read()).selected).toEqual({ tabID: "dock-2", generation: 1 })
  await page.evaluate(() => window.dispatchEvent(new Event("resize")))
  await settled()
  strict.deepEqual((await read()).resizes.at(-1), { tab: { tabID: "dock-2", generation: 1 }, bounds: moved })
  strict.equal((await read()).resizes.length - beforeDuplicate.resizes.length, 1, "active identity IPC count")

  const beforeCleanup = await read()
  strict.equal(await windowListeners(), 2, "production and probe listeners must both be present")
  await page.evaluate(() => {
    window.dispatchEvent(new Event("resize"))
    document.getElementById("unmount")!.click()
  })
  await expect(page.getByRole("tab")).toHaveCount(0)
  await settled()
  strict.equal(await windowListeners(), 1, "window resize listener survived cleanup")
  strict.equal((await read()).closed, 1, "native cleanup did not run")
  strict.equal((await read()).resizes.length, beforeCleanup.resizes.length, "pending resize survived cleanup")
  await windowResize(1600)
  strict.equal((await read()).resizes.length, beforeCleanup.resizes.length, "window resize listener survived cleanup")
  console.log(
    "PASS: x-only window resize, RO width control, inactive guard, duplicate suppression, identity, cleanup",
    {
      before: afterWidth,
      after: moved,
      bridge: beforeCleanup.resizes.at(-1),
    },
  )
} finally {
  await browser.close()
  await server.close()
}
