# Static session backdrop prototype

Verdict: **exact-pixel contract fails; prototype remains opt-in, unintegrated**.

Implementation: `packages/app/src/orchestra/session-backdrop.ts` (203 lines), plus 35 opt-in lines in `session.css`. Viewport-aligned 900×601 wallpaper, observed workspace overlays and shell paints; existing dense gradient/border/shadow retain their paint owner. Native CSS image filter, cropped filter, fused SVG matrix, and cached PNG variants. Runtime uses only owned static source paints; verification screenshots never populate the picture. No runtime dependencies or perpetual timers.

Cache control: 12 real SSE reducer deltas leave rasterizations **1→1**. Layout resize produces **2**, theme change **3**. Observer updates coalesce; disposal removes observers/decorators and revokes image URLs.

Current evidence: Chromium 147.0.7727.15, DPR 1, two-message/12-delta tiny fixture. Headless Metal independently reports Intel UHD Graphics 630, GPU compositing enabled. Software control reports SwiftShader, compositing disabled_software.

| Whole-conversation differing pixels | Cropped CSS | Cached PNG |
| --- | ---: | ---: |
| Metal dark, 1400×900 | 42,706 | 50,655 |
| Metal light, 1400×900 | 71,121 | 92,003 |
| CPU dark | 24,962 | 692,854 |
| CPU light/RTL, 1100×900 | 35,126 | 188,833 |

Metal dark fused SVG: **42,707** differences. Differences cover interior and 48px/54px edge bands; outside conversation: **0**. Frozen repeat controls: **0**; magenta mutations detected. Hiding adjacent glass changes **360/789** conversation pixels (Metal dark/light), proving non-wallpaper backdrop input. Filter-path interior mismatch remains unresolved.

Metal tiny RAF p95: **16.7→16.8ms**. CPU dark: **66.7→33.4ms**, callback rate **16.2→42.9fps**. CPU restored baseline: **83.3ms**. No Metal gain established.

Focused typecheck passes; compiler and foreground-state guards falsified successfully. Package typecheck remains blocked by pre-existing deleted session modules.

Raw data/scripts/PNGs: `/var/folders/lt/z11pyzhj0m17vn798jkk69hh0000gn/T/opencode/perf-backdrop-static/`. Use guarded `metal-headless-*` and `cpu-headless-*` records. Earlier visible-window capture `metal-dark-r4` caught keyboard input and is invalid; `metal-light` timed out.
