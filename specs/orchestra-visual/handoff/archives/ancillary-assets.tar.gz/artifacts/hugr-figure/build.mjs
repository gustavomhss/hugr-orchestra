import path from "node:path"
import { createRequire } from "node:module"
import { pathToFileURL } from "node:url"

const { chromium } = await import(
  createRequire(new URL("../../packages/app/package.json", import.meta.url)).resolve("@playwright/test")
)
const browser = await chromium.launch({ headless: true })
const context = await browser.newContext({ viewport: { width: 1024, height: 1024 }, reducedMotion: "reduce" })
const source = await Bun.file(new URL("./mascote.svg", import.meta.url)).text()
await Promise.all([
  { name: "bonequinho", hastes: false, motion: false },
  { name: "abraco-h", hastes: true, motion: false },
  { name: "bonequinho-animado", hastes: false, motion: true },
  { name: "abraco-h-animado", hastes: true, motion: true },
].map(async (variant) => {
  const page = await context.newPage()
  const markup = await page.evaluate((input) => {
    const xml = new DOMParser().parseFromString(input.source, "image/svg+xml")
    if (xml.querySelector("parsererror")) throw new Error("The mascot master is not valid SVG XML")
    const svg = xml.documentElement
    svg.setAttribute("width", "1024")
    svg.setAttribute("height", "1024")
    svg.setAttribute("data-hastes", input.variant.hastes ? "on" : "off")
    svg.setAttribute("data-motion", input.variant.motion ? "on" : "off")
    svg.querySelector("desc").textContent = input.variant.hastes
      ? "Bonequinho azul sem rosto, com cabeça redonda lisa e braços abraçando duas hastes que formam o H."
      : "Bonequinho azul sem rosto, com cabeça redonda lisa, braços abertos em abraço e pés arredondados."
    return new XMLSerializer().serializeToString(svg)
  }, { source, variant })
  await Bun.write(path.join(import.meta.dir, "exports", `${variant.name}.svg`), markup)
  if (!variant.motion) {
    await page.setContent(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><style>html,body{margin:0;background:transparent}svg{display:block;width:1024px;height:1024px}</style></head><body>${markup}</body></html>`)
    await page.locator("svg").screenshot({ path: path.join(import.meta.dir, "exports", `${variant.name}.png`), omitBackground: true })
  }
  await page.close()
}))
const preview = await Bun.file(new URL("./preview.html", import.meta.url)).text()
const start = preview.indexOf("<!--HUGR-FIGURE:START-->")
const end = preview.indexOf("<!--HUGR-FIGURE:END-->")
if (start < 0 || end <= start) throw new Error("The preview is missing its generated SVG delimiters")
await Bun.write(new URL("./preview.html", import.meta.url), `${preview.slice(0, start)}<!--HUGR-FIGURE:START-->\n${source}\n            ${preview.slice(end)}`)
const page = await context.newPage()
await page.setViewportSize({ width: 1100, height: 850 })
await page.goto(pathToFileURL(path.join(import.meta.dir, "preview.html")).href)
await page.evaluate(async () => { await Promise.all(Array.from(document.images, (image) => image.decode())); await document.fonts.ready })
await page.locator(".sheet").screenshot({ path: path.join(import.meta.dir, "preview.png") })
await browser.close()
console.log("HuGR figure exported: isolated mascot, H embrace, transparent PNGs and local preview.")
