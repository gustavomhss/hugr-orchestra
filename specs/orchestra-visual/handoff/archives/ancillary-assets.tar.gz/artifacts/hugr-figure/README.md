# Bonequinho HuGR — versão mascote

O próprio personagem azul do símbolo HuGR, com cabeça redonda lisa e braços em gesto de abraço. A cabeça não recebe rosto. A forma central azul é o bonequinho; as duas hastes são os objetos que ele abraça.

![Bonequinho e abraço que forma o H.](preview.png)

As curvas da cabeça e do corpo vêm de `head`, `ribbon-blue` e `ribbon-light` de `~/Downloads/HuGR-Brand-Kit-v1.0/09-source/geometry.json`. A versão mascote acrescenta pernas com pés arredondados. As hastes ficam em um grupo separado, e podem ser exibidas ou ocultadas.

## Arquivos

- `mascote.svg`: master vetorial com cabeça, corpo, pernas e hastes separados.
- `exports/bonequinho.svg` e `.png`: o personagem isolado.
- `exports/abraco-h.svg` e `.png`: o mesmo personagem abraçando as duas hastes.
- `exports/*-animado.svg`: movimento discreto de presença, respeitando `prefers-reduced-motion`.
- PNGs transparentes: 1024 × 1024.
- `preview.html`: funciona por arquivo local; alterna movimento e hastes.

Controle SVG inline com `data-hastes="on|off"` e `data-motion="on|off"`. Ao repetir instâncias no mesmo DOM, prefixe IDs e referências de gradientes/ARIA. Em `<img>`, cada SVG tem seu próprio documento.

Para reexportar, com as dependências do Orchestra e Chromium do Playwright instalados, execute em `artifacts/hugr-figure`:

```sh
bun run build.mjs
```
