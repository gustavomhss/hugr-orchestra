# Fiapo × HuGR — direção 03

Fusão do Fiapo com o símbolo HuGR, com óculos escuros pixelados. O H vira corpo, a fita cruzada vira seu abraço e a bolinha central vira a cabeça irregular do Fiapo. O dentinho e as pernas minúsculas mantêm sua personalidade.

![Fiapo × HuGR.](concept-board-dark.png)

## Geometria e cor

O corpo usa a curva `body` e as fitas `ribbon-blue` e `ribbon-light` de `~/Downloads/HuGR-Brand-Kit-v1.0/09-source/geometry.json`, sob uma transformação uniforme. A cabeça usa a silhueta do Fiapo aprovado na direção anterior. Os óculos são uma construção vetorial em blocos de 6 unidades, com reflexos quadriculados e inclinação leve.

Sapphire `#A3BFDA` vem do HuGR Design System. Navy `#0B1423`, azul `#1266F6`, gelo `#DCEEFF` e branco vêm do brandkit HuGR. Esta composição é uma versão de personagem derivada da marca.

## Abrir e usar

- `preview.html`: abre por arquivo local, com poses, animação e fundo claro/escuro. Respeita `prefers-reduced-motion`.
- `fiapo-hugr.svg`: master editável com grupos nomeados.
- `exports/fiapo-hugr-{idle,scan,shake,done,oops}.svg`: poses estáticas.
- `exports/fiapo-hugr-*-animated.svg`: poses com motion CSS.
- PNGs correspondentes: 1024 × 1024, fundo transparente.
- `exports/fiapo-hugr-icon.svg` e `.png`: fusão compacta com o H inteiro, sem pés.
- `exports/fiapo-hugr-avatar.svg` e `.png`: só a cabeça com os óculos, para usos pequenos.
- `concept-board-dark.png` e `concept-board-light.png`: pranchas para compartilhar.

## Expressões

| Estado | Gesto |
| --- | --- |
| `idle` | Óculos tortos e sorriso de um dente |
| `scan` | Levanta os óculos e procura com os olhos desencontrados |
| `shake` | Sacode o H inteiro, com uma pausa entre os gestos |
| `done` | Sorri e ajeita os óculos, cheio de confiança |
| `oops` | Os óculos escorregam e ele abre a boca: “ué?” |

As poses são estudos visuais. Janitor continua sendo scanner read-only; use dados reais para conectar estados operacionais.

## Rig

`creature` gira em `245, 415`. `head` gira em `245, 247`. `glasses` se move e gira em `244, 184`; armação e reflexos estão separados. Corpo em H, duas fitas, cabeça, olhos, pupilas individuais, bocas, pés, sombra e partículas também têm grupos próprios.

O corpo mantém as coordenadas originais do brandkit dentro de `translate(110 140) scale(0.56) translate(-390 -270)`. A cabeça preserva o desenho anterior dentro de `translate(120 65) scale(0.51)`.

Controle SVG inline com `data-state` e `data-motion="on|off"`. Ao repetir instâncias no mesmo DOM, prefixe IDs, referências `href`, `url(#...)` e ARIA. Em `<img>`, cada documento é isolado.

## Reexportar no checkout do Orchestra

Com as dependências do repositório e o Chromium do Playwright instalados, execute em `artifacts/janitor-fiapo-hugr`:

```sh
bun run build.mjs
```

O script gera poses, PNGs, ícone, avatar e pranchas e atualiza o SVG entre `<!--FIAPO-HUGR:START-->` e `<!--FIAPO-HUGR:END-->` no preview. Edite o master para mudar o personagem.
