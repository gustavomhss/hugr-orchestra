# Fiapo — Janitor, direção 02

**Nome de trabalho.** Um fiapo de poeira ganhou pernas e decidiu trabalhar no Janitor. A graça está na contradição: a poeira virou o zelador.

![Fiapo: conceito e expressões.](concept-board-dark.png)

## Desenho

Silhueta irregular, três pontas tortas, pernas minúsculas, olhos desencontrados e um único dente. Desenho flat, com formas grandes e poucos detalhes. A expressão padrão mistura satisfação com absoluta falta de contexto.

Sapphire `#A3BFDA` vem dos tokens do HuGR Design System em `~/Documents/HuGR/HuGR brand kit/tokens.css`. Navy `#0B1423`, gelo `#DCEEFF` e branco vêm do HuGR Brand Kit v1.0. O personagem é original; as referências de simplicidade e humor são os mascotes citados pelo usuário.

## Arquivos

- Abra `preview.html` diretamente no navegador para alternar expressões, animação e fundo. O SVG principal está inline, e o preview respeita movimento reduzido.
- `fiapo.svg`: master vetorial com grupos nomeados.
- `exports/fiapo-{idle,scan,shake,done,oops}.svg`: poses estáticas.
- `exports/fiapo-*-animated.svg`: versões com animação CSS e `prefers-reduced-motion`.
- PNGs correspondentes: 1024 × 1024, fundo transparente.
- `exports/fiapo-icon.svg` e `.png`: silhueta sem pernas, para uso compacto. O preview mostra 24, 32, 48 e 64 px.
- `concept-board-dark.png` e `concept-board-light.png`: pranchas para compartilhar.

## Expressões

| Estado | Personalidade | Movimento |
| --- | --- | --- |
| `idle` | Um olho trabalha; o outro está de folga | Balanço leve, piscada |
| `scan` | Procura coisas em duas direções | Pupilas com tempos diferentes |
| `shake` | Ele mesmo é o espanador | Sacudida curta, seguida de pausa |
| `done` | Fez uma coisa e virou herói | Sorriso orgulhoso, balanço |
| `oops` | “Isso tava aí antes?” | Boca aberta, inclinação curiosa |

As poses são estudos de personagem. Janitor permanece um scanner read-only; a sacudida é metáfora visual. Na integração, os estados operacionais devem vir de dados reais.

## Rig

Todos os grupos têm `id` e `data-part`. O grupo `creature` gira em `245, 360`; `eyes-open` pisca em `237, 225`. `foot-left` e `foot-right` giram em `205, 348` e `269, 352`. Corpo, pés, pupilas individuais, pálpebra, olhos fechados, bocas, sombra e partículas ficam separados.

Altere `data-state` e `data-motion="on|off"` na raiz para controlar um SVG inline. Prefixe IDs e referências ARIA ao montar várias instâncias no mesmo DOM; em `<img>`, os documentos ficam separados. Os movimentos são CSS dentro do SVG.

## Reexportar no checkout do Orchestra

Com as dependências do repositório e o Chromium do Playwright instalados, execute em `artifacts/janitor-fiapo`:

```sh
bun run build.mjs
```

O script gera as poses, PNGs e pranchas e atualiza o SVG entre `<!--FIAPO:START-->` e `<!--FIAPO:END-->` no preview. Edite o master para mudar o personagem.
