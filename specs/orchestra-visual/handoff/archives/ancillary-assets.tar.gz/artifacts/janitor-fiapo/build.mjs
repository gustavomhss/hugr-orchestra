import path from "node:path"
import { createRequire } from "node:module"
import { pathToFileURL } from "node:url"

const { chromium } = await import(
  createRequire(new URL("../../packages/app/package.json", import.meta.url)).resolve("@playwright/test")
)
const browser = await chromium.launch({ headless: true })
const context = await browser.newContext({ viewport: { width: 1024, height: 1024 }, reducedMotion: "reduce" })
const source = await Bun.file(new URL("./fiapo.svg", import.meta.url)).text()
const states = ["idle", "scan", "shake", "done", "oops"]
const descriptions = {
  idle: ["Existindo", "Fiapo distraído, com um olho meio fechado, pernas minúsculas e um único dentinho."],
  scan: ["Caçando bug", "Fiapo procurando com os olhos em duas direções diferentes."],
  shake: ["Espana-espana", "Fiapo inclinado, sacudindo a si mesmo e pequenas partículas de poeira."],
  done: ["Se achando", "Fiapo sorrindo de olhos fechados e exibindo seu único dentinho, todo orgulhoso."],
  oops: ["Ué?", "Fiapo com boca aberta, olhos desencontrados e expressão de surpresa."],
  icon: ["Ícone", "Silhueta irregular azul-acinzentada de Fiapo, com olhos desencontrados e um dentinho."],
}
const variants = [
  ...states.flatMap((state) => [{ state, motion: false }, { state, motion: true }]),
  { state: "icon", motion: false },
]
await Promise.all(variants.map(async (variant) => {
  const page = await context.newPage()
  const markup = await page.evaluate((input) => {
    const xml = new DOMParser().parseFromString(input.source, "image/svg+xml")
    if (xml.querySelector("parsererror")) throw new Error("The mascot master is not valid SVG XML")
    const svg = xml.documentElement
    svg.setAttribute("data-state", input.variant.state === "icon" ? "idle" : input.variant.state)
    svg.setAttribute("data-motion", input.variant.motion ? "on" : "off")
    svg.setAttribute("width", "1024")
    svg.setAttribute("height", "1024")
    svg.querySelector("title").textContent = `Fiapo — ${input.description[0]}`
    svg.querySelector("desc").textContent = input.description[1]
    if (input.variant.state === "icon") {
      svg.setAttribute("viewBox", "100 95 285 285")
      svg.querySelectorAll('[data-part="feet"], [data-part="shadow"], [data-part="dust"]').forEach((part) => part.setAttribute("style", "display: none"))
    }
    return new XMLSerializer().serializeToString(svg)
  }, { source, variant, description: descriptions[variant.state] })
  await Bun.write(path.join(import.meta.dir, "exports", `fiapo-${variant.state}${variant.motion ? "-animated" : ""}.svg`), markup)
  if (!variant.motion) {
    await page.setContent(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><style>html,body{margin:0;background:transparent}svg{display:block;width:1024px;height:1024px}</style></head><body>${markup}</body></html>`)
    await page.locator("svg").screenshot({ path: path.join(import.meta.dir, "exports", `fiapo-${variant.state}.png`), omitBackground: true })
  }
  await page.close()
}))

const preview = await Bun.file(new URL("./preview.html", import.meta.url)).text()
const start = preview.indexOf("<!--FIAPO:START-->")
const end = preview.indexOf("<!--FIAPO:END-->")
if (start < 0 || end <= start) throw new Error("The preview is missing its generated SVG delimiters")
await Bun.write(new URL("./preview.html", import.meta.url), `${preview.slice(0, start)}<!--FIAPO:START-->\n${source}\n            ${preview.slice(end)}`)
const page = await context.newPage()
await page.setViewportSize({ width: 1160, height: 1050 })
await page.goto(pathToFileURL(path.join(import.meta.dir, "preview.html")).href)
await page.evaluate(async () => { await Promise.all(Array.from(document.images, (image) => image.decode())); await document.fonts.ready })
await page.locator(".presentation").screenshot({ path: path.join(import.meta.dir, "concept-board-dark.png") })
await page.locator("#theme").click()
await page.locator(".presentation").screenshot({ path: path.join(import.meta.dir, "concept-board-light.png") })
await browser.close()
console.log("Fiapo exported: vector poses, transparent PNGs, icon and concept boards.")
