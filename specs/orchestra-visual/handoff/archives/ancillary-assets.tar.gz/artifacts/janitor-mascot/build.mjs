import path from "node:path"
import { createRequire } from "node:module"
import { pathToFileURL } from "node:url"

// Reuse the repository's installed browser tooling; the mascot has no runtime dependencies.
const { chromium } = await import(
  createRequire(new URL("../../packages/app/package.json", import.meta.url)).resolve("@playwright/test")
)
const browser = await chromium.launch({ headless: true })
const context = await browser.newContext({ viewport: { width: 1024, height: 1024 }, reducedMotion: "reduce" })
const page = await context.newPage()
const source = await Bun.file(new URL("./zelo.svg", import.meta.url)).text()
const states = [
  {
    state: "idle",
    title: "Zelo — disponível",
    description:
      "Zelador de rosto azul-gelo, boné azul torto, macacão navy e vassourinha apoiada ao lado. Expressão tranquila e meio-sorriso.",
  },
  {
    state: "scan",
    title: "Zelo — inspecionando",
    description: "Zelo observando com uma lupa, cabeça levemente inclinada e olhar atento.",
  },
  {
    state: "sweep",
    title: "Zelo — varrendo",
    description:
      "Zelo inclinado em um pequeno gesto com a vassourinha e três grãos de poeira. Metáfora visual de cuidado.",
  },
  {
    state: "done",
    title: "Zelo — concluído",
    description: "Zelo sorrindo de olhos fechados e levantando a mão em um aceno curto.",
  },
  {
    state: "attention",
    title: "Zelo — atenção",
    description: "Zelo com sobrancelha levantada, lupa abaixada e uma interrogação discreta ao lado.",
  },
]
const variants = [
  ...states.flatMap((state) => [
    { ...state, motion: false },
    { ...state, motion: true },
  ]),
  {
    state: "avatar",
    motion: false,
    title: "Zelo — avatar do Janitor",
    description: "Rosto azul-gelo, boné azul torto e meio-sorriso do mascote Zelo.",
  },
]

await Promise.all(
  variants.map(async (variant) => {
    const svg = await context.newPage()
    const markup = await svg.evaluate(
      (input) => {
        const xml = new DOMParser().parseFromString(input.source, "image/svg+xml")
        if (xml.querySelector("parsererror")) throw new Error("The mascot master is not valid SVG XML")
        const root = xml.documentElement
        root.setAttribute("data-state", input.variant.state === "avatar" ? "idle" : input.variant.state)
        root.setAttribute("data-motion", input.variant.motion ? "on" : "off")
        root.setAttribute("width", "1024")
        root.setAttribute("height", "1024")
        root.querySelector("title").textContent = input.variant.title
        root.querySelector("desc").textContent = input.variant.description
        if (input.variant.state === "avatar") {
          root.setAttribute("viewBox", "152 92 184 184")
          root
            .querySelectorAll(
              '[data-part="ground"], [data-part="feet"], [data-part="body"], [data-part^="arm-"], [data-part="dust"], [data-part="signal"]',
            )
            .forEach((part) => part.setAttribute("style", "display: none"))
        }
        return new XMLSerializer().serializeToString(root)
      },
      { source, variant },
    )
    await Bun.write(
      path.join(import.meta.dir, "exports", `zelo-${variant.state}${variant.motion ? "-animated" : ""}.svg`),
      markup,
    )
    if (!variant.motion) {
      await svg.setContent(
        `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><style>html,body{margin:0;background:transparent}svg{display:block;width:1024px;height:1024px}</style></head><body>${markup}</body></html>`,
      )
      await svg.locator("svg").screenshot({
        path: path.join(import.meta.dir, "exports", `zelo-${variant.state}.png`),
        omitBackground: true,
      })
    }
    await svg.close()
  }),
)

const preview = await Bun.file(new URL("./preview.html", import.meta.url)).text()
const start = preview.indexOf("<!--ZELO:START-->")
const end = preview.indexOf("<!--ZELO:END-->")
if (start < 0 || end <= start) throw new Error("The preview is missing its generated SVG delimiters")
await Bun.write(
  new URL("./preview.html", import.meta.url),
  `${preview.slice(0, start)}<!--ZELO:START-->\n${source}\n              ${preview.slice(end)}`,
)

await page.setViewportSize({ width: 1240, height: 1140 })
await page.goto(pathToFileURL(path.join(import.meta.dir, "preview.html")).href)
await page.evaluate(async () => {
  await Promise.all(Array.from(document.images, (image) => image.decode()))
  await document.fonts.ready
})
await page.locator(".presentation").screenshot({ path: path.join(import.meta.dir, "concept-board-dark.png") })
await page.locator("#theme-toggle").click()
await page.locator(".presentation").screenshot({ path: path.join(import.meta.dir, "concept-board-light.png") })
await browser.close()
console.log("Mascot SVGs, transparent PNGs and concept boards exported to artifacts/janitor-mascot.")
