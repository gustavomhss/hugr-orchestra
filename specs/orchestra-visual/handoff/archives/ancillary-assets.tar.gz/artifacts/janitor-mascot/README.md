# Zelo — mascote do Janitor

Proposta de personagem para HuGR Orchestra. **Zelo** é um nome de trabalho: cuidado, presença e humor discreto.

![Zelo: estudo do personagem em fundo escuro.](concept-board-dark.png)

## Direção visual

Um pequeno zelador de oficina, com formas macias e postura tranquila. O boné ligeiramente torto e o meio-sorriso dão atitude; a lupa e a vassourinha explicam seu papel. O personagem tem rosto orgânico, mãos simples e macacão navy. A marca aparece como um pequeno patch, usando a geometria original do símbolo HuGR.

O desenho usa navy `#0B1423`, slate `#223A5B`, azul `#1266F6`, gelo `#DCEEFF` e branco do **HuGR Brand Kit v1.0** encontrado em `~/Downloads/HuGR-Brand-Kit-v1.0`. O azul concentra-se no boné, na gola e no detalhe da ferramenta. As superfícies do preview seguem o grafite frio do handoff Orchestra encontrado em `~/Downloads/orchestra_handoff_v1`.

## Abrir e usar

- Abra [`preview.html`](preview.html) no navegador. Funciona por arquivo local, sem servidor ou acesso à rede. Os botões alternam poses, animação e fundo. O personagem principal é SVG inline; o bloco entre `<!--ZELO:START-->` e `<!--ZELO:END-->` é regenerado pelo script de exportação a partir do master.
- [`zelo.svg`](zelo.svg) é o master vetorial editável. Tem grupos nomeados, gradientes vetoriais e expressões separadas.
- `exports/zelo-{idle,scan,sweep,done,attention}.svg` são poses estáticas. Os PNGs correspondentes têm fundo transparente e resolução de 1024 × 1024.
- `exports/zelo-*-animated.svg` são as mesmas poses com motion CSS. Funcionam também em `<img>` e respeitam `prefers-reduced-motion`.
- [`exports/zelo-avatar.svg`](exports/zelo-avatar.svg) e o PNG correspondente recortam o rosto para usos pequenos. O preview mostra 32, 48 e 64 px; para botões menores, prefira o ícone de interface.
- `concept-board-dark.png` e `concept-board-light.png` são pranchas prontas para compartilhar.

```html
<img src="/brand/janitor/zelo-scan-animated.svg"
     width="96" height="96"
     alt="Janitor inspecionando o workspace">
```

## Poses e significado

| Arquivo / `data-state` | Intenção | Movimento |
| --- | --- | --- |
| `idle` | Disponível e atento | Respiração pequena, piscada espaçada |
| `scan` | Inspeção em andamento | Lupa e inclinação leve de cabeça |
| `sweep` | Metáfora de cuidado | Vassourinha, gesto curto, três grãos de poeira |
| `done` | Conclusão real de uma tarefa | Sorriso de olhos fechados e aceno |
| `attention` | Algo precisa de uma olhada | Sobrancelha levantada, lupa baixa, pausa curiosa |

O handoff descreve Janitor como scanner **read-only**. A pose com vassoura é uma metáfora visual. Este pacote cria arte e demonstra movimento; a integração deve conectar inspeção, conclusão e atenção aos estados reais do Janitor, sem inventar resultados ou operações de limpeza.

## Rig de animação

As coordenadas abaixo usam o sistema original do master, antes do recorte `viewBox="80 56 352 352"`.

| Grupo / `data-part` | Pivô em unidades SVG | Uso |
| --- | --- | --- |
| `character` | `240, 390` | Corpo completo; respiração e inclinação |
| `head` | `238, 249` | Cabeça, boné e rosto |
| `eyes-open` | `234, 192` | Piscada por escala vertical |
| `pupils` | — | Direção do olhar |
| `brow-right` | `259, 172` | Curiosidade e atenção |
| `arm-right-broom` | `287, 255` | Braço, mão e vassoura como uma cadeia |
| `arm-right-scan` | `286, 256` | Braço, mão e lupa como uma cadeia |
| `arm-left-wave` | `186, 254` | Aceno discreto |

`cap`, `body`, `feet`, `broom`, `loupe`, `mouth-smile`, `mouth-attention`, `eyes-happy`, `brand-patch`, `ground`, `signal` e `dust` também ficam separados. O SVG pode ser importado em editores vetoriais; a organização exata das camadas depende do importador. Os movimentos entregues são CSS dentro do SVG, não arquivos de After Effects ou Lottie.

Para SVG inline, altere `data-state` e `data-motion="on|off"` na raiz. Para várias instâncias inline no mesmo DOM, prefixe os IDs e suas referências `url(#...)`/ARIA. Em `<img>`, cada SVG tem seu próprio documento.

## Reexportar no repositório

Com as dependências do repositório e o Chromium do Playwright instalados, execute em `artifacts/janitor-mascot` dentro do checkout do Orchestra:

```sh
bun run build.mjs
```

O script reutiliza o Playwright instalado em `packages/app`, lê o master e reexporta todas as poses, PNGs e pranchas. O preview é HTML local; nenhuma dependência entra no runtime do produto.
