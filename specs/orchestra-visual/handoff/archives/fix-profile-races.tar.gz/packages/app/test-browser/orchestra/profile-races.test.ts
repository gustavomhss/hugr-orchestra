import { afterEach, describe, expect, test } from "bun:test"
import { stat } from "node:fs/promises"
import { fileURLToPath } from "node:url"
import { makeEventListener } from "@solid-primitives/event-listener"
import {
  createComponent,
  createContext,
  createEffect,
  createMemo,
  createRoot,
  createSignal,
  getOwner,
  onCleanup,
  runWithOwner,
  Show,
  startTransition,
  useContext,
  type JSX,
  type Owner,
} from "solid-js"
import { createStore } from "solid-js/store"
import ts from "typescript"
import { pathKey } from "../../src/utils/path-key"

// Execute private production callbacks without rendering the unrelated sidebar chrome.
// The real Dialog stack runs too; only its Kobalte/portal JSX is replaced by element().
const sidebar = await source("../../src/orchestra/sidebar.tsx")
const dialogSource = await source("../../../ui/src/context/dialog.tsx")
const homeSource = await source("../../src/pages/home/home-controller.ts")
const helpers = await source("../../src/pages/layout/helpers.ts")
const transpiler = new Bun.Transpiler({ loader: "ts" })
const disposers: (() => void)[] = []
const repository = fileURLToPath(new URL("../../../../", import.meta.url)).replace(/\/$/, "")

afterEach(() =>
  disposers
    .splice(0)
    .reverse()
    .forEach((dispose) => dispose()),
)

async function source(relative: string) {
  return ts.createSourceFile(
    relative,
    await Bun.file(new URL(relative, import.meta.url)).text(),
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TSX,
  )
}

function find<T extends ts.Node>(root: ts.Node, matches: (node: ts.Node) => node is T): T {
  const found: T[] = []
  const visit = (node: ts.Node) => {
    if (matches(node)) found.push(node)
    ts.forEachChild(node, visit)
  }
  visit(root)
  if (found.length !== 1) throw new Error(`Expected one source node, found ${found.length}`)
  return found[0]
}

function functionSource(source: ts.SourceFile, name: string) {
  const node = find(
    source,
    (node): node is ts.FunctionDeclaration => ts.isFunctionDeclaration(node) && node.name?.text === name,
  )
  if (!node.body) throw new Error(`Missing body: ${name}`)
  const async = node.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ? "async " : ""
  return `${async}function ${name}(${node.parameters.map((parameter) => parameter.getText(source)).join(",")}) ${node.body.getText(source)}`
}

function evaluate<T>(code: string, bindings: Record<string, unknown>): T {
  return new Function(...Object.keys(bindings), transpiler.transformSync(code))(...Object.values(bindings)) as T
}

function launcherAttribute(name: string) {
  const launcher = find(
    sidebar,
    (node): node is ts.JsxSelfClosingElement =>
      ts.isJsxSelfClosingElement(node) && node.tagName.getText(sidebar) === "SettingsLauncher",
  )
  const attribute = launcher.attributes.properties.find(
    (attribute) => ts.isJsxAttribute(attribute) && attribute.name.getText(sidebar) === name,
  )
  if (
    !attribute ||
    !ts.isJsxAttribute(attribute) ||
    !attribute.initializer ||
    !ts.isJsxExpression(attribute.initializer) ||
    !attribute.initializer.expression
  )
    throw new Error(`Missing SettingsLauncher expression: ${name}`)
  return attribute.initializer.expression.getText(sidebar)
}

type Connection = { id: string }
type Project = { id: string; worktree: string }
type Selection = { server: string; directory?: string }
type Controls = {
  chooseProject: (conn: Connection, draft?: boolean) => void
  selectProject: (conn: Connection, project: Project, draft?: boolean) => Promise<void>
}

function pickerProbe() {
  return createRoot((dispose) => {
    disposers.push(dispose)
    const [state, setState] = createStore({
      epoch: 0,
      target: { server: "A", directory: "/opening" },
      selection: { server: "A", directory: "/opening" } as Selection,
    })
    const connections = [{ id: "A" }, { id: "B" }]
    const project = { id: "actual-repository", worktree: repository }
    const mutations: { action: string; server: string; directory?: string }[] = []
    const pickers: { server: Connection; onSelect: (result: string | string[] | null) => void }[] = []
    const hooks = { selection: undefined as (() => void) | undefined }
    const route = createMemo(() => {
      state.epoch
      return { type: "dir-new-sesssion", dir: "/opening" }
    })
    const profile = createMemo(() => ({ ...state.target }))
    const layout = {
      route,
      home: {
        selection: () => state.selection,
        setSelection: (selection: Selection) => {
          mutations.push({ action: "selection", ...selection })
          setState("selection", selection)
          hooks.selection?.()
        },
      },
    }
    const contexts = connections.map((conn) => ({
      projects: {
        list: () => [project],
        recentlyClosed: () => [],
        last: () => project.worktree,
        open: (directory: string) => mutations.push({ action: "open", server: conn.id, directory }),
        touch: (directory: string) => mutations.push({ action: "touch", server: conn.id, directory }),
      },
      sync: { data: { path: { home: "/" } }, session: { peek: () => undefined } },
    }))
    const global = {
      servers: { list: () => connections, health: {} },
      ensureServerCtx: (conn: Connection) => contexts[connections.indexOf(conn)],
    }
    const tabs = {
      store: [],
      info: {},
      newDraft: (selection: Selection) => mutations.push({ action: "draft", ...selection }),
    }
    const ServerConnection = { key: (conn: Connection) => conn.id }
    const home = evaluate<{
      project: {
        add: (conn: Connection, directories: string[]) => void
        openProjectNewSession: (conn: Connection, directory: string) => void
      }
    }>(`${functionSource(homeSource, "createHomeController")} return createHomeController()`, {
      createEffect,
      createMemo,
      useGlobal: () => global,
      useLayout: () => layout,
      useServer: () => ({ key: "A", current: connections[0] }),
      useServerSync: () => () => contexts[0].sync,
      useTabs: () => tabs,
      ServerConnection,
    })
    const request = find(
      sidebar,
      (node): node is ts.VariableDeclaration =>
        ts.isVariableDeclaration(node) && node.name.getText(sidebar) === "requests",
    )
    const cleanup = find(
      find(
        sidebar,
        (node): node is ts.FunctionDeclaration =>
          ts.isFunctionDeclaration(node) && node.name?.text === "OrchestraSidebar",
      ),
      (node): node is ts.CallExpression =>
        ts.isCallExpression(node) && node.expression.getText(sidebar) === "onCleanup",
    )
    const controls = evaluate<Controls>(
      `const ${request.getText(sidebar)}; ${cleanup.getText(sidebar)}; ${["projectTab", "selectProject", "chooseProject"].map((name) => functionSource(sidebar, name)).join("\n")} return { chooseProject, selectProject }`,
      {
        global,
        layout,
        profile,
        home,
        tabs,
        ServerConnection,
        pathKey,
        onCleanup,
        pickDirectory: (input: (typeof pickers)[number]) => pickers.push(input),
        setState: () => undefined,
        language: { t: (key: string) => key },
        homeProjectDirectories: evaluate<(result: string | string[] | null) => string[]>(
          `${functionSource(helpers, "homeProjectDirectories")} return homeProjectDirectories`,
          {},
        ),
      },
    )
    return { ...controls, state, setState, route, connections, project, mutations, pickers, hooks, dispose }
  })
}

type Active = { owner: Owner }
type Stack = { stack: () => Active[] }
type Dialog = {
  active?: Active
  show: (content: () => JSX.Element, onClose?: () => void) => Promise<void>
  push: (content: () => JSX.Element, onClose?: () => void) => Promise<void>
}

function settingsProbe() {
  return createRoot((dispose) => {
    disposers.push(dispose)
    const [state, setState] = createStore({
      path: "/A",
      server: "A",
      directory: "/A",
      pulse: 0,
      settings: undefined as (() => JSX.Element) | undefined,
    })
    const observations = { live: 0, reads: 0 }
    const route = createMemo(() => ({ type: "dir-new-sesssion", dir: state.path }))
    const profile = () => ({ server: state.server, directory: state.directory })
    const valid = evaluate<() => boolean>(`return () => (${launcherAttribute("valid")})`, {
      layout: { route },
      profile,
      route: route(),
      target: profile(),
    })
    const Context = createContext<Stack>()
    const init = find(
      dialogSource,
      (node): node is ts.FunctionDeclaration => ts.isFunctionDeclaration(node) && node.name?.text === "init",
    )
    const transformed = ts.transform(init, [
      (context) => (root) => {
        const visit = (node: ts.Node): ts.VisitResult<ts.Node> =>
          ts.isJsxElement(node)
            ? ts.factory.createCallExpression(ts.factory.createIdentifier("element"), undefined, [])
            : ts.visitEachChild(node, visit, context)
        return ts.visitNode(root, visit) as ts.FunctionDeclaration
      },
    ])
    const dialogs = evaluate<{ init: () => Stack; useDialog: () => Dialog }>(
      `${ts.createPrinter().printNode(ts.EmitHint.Unspecified, transformed.transformed[0], dialogSource)} ${functionSource(dialogSource, "useDialog")} return { init, useDialog }`,
      {
        Context,
        createSignal,
        createEffect,
        createRoot,
        getOwner,
        onCleanup,
        runWithOwner,
        startTransition,
        useContext,
        makeEventListener,
      },
    )
    transformed.dispose()
    const stack = dialogs.init()
    const Launcher = evaluate<
      (props: { valid: boolean; content: () => JSX.Element; onClose: () => void }) => JSX.Element
    >(`${functionSource(sidebar, "SettingsLauncher")} return SettingsLauncher`, {
      createEffect,
      createRoot,
      getOwner,
      onCleanup,
      useDialog: dialogs.useDialog,
    })
    const handle = { dialog: undefined as Dialog | undefined }
    const content = () => {
      observations.live++
      handle.dialog = dialogs.useDialog()
      createEffect(() => {
        state.pulse
        observations.reads++
      })
      onCleanup(() => observations.live--)
      return null
    }
    createComponent(Context.Provider, {
      value: stack,
      get children() {
        const launch = () =>
          createComponent(Launcher, {
            get valid() {
              return valid()
            },
            content,
            onClose: () => close(),
          })
        const close = evaluate<() => void>(`return (${launcherAttribute("onClose")})`, { state, setState, launch })
        setState("settings", () => launch)
        return createComponent(Show, {
          get when() {
            return state.settings
          },
          keyed: true,
          children: (launch: () => JSX.Element) => launch(),
        })
      },
    })
    return { state, setState, stack, handle, content, observations }
  })
}

describe("Orchestra profile request lifetime", () => {
  test("browser route identity changes reject an old picker even with equal route fields", async () => {
    const probe = pickerProbe()
    probe.chooseProject(probe.connections[0])
    const opening = probe.route()
    probe.setState("epoch", 1)
    expect(probe.route()).not.toBe(opening)
    expect(probe.route()).toEqual(opening)
    probe.pickers[0].onSelect(repository)
    await Bun.sleep(0)
    expect(probe.mutations).toEqual([])
    expect(probe.state.selection.directory).toBe("/opening")
  })

  test.each(["server", "directory"] as const)("same-route %s changes reject an old picker", async (field) => {
    const probe = pickerProbe()
    probe.chooseProject(probe.connections[0])
    const opening = probe.route()
    probe.setState("target", field, field === "server" ? "B" : "/B")
    expect(probe.route()).toBe(opening)
    probe.pickers[0].onSelect(repository)
    await Bun.sleep(0)
    expect(probe.mutations).toEqual([])
  })

  test("new picker rejects previous callback; current picker opens the actual repository on its chosen server", async () => {
    const checkout = await stat(new URL("../../../../.git", import.meta.url))
    expect(checkout.isFile() || checkout.isDirectory()).toBe(true)
    const probe = pickerProbe()
    probe.chooseProject(probe.connections[0])
    probe.chooseProject(probe.connections[1])
    probe.pickers[0].onSelect(repository)
    expect(probe.mutations).toEqual([])
    probe.pickers[1].onSelect([repository])
    await Bun.sleep(0)
    expect(probe.state.selection).toEqual({ server: "B", directory: repository })
    expect(probe.mutations.filter((mutation) => mutation.action === "draft")).toEqual([
      { action: "draft", server: "B", directory: repository },
    ])
    expect(probe.mutations.every((mutation) => mutation.server === "B")).toBe(true)
  })

  test("project navigation invalidates a pending picker before it can mutate state", async () => {
    const probe = pickerProbe()
    probe.chooseProject(probe.connections[0])
    await probe.selectProject(probe.connections[1], probe.project)
    const before = probe.mutations.slice()
    probe.pickers[0].onSelect(repository)
    await Bun.sleep(0)
    expect(probe.mutations).toEqual(before)
  })

  test("new picker cancels a project navigation that has not finished resolving tabs", async () => {
    const probe = pickerProbe()
    const pending = probe.selectProject(probe.connections[0], probe.project)
    probe.chooseProject(probe.connections[1])
    await pending
    expect(probe.mutations.filter((mutation) => mutation.action === "draft")).toEqual([])
  })

  test("navigation triggered by project admission prevents the remaining selection step", async () => {
    const probe = pickerProbe()
    probe.chooseProject(probe.connections[1])
    probe.hooks.selection = () => probe.setState("epoch", 1)
    probe.pickers[0].onSelect(repository)
    await Bun.sleep(0)
    expect(probe.mutations.map((mutation) => mutation.action)).toEqual(["touch", "selection"])
  })

  test("disposed sidebar rejects native picker completion", async () => {
    const probe = pickerProbe()
    probe.chooseProject(probe.connections[0])
    probe.dispose()
    probe.pickers[0].onSelect(repository)
    await Bun.sleep(0)
    expect(probe.mutations).toEqual([])
  })
})

describe("Orchestra settings opening owner", () => {
  test.each(["path", "server", "directory"] as const)(
    "%s navigation synchronously invalidates launcher and drains every nested owner root",
    async (field) => {
      const probe = settingsProbe()
      await Bun.sleep(0)
      expect(probe.stack.stack()).toHaveLength(1)
      expect(probe.observations.live).toBe(1)
      const owner = probe.stack.stack()[0].owner
      const launch = probe.state.settings
      await probe.handle.dialog!.show(probe.content)
      expect(probe.state.settings).toBe(launch)
      await probe.handle.dialog!.push(probe.content)
      await probe.handle.dialog!.push(probe.content)
      expect(probe.stack.stack()).toHaveLength(3)
      expect(probe.stack.stack().every((active) => active.owner === owner)).toBe(true)
      expect(probe.observations.live).toBe(3)
      probe.setState(field, field === "server" ? "B" : "/B")
      expect(probe.state.settings).toBeUndefined()
      await new Promise<void>((resolve) => {
        createRoot((dispose) => {
          disposers.push(dispose)
          createEffect(() => {
            if (probe.stack.stack().length) return
            dispose()
            resolve()
          })
        })
      })
      expect(probe.stack.stack()).toHaveLength(0)
      expect(probe.observations.live).toBe(0)
      const reads = probe.observations.reads
      probe.setState("pulse", 1)
      expect(probe.observations.reads).toBe(reads)
    },
  )
})
