// Interactive preview only. These flows use profile-owned sample data and never
// run shell commands, contact providers, or change the real repository.
(() => {
  const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]))
  const paths = {
    mcp: '<path d="M5 2v3M11 2v3M3 5h10v3a5 5 0 0 1-10 0V5ZM8 13v2"/>',
    skills: '<path d="m8 1 2 5 5 2-5 2-2 5-2-5-5-2 5-2 2-5Z"/>',
    plugins: '<path d="M2 3h4a2 2 0 1 1 4 0h4v4a2 2 0 1 0 0 4v3h-4a2 2 0 1 0-4 0H2V3Z"/>',
    hooks: '<path d="M4 2v7a4 4 0 0 0 8 0V7M9 9l3-3 3 3"/><circle cx="4" cy="2" r="1"/>',
    providers: '<path d="M3 6a5 5 0 0 1 10 0M2 6h12v6H2V6ZM6 9h4"/>',
    shortcuts: '<rect x="1" y="3" width="14" height="10" rx="2"/><path d="M4 6h.1M7 6h.1M10 6h.1M12 6h.1M4 9h.1M7 9h5"/>',
    cicd: '<circle cx="3" cy="8" r="2"/><circle cx="13" cy="4" r="2"/><circle cx="13" cy="12" r="2"/><path d="M5 8h3V4h3M8 8v4h3"/>',
    schedule: '<circle cx="8" cy="8" r="6"/><path d="M8 4v4l3 2"/>',
    env: '<rect x="2" y="3" width="12" height="10" rx="2"/><path d="m5 6 2 2-2 2M9 10h2"/>',
    arrow: '<path d="m6 4 4 4-4 4"/>',
    plus: '<path d="M8 3v10M3 8h10"/>',
    check: '<path d="m3 8 3 3 7-7"/>',
    file: '<path d="M4 2h5l3 3v9H4V2ZM9 2v3h3M6 8h4M6 11h3"/>',
    close: '<path d="m4 4 8 8m0-8-8 8"/>',
    link: '<path d="m6 10 4-4M6 6 4 8a3 3 0 0 0 4 4l2-2M10 10l2-2a3 3 0 0 0-4-4L6 6"/>',
  }
  const icon = name => `<svg class="ic" viewBox="0 0 16 16" aria-hidden="true">${paths[name] || paths.file}</svg>`
  const brand = id => `<svg class="mx-brand" viewBox="0 0 24 24" aria-hidden="true"><use href="#session-logo-${Object.hasOwn(MODEL_LOGOS, id) ? id : "neutral"}" width="24" height="24"/></svg>`
  const titles = { mcp: "MCP", skills: "Skills", plugins: "LLM Plugins", hooks: "Hooks", cicd: "CI/CD", schedule: "Agendar", env: ".env", providers: "Providers", shortcuts: "Shortcuts" }
  // Chapters identify proposed Orchestra screens, not ownership of the underlying features.
  const orchestraChapters = {
    mcp: ["C01", "Página dedicada de gerenciamento MCP por perfil."],
    skills: ["C02", "Página dedicada de gerenciamento de Skills por perfil."],
    plugins: ["C03", "Página de comportamentos e instruções LLM por perfil."],
    hooks: ["C04", "Página de automações e eventos por perfil."],
    providers: ["C05", "Página dedicada por perfil; Providers já existe em Settings do OpenCode."],
    shortcuts: ["C06", "Página dedicada por perfil; Shortcuts já existe em Settings do OpenCode."],
    cicd: ["C07", "Página de pipelines, logs e deploys por perfil."],
    schedule: ["C08", "Página de agendamento de tarefas por perfil."],
    env: ["C09", "Editor dedicado de arquivos .env."],
    home: ["C10", "Dashboard de KPIs, impacto e gastos; não a Home original do OpenCode."],
    agents: ["C11", "Página dedicada de roster e configuração por perfil; agents não são novidade do Orchestra."],
    workspaces: ["C12", "Página dedicada de gerenciamento por perfil; workspaces não são novidade do Orchestra."],
    dock: ["C13", "Destino próprio na navegação; browser App Dock reaproveitado, não um browser novo."],
  }
  const descriptions = {
    mcp: "Connect tools and context to the agents in this profile.",
    skills: "Focused instructions, available when an agent needs them.",
    providers: "Choose how this profile reaches its models.",
    shortcuts: "Make the workspace feel like yours.",
    plugins: "Shape how the LLM thinks and speaks. Each profile has its own behavior.",
    hooks: "Small actions at the right moment. Before prompts, after tools, and when sessions finish.",
    cicd: "Build, check, test, and see the evidence. Pipelines belong to this profile.",
    schedule: "One-off work or a recurring rhythm. Choose the task, agent, and next run.",
    env: "Your project's environment keys. Open, edit, and download a .env file.",
  }
  const css = document.createElement("style")
  css.textContent = `
    :root{--mx-line:rgba(166,189,211,.14);--mx-soft:rgba(170,196,220,.055);--mx-raised:rgba(19,28,38,.55);--mx-modal:#111922;--mx-dim:#8d9cab;--mx-strong:#e1e9f0;--mx-blue:#9abfe5;--mx-good:#92bea7;--mx-bad:#d99a94;--mx-highlight:inset 0 1px 0 rgba(255,255,255,.035);--mx-shadow:0 30px 100px rgba(0,0,0,.36);--mx-pop-shadow:0 14px 35px rgba(0,0,0,.24);--mx-backdrop:rgba(3,9,16,.55);--mx-primary:linear-gradient(180deg,#3f7ebc,#326ba5);--mx-primary-text:#fff;--mx-enabled:rgba(84,135,178,.22)}
    [data-scheme="light"]{--mx-line:rgba(65,86,107,.14);--mx-soft:rgba(60,87,118,.045);--mx-raised:rgba(255,255,255,.63);--mx-modal:#f8fafc;--mx-dim:#697586;--mx-strong:#263341;--mx-blue:#376ea5;--mx-good:#3d7e5e;--mx-bad:#a75249;--mx-highlight:inset 0 1px 0 rgba(255,255,255,.7);--mx-shadow:0 30px 100px rgba(28,46,65,.2);--mx-pop-shadow:0 14px 35px rgba(28,46,65,.16);--mx-backdrop:rgba(28,43,59,.3);--mx-primary:linear-gradient(180deg,#3f7ebc,#326ba5);--mx-primary-text:#fff;--mx-enabled:rgba(84,135,178,.16)}
    .mx-page .inner{width:calc(100% - 64px);max-width:1080px;padding:40px 0 48px}
    .mx-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;margin-bottom:28px}
    .mx-eyebrow{color:var(--mx-dim);font-size:10px;letter-spacing:.12em;text-transform:uppercase;margin-bottom:8px}
    .mx-heading h1{margin:0;color:var(--mx-strong);font-size:30px;letter-spacing:-.035em;font-weight:590;line-height:1.2}
    .mx-heading p{margin:9px 0 0;max-width:540px;color:var(--mx-dim);font-size:13px;line-height:1.6}
    .mx-toolbar{display:flex;align-items:center;gap:10px;margin:0 0 18px}
    .mx-search{min-width:0;flex:1;max-width:360px;height:34px;padding:0 11px;border:1px solid var(--mx-line);border-radius:8px;background:var(--mx-raised);color:var(--mx-strong);font:inherit;font-size:12px;outline:none}
    .mx-search:focus{outline:1px solid var(--mx-blue);outline-offset:1px}
    .mx-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px}
    .mx-card{display:flex;flex-direction:column;min-width:0;padding:18px;border:1px solid var(--mx-line);border-radius:11px;background:var(--mx-raised);box-shadow:var(--mx-highlight)}
    .mx-card-top{display:flex;align-items:center;gap:10px;min-height:32px}
    .mx-mark{display:grid;width:32px;height:32px;flex:none;place-items:center;border:1px solid var(--mx-line);border-radius:8px;background:var(--mx-soft);color:var(--mx-blue)}
    .mx-brand{width:22px;height:22px;display:block}
    .mx-card h3{font-size:14px;letter-spacing:-.015em;margin:0;color:var(--mx-strong);font-weight:580}
    .mx-card p{margin:12px 0;color:var(--mx-dim);font-size:12px;line-height:1.65}
    .mx-meta{display:flex;flex-wrap:wrap;gap:7px;align-items:center;color:var(--mx-dim);font:10px ui-monospace,SFMono-Regular,Menlo,monospace}
    .mx-badge{display:inline-flex;align-items:center;gap:5px;border:1px solid var(--mx-line);border-radius:5px;padding:2px 6px;color:var(--mx-dim);font:10px/15px ui-monospace,SFMono-Regular,Menlo,monospace}
    .mx-badge.good{color:var(--mx-good)}.mx-badge.bad{color:var(--mx-bad)}
    .mx-card>.mx-meta{margin-bottom:15px}
    .mx-card-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;padding-top:14px;margin-top:auto;border-top:1px solid var(--mx-line)}
    .mx-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:30px;padding:0 10px;border:1px solid var(--mx-line);border-radius:7px;background:var(--mx-soft);color:var(--mx-strong);font:inherit;font-size:11.5px;cursor:pointer;white-space:nowrap}
    .mx-btn:hover{background:var(--mx-raised);border-color:var(--mx-blue)}
    .mx-btn.primary{background:var(--mx-primary);color:var(--mx-primary-text);border-color:var(--mx-line)}
    .mx-btn.danger{color:var(--mx-bad)}.mx-btn:disabled{opacity:.4;cursor:default}
    .mx-link{padding:0;border:0;background:transparent;color:var(--mx-blue);font:inherit;font-size:11.5px;cursor:pointer}
    .mx-toggle{position:relative;width:32px;height:19px;flex:none;display:inline-block;border:1px solid var(--mx-line);border-radius:12px;background:var(--mx-soft);cursor:pointer}
    .mx-toggle:before{content:"";position:absolute;left:3px;top:3px;width:11px;height:11px;border-radius:50%;background:var(--mx-dim);transition:transform .14s ease}
    .mx-toggle[aria-checked="true"]{background:var(--mx-enabled);border-color:var(--mx-blue)}
    .mx-toggle[aria-checked="true"]:before{background:var(--mx-blue);transform:translateX(13px)}
    .mx-section{margin:26px 0 12px;font-size:12px;font-weight:550;color:var(--mx-strong)}
    .mx-table{border:1px solid var(--mx-line);border-radius:10px;overflow:hidden;background:var(--mx-raised)}
    .mx-row{display:flex;min-width:0;align-items:center;gap:14px;padding:12px 15px;border-top:1px solid var(--mx-line)}
    .mx-row:first-child{border-top:0}.mx-grow{min-width:0;flex:1}.mx-row strong{display:block;font-size:12px;color:var(--mx-strong);font-weight:550}
    .mx-row small{display:block;color:var(--mx-dim);font-size:11px;margin-top:4px;line-height:1.45}
    .mx-empty{padding:38px 20px;border:1px dashed var(--mx-line);border-radius:10px;text-align:center;color:var(--mx-dim);font-size:12px;line-height:1.7}
    .mx-note{margin:18px 0 0;color:var(--mx-dim);font-size:10.5px;line-height:1.6}
    .mx-dialog{width:min(680px,calc(100vw - 48px));max-height:calc(100vh - 64px);padding:0;border:1px solid var(--mx-line);border-radius:14px;background:var(--mx-modal);color:var(--mx-strong);box-shadow:var(--mx-shadow);overflow:hidden}
    .mx-dialog::backdrop{background:var(--mx-backdrop);backdrop-filter:blur(5px)}
    .mx-dialog form{display:flex;max-height:calc(100vh - 66px);flex-direction:column;margin:0}
    .mx-dialog-head{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;padding:22px 24px 18px;border-bottom:1px solid var(--mx-line)}
    .mx-dialog-head h2{margin:0;font-size:20px;font-weight:570;letter-spacing:-.025em}
    .mx-dialog-head p{margin:7px 0 0;font-size:12px;color:var(--mx-dim);line-height:1.6}
    .mx-dialog-body{padding:22px 24px;overflow:auto;min-height:0}
    .mx-dialog-foot{display:flex;justify-content:flex-end;gap:8px;padding:14px 24px;border-top:1px solid var(--mx-line)}
    .mx-fields{display:grid;grid-template-columns:1fr 1fr;gap:17px}.mx-field{display:flex;min-width:0;flex-direction:column;gap:7px;margin-bottom:16px}
    .mx-field>span{font-size:11.5px;color:var(--mx-dim)}
    .mx-field input,.mx-field select,.mx-field textarea{width:100%;min-width:0;height:35px;padding:7px 10px;border:1px solid var(--mx-line);border-radius:7px;background:var(--mx-raised);color:var(--mx-strong);outline:0;font-family:inherit;font-size:12px;line-height:1.5}
    .mx-field textarea{height:auto;min-height:120px;resize:vertical;font:11.5px/1.65 ui-monospace,SFMono-Regular,Menlo,monospace}
    .mx-field input:focus,.mx-field textarea:focus,.mx-field select:focus{border-color:var(--mx-blue)}
    .mx-field option{background:var(--mx-modal);color:var(--mx-strong)}
    .mx-error{margin:0 0 15px;color:var(--mx-bad);font-size:12px;line-height:1.5}
    .mx-menu{position:fixed;z-index:100;min-width:180px;padding:5px;border:1px solid var(--mx-line);border-radius:9px;background:var(--mx-modal);box-shadow:var(--mx-pop-shadow)}
    .mx-menu button{display:flex;width:100%;padding:8px 10px;border:0;border-radius:5px;background:transparent;color:var(--mx-strong);font-family:inherit;font-size:12px;text-align:left;cursor:pointer}
    .mx-menu button:hover{background:var(--mx-soft)}
    .mx-log{margin:14px 0 0;padding:12px;border:1px solid var(--mx-line);border-radius:8px;background:var(--mx-raised);color:var(--mx-dim);font:11px/1.7 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre-wrap}
    .mx-menu button.danger{color:var(--mx-bad)}
    .side{overflow:hidden}.side-brand{padding-bottom:16px;flex:none}.side-foot{padding-top:12px;flex:none}
    .mx-navigation{min-height:0;flex:1;overflow-y:auto;scrollbar-width:thin;scrollbar-color:var(--mx-line) transparent}
    .mx-navigation .side-nav button{height:31px;font-size:12.5px}.mx-navigation .side-nav{gap:1px}
    .mx-origin{display:inline-flex;align-items:center;gap:8px;width:fit-content;padding:4px 8px;border:1px solid var(--mx-line);border-radius:6px;background:var(--mx-soft);color:var(--warm);font:10px/16px ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:0;text-transform:none}
    .mx-origin-dot{width:5px;height:5px;flex:none;margin-left:auto;border-radius:50%;background:var(--warm)}
    .mx-origin-banner{margin-bottom:18px}
    .mx-origin-dock{display:flex;flex-direction:column}
    .mx-origin-dock>.mx-origin-banner{flex:none;align-self:flex-start;margin:10px 12px 4px}
    .mx-origin-dock>.dock-host{height:auto;flex:1;min-height:0}
  `
  document.head.append(css)

  const dialog = document.createElement("dialog")
  dialog.className = "mx-dialog"
  document.body.append(dialog)
  let submitDialog
  function modal(title, subtitle, body, save, label = "Save") {
    if (dialog.open) dialog.close()
    submitDialog = save
    dialog.innerHTML = `<form autocomplete="off"><header class="mx-dialog-head"><div><h2>${esc(title)}</h2><p>${esc(subtitle)}</p></div><button type="button" class="mx-link" data-mx-action="close-dialog" aria-label="Close dialog">${icon("close")}</button></header><div class="mx-dialog-body"><p class="mx-error" role="alert" hidden></p>${body}</div><footer class="mx-dialog-foot"><button type="button" class="mx-btn" data-mx-action="close-dialog">Cancel</button>${save ? `<button class="mx-btn primary" type="submit">${esc(label)}</button>` : ""}</footer></form>`
    dialog.showModal()
  }
  const formError = text => { const e = dialog.querySelector(".mx-error"); e.textContent = text; e.hidden = false }
  dialog.addEventListener("submit", e => {
    e.preventDefault()
    if (submitDialog?.(new FormData(e.target)) === false) return
    dialog.close()
  })
  dialog.addEventListener("click", e => {
    if (e.target !== dialog) return
    const r = dialog.getBoundingClientRect()
    if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close()
  })
  const field = (label, name, value = "", type = "text", required = true) => `<label class="mx-field"><span>${esc(label)}</span><input name="${name}" type="${type}" value="${esc(value)}"${required ? " required" : ""}></label>`
  const textarea = (label, name, value = "") => `<label class="mx-field"><span>${esc(label)}</span><textarea name="${name}">${esc(value)}</textarea></label>`
  const select = (label, name, value, options) => `<label class="mx-field"><span>${esc(label)}</span><select name="${name}">${options.map(o => { const pair = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(pair[0])}"${pair[0] === value ? " selected" : ""}>${esc(pair[1])}</option>` }).join("")}</select></label>`
  const button = (label, action, id = "", primary = false) => `<button class="mx-btn${primary ? " primary" : ""}" data-mx-action="${action}" data-id="${esc(id)}">${esc(label)}</button>`
  const toggle = (action, id, enabled, label) => `<button class="mx-toggle" role="switch" aria-checked="${enabled}" aria-label="${esc(label)}" data-mx-action="${action}" data-id="${esc(id)}"></button>`
  const badge = (text, kind = "") => `<span class="mx-badge ${kind}">${esc(text)}</span>`
  const modelOptions = () => MODELS.map(m => [m[0], m[1]])
  const providerCatalog = [
    { id: "opencode", name: "OpenCode", note: "Curated models including Claude, GPT, Gemini and more" },
    { id: "anthropic", name: "Anthropic", note: "Direct access to Claude models, including Pro and Max" },
    { id: "openai", name: "OpenAI", note: "GPT models for fast, capable general AI tasks" },
    { id: "openrouter", name: "OpenRouter", note: "Access all supported models from one provider" },
    { id: "google", name: "Google", note: "Gemini models for fast, structured responses" },
  ]
  const defaults = { "Command palette": "⌘K", "New session": "⌘N", "Choose model": "⌘⇧M", "Close tab": "⌘W", "Focus input": "⌘⇧F", "Cycle thinking effort": "⌘⇧E" }
  const storageKey = "orchestra-mock-complete-v1"
  const saved = localStorage.getItem(storageKey)
  let restored = {}
  if (saved) { try { restored = JSON.parse(saved) } catch {} }
  Object.values(PROFILES).forEach(p => {
    p.skills = [{ id: "review", name: "Code review", description: "Review the actual diff and explain the trade-offs.", instructions: "Read the diff. Check correctness, boundaries and evidence. Be specific.", enabled: true, source: "Project" }, { id: "docs", name: "Documentation", description: "Keep the written contract in step with the code.", instructions: "Document observed behavior, not intentions. Include examples.", enabled: p.id === "canonical", source: "Project" }]
    p.llmPlugins = [{ id: "caveman", name: "Caveman", description: "Technical substance stays. Fluff goes.", enabled: p.id === "canonical", intensity: "full", instructions: "Respond terse like smart caveman. Preserve technical accuracy." }]
    p.hooks = [{ id: "context", name: "Context reminder", event: "Before prompt", action: "Add instruction", value: "Read project instructions before making changes.", enabled: true, runs: 0 }, { id: "evidence", name: "Evidence note", event: "After tool", action: "Record event", value: "Record tool results in the session.", enabled: p.id === "canonical", runs: 0 }]
    p.mcpServers = p.id === "canonical" ? [{ id: "filesystem", name: "Filesystem", transport: "stdio", endpoint: "bunx @modelcontextprotocol/server-filesystem .", enabled: true, status: "Connected", tools: ["read_file", "list_directory", "search_files"] }, { id: "docs", name: "Documentation", transport: "http", endpoint: "https://mcp.example.test/docs", enabled: true, status: "Connected", tools: ["search_docs", "read_page"] }] : []
    p.providers = providerCatalog.filter(c => ["opencode", "anthropic", p.id === "canonical" ? "openai" : "openrouter"].includes(c.id)).map(c => ({ ...c, status: "Connected", method: "Config" }))
    p.enabledModels = MODELS.map(m => m[0])
    p.shortcuts = { ...defaults }
    p.workspaces = [{ id: "primary", name: p.name, path: p.path, type: "local", branch: p.branch, active: true }]
    p.pipelines = [{ id: "checks", name: "Project checks", branch: p.branch, command: "bun run build && bun run lint && bun test", trigger: "On push", environment: "Preview", deploy: false, status: "Passed", runs: 12, logs: "Sample run\nBuild completed\nLint completed\nTests passed\nAll checks complete." }]
    p.schedules = [{ id: "daily-review", name: "Daily code review", prompt: "Review the changes in this project and summarize risks and next steps.", cadence: "Daily", timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, nextRun: new Date(Date.now() + 86400000).toISOString(), agent: "Maestro", enabled: true, runs: 0 }]
    p.envRecords = p.id === "canonical" ? [{ key: "DATABASE_URL", value: "sqlite:./orchestra.db" }, { key: "OPENAI_API_KEY", value: "sample-key-not-a-real-credential" }, { key: "LOG_LEVEL", value: "info" }] : [{ key: "VITE_API_URL", value: "http://localhost:4096" }, { key: "NODE_ENV", value: "development" }]
    p.agents.forEach(a => { a.system = a.desc; a.mode = a.name === "Maestro" ? "primary" : "subagent"; a.steps = 20; a.permissions = { ...p.perms }; a.permissionOverrides = {}; a.hidden = false })
    if (restored[p.id]) Object.assign(p, restored[p.id])
  })
  Object.entries(restored).forEach(([id, state]) => {
    if (PROFILES[id]) return
    const p = structuredClone(PROFILES.canonical)
    Object.assign(p, state, { id, sessions: [], closedSessionIDs: [] })
    p.sessions.push({ id: crypto.randomUUID(), title: "New session", prompt: "", sub: "Describe what you want changed.", when: "just now", branch: p.branch, files: 0, add: 0, del: 0, tokens: 0, live: "idle", model: { id: p.model, providerID: p.routerID }, agent: p.agents[0]?.name || "Maestro" })
    PROFILES[id] = p
  })
  function persist() {
    const keys = ["name", "path", "branch", "routerID", "delivery", "agents", "perms", "skills", "llmPlugins", "hooks", "mcpServers", "providers", "enabledModels", "shortcuts", "workspaces", "pipelines", "schedules", "model", "effort", "subagent", "dock"]
    const state = Object.fromEntries(Object.values(PROFILES).map(p => [p.id, Object.fromEntries(keys.map(k => [k, p[k]]))]))
    localStorage.setItem(storageKey, JSON.stringify(state))
  }

  for (const key of Object.keys(titles)) {
    const screen = document.createElement("section")
    screen.className = "main glass mx-page"
    screen.id = `view${key[0].toUpperCase()}${key.slice(1)}`
    screen.hidden = true
    screen.innerHTML = `<div class="inner"><header class="mx-heading"><div><div class="mx-eyebrow" data-mx-profile></div><h1>${titles[key]}</h1><p>${descriptions[key]}</p></div><div data-mx-header></div></header><div data-mx-body></div></div>`
    document.querySelector(".workspace").append(screen)
    views[key] = screen
    const nav = document.createElement("button")
    nav.dataset.view = key
    nav.dataset.mxNav = key
    nav.innerHTML = `<span class="side-icon">${icon(key)}</span><span>${titles[key] === "LLM Plugins" ? "Plugins" : titles[key]}</span>`
    const parent = ["providers", "shortcuts"].includes(key) ? document.querySelector('[data-view="settings"]').parentElement : document.getElementById("sideNav")
    parent.insertBefore(nav, ["providers", "shortcuts"].includes(key) ? document.querySelector('[data-view="settings"]') : document.querySelector('[data-view="dock"]'))
  }
  Object.entries(orchestraChapters).forEach(([key, chapter]) => {
    const screen = views[key]
    screen.dataset.orchestraChapter = chapter[0]
    screen.dataset.rework = "pending"
    const marker = document.createElement("div")
    marker.className = "mx-origin mx-origin-banner"
    marker.dataset.chapterMarker = chapter[0]
    marker.textContent = `${chapter[0]} · Orchestra · Rework pendente`
    marker.title = chapter[1]
    if (key === "dock") screen.classList.add("mx-origin-dock")
    const heading = screen.querySelector(".mx-heading,.mast")
    if (heading) heading.before(marker)
    if (!heading) screen.prepend(marker)
    const nav = document.querySelector(`.side-nav [data-view="${key}"]`)
    nav.dataset.orchestraChapter = chapter[0]
    nav.title = `${marker.textContent}. ${chapter[1]}`
    const dot = document.createElement("span")
    dot.className = "mx-origin-dot"
    dot.setAttribute("aria-hidden", "true")
    nav.append(dot)
  })
  const navigation = document.createElement("div")
  navigation.className = "mx-navigation"
  const side = document.querySelector(".side")
  const navNodes = [...side.children].filter(e => e.matches("nav,.side-rule"))
  side.insertBefore(navigation, navNodes[0])
  navNodes.forEach(e => navigation.append(e))
  const baseView = setView
  setView = function(v, agent) {
    baseView(v, agent)
    if (titles[v]) crumb.textContent = titles[v]
    document.querySelectorAll(".side-nav [data-view]").forEach(b => b.classList.toggle("on", b.dataset.view === v))
    if (titles[v]) renderPage(v)
    if (v === "workspaces") renderWorkspaces()
  }
  const baseSwitch = switchProfile
  switchProfile = function(id) {
    if (id !== P.id && dialog.open) dialog.close()
    baseSwitch(id)
    renderOpenPage()
  }
  function renderOpenPage() {
    const key = Object.keys(views).find(k => !views[k].hidden)
    if (titles[key]) renderPage(key)
    if (key === "settings") renderSettings(document.querySelector("#settingsNav .on")?.dataset.sec || "permissions")
    if (key === "agents") renderAgents()
    if (key === "workspaces") renderWorkspaces()
  }
  function pageData(key) {
    if (key === "providers") return providersBody()
    if (key === "shortcuts") return shortcutsBody()
    if (key === "mcp") return mcpBody()
    if (key === "skills") return skillsBody()
    if (key === "plugins") return pluginsBody()
    if (key === "hooks") return hooksBody()
    if (key === "cicd") return pipelinesBody()
    if (key === "schedule") return schedulesBody()
    if (key === "env") return envBody()
    return ""
  }
  function renderPage(key) {
    const screen = views[key]
    screen.querySelector("[data-mx-profile]").textContent = `${P.name} / profile configuration`
    const add = { mcp: ["Add MCP server", "mcp-edit"], skills: ["Add skill", "skill-edit"], providers: ["Connect provider", "provider-pick"], plugins: ["Add behavior", "plugin-edit"], hooks: ["Add hook", "hook-edit"], shortcuts: ["Reset to defaults", "shortcuts-reset"], cicd: ["New pipeline", "pipeline-edit"], schedule: ["Agendar tarefa", "schedule-edit"], env: ["Open .env", "env-open"] }[key]
    screen.querySelector("[data-mx-header]").innerHTML = button(add[0], add[1], "", true)
    screen.querySelector("[data-mx-body]").innerHTML = `<div class="mx-toolbar"><input class="mx-search" data-mx-search placeholder="Search ${titles[key].toLowerCase()}" aria-label="Search ${titles[key]}">${badge(P.name)}</div>${pageData(key)}<p class="mx-note">Interactive preview · settings belong to this profile · connections and hook execution are simulated.</p>`
  }
  function providersBody() {
    const route = `<label class="mx-field" style="max-width:300px"><span>Route for new turns</span><select data-mx-route><option value="">Choose a connected provider</option>${P.providers.filter(p => p.status === "Connected").map(p => `<option value="${esc(p.id)}"${p.id === P.routerID ? " selected" : ""}>${esc(p.name)}</option>`).join("")}</select></label>`
    const cards = P.providers.map(p => `<article class="mx-card" data-mx-card><div class="mx-card-top"><span class="mx-mark">${brand(p.id)}</span><h3>${esc(p.name)}</h3></div><p>${esc(p.note || "OpenAI-compatible provider")}</p><div class="mx-meta">${badge(p.status, p.status === "Connected" ? "good" : "bad")}${badge(p.method || "API key")}</div><footer class="mx-card-foot"><div>${button("Configure", "provider-connect", p.id)} ${button("Models", "provider-models", p.id)}</div>${button(p.status === "Connected" ? "Disconnect" : "Connect", p.status === "Connected" ? "provider-disconnect" : "provider-connect", p.id)}</footer></article>`).join("")
    const available = providerCatalog.filter(p => !P.providers.some(x => x.id === p.id))
    const popular = available.map(p => `<div class="mx-row" data-mx-card>${brand(p.id)}<div class="mx-grow"><strong>${p.name}</strong><small>${p.note}</small></div>${button("Connect", "provider-connect", p.id)}</div>`).join("") || `<div class="mx-row"><small>All sample providers are listed above.</small></div>`
    return route + `<div class="mx-grid">${cards}</div><h3 class="mx-section">Popular providers</h3><div class="mx-table">${popular}</div>`
  }
  function mcpBody() {
    if (!P.mcpServers.length) return `<div class="mx-empty">No MCP servers configured.<br>Add a server to make its tools available to this profile.</div>`
    return `<div class="mx-grid">${P.mcpServers.map(s => `<article class="mx-card" data-mx-card><div class="mx-card-top"><span class="mx-mark">${icon("mcp")}</span><h3>${esc(s.name)}</h3></div><p>${esc(s.endpoint)}</p><div class="mx-meta">${badge(s.enabled ? s.status : "Disabled", s.enabled && s.status === "Connected" ? "good" : s.status === "Error" ? "bad" : "")}${badge(s.transport)}${badge(`${s.tools.length} tools`)}</div><footer class="mx-card-foot"><div>${button("Configure", "mcp-edit", s.id)} ${button("Tools", "mcp-tools", s.id)}</div>${toggle("mcp-toggle", s.id, s.enabled, `Enable ${s.name}`)}</footer></article>`).join("")}</div>`
  }
  function skillsBody() {
    return `<div class="mx-grid">${P.skills.map(s => `<article class="mx-card" data-mx-card><div class="mx-card-top"><span class="mx-mark">${icon("skills")}</span><h3>${esc(s.name)}</h3></div><p>${esc(s.description)}</p><div class="mx-meta">${badge(s.source)}${badge(s.enabled ? "Available" : "Disabled", s.enabled ? "good" : "")}</div><footer class="mx-card-foot">${button("Read & edit", "skill-edit", s.id)}${toggle("skill-toggle", s.id, s.enabled, `Enable ${s.name}`)}</footer></article>`).join("")}</div>`
  }
  function pluginsBody() {
    return `<div class="mx-grid">${P.llmPlugins.map(p => `<article class="mx-card" data-mx-card><div class="mx-card-top"><span class="mx-mark">${icon("plugins")}</span><h3>${esc(p.name)}</h3></div><p>${esc(p.description)}</p><div class="mx-meta">${badge("LLM behavior")}${badge(p.intensity || "custom")}${badge(p.enabled ? "Active" : "Disabled", p.enabled ? "good" : "")}</div><footer class="mx-card-foot">${button("Configure", "plugin-edit", p.id)}${toggle("plugin-toggle", p.id, p.enabled, `Enable ${p.name}`)}</footer></article>`).join("")}</div>`
  }
  function hooksBody() {
    return `<div class="mx-grid">${P.hooks.map(h => `<article class="mx-card" data-mx-card><div class="mx-card-top"><span class="mx-mark">${icon("hooks")}</span><h3>${esc(h.name)}</h3></div><p>${esc(h.value)}</p><div class="mx-meta">${badge(h.event)}${badge(h.action)}${badge(`${h.runs} runs`)}</div><footer class="mx-card-foot"><div>${button("Configure", "hook-edit", h.id)} ${button("Test", "hook-test", h.id)}</div>${toggle("hook-toggle", h.id, h.enabled, `Enable ${h.name}`)}</footer>${h.lastRun ? `<pre class="mx-log">${esc(h.lastRun)}</pre>` : ""}</article>`).join("")}</div>`
  }
  function shortcutsBody() {
    return `<div class="mx-table">${Object.entries(P.shortcuts).map(([name, binding]) => `<div class="mx-row" data-mx-card><div class="mx-grow"><strong>${esc(name)}</strong><small>Profile shortcut</small></div><kbd class="mx-badge">${esc(binding)}</kbd>${button("Edit", "shortcut-edit", name)}</div>`).join("")}</div>`
  }
  function pipelinesBody() {
    if (!P.pipelines.length) return `<div class="mx-empty">No pipelines configured.<br>Create a pipeline to preview build, test and deployment stages.</div>`
    return `<div class="mx-grid">${P.pipelines.map(p => `<article class="mx-card" data-mx-card><div class="mx-card-top"><span class="mx-mark">${icon("cicd")}</span><h3>${esc(p.name)}</h3></div><p>${esc(p.command)}</p><div class="mx-meta">${badge(p.status, p.status === "Passed" ? "good" : p.status === "Failed" ? "bad" : "")}${badge(p.branch)}${badge(p.trigger)}${badge(p.deploy ? `Deploy: ${p.environment}` : "Checks only")}</div><footer class="mx-card-foot"><div>${button(p.status === "Running" ? "Stop" : "Run", p.status === "Running" ? "pipeline-stop" : "pipeline-run", p.id)} ${button("Logs", "pipeline-logs", p.id)}</div>${button("Edit", "pipeline-edit", p.id)}</footer></article>`).join("")}</div>`
  }
  function schedulesBody() {
    if (!P.schedules.length) return `<div class="mx-empty">Nenhuma tarefa agendada.<br>Crie uma tarefa única ou recorrente.</div>`
    const cadence = { Once: "Única", "Every hour": "A cada hora", Daily: "Diária", Weekly: "Semanal" }
    return `<div class="mx-grid">${P.schedules.map(s => `<article class="mx-card" data-mx-card><div class="mx-card-top"><span class="mx-mark">${icon("schedule")}</span><h3>${esc(s.name)}</h3></div><p>${esc(s.prompt)}</p><div class="mx-meta">${badge(cadence[s.cadence] || s.cadence)}${badge(s.agent)}${badge(s.enabled ? "Agendada" : "Pausada", s.enabled ? "good" : "")}</div><p>Próxima: ${esc(new Date(s.nextRun).toLocaleString("pt-BR", { dateStyle: "medium", timeStyle: "short", timeZone: s.timezone }))}<br><small>${esc(s.timezone)} · ${s.runs} execuções</small></p><footer class="mx-card-foot"><div>${button("Executar agora", "schedule-run", s.id)} ${button("Editar", "schedule-edit", s.id)}</div>${toggle("schedule-toggle", s.id, s.enabled, `Ativar ${s.name}`)}</footer>${s.lastRun ? `<p class="mx-note">Última: ${esc(s.lastRun)}</p>` : ""}</article>`).join("")}</div>`
  }
  function envBody() {
    return `<div class="mx-toolbar">${button("Add key", "env-edit")}${button("Download .env", "env-download")}${button("View file", "env-preview")}${badge(`${P.envRecords.length} keys`)}</div><div class="mx-table">${P.envRecords.map(r => `<div class="mx-row" data-mx-card><div class="mx-grow"><strong><code>${esc(r.key)}</code></strong><small><code>${esc(r.revealed ? r.value : "••••••••••••")}</code></small></div>${button(r.revealed ? "Hide" : "Show", "env-reveal", r.key)}${button("Edit", "env-edit", r.key)}${button("Remove", "env-remove", r.key)}</div>`).join("")}</div><p class="mx-note">Sample keys until you open a file. Values stay in this page; Download .env saves the edited file.</p>`
  }
  function download(name, content, type = "text/plain") {
    const blob = new Blob([content], { type })
    const url = URL.createObjectURL(blob)
    if (window.Mock) {
      window.Mock.downloads ||= []
      window.Mock.downloads.push({ name, size: blob.size, type })
      if (window.Mock.downloads.length > 30) window.Mock.downloads.shift()
    }
    const a = document.createElement("a")
    a.href = url; a.download = name; a.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }
  const envAssignment = r => `${r.key}=${/[\s#"'\\]/.test(r.value) ? JSON.stringify(r.value) : r.value}`
  function envText() {
    if (!P.envSourceLines) return P.envRecords.map(envAssignment).join("\n") + "\n"
    const output = [], seen = new Set(), entries = new Map(P.envSourceEntries.map(e => [e.start, e]))
    for (let i = 0; i < P.envSourceLines.length; i++) {
      const entry = entries.get(i)
      if (!entry) { output.push(P.envSourceLines[i]); continue }
      const record = P.envRecords.find(r => r.key === entry.key)
      if (record) {
        seen.add(record.key)
        output.push(record.value === entry.value ? P.envSourceLines.slice(entry.start, entry.end + 1).join("\n") : entry.prefix + envAssignment(record))
      }
      i = entry.end
    }
    P.envRecords.filter(r => !seen.has(r.key)).forEach(r => output.push(envAssignment(r)))
    return output.join("\n").replace(/\n*$/, "\n")
  }
  function editEnv(key) {
    const item = P.envRecords.find(r => r.key === key)
    modal(item ? `Edit ${key}` : "Add environment key", "Keep it simple. Changes belong to this profile; download to save the file.", field("Key", "key", key) + field("Value", "value", item?.value || "", "text", false), data => {
      const name = String(data.get("key")).trim()
      if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name)) { formError("Use a valid environment key name."); return false }
      if (P.envRecords.some(r => r.key === name && r !== item)) { formError("This key already exists."); return false }
      const next = { key: name, value: String(data.get("value")) }
      const i = P.envRecords.indexOf(item)
      if (i < 0) P.envRecords.push(next); else P.envRecords[i] = next
      renderOpenPage()
    })
  }
  const envInput = document.createElement("input")
  envInput.type = "file"; envInput.hidden = true; envInput.dataset.mxEnv = "true"
  document.body.append(envInput)
  envInput.addEventListener("change", async () => {
    const file = envInput.files[0]
    if (!file) return
    const owner = PROFILES[envInput.dataset.owner] || P
    const text = await file.text()
    const values = new Map(), lines = text.split(/\r?\n/), entries = []
    for (let i = 0; i < lines.length; i++) {
      const match = /^(\s*(?:export\s+)?)([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(lines[i])
      if (!match) continue
      const start = i
      let value = match[3].trim()
      const quote = value[0]
      if (quote === '"' || quote === "'") {
        const closing = new RegExp(`^${quote}([\\s\\S]*)${quote}\\s*(?:#.*)?$`)
        while (!closing.test(value) && i + 1 < lines.length) value += "\n" + lines[++i]
        const quoted = closing.exec(value)
        if (quoted) value = quoted[1]
        if (quote === '"') value = value.replace(/\\([nr\\"])/g, (_, key) => ({ n: "\n", r: "\r", "\\": "\\", '"': '"' }[key]))
      } else value = value.replace(/#.*$/, "").trim()
      values.set(match[2], value)
      entries.push({ start, end: i, key: match[2], value, prefix: match[1] })
    }
    owner.envRecords = [...values].map(([key, value]) => ({ key, value }))
    owner.envSourceLines = lines; owner.envSourceEntries = entries
    envInput.value = ""
    if (P === owner) renderOpenPage()
  })
  function editPipeline(id) {
    const p = P.pipelines.find(x => x.id === id) || { id: crypto.randomUUID(), name: "", branch: P.branch, trigger: "Manual", command: "bun run build && bun test", status: "Not run", runs: 0, logs: "" }
    modal(id ? `Edit ${p.name}` : "New pipeline", "Pipeline preview. No commands are executed.", field("Name", "name", p.name) + `<div class="mx-fields">${field("Branch", "branch", p.branch)}${select("Trigger", "trigger", p.trigger, ["Manual", "On push", "On pull request"])}</div>` + textarea("Commands", "command", p.command) + select("Deployment environment", "environment", p.environment || "Preview", ["Preview", "Staging", "Production"]) + `<label class="mx-choice"><input type="checkbox" name="deploy"${p.deploy ? " checked" : ""}>Include a deployment stage</label>` + (id ? button("Remove pipeline", "remove-config", "pipelines:" + id) : ""), data => {
      Object.assign(p, { name: data.get("name"), branch: data.get("branch"), trigger: data.get("trigger"), command: data.get("command"), environment: data.get("environment"), deploy: data.has("deploy") })
      if (!P.pipelines.some(x => x.id === p.id)) P.pipelines.push(p)
      persist(); renderOpenPage()
    })
  }
  const jobs = new Map()
  function runPipeline(id) {
    const owner = P, p = owner.pipelines.find(x => x.id === id)
    if (p.status === "Running") return
    p.status = "Running"; p.runs++; p.logs = `Preview run ${p.runs}\nBranch: ${p.branch}\n$ ${p.command}\n\nStarting checks…`
    renderOpenPage()
    const key = owner.id + ":" + id
    jobs.set(key, setTimeout(() => {
      p.status = /fail|invalid/i.test(p.command) ? "Failed" : "Passed"
      p.logs += `\nBuild: completed\nLint: completed\nTests: ${p.status === "Passed" ? "passed" : "failed"}${p.deploy ? `\nDeploy to ${p.environment}: ${p.status === "Passed" ? "preview complete" : "skipped due to failed checks"}` : ""}\nPipeline ${p.status.toLowerCase()}.\nSimulated run; no external commands executed.`
      jobs.delete(key); persist()
      if (owner === P) renderOpenPage()
      const log = dialog.querySelector('[data-mx-pipeline-log="' + id + '"]')
      if (log && owner === P) log.textContent = p.logs
    }, 1800))
  }
  function editSchedule(id) {
    const s = P.schedules.find(x => x.id === id) || { id: crypto.randomUUID(), name: "", prompt: "", cadence: "Once", timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, nextRun: new Date(Date.now() + 3600000).toISOString(), agent: P.agents[0]?.name || "Maestro", enabled: true, runs: 0 }
    const date = new Date(s.nextRun)
    const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
    modal(id ? `Editar ${s.name}` : "Agendar tarefa", "Horário exibido no fuso local. Recorrência e agente pertencem ao perfil.", field("Nome", "name", s.name) + textarea("O que executar", "prompt", s.prompt) + `<div class="mx-fields">${select("Recorrência", "cadence", s.cadence, [["Once", "Única"], ["Every hour", "A cada hora"], ["Daily", "Diária"], ["Weekly", "Semanal"]])}${select("Agente", "agent", s.agent, P.agents.map(a => a.name))}</div>` + field("Próxima execução", "date", local, "datetime-local") + (id ? button("Excluir tarefa", "remove-config", "schedules:" + id) : ""), data => {
      if (!String(data.get("prompt")).trim()) { formError("Descreva a tarefa."); return false }
      const next = new Date(data.get("date"))
      if (!Number.isFinite(next.getTime())) { formError("Escolha um horário válido."); return false }
      if (next.getTime() <= Date.now()) { formError("Escolha um horário futuro."); return false }
      Object.assign(s, { name: data.get("name"), prompt: data.get("prompt"), cadence: data.get("cadence"), agent: data.get("agent"), nextRun: next.toISOString() })
      if (!P.schedules.some(x => x.id === s.id)) P.schedules.push(s)
      persist(); renderOpenPage()
    }, "Agendar")
  }
  function sessionRecord(profile, title = "New session", prompt = "", agentName) {
    const agent = profile.agents.find(a => a.name === agentName) || profile.agents[0]
    const workspace = profile.workspaces.find(w => w.active)
    return { id: crypto.randomUUID(), title, prompt, sub: prompt || "Describe what you want changed.", when: "just now", branch: workspace?.branch || profile.branch, workspaceID: workspace?.id, files: 0, add: 0, del: 0, tokens: 0, live: "idle", model: { id: agentName ? agent?.model || profile.model : profile.model, providerID: profile.routerID, variant: profile.effort }, extras: [], agent: agent?.name || "Maestro" }
  }
  function createSession(title = "New session", prompt = "", agentName) {
    const session = sessionRecord(P, title, prompt, agentName)
    P.sessions.unshift(session); openSessionID = session.id
    renderChatSessions(); renderSessionRows(); setView("session"); applyOpenSession()
    runHooks("Session start", session)
    return session
  }
  function confirmAction(title, detail, commit) {
    modal(title, detail, `<p class="mx-note">This changes the preview data for ${esc(P.name)}.</p>`, () => { commit(); persist(); renderOpenPage() }, "Confirm")
  }
  function agentCards(list = P.agents) {
    return `<div class="mx-grid">${list.map(a => `<article class="agent mx-card" data-mx-card><div class="agent-top mx-card-top"><span class="mx-mark">${icon("skills")}</span><b>${esc(a.name)}</b><span class="agent-role">${esc(a.mode)}</span></div><p>${esc(a.desc)}</p><div class="mx-meta">${badge(a.model)}${badge(`${a.steps} steps`)}${badge(a.hidden ? "Hidden" : "Available", a.hidden ? "" : "good")}</div><footer class="mx-card-foot">${button("Configure", "agent-edit", a.name)}${button("Open Chat", "agent-chat", a.name)}</footer></article>`).join("")}</div>`
  }
  renderAgents = function(focus) {
    const agent = focus && P.agents.find(a => a.name.toLowerCase() === focus)
    document.getElementById("agentsBody").innerHTML = `<div class="mx-toolbar">${button("Create agent", "agent-edit", "", true)}${badge(P.name)}</div>` + agentCards(agent ? [agent] : P.agents)
  }
  function editAgent(name) {
    const a = P.agents.find(x => x.name === name) || { name: "", model: P.model, mode: "subagent", desc: "", system: "", steps: 20, permissions: { ...P.perms }, hidden: false, tokens: "0", sessions: 0, tools: 0 }
    const body = `<div class="mx-fields">${field("Name", "name", a.name)}${select("Mode", "mode", a.mode, ["primary", "subagent", "all"])}</div>${field("Description", "description", a.desc)}<div class="mx-fields">${select("Model", "model", a.model, modelOptions())}${field("Provider-turn allowance", "steps", a.steps, "number")}</div>${textarea("System instructions", "system", a.system)}<h3 class="mx-section">Tool permissions</h3><p class="mx-note">Inherit follows this profile. An explicit Deny always blocks the tool.</p><div class="mx-table">${PERM_TOOLS.map(([id, label]) => `<div class="mx-row"><div class="mx-grow"><strong>${label}</strong></div><select name="perm-${id}" class="mx-search">${["inherit", "allow", "ask", "deny"].map(v => `<option value="${v}"${(a.permissionOverrides?.[id] || "inherit") === v ? " selected" : ""}>${v === "inherit" ? `Inherit (${P.perms[id]})` : v[0].toUpperCase() + v.slice(1)}</option>`).join("")}</select></div>`).join("")}</div>${name ? `<p class="mx-note">${button("Remove agent", "agent-remove", name)}</p>` : ""}`
    modal(name ? `Configure ${name}` : "Create agent", "Model, instructions and permissions are local to this profile.", body, data => {
      const nextName = String(data.get("name")).trim()
      if (P.agents.some(x => x !== a && x.name.toLowerCase() === nextName.toLowerCase())) { formError("An agent with this name already exists."); return false }
      const steps = Number(data.get("steps"))
      if (!Number.isInteger(steps) || steps < 1) { formError("Turn allowance must be a positive integer."); return false }
      const overrides = Object.fromEntries(PERM_TOOLS.map(([id]) => [id, data.get(`perm-${id}`)]).filter(([, value]) => value !== "inherit"))
      Object.assign(a, { name: nextName, desc: data.get("description"), model: data.get("model"), mode: data.get("mode"), system: data.get("system"), steps, permissionOverrides: overrides, permissions: { ...P.perms, ...overrides } })
      if (!P.agents.includes(a)) P.agents.push(a)
      persist(); renderAgents(); renderProfileSwitcher(); renderOpenPage()
    })
  }
  function modelsBody() {
    return `<div class="mx-table">${MODELS.map(m => `<div class="mx-row" data-mx-card>${brand(MODEL_MANUFACTURERS[m[0]])}<div class="mx-grow"><strong>${esc(m[1])}</strong><small>${esc(m[2])} · Context ${m[6]}</small></div>${toggle("model-toggle", m[0], P.enabledModels.includes(m[0]), `Enable ${m[1]}`)}</div>`).join("")}</div>`
  }
  SETTINGS_SECTIONS.providers = { title: "Providers", desc: descriptions.providers, body: providersBody }
  SETTINGS_SECTIONS.models = { title: "Models", desc: "Choose which models appear in this profile's composer.", body: modelsBody }
  SETTINGS_SECTIONS.agents = { title: "Agents", desc: "Configure this profile's agents.", body: agentCards }
  SETTINGS_SECTIONS.mcp = { title: "MCP", desc: descriptions.mcp, body: mcpBody }
  SETTINGS_SECTIONS.shortcuts = { title: "Keyboard shortcuts", desc: descriptions.shortcuts, body: shortcutsBody }
  const originalSettings = renderSettings
  renderSettings = function(section) {
    originalSettings(section)
    const labels = { providers: ["Connect provider", "provider-pick"], mcp: ["Add MCP server", "mcp-edit"], agents: ["Create agent", "agent-edit"], shortcuts: ["Reset to defaults", "shortcuts-reset"] }
    if (labels[section]) document.getElementById("settingsBody").insertAdjacentHTML("afterbegin", `<div class="mx-toolbar">${button(...labels[section])}</div>`)
  }
  const baseModelMenu = modelMenu
  modelMenu = function(current) {
    const template = document.createElement("template")
    template.innerHTML = baseModelMenu(current)
    template.content.querySelectorAll("[data-pick]").forEach(row => { if (!P.enabledModels.includes(row.dataset.pick)) row.remove() })
    if (!template.content.querySelector("[data-pick]")) template.content.querySelector(".pop-search").insertAdjacentHTML("afterend", `<p class="pop-note">No model results. Enable a model in Settings.</p>`)
    return template.innerHTML
  }
  function renderWorkspaces() {
    document.getElementById("workspacesBody").innerHTML = `<div class="mx-toolbar">${button("New workspace", "workspace-edit", "", true)}${badge(P.name)}</div><div class="mx-grid">${P.workspaces.map(w => `<article class="mx-card"><div class="mx-card-top"><span class="mx-mark">${icon("file")}</span><h3>${esc(w.name)}</h3></div><p><code>${esc(w.path)}</code></p><div class="mx-meta">${badge(w.type)}${badge(w.branch)}${badge(w.active ? "Active" : "Idle", w.active ? "good" : "")}</div><footer class="mx-card-foot">${button(w.active ? "Open Chat" : "Use workspace", "workspace-use", w.id)}${button("Configure", "workspace-edit", w.id)}</footer></article>`).join("")}</div>`
  }
  function editWorkspace(id) {
    const w = P.workspaces.find(x => x.id === id) || { id: crypto.randomUUID(), name: "", path: P.path, branch: P.branch, type: "local", active: false }
    modal(id ? `Configure ${w.name}` : "New workspace", "Placement for this profile's work. Creating a preview does not create directories.", field("Name", "name", w.name) + field("Directory", "path", w.path) + `<div class="mx-fields">${field("Branch", "branch", w.branch)}${select("Type", "type", w.type, ["local", "sandbox"])}</div>` + (id && !w.active ? button("Delete workspace", "workspace-delete", id) : ""), data => {
      Object.assign(w, { name: data.get("name"), path: data.get("path"), branch: data.get("branch"), type: data.get("type") })
      if (!P.workspaces.includes(w)) P.workspaces.push(w)
      persist(); renderWorkspaces()
    })
  }
  function editProfile(id = P.id) {
    const profile = PROFILES[id]
    modal(profile ? "Edit profile" : "New profile", profile ? "One repository is one profile. Its configuration and sessions stay together." : "Starts from this profile's configuration. Conversations, browser tabs and .env keys start fresh.", field("Name", "name", profile?.name || "") + field("Repository directory", "path", profile?.path || "") + field("Branch", "branch", profile?.branch || "dev"), data => {
      if (profile) { profile.name = data.get("name"); profile.path = data.get("path"); profile.branch = data.get("branch") }
      else {
        const id = crypto.randomUUID()
        const clone = structuredClone(P)
        Object.assign(clone, { id, name: data.get("name"), path: data.get("path"), branch: data.get("branch"), sessions: [], closedSessionIDs: [], schedules: [], pipelines: [], envRecords: [], envSourceLines: undefined, envSourceEntries: undefined, workspaces: [{ id: "primary", name: data.get("name"), path: data.get("path"), branch: data.get("branch"), type: "local", active: true }] })
        clone.dock = { ...clone.dock, profile: "personal", active: undefined, tabs: { personal: [], work: [] }, bookmarks: [], history: [], downloads: [], lib: undefined, menu: undefined, findOpen: false }
        PROFILES[id] = clone
        clone.sessions.push(sessionRecord(clone))
        switchProfile(id)
      }
      persist(); renderProfileSwitcher(); renderKicker(); renderOpenPage()
    })
  }
  const baseProfileMenu = renderProfileSwitcher
  renderProfileSwitcher = function() {
    baseProfileMenu()
    profileMenu.insertAdjacentHTML("beforeend", `<div style="border-top:1px solid var(--mx-line);margin:5px 0"></div><button class="profile-menu-item" role="menuitem" data-mx-action="profile-edit" data-id="${esc(P.id)}">Edit profile</button><button class="profile-menu-item" role="menuitem" data-mx-action="profile-new">New profile</button>`)
  }
  function providerPicker() {
    modal("Connect provider", "Choose a provider for this profile.", `<div class="mx-table">${providerCatalog.map(p => `<div class="mx-row">${brand(p.id)}<div class="mx-grow"><strong>${p.name}</strong><small>${p.note}</small></div>${button("Connect", "provider-connect", p.id)}</div>`).join("")}</div><p class="mx-note">${button("Custom OpenAI-compatible provider", "provider-custom")}</p>`, null)
  }
  function providerConnect(id) {
    const p = P.providers.find(x => x.id === id) || providerCatalog.find(x => x.id === id)
    modal(`Connect ${p.name}`, "Preview connection. Credentials are not sent or saved.", select("Connection method", "method", p.method || "API key", ["API key", "OAuth", "Local endpoint"]) + field("API key or endpoint", "credential", p.method === "Local endpoint" ? p.endpoint || "" : "", p.method === "Local endpoint" ? "text" : "password", false) + `<p class="mx-note">Use any sample value to demonstrate the connected state. An empty API key shows validation.</p>`, data => {
      if (data.get("method") === "API key" && !data.get("credential")) { formError("Enter an API key to continue."); return false }
      if (data.get("method") === "Local endpoint" && !URL.canParse(String(data.get("credential")))) { formError("Enter a valid local endpoint URL."); return false }
      const item = { ...p, status: "Connected", method: data.get("method"), ...(data.get("method") === "Local endpoint" ? { endpoint: data.get("credential") } : {}) }
      const i = P.providers.findIndex(x => x.id === id)
      if (i < 0) P.providers.push(item); else P.providers[i] = item
      persist(); renderOpenPage()
    }, "Connect")
    dialog.querySelector('[name="method"]').addEventListener("change", e => {
      dialog.querySelector('[name="credential"]').type = e.target.value === "API key" ? "password" : "text"
    })
  }
  function editMCP(id) {
    const item = P.mcpServers.find(x => x.id === id) || { id: crypto.randomUUID(), name: "", transport: "stdio", endpoint: "", enabled: true, tools: ["search", "read"] }
    modal(id ? `Configure ${item.name}` : "Add MCP server", "Connect tools to this profile. Preview does not launch a server.", field("Name", "name", item.name) + select("Transport", "transport", item.transport, ["stdio", "http"]) + field("Command or server URL", "endpoint", item.endpoint) + (id ? button("Remove server", "remove-config", "mcpServers:" + id) : ""), data => {
      const endpoint = String(data.get("endpoint")).trim()
      const bad = data.get("transport") === "http" && !URL.canParse(endpoint)
      if (bad) { formError("Enter a valid server URL."); return false }
      const next = { ...item, name: data.get("name"), transport: data.get("transport"), endpoint, status: endpoint.includes("invalid") ? "Error" : "Connected" }
      const i = P.mcpServers.findIndex(x => x.id === item.id)
      if (i < 0) P.mcpServers.push(next); else P.mcpServers[i] = next
      persist(); renderOpenPage()
    })
  }
  function editSkill(id) {
    const item = P.skills.find(x => x.id === id) || { id: crypto.randomUUID(), name: "", description: "", instructions: "", source: "Project", enabled: true }
    modal(id ? `Edit ${item.name}` : "Add skill", "Instructions are stored in this mock profile.", field("Name", "name", item.name) + field("Description", "description", item.description) + textarea("Instructions", "instructions", item.instructions) + (id ? button("Remove skill", "remove-config", "skills:" + id) : ""), data => {
      const next = { ...item, name: data.get("name"), description: data.get("description"), instructions: data.get("instructions") }
      const i = P.skills.findIndex(x => x.id === item.id)
      if (i < 0) P.skills.push(next); else P.skills[i] = next
      persist(); renderOpenPage()
    })
  }
  function editPlugin(id) {
    const item = P.llmPlugins.find(x => x.id === id) || { id: crypto.randomUUID(), name: "", description: "", instructions: "", enabled: true, intensity: "custom" }
    modal(id ? `Configure ${item.name}` : "Add LLM behavior", "Behavior plugins affect simulated answers in this profile.", field("Name", "name", item.name) + field("Description", "description", item.description) + (item.id === "caveman" ? select("Intensity", "intensity", item.intensity, ["lite", "full", "ultra"]) : "") + textarea("Behavior instructions", "instructions", item.instructions) + (id ? button("Remove behavior", "remove-config", "llmPlugins:" + id) : ""), data => {
      Object.assign(item, { name: data.get("name"), description: data.get("description"), instructions: data.get("instructions"), intensity: data.get("intensity") || "custom" })
      if (!P.llmPlugins.some(x => x.id === item.id)) P.llmPlugins.push(item)
      persist(); renderOpenPage()
    })
  }
  function editHook(id) {
    const item = P.hooks.find(x => x.id === id) || { id: crypto.randomUUID(), name: "", event: "Before prompt", action: "Add instruction", value: "", enabled: true, runs: 0 }
    modal(id ? `Configure ${item.name}` : "Add hook", "Events are simulated. Commands are displayed, never executed.", field("Name", "name", item.name) + `<div class="mx-fields">${select("Event", "event", item.event, ["Session start", "Before prompt", "Before tool", "After tool", "Session idle"])}${select("Action", "action", item.action, ["Add instruction", "Record event", "Run command"])}</div>` + textarea("Instruction or command", "value", item.value) + (id ? button("Remove hook", "remove-config", "hooks:" + id) : ""), data => {
      Object.assign(item, { name: data.get("name"), event: data.get("event"), action: data.get("action"), value: data.get("value") })
      if (!P.hooks.some(x => x.id === item.id)) P.hooks.push(item)
      persist(); renderOpenPage()
    })
  }
  function runHooks(event, session, owner = P) {
    return owner.hooks.filter(h => h.enabled && h.event === event).map(h => {
      h.runs++
      h.lastRun = `${new Date().toLocaleTimeString()} · ${event}\n${h.action}: ${h.value}\nPreview: completed without external execution.`
      if (session) (session.hookEvents ||= []).push({ name: h.name, event, action: h.action, value: h.value })
      return h
    })
  }
  function editShortcut(name) {
    modal("Press keys", `Shortcut for ${name}. Existing assignments remain unchanged until Save.`, field("Key combination", "binding", P.shortcuts[name]) + `<p class="mx-note">Focus the field and press your keys. Examples: ⌘K, ⌘⇧M.</p>`, data => {
      const binding = String(data.get("binding")).trim()
      const conflict = Object.entries(P.shortcuts).find(([key, value]) => key !== name && value === binding)
      if (conflict) { formError(`Shortcut already in use: ${conflict[0]}`); return false }
      P.shortcuts[name] = binding
      persist(); renderOpenPage()
    })
    dialog.querySelector('[name="binding"]').readOnly = true
    dialog.querySelector('[name="binding"]').addEventListener("keydown", e => {
      if (["Meta", "Shift", "Alt", "Control", "Tab", "Escape"].includes(e.key)) return
      e.preventDefault(); e.stopPropagation()
      e.target.value = `${e.metaKey ? "⌘" : ""}${e.ctrlKey ? "⌃" : ""}${e.altKey ? "⌥" : ""}${e.shiftKey ? "⇧" : ""}${e.key.toUpperCase()}`
    })
  }

  const actions = {
    "close-dialog": () => dialog.close(), "provider-pick": providerPicker, "provider-connect": providerConnect,
    "provider-disconnect": id => { P.providers.find(p => p.id === id).status = "Disconnected"; persist(); renderOpenPage() },
    "provider-models": () => { setView("settings"); document.querySelector('[data-sec="models"]').click() },
    "provider-custom": () => modal("Custom provider", "Add an OpenAI-compatible endpoint to this profile.", field("Name", "name", "") + field("Base URL", "endpoint", "http://localhost:8080/v1"), data => {
      const id = String(data.get("name")).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")
      if (!id || P.providers.some(p => p.id === id)) { formError("Choose a unique provider name."); return false }
      if (!URL.canParse(String(data.get("endpoint")))) { formError("Enter a valid endpoint URL."); return false }
      P.providers.push({ id, name: data.get("name"), endpoint: data.get("endpoint"), status: "Connected", method: "Local endpoint", note: "Custom OpenAI-compatible provider" })
      persist(); renderOpenPage()
    }, "Connect"),
    "mcp-edit": editMCP, "skill-edit": editSkill, "plugin-edit": editPlugin, "hook-edit": editHook, "shortcut-edit": editShortcut,
    "shortcuts-reset": () => { P.shortcuts = { ...defaults }; persist(); renderOpenPage() },
    "mcp-tools": id => { const s = P.mcpServers.find(x => x.id === id); modal(`${s.name} tools`, s.endpoint, `<div class="mx-table">${s.tools.map(t => `<div class="mx-row"><div class="mx-grow"><strong>${esc(t)}</strong><small>Available when this server is connected</small></div>${badge(s.enabled ? s.status : "Disabled")}</div>`).join("")}</div>`, null) },
    "hook-test": id => { const h = P.hooks.find(x => x.id === id); h.runs++; h.lastRun = `${h.event}\n${h.action}: ${h.value}\nPreview test completed. No command executed.`; persist(); renderOpenPage() },
    "agent-edit": editAgent, "agent-chat": name => createSession(`Work with ${name}`, "", name),
    "agent-remove": name => confirmAction(`Remove ${name}?`, "Existing sessions keep their recorded model and conversation.", () => { P.agents = P.agents.filter(a => a.name !== name); renderAgents(); renderProfileSwitcher() }),
    "remove-config": value => { const [key, id] = value.split(":"); confirmAction("Remove this item?", "Its configuration is removed from this profile.", () => { P[key] = P[key].filter(x => x.id !== id) }) },
    "model-toggle": id => { P.enabledModels = P.enabledModels.includes(id) ? P.enabledModels.filter(x => x !== id) : [...P.enabledModels, id]; persist(); renderOpenPage() },
    "pipeline-edit": editPipeline, "pipeline-run": runPipeline,
    "pipeline-stop": id => { const key = P.id + ":" + id; clearTimeout(jobs.get(key)); jobs.delete(key); const p = P.pipelines.find(x => x.id === id); p.status = "Cancelled"; p.logs += "\nCancelled by you."; persist(); renderOpenPage() },
    "pipeline-logs": id => { const p = P.pipelines.find(x => x.id === id); modal(`${p.name} · logs`, `${p.branch} · ${p.status}`, `<pre class="mx-log" data-mx-pipeline-log="${esc(id)}">${esc(p.logs || "No runs yet.")}</pre>${button("Download logs", "pipeline-download", id)}`, null) },
    "pipeline-download": id => { const p = P.pipelines.find(x => x.id === id); download(`${p.name}.log`, p.logs) },
    "schedule-edit": editSchedule,
    "schedule-run": id => { const s = P.schedules.find(x => x.id === id); s.runs++; s.lastRun = new Date().toLocaleString(); if (s.cadence === "Once") s.enabled = false; else s.nextRun = new Date(Date.now() + ({ "Every hour": 3600000, Daily: 86400000, Weekly: 604800000 }[s.cadence] || 86400000)).toISOString(); persist(); const session = createSession(s.name, s.prompt, s.agent); window.Mock.start?.(session) },
    "schedule-toggle": id => { const s = P.schedules.find(x => x.id === id); s.enabled = !s.enabled; persist(); renderOpenPage() },
    "env-edit": editEnv, "env-open": () => { envInput.dataset.owner = P.id; envInput.click() }, "env-download": () => download(".env", envText()),
    "env-preview": () => modal(".env", `${P.name} · current preview`, `<pre class="mx-log">${esc(envText())}</pre>`, null),
    "env-reveal": key => { const r = P.envRecords.find(x => x.key === key); r.revealed = !r.revealed; renderOpenPage() },
    "env-remove": key => confirmAction(`Remove ${key}?`, "The key is removed from this profile's preview. Download to save the file.", () => { P.envRecords = P.envRecords.filter(r => r.key !== key) }),
    "workspace-edit": editWorkspace,
    "workspace-use": id => { P.workspaces.forEach(w => { w.active = w.id === id }); persist(); renderWorkspaces(); setView("session") },
    "workspace-delete": id => confirmAction("Delete workspace?", "Only the sample workspace record is removed.", () => { P.workspaces = P.workspaces.filter(w => w.id !== id); renderWorkspaces() }),
    "profile-edit": id => { toggleProfileMenu(false); editProfile(id) }, "profile-new": () => { toggleProfileMenu(false); editProfile("new") },
  }
  const toggleCollections = { "mcp-toggle": "mcpServers", "skill-toggle": "skills", "plugin-toggle": "llmPlugins", "hook-toggle": "hooks" }
  document.addEventListener("click", e => {
    if (!(e.target instanceof Element)) return
    const nav = e.target.closest("[data-mx-nav]")
    if (nav) { e.preventDefault(); e.stopImmediatePropagation(); menu.hidden = true; setView(nav.dataset.mxNav); return }
    if (e.target.closest('#pop [data-act="manage"]')) { e.preventDefault(); e.stopImmediatePropagation(); closePopover(); setView("settings"); document.querySelector('[data-sec="models"]').click(); return }
    const btn = e.target.closest("[data-mx-action]")
    if (!btn) return
    e.preventDefault(); e.stopImmediatePropagation()
    menu.hidden = true
    const action = btn.dataset.mxAction
    if (toggleCollections[action]) {
      const item = P[toggleCollections[action]].find(x => x.id === btn.dataset.id)
      item.enabled = !item.enabled
      persist(); renderOpenPage(); return
    }
    actions[action]?.(btn.dataset.id, btn)
  }, true)
  document.addEventListener("input", e => {
    if (!e.target.matches?.("[data-mx-search]")) return
    const q = e.target.value.toLowerCase()
    e.target.closest(".inner").querySelectorAll("[data-mx-card]").forEach(card => { card.hidden = !card.textContent.toLowerCase().includes(q) })
  })
  document.addEventListener("change", e => {
    if (e.target.matches?.("[data-mx-route]")) { P.routerID = e.target.value; persist() }
  })

  // Session-owned preview data. The DOM is a projection, never the transcript store.
  const seedTranscript = document.querySelector("#viewSession .scroll").innerHTML
  const seedFiles = structuredClone(CHANGED)
  const seedAllFiles = [...ALL_FILES]
  const current = () => P.sessions.find(s => s.id === openSessionID)
  const isCurrent = (owner, session) => owner === P && session.id === openSessionID
  const fileStems = { s2: "session-recovery", s3: "provider-keys", s4: "preview-shell", s5: "asset-cache", s6: "session-drain" }
  function prepareSession(session) {
    if (session.prepared) return
    session.prepared = true
    session.extras ||= []
    session.draft ||= ""
    session.attachments ||= []
    session.contextFiles ||= []
    session.pendingPrompts ||= []
    session.agent ||= "Maestro"
    const agent = P.agents.find(a => a.name === session.agent) || P.agents[0]
    session.taskRecords = session.prompt ? [
      { title: session.title, agent: agent?.name || "Maestro", kind: "Agent", model: session.model?.id || agent?.model || P.model, tools: 4, fails: 0 },
      { title: "Validate changes", agent: P.agents.find(a => a.name === "Atlas")?.name || agent?.name || "Maestro", kind: "Shell", model: P.agents.find(a => a.name === "Atlas")?.model || P.model, tools: 2, fails: 0 },
      { title: "Update documentation", agent: P.agents.find(a => a.name === "Scribe")?.name || agent?.name || "Maestro", kind: "Agent", model: P.model, tools: 1, fails: 0 },
    ] : []
    if (session.id === "s1") session.fileRecords = structuredClone(seedFiles)
    else session.fileRecords = Array.from({ length: session.files || 0 }, (_, i) => {
      const stem = fileStems[session.id] || "session"
      const path = i === 0 ? `src/${stem}.ts` : i === 1 ? `tests/${stem}.test.ts` : i === 2 ? `docs/${stem}.md` : `src/${stem}/part-${i}.ts`
      const code = path.endsWith(".md") ? `# ${session.title}\n\nObserved behavior and verification for ${P.name}.\n` : `// ${session.title}\nexport const profile = ${JSON.stringify(P.name)}\nexport const branch = ${JSON.stringify(session.branch)}\nexport function ready() {\n  return true\n}\n`
      return { path, add: Math.max(1, Math.round((session.add || 6) / Math.max(session.files, 1))), del: Math.round((session.del || 0) / Math.max(session.files, 1)), content: code, diff: code.trimEnd().split("\n").map((line, n) => [n + 1, line, "+"]) }
    })
    session.fileRecords.forEach(file => { file.content ||= file.diff.filter(line => line[2] !== "-").map(line => String(line[1]).replace(/^[+-]/, "")).join("\n") + "\n" })
    session.allFilePaths = session.id === "s1" ? [...seedAllFiles] : [...session.fileRecords.map(f => f.path), "README.md", "package.json"]
    session.selectedFile = session.fileRecords[0]?.path || ""
    session.replyCount = 0
  }
  const sessionCSS = document.createElement("style")
  sessionCSS.textContent = `
    .mx-extra p{white-space:pre-wrap}.mx-extra .when{margin-left:8px}.mx-answer-note{display:block;margin-top:8px;color:var(--mx-dim);font-size:10px}
    .composer{display:grid;grid-template-columns:minmax(0,1fr) auto auto auto auto;row-gap:10px;height:auto;min-height:90px;padding:12px 14px}
    .composer>input{grid-column:1/-1;width:100%;height:28px;min-width:0}
    .mx-compose-tools{display:flex;min-width:0;align-items:center;gap:6px}
    .mx-compose-tools .mx-btn{min-height:26px;padding:0 7px;font-size:10.5px}
    .mx-attachments{grid-column:1/-1;display:flex;flex-wrap:wrap;gap:6px}.mx-attachment{display:inline-flex;align-items:center;gap:6px;max-width:220px;padding:4px 6px;border:1px solid var(--mx-line);border-radius:6px;background:var(--mx-soft);color:var(--mx-dim);font-size:10px}
    .mx-attachment img{width:28px;height:28px;object-fit:cover;border-radius:3px}.mx-attachment button{padding:0;border:0;background:transparent;color:inherit;font:inherit;cursor:pointer}
    .mx-task-detail{display:grid;grid-template-columns:1fr 1fr;gap:10px}.mx-question{margin:0 30px 8px}.mx-question p{color:var(--mx-dim);font-size:12px}
    .mx-choice{display:flex;gap:9px;align-items:center;padding:8px 10px;border:1px solid var(--mx-line);border-radius:7px;color:var(--mx-strong);font-size:12px;background:var(--mx-soft);cursor:pointer}
    .mx-choices{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px}.mx-question textarea{width:100%;min-height:52px;border:1px solid var(--mx-line);border-radius:7px;background:var(--mx-raised);color:var(--mx-strong);padding:8px;font:12px/1.5 inherit}
    .mx-question-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:9px}.mx-image-preview{display:block;max-width:100%;max-height:480px;margin:0 auto;border-radius:8px}
    .mx-task-button{display:block;width:100%;text-align:left;border:0;background:transparent;color:inherit;font:inherit;cursor:pointer}
  `
  document.head.append(sessionCSS)
  const composer = document.querySelector(".composer")
  const composeTools = document.createElement("div")
  composeTools.className = "mx-compose-tools"
  composer.insertBefore(composeTools, composer.querySelector(".ctl"))
  const attachmentsBar = document.createElement("div")
  attachmentsBar.className = "mx-attachments"
  composer.prepend(attachmentsBar)
  const attachmentInput = document.createElement("input")
  attachmentInput.type = "file"; attachmentInput.multiple = true; attachmentInput.hidden = true; attachmentInput.dataset.mxAttachmentInput = "true"
  document.body.append(attachmentInput)
  const questionDock = document.createElement("section")
  questionDock.className = "perm mx-question"
  questionDock.id = "questionDock"
  questionDock.hidden = true
  composer.before(questionDock)
  STATES.question = { ...STATES.permission, perm: false, pending: false, ck: ["Waiting for your answer", "now"], home: ["needs input", "wait"] }
  const questionDemo = document.createElement("button")
  questionDemo.dataset.state = "question"; questionDemo.textContent = "Question"
  stateSwitch.append(questionDemo)
  questionDemo.addEventListener("click", () => setState("question"))

  function renderCompose(session) {
    composeTools.innerHTML = `<button class="mx-btn" data-mx-action="attach" aria-label="Attach file">${icon("plus")}</button><button class="mx-btn" data-mx-action="context-files" aria-label="Add files to context">${icon("file")}</button>${button(P.delivery || "Steer", "delivery-mode")}${["running", "permission", "question"].includes(session.live) || session.executing ? button("Stop", "stop-run") : ""}${session.pendingPrompts.length ? badge(`${session.pendingPrompts.length} pending`) + (!session.executing && !session.waitingForResponse ? button("Resume", "resume-pending") : "") : ""}`
    attachmentsBar.innerHTML = session.attachments.map((a, i) => `<span class="mx-attachment">${a.image ? `<img src="${a.content}" alt="">` : icon("file")}<button data-mx-action="attachment-view" data-id="${i}">${esc(a.name)}</button><button data-mx-action="attachment-remove" data-id="${i}" aria-label="Remove ${esc(a.name)}">×</button></span>`).join("") + session.contextFiles.map(path => `<span class="mx-attachment">${icon("file")}<span>${esc(path)}</span><button data-mx-action="context-remove" data-id="${esc(path)}" aria-label="Remove ${esc(path)}">×</button></span>`).join("")
    attachmentsBar.hidden = !session.attachments.length && !session.contextFiles.length
    document.querySelector(".composer input").value = session.draft
  }
  function entryHTML(entry) {
    return `<article class="msg mx-extra" data-entry="${esc(entry.id)}"><span class="task-mark">${icon(entry.role === "user" ? "file" : "skills")}</span><div><span class="who">${esc(entry.role === "user" ? "You" : entry.agent || "Maestro")}</span><span class="when">${esc(entry.time || "just now")}</span><p>${esc(entry.text)}</p>${entry.attachments?.length ? `<div class="mx-meta" style="margin-top:8px">${entry.attachments.map((a, i) => button(a.name, "message-attachment", entry.id + ":" + i)).join("")}</div>` : ""}${entry.role === "assistant" ? `<span class="mx-answer-note">Simulated response${entry.plugin ? ` · ${esc(entry.plugin)}` : ""}${entry.streaming ? " · streaming" : ""}</span>` : ""}</div></article>`
  }
  function renderExtras(session) {
    const scroll = document.querySelector("#viewSession .scroll")
    scroll.querySelectorAll(".mx-extra").forEach(e => e.remove())
    session.extras.forEach(entry => scroll.insertAdjacentHTML("beforeend", entryHTML(entry)))
    if (session.executing) {
      document.getElementById("tailRunning").hidden = true
      document.getElementById("msgPlan").hidden = true
    }
    document.getElementById("msgUser").hidden = !session.prompt
    if (session.extras.length) scroll.scrollTop = scroll.scrollHeight
  }
  function renderTasks(session) {
    const statuses = STATES[session.live]?.tasks || STATES.idle.tasks
    const ids = ["Refactor", "Test", "Docs"]
    const body = document.querySelector('.rail-panel[data-panel="tasks"] .card')
    body.innerHTML = ids.map((suffix, i) => {
      const task = session.taskRecords[i]
      const status = task?.status || statuses[i]?.[1] || "completed"
      return `<div class="task" id="task${suffix}"${task ? "" : " hidden"}><span class="task-mark">${icon(task?.kind === "Shell" ? "env" : "skills")}</span><div class="mx-grow"><button class="mx-task-button" data-mx-action="task-detail" data-id="${i}"><div class="task-title">${esc(task?.title || "")}</div><div class="task-meta">${esc(task?.agent || "")} · ${esc(task?.kind || "")}</div></button></div><span class="task-state${status === "needs input" ? " now" : ""}${status === "failed" ? " bad" : ""}" id="state${suffix}">${esc(status)}</span></div>`
    }).join("")
    const active = session.taskRecords.filter((t, i) => ["running", "needs input"].includes(t.status || statuses[i]?.[1])).length
    document.getElementById("tabTasksBadge").textContent = active
    if (!session.taskRecords.length) body.insertAdjacentHTML("beforeend", `<div class="mx-empty">No background work running.</div>`)
  }
  function systemInstructions(session) {
    const agent = P.agents.find(a => a.name === session.agent) || P.agents[0]
    const hookInstructions = [...new Map((session.hookEvents || []).filter(e => e.action === "Add instruction").map(e => [e.name, e.value])).values()]
    return [agent?.system || "You are Orchestra, a coding assistant.", ...P.llmPlugins.filter(p => p.enabled).map(p => `${p.name} (${p.intensity}): ${p.instructions}`), ...P.skills.filter(s => s.enabled).map(s => `Available skill: ${s.name} — ${s.description}`), ...P.skills.filter(s => session.usedSkills?.includes(s.id)).map(s => `Loaded skill ${s.name}:\n${s.instructions}`), ...hookInstructions].join("\n\n")
  }
  function renderContext(session) {
    const model = session.model?.id || P.model
    const catalog = MODELS.find(m => m[0] === model.split("/").at(-1))
    const tokens = Math.round((session.tokens || 0) * 1000)
    const limit = catalog?.[5]
    const estimates = [systemInstructions(session).length, session.prompt.length + session.extras.filter(e => e.role === "user").reduce((sum, e) => sum + e.text.length, 0), session.extras.filter(e => e.role === "assistant").reduce((sum, e) => sum + e.text.length, 0), session.taskRecords.reduce((sum, t) => sum + (t.output?.length || 0), 0)].map(n => Math.ceil(n / 4))
    const windowTokens = estimates.reduce((sum, n) => sum + n, 0)
    const stats = [["Session", session.title], ["Messages", (session.prompt ? 1 : 0) + session.extras.length], ["Provider", session.model?.providerID || P.routerID], ["Model", model], ["Context Limit", limit?.toLocaleString() || "—"], ["Total Tokens", tokens.toLocaleString()], ["Usage", limit ? `${Math.round(windowTokens / limit * 100)}%` : "—"], ["User Messages", (session.prompt ? 1 : 0) + session.extras.filter(e => e.role === "user").length], ["Assistant Messages", session.extras.filter(e => e.role === "assistant").length], ["Total Cost", "$" + (tokens * .0000015).toFixed(2)]]
    const colors = ["var(--mx-blue)", "var(--mx-good)", "var(--warm)", "var(--mx-dim)"]
    document.querySelector('.rail-panel[data-panel="context"] .ctx').innerHTML = `<div class="ctx-stats">${stats.map(([name, value]) => `<div class="ctx-stat"><span>${name}</span><b>${esc(value)}</b></div>`).join("")}</div><div class="ctx-title">Context Breakdown</div><div class="ctx-bar">${estimates.map((n, i) => `<i style="flex:${Math.max(n, 1)};background:${colors[i]}"></i>`).join("")}</div><div class="ctx-note">Estimated current window: ${windowTokens.toLocaleString()} tokens · system / user / assistant / tools. Estimates use character counts; cumulative session spending is separate.</div><div class="ctx-title">System Prompt</div><pre class="ctx-pre">${esc(systemInstructions(session))}</pre><div class="ctx-title">Raw messages</div><button class="mx-btn" data-mx-action="raw-messages">View messages</button><button class="btn ctx-export" data-mx-action="session-export">Export session</button>`
  }
  function renderSessionFiles(session) {
    CHANGED.splice(0, CHANGED.length, ...session.fileRecords)
    ALL_FILES.splice(0, ALL_FILES.length, ...session.allFilePaths)
    PALETTE_FILES.splice(0, PALETTE_FILES.length, ...session.allFilePaths)
    selectedFile = session.selectedFile
    renderFileList(); renderDiff()
    document.querySelector('#railTabs [data-panel="review"] .badge').textContent = session.fileRecords.length
    document.querySelector('#reviewSubTabs [data-sub="changed"]').textContent = `Files Changed ${session.fileRecords.length}`
    renderEditor(session, selectedFile)
  }
  function renderEditor(session, path) {
    if (!path) path = session.allFilePaths[0] || "README.md"
    const file = session.fileRecords.find(f => f.path === path)
    const content = file?.content || (path === "package.json" ? JSON.stringify({ name: P.name, scripts: { build: "bun run build", test: "bun test" } }, null, 2) : `# ${P.name}\n\nSample project file: ${path}\nBranch: ${session.branch}\n`)
    document.getElementById("editorTabName").textContent = path.split("/").at(-1)
    const editor = document.querySelector('.rail-panel[data-panel="editor"] .editor')
    editor.innerHTML = `<div class="editor-bar">${esc(path)}<span class="caret">${content.split("\n").length} lines</span></div><pre>${content.split("\n").map((line, i) => `<span class="unchanged" style="display:block"><span class="ln">${i + 1}</span> ${esc(line)}</span>`).join("")}</pre>`
  }
  const baseSelectFile = selectFile
  selectFile = function(path) {
    baseSelectFile(path)
    const session = current()
    if (!session) return
    session.selectedFile = path
    renderEditor(session, path)
  }
  const baseOpenSession = applyOpenSession
  applyOpenSession = function() {
    const session = current()
    if (!session) return
    prepareSession(session)
    document.querySelector("#viewSession .scroll").innerHTML = seedTranscript
    baseOpenSession()
    const agent = P.agents.find(a => a.name === session.agent) || P.agents[0]
    document.querySelector("#msgPlan .who").textContent = agent?.name || "Maestro"
    document.querySelector("#msgPlan p").textContent = session.id === "s1" ? "Analyzing the current approval system and preparing a refactor plan." : `Planning work for ${session.title}.`
    document.querySelector("#tailRunning .who").textContent = P.agents.find(a => a.name === "Atlas")?.name || agent?.name || "Maestro"
    if (session.id !== "s1") {
      document.querySelector("#msgPlan .ck").innerHTML = `<li class="done">Read the instructions for ${esc(P.name)}</li><li class="done">Reviewed the session's context</li><li id="ckLast" class="${["error", "denied"].includes(session.live) ? "bad" : "now"}">${esc(STATES[session.live]?.ck[0] || "Ready for work")}</li>`
      document.querySelector("#tailRunning p").textContent = `Work in progress: ${session.title}.`
      document.querySelector("#tailRunning .ev-card pre").textContent = `Sample execution for ${P.name}\n${session.fileRecords.length} session files\nModel: ${session.model?.id || P.model}`
      document.querySelector("#tailError p").textContent = `Validation failed for ${session.title}. Inspect the sample failure before retrying.`
    }
    renderExtras(session); renderSessionFiles(session); renderContext(session); renderCompose(session); renderTasks(session); renderQuestion(session)
  }
  const baseState = setState
  setState = function(name) {
    const session = current()
    if (session) prepareSession(session)
    baseState(name)
    if (!session) return
    session.waitingForResponse = name === "permission" || name === "question"
    updateSessionLogo(session)
    if (name === "question" && !session.question) session.question = { title: "How should we proceed?", choices: ["Focused change", "Full review", "Tests first", "Explain the plan"], multiple: false, text: "Choose one option or write a custom answer." }
    renderQuestion(session); renderTasks(session); renderContext(session); renderCompose(session)
    if (session.executing) document.getElementById("tailRunning").hidden = true
  }
  function renderQuestion(session) {
    questionDock.hidden = session.live !== "question"
    if (questionDock.hidden) return
    const question = session.question
    questionDock.innerHTML = `<header class="perm-head">${icon("skills")}<span class="perm-title">${esc(question.title)}</span></header><div class="perm-body"><p>${esc(question.text)}</p><div class="mx-choices">${question.choices.map((choice, i) => `<label class="mx-choice"><input type="${question.multiple ? "checkbox" : "radio"}" name="question-choice" value="${i}"><span>${esc(choice)}</span></label>`).join("")}</div><textarea aria-label="Custom answer" placeholder="Or write your answer…"></textarea><p class="mx-error" hidden></p><div class="mx-question-actions">${button("Multiple choice", "question-multiple")}${button("Skip question", "question-skip")}${button("Send answer", "question-answer", "", true)}</div></div>`
  }
  function rawMessages(session) {
    return [...(session.prompt ? [{ role: "user", content: session.prompt }] : []), ...session.extras.map(e => ({ role: e.role, content: e.text, model: e.model, attachments: e.attachments?.map(a => ({ name: a.name, size: a.size })) }))]
  }
  function taskDetail(index) {
    const task = current().taskRecords[index]
    if (!task) return
    modal(task.title, `${task.agent} · ${task.kind}`, `<div class="mx-task-detail">${[["Model", task.model], ["Agent", task.agent], ["Tools", task.tools], ["Fails", task.fails]].map(([k, value]) => `<div class="mx-card"><small>${k}</small><h3>${esc(value)}</h3></div>`).join("")}</div><pre class="mx-log">${esc(task.output || "Sample task details. Tool results are recorded here during simulated execution.")}</pre>${button("Open child session", "task-open", index)}`, null)
  }
  function chooseContext() {
    const s = current()
    modal("Add files to context", "Selection belongs to this session.", `<div class="mx-table">${s.allFilePaths.map(path => `<label class="mx-row"><input type="checkbox" name="file" value="${esc(path)}"${s.contextFiles.includes(path) ? " checked" : ""}><code>${esc(path)}</code></label>`).join("")}</div>`, data => { s.contextFiles = data.getAll("file"); renderCompose(s) }, "Add selection")
  }
  attachmentInput.addEventListener("change", async () => {
    const owner = PROFILES[attachmentInput.dataset.owner] || P
    const s = owner.sessions.find(s => s.id === attachmentInput.dataset.session) || current()
    for (const file of attachmentInput.files) {
      if (file.size > 5 * 1024 * 1024) { modal("File too large", "Preview accepts files up to 5 MB.", `<p>${esc(file.name)}</p>`, null); continue }
      const image = file.type.startsWith("image/")
      const content = image ? await new Promise(resolve => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.readAsDataURL(file) }) : await file.text()
      s.attachments.push({ name: file.name, size: file.size, image, content })
    }
    attachmentInput.value = ""
    if (isCurrent(owner, s)) renderCompose(s)
  })
  document.querySelector(".composer input").addEventListener("input", e => { if (current()) current().draft = e.target.value })
  Object.assign(actions, {
    attach: () => { attachmentInput.dataset.owner = P.id; attachmentInput.dataset.session = openSessionID; attachmentInput.click() }, "context-files": chooseContext,
    "attachment-view": id => { const a = current().attachments[Number(id)]; modal(a.name, `${a.size.toLocaleString()} bytes`, a.image ? `<img class="mx-image-preview" src="${a.content}" alt="${esc(a.name)}">` : `<pre class="mx-log">${esc(a.content)}</pre>`, null) },
    "message-attachment": value => { const [id, index] = value.split(":"); const a = current().extras.find(e => e.id === id).attachments[Number(index)]; modal(a.name, `${a.size.toLocaleString()} bytes`, a.image ? `<img class="mx-image-preview" src="${a.content}" alt="${esc(a.name)}">` : `<pre class="mx-log">${esc(a.content)}</pre>`, null) },
    "attachment-remove": id => { current().attachments.splice(Number(id), 1); renderCompose(current()) },
    "context-remove": path => { current().contextFiles = current().contextFiles.filter(p => p !== path); renderCompose(current()) },
    "raw-messages": () => modal("Raw messages", current().title, `<pre class="mx-log">${esc(JSON.stringify(rawMessages(current()), null, 2))}</pre>`, null),
    "session-export": () => download(`${current().title}.json`, JSON.stringify({ profile: P.name, session: current().title, model: current().model, messages: rawMessages(current()) }, null, 2), "application/json"),
    "task-detail": taskDetail,
    "task-open": index => { const parent = current(), task = parent.taskRecords[Number(index)]; dialog.close(); const child = createSession(task.title, `Inspect the results of ${task.title}.`, task.agent); child.parentID = parent.id; applyOpenSession() },
    "delivery-mode": () => modal("Follow-up behavior", "Steer at the next safe turn boundary; queue when execution becomes idle.", select("Delivery", "delivery", P.delivery || "Steer", ["Steer", "Queue"]), data => { P.delivery = data.get("delivery"); renderCompose(current()) }),
  })

  const turns = new Map()
  function projectSession(owner, session) {
    if (!isCurrent(owner, session)) return
    setState(session.live)
    renderExtras(session); renderCompose(session); renderTasks(session); renderContext(session)
  }
  function userEntry(session, text, attachments = [], contextFiles = []) {
    const entry = { id: crypto.randomUUID(), role: "user", text, attachments, contextFiles, time: "just now" }
    session.extras.push(entry)
    session.tokens += Math.max(1, text.length / 4) / 1000
    return entry
  }
  function replyText(owner, session, request) {
    const caveman = owner.llmPlugins.find(p => p.id === "caveman" && p.enabled)
    const names = session.contextFiles.length ? session.contextFiles.join(", ") : `${session.fileRecords.length} project files`
    if (caveman?.intensity === "ultra") return `Context: ${names}.\n${session.title} → reviewed. Next → validate, report evidence.\nRequest: ${request}`
    if (caveman?.intensity === "full") return `Context reviewed: ${names}.\nPlan: inspect source, make focused change, validate.\nRequest: ${request}\nResults stay in this session. No external commands ran.`
    return `I reviewed the context for “${session.title}” in ${owner.name}.\n\nFor your request, “${request}”, I would inspect ${names}, make the smallest useful change, and validate it with the project's checks.\n\nThis is a simulated answer. The transcript, tools and context are recorded separately for this session.`
  }
  function startTurn(owner, session, text, options = {}) {
    prepareSession(session)
    const agent = owner.agents.find(a => a.name === session.agent) || owner.agents[0]
    if (!agent) { session.live = "error"; projectSession(owner, session); return }
    if (!owner.providers.some(p => p.id === session.model.providerID && p.status === "Connected")) {
      session.live = "error"; session.executing = false
      session.extras.push({ id: crypto.randomUUID(), role: "assistant", agent: agent.name, text: "Connect this session's provider before executing the next turn.", time: "just now" })
      projectSession(owner, session); return
    }
    session.pendingTurn = { text, options }
    const asks = /\b(ask|question|choose|confirm|pergunt|escolh)\b/i.test(text)
    const shell = /\b(test|tests|bun|npm|shell|terminal)\b/i.test(text)
    if (asks && !options.answered) {
      session.question = { title: "Which approach do you prefer?", text: "Choose an approach before the next simulated turn.", choices: ["Focused change", "Broader refactor", "Tests first", "Explain the plan"], multiple: false }
      session.live = "question"; session.executing = false; session.waitingForResponse = true
      projectSession(owner, session); return
    }
    const policy = owner.perms.bash === "deny" || agent.permissionOverrides?.bash === "deny" ? "deny" : agent.permissionOverrides?.bash || owner.perms.bash
    if (shell && (policy === "deny" || (!options.allowed && policy === "ask" && !owner.permissionGrants?.includes("bun test *")))) {
      session.executing = false
      session.live = policy === "deny" ? "denied" : "permission"
      projectSession(owner, session); return
    }
    session.executing = true; session.live = "running"; session.waitingForResponse = false
    session.usedSkills = owner.skills.filter(s => s.enabled && (text.includes("@" + s.id) || text.toLowerCase().includes("/skill " + s.name.toLowerCase()))).map(s => s.id)
    session.taskRecords = [{ title: `Work on ${session.title}`, agent: agent.name, kind: "Agent", model: session.model.id, tools: 0, fails: 0, status: "running", output: "Reading session context…" }]
    runHooks("Before prompt", session, owner)
    runHooks("Before tool", session, owner)
    const response = { id: crypto.randomUUID(), role: "assistant", agent: agent.name, text: "", time: "just now", streaming: true, model: { ...session.model }, plugin: owner.llmPlugins.filter(p => p.enabled).map(p => p.name).join(", ") }
    const words = replyText(owner, session, text).match(/\S+\s*/g) || []
    const run = { owner, session, response, words, index: 0, timer: null }
    turns.set(session.id, run)
    projectSession(owner, session)
    function advance() {
      if (turns.get(session.id) !== run) return
      if (!session.extras.includes(response)) session.extras.push(response)
      run.index = Math.min(run.index + 5, words.length)
      response.text = words.slice(0, run.index).join("")
      session.taskRecords[0].tools = Math.min(4, Math.ceil(run.index / 15))
      session.taskRecords[0].output = `Session: ${session.title}\nModel: ${session.model.id}\nContext files: ${session.contextFiles.length}\nPreview: processing ${run.index}/${words.length} response chunks.`
      if (run.index < words.length) {
        projectSession(owner, session)
        run.timer = setTimeout(advance, 100)
        return
      }
      response.streaming = false; session.replyCount++; session.executing = false
      if (/\b(refactor|change|fix|build|update|edit|patch|implement|corrigir|alterar|atualizar)\b/i.test(text)) {
        const path = "preview/session-change.ts"
        const content = `// Generated preview, not a repository write.\nexport const profile = ${JSON.stringify(owner.name)}\nexport const request = ${JSON.stringify(text)}\nexport const model = ${JSON.stringify(session.model.id)}\n`
        const record = { path, content, add: 4, del: 0, diff: content.trimEnd().split("\n").map((line, i) => [i + 1, line, "+"]) }
        const i = session.fileRecords.findIndex(f => f.path === path)
        if (i < 0) session.fileRecords.push(record); else session.fileRecords[i] = record
        if (!session.allFilePaths.includes(path)) session.allFilePaths.push(path)
        session.files = session.fileRecords.length
        response.text += "\n\nA generated preview is available in Review."
        if (isCurrent(owner, session)) renderSessionFiles(session)
      }
      session.tokens += Math.max(1, response.text.length / 4) / 1000
      session.taskRecords[0].status = "completed"
      session.taskRecords[0].output += "\nSimulated execution complete. No external command executed."
      session.live = "idle"; session.pendingTurn = undefined
      turns.delete(session.id)
      runHooks("After tool", session, owner); runHooks("Session idle", session, owner)
      projectSession(owner, session)
      if (owner === P) renderSessionRows()
      drainPending(owner, session)
    }
    run.timer = setTimeout(advance, 450)
  }
  function drainPending(owner, session) {
    if (!session.pendingPrompts.length || session.executing) return
    const steers = session.pendingPrompts.filter(p => p.delivery === "Steer")
    const next = steers.length ? steers : [session.pendingPrompts[0]]
    session.pendingPrompts = session.pendingPrompts.filter(p => !next.includes(p))
    next.forEach(p => userEntry(session, p.text, p.attachments, p.contextFiles))
    session.model = next.at(-1).model
    session.contextFiles = [...next.at(-1).contextFiles]
    startTurn(owner, session, next.map(p => p.text).join("\n"))
  }
  function submitMessage() {
    const session = current()
    if (!session) return
    const input = document.querySelector(".composer input")
    const text = input.value.trim()
    if (!text) { input.focus(); return }
    if (!P.enabledModels.includes(P.model)) { modal("Choose an enabled model", "Enable a model in Settings before sending.", modelsBody(), null); return }
    const model = { id: P.model, providerID: P.routerID, variant: P.effort }
    const attachments = [...session.attachments], contextFiles = [...session.contextFiles]
    input.value = ""; session.draft = ""; session.attachments = []
    if (session.executing || session.waitingForResponse) {
      session.pendingPrompts.push({ text, model, attachments, contextFiles, delivery: P.delivery || "Steer" })
      renderCompose(session); return
    }
    if (session.title === "New session") {
      session.title = text.slice(0, 54)
      session.sub = text.slice(0, 160)
      document.getElementById("convTitle").textContent = session.title
      document.getElementById("convSub").textContent = session.sub
    }
    userEntry(session, text, attachments, contextFiles)
    session.model = model
    setView("session"); renderChatSessions(); renderSessionRows()
    startTurn(P, session, text)
  }
  function stopRun(session = current()) {
    if (!session) return
    const run = turns.get(session.id)
    if (run) {
      clearTimeout(run.timer); turns.delete(session.id)
      run.response.streaming = false
      if (session.extras.includes(run.response)) run.response.text += "\n\nStopped by you."
    }
    session.executing = false; session.pendingTurn = undefined; session.live = "idle"; session.waitingForResponse = false
    session.taskRecords.forEach(t => { t.status = "cancelled"; t.output = "Stopped by you. No further preview work was performed." })
    projectSession(P, session)
  }
  const basePermission = resolvePermission
  resolvePermission = function(outcome) {
    const session = current()
    if (!session) return basePermission(outcome)
    if (outcome === "always") {
      P.permissionGrants ||= []
      if (!P.permissionGrants.includes("bun test *")) P.permissionGrants.push("bun test *")
    }
    basePermission(outcome)
    if (outcome === "deny") {
      session.pendingTurn = undefined; session.live = "denied"; session.waitingForResponse = false
      projectSession(P, session); return
    }
    if (session.pendingTurn) startTurn(P, session, session.pendingTurn.text, { ...session.pendingTurn.options, allowed: true })
  }
  syncPermissionMemory = function() {
    const code = document.querySelector("#permDock .perm-patterns code")
    if (code) code.textContent = P.permissionGrants?.includes("bun test *") ? "bun test *  (always allowed)" : "bun test *"
  }
  function answerQuestion(skip) {
    const session = current()
    const chosen = [...questionDock.querySelectorAll('input:checked')].map(input => session.question.choices[Number(input.value)])
    const text = questionDock.querySelector("textarea").value.trim()
    if (!skip && !chosen.length && !text) { const error = questionDock.querySelector(".mx-error"); error.textContent = "Choose an option or write your answer."; error.hidden = false; return }
    userEntry(session, skip ? "Skipped the question; continue with the default approach." : `Answer: ${[...chosen, text].filter(Boolean).join(" · ")}`)
    const pending = session.pendingTurn
    session.question = undefined
    startTurn(P, session, pending?.text || "Continue with the selected plan", { ...pending?.options, answered: true })
  }
  Object.assign(actions, {
    "stop-run": () => stopRun(),
    "question-answer": () => answerQuestion(false), "question-skip": () => answerQuestion(true),
    "question-multiple": () => { current().question.multiple = !current().question.multiple; renderQuestion(current()) },
    "resume-pending": () => drainPending(P, current()),
  })
  document.addEventListener("click", e => {
    if (!(e.target instanceof Element)) return
    if (e.target.closest('#chatTabs [data-act="newsession"]')) { e.preventDefault(); e.stopImmediatePropagation(); createSession(); return }
    if (e.target.closest(".send")) { e.preventDefault(); e.stopImmediatePropagation(); submitMessage() }
    const permission = e.target.closest("#settingsBody .seg button")
    if (permission) {
      e.preventDefault(); e.stopImmediatePropagation()
      const seg = permission.closest(".seg"), tool = seg.dataset.tool
      P.perms[tool] = permission.dataset.v
      seg.querySelectorAll("button").forEach(b => b.classList.toggle("on", b === permission))
      if (tool === "bash" && current()?.live === "permission" && permission.dataset.v !== "ask") resolvePermission(permission.dataset.v === "allow" ? "once" : "deny")
      persist()
    }
  }, true)
  document.querySelector(".composer input").addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submitMessage() }
  })
  document.addEventListener("paste", async e => {
    if (e.target !== document.querySelector(".composer input")) return
    const image = [...(e.clipboardData?.items || [])].find(item => item.type.startsWith("image/"))?.getAsFile()
    if (!image) return
    e.preventDefault()
    const session = current(), owner = P
    const content = await new Promise(resolve => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.readAsDataURL(image) })
    session.attachments.push({ name: image.name, size: image.size, image: true, content })
    if (isCurrent(owner, session)) renderCompose(session)
  })
  window.addEventListener("keydown", e => {
    if (!e.metaKey && !e.ctrlKey) return
    if (dialog.open) return
    const binding = `${e.metaKey ? "⌘" : ""}${e.ctrlKey ? "⌃" : ""}${e.altKey ? "⌥" : ""}${e.shiftKey ? "⇧" : ""}${e.key.toUpperCase()}`
    const action = Object.entries(P.shortcuts).find(([, key]) => key === binding)?.[0]
    if (!action) return
    e.preventDefault(); e.stopImmediatePropagation()
    if (action === "Command palette") { palette.hidden ? openPalette() : closePalette(); return }
    if (action === "New session") { createSession(); return }
    if (action === "Choose model") { setView("session"); document.querySelector('.ctl[data-menu="model"]').click(); return }
    if (action === "Close tab") { document.querySelector("#chatTabs .chat-tab.on .chat-tab-x")?.click(); return }
    if (action === "Focus input") { setView("session"); document.querySelector(".composer input").focus(); return }
    if (action === "Cycle thinking effort") { const i = EFFORTS.findIndex(x => x[0] === P.effort); P.effort = EFFORTS[(i + 1) % EFFORTS.length][0]; document.querySelector('.ctl[data-menu="reasoning"]').textContent = renderCtlLabel("reasoning") }
  }, true)

  // Real menus and result dialogs replace the earlier notification-only actions.
  const menu = document.createElement("div")
  menu.className = "mx-menu"; menu.hidden = true; menu.setAttribute("role", "menu")
  document.body.append(menu)
  function showMenu(anchor, items) {
    menu.innerHTML = items.map(item => `<button role="menuitem" data-mx-action="${item.action}" data-id="${esc(item.id || "")}"${item.danger ? ' class="danger"' : ""}>${esc(item.label)}</button>`).join("")
    const r = anchor.getBoundingClientRect()
    menu.hidden = false
    menu.style.left = Math.max(8, Math.min(r.right - menu.offsetWidth, innerWidth - menu.offsetWidth - 8)) + "px"
    menu.style.top = Math.min(r.bottom + 5, innerHeight - menu.offsetHeight - 8) + "px"
    menu.querySelector("button")?.focus()
  }
  menu.addEventListener("keydown", e => {
    if (e.key === "Escape") { menu.hidden = true; return }
    if (!["ArrowDown", "ArrowUp"].includes(e.key)) return
    e.preventDefault()
    const items = [...menu.querySelectorAll("button")], i = items.indexOf(document.activeElement)
    items[(i + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length].focus()
  })
  function openSession(id) {
    const session = P.sessions.find(s => s.id === id)
    if (!session) return
    P.closedSessionIDs = (P.closedSessionIDs || []).filter(x => x !== id)
    openSessionID = id; renderChatSessions(); setView("session"); applyOpenSession()
  }
  function renameSession() {
    const s = current()
    modal("Rename session", "The title changes in Chat, Home and search together.", field("Title", "title", s.title), data => {
      s.title = String(data.get("title")).trim()
      renderChatSessions(); renderSessionRows(); applyOpenSession()
    })
  }
  function archiveSession() {
    const s = current()
    confirmAction(s.archived ? "Unarchive session?" : "Archive session?", s.title, () => {
      s.archived = !s.archived
      if (s.archived) {
        stopRun(s)
        P.closedSessionIDs = [...new Set([...(P.closedSessionIDs || []), s.id])]
        const next = P.sessions.find(x => !x.archived && !P.closedSessionIDs.includes(x.id))
        if (next) openSession(next.id); else createSession()
      } else openSession(s.id)
      renderSessionRows()
    })
  }
  function deleteSession() {
    const s = current()
    confirmAction(`Delete session “${s.title}”?`, "Its preview conversation and metadata will be removed. Closing a tab is different: it preserves history.", () => {
      stopRun(s)
      P.sessions = P.sessions.filter(x => x.id !== s.id)
      P.closedSessionIDs = (P.closedSessionIDs || []).filter(id => id !== s.id)
      const next = P.sessions.find(x => !P.closedSessionIDs?.includes(x.id))
      if (next) openSession(next.id); else createSession()
      renderSessionRows()
    })
  }
  function shareSession() {
    const link = new URL(location.href)
    link.searchParams.set("profile", P.id)
    link.hash = `session/${current().id}`
    modal("Share session", "A preview link to this profile and session.", field("Session link", "link", link.href) + button("Copy link", "copy-session-link") + `<p class="mx-note">Preview links refer to sample sessions stored in this browser.</p>`, null)
  }
  function createPR() {
    const s = current()
    modal("Create pull request", "Preview the proposal. No remote pull request is created.", field("Title", "title", s.title) + `<div class="mx-fields">${field("From branch", "from", s.branch)}${field("Base branch", "base", "dev")}</div>` + textarea("Description", "description", `Summary\n- ${s.title}\n\nFiles\n${s.fileRecords.map(f => `- ${f.path}`).join("\n")}`), data => {
      s.pullRequest = { title: data.get("title"), from: data.get("from"), base: data.get("base"), description: data.get("description"), status: "Preview ready" }
      queueMicrotask(() => modal("Pull request preview", `${s.pullRequest.from} → ${s.pullRequest.base}`, `<h3>${esc(s.pullRequest.title)}</h3><pre class="mx-log">${esc(s.pullRequest.description)}</pre>${button("Download proposal", "pr-download")}`, null))
    }, "Create preview")
  }
  function toggleTerminal() {
    const s = current()
    s.terminalOpen = !s.terminalOpen
    renderTerminal(s)
  }
  const terminal = document.createElement("section")
  terminal.className = "mx-card"; terminal.hidden = true; terminal.style.gridColumn = "1 / -1"; terminal.style.padding = "10px 14px"
  document.getElementById("viewSession").append(terminal)
  const finalCSS = document.createElement("style")
  finalCSS.textContent = `
    .mx-page,.mx-dialog,.mx-question{color-scheme:dark}
    [data-scheme="light"] .mx-page,[data-scheme="light"] .mx-dialog,[data-scheme="light"] .mx-question{color-scheme:light}
    .mx-choices input,.mx-choice input{accent-color:var(--accent)}
    .mx-compose-tools{flex-wrap:wrap}.composer .ctl{white-space:nowrap;min-width:0}
    .composer .ctl[data-menu="model"]{max-width:150px;overflow:hidden;text-overflow:ellipsis}
    .mx-review-actions{display:flex;align-items:center;gap:7px;flex:none}
    @media(max-width:1180px){.composer{grid-template-columns:minmax(70px,1fr) auto auto auto;column-gap:5px}.mx-compose-tools{grid-column:1/-1}.composer .ctl{font-size:11px}}
  `
  document.head.append(finalCSS)
  const reviewActions = document.createElement("div")
  reviewActions.className = "mx-review-actions"
  reviewActions.innerHTML = button("Create PR", "pr-create") + button("Export diff", "diff-export")
  document.getElementById("reviewSubTabs").after(reviewActions)
  function renderTerminal(s) {
    terminal.hidden = !s.terminalOpen
    document.getElementById("viewSession").style.gridTemplateRows = s.terminalOpen ? "auto minmax(0,1fr) auto" : ""
    if (!s.terminalOpen) return
    terminal.innerHTML = `<div class="mx-row" style="padding:0;border:0"><strong class="mx-grow">Terminal · preview</strong>${button("Close", "terminal-toggle")}</div><pre class="mx-log" style="max-height:100px;overflow:auto;margin:8px 0">${esc((s.terminalLines || [`${P.name} · ${s.branch}`, "Commands here produce simulated output."]).join("\n"))}</pre><form data-mx-terminal><input class="mx-search" style="max-width:none;width:100%" placeholder="Enter a sample command…" aria-label="Terminal command"></form>`
    terminal.querySelector("form").addEventListener("submit", e => {
      e.preventDefault()
      const value = e.target.querySelector("input").value.trim()
      if (!value) return
      s.terminalLines ||= []
      s.terminalLines.push(`$ ${value}`, value.includes("fail") ? "Preview: command failed (exit 1)." : "Preview: command completed (exit 0). No shell command executed.")
      runHooks("Before tool", s); runHooks("After tool", s)
      renderTerminal(s)
    })
  }
  function sessionStep(direction) {
    const tabs = [...chatTabs.querySelectorAll("[data-session]")]
    const i = tabs.findIndex(t => t.dataset.session === openSessionID)
    tabs[(i + direction + tabs.length) % tabs.length]?.querySelector(".chat-tab-select").click()
  }
  const reviewButton = document.createElement("button")
  reviewButton.className = "btn"; reviewButton.dataset.mxAction = "review-toggle"; reviewButton.textContent = "Review"
  document.querySelector(".head-actions").prepend(reviewButton)
  function toggleReview() {
    const rail = document.querySelector(".rail"), s = current()
    s.railHidden = !s.railHidden
    rail.style.display = s.railHidden ? "none" : ""
    document.getElementById("viewSession").style.gridTemplateColumns = s.railHidden ? "minmax(0,1fr)" : ""
    if (!s.railHidden) document.querySelector('[data-panel="review"]').click()
  }
  function closeFileTab() {
    const tab = document.querySelector('#railTabs [data-panel="editor"]')
    current().closedFileTab = selectedFile
    tab.hidden = true
    document.querySelector('[data-panel="review"]').click()
  }
  function focusEditor(path) {
    const session = current()
    session.selectedFile = path; selectedFile = path
    renderEditor(session, path)
    const tab = document.querySelector('#railTabs [data-panel="editor"]')
    tab.hidden = false; tab.click()
    if (session.railHidden) toggleReview()
    tab.click()
  }
  Object.assign(actions, {
    "rename-session": renameSession, "archive-session": archiveSession, "delete-session": deleteSession,
    "share-session": shareSession, "pr-create": createPR,
    "pr-download": () => download(`${current().title}-pr.md`, current().pullRequest.description),
    "diff-export": () => download(`${current().title}.diff`, current().fileRecords.map(f => `diff -- ${f.path}\n${f.diff.map(([, text, marker]) => marker + " " + text).join("\n")}`).join("\n\n")),
    "copy-session-link": async () => { const field = dialog.querySelector('[name="link"]'); try { await navigator.clipboard.writeText(field.value); field.select(); dialog.querySelector('[data-mx-action="copy-session-link"]').textContent = "Copied" } catch { field.focus(); field.select(); dialog.querySelector('[data-mx-action="copy-session-link"]').textContent = "Press ⌘C" } },
    "review-toggle": toggleReview, "terminal-toggle": toggleTerminal,
    "metrics-export": () => download(`${P.name}-metrics.csv`, "Metric,Value,Unit\n" + P.ranges[document.querySelector("#rangeSwitch .on").dataset.range].kpis.map(m => [m[0], m[1], m[2]].map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n"), "text/csv"),
    "appearance": () => modal("Appearance", "Orchestra glass keeps the same material across the workspace.", select("Color scheme", "scheme", root.dataset.scheme === "light" ? "light" : "dark", [["dark", "Dark"], ["light", "Light"]]), data => { root.dataset.scheme = data.get("scheme"); localStorage.setItem("orchestra-scheme", data.get("scheme")) }),
    "resume-pending": () => drainPending(P, current()),
  })
  document.addEventListener("click", e => {
    if (!(e.target instanceof Element)) return
    const b = e.target.closest("button")
    if (!b) { if (!menu.contains(e.target)) menu.hidden = true; return }
    if (menu.contains(b)) menu.hidden = true
    const label = b.textContent.trim()
    if (b.closest(".head-actions") && label === "•••") {
      e.preventDefault(); e.stopImmediatePropagation()
      showMenu(b, [{ label: "Rename session", action: "rename-session" }, { label: "Share", action: "share-session" }, { label: "Export session", action: "session-export" }, { label: current().archived ? "Unarchive session" : "Archive session", action: "archive-session" }, { label: "Delete session", action: "delete-session", danger: true }]); return
    }
    if (b.closest(".head-actions") && label === "Share") { e.preventDefault(); e.stopImmediatePropagation(); shareSession(); return }
    if (b.closest(".msg-actions")) {
      e.preventDefault(); e.stopImmediatePropagation()
      if (label.startsWith("Create PR")) createPR()
      else if (label.startsWith("View changed files")) { if (current().railHidden) toggleReview(); document.querySelector('[data-panel="review"]').click() }
      else if (label === "View failure") modal("Validation failure", current().title, `<pre class="mx-log">${esc(current().taskRecords.find(t => t.fails)?.output || "Sample assertion failed. Inspect the session's validation record before retrying.")}</pre>${button("Retry validation", "validate-again")}`, null)
      else if (/Retry|Run tests|Run anyway/.test(label)) { current().pendingTurn = { text: "Run bun test for this session", options: {} }; setState("permission") }
      else startTurn(P, current(), "Adapt the plan to the declined validation")
      return
    }
    if (b.closest(".foot") && label === "Export") { e.preventDefault(); e.stopImmediatePropagation(); actions["metrics-export"](); return }
    if (b.closest(".foot") && label === "Configure tracking") { e.preventDefault(); e.stopImmediatePropagation(); setView("providers"); return }
    if (e.target.closest('#railTabs [data-panel="editor"] .x')) { e.preventDefault(); e.stopImmediatePropagation(); closeFileTab(); return }
    if (b.dataset.mxAction && actions[b.dataset.mxAction]) menu.hidden = true
  }, true)
  actions["validate-again"] = () => { dialog.close(); current().pendingTurn = { text: "Run bun test for this session", options: {} }; setState("permission") }
  document.addEventListener("keydown", e => { if (e.key === "Escape") menu.hidden = true })
  document.getElementById("fileList").addEventListener("dblclick", e => { const row = e.target.closest("[data-file]"); if (row) focusEditor(row.dataset.file) })

  runPaletteItem = function(item) {
    if (!item) return
    closePalette()
    if (item.kind === "session") { const s = P.sessions.find(s => s.title === item.title); if (s) openSession(s.id); return }
    if (item.kind === "file") { setView("session"); focusEditor(item.title); return }
    const command = item.id
    if (command === "session.new") return createSession()
    if (command === "session.archive") return archiveSession()
    if (command === "session.previous" || command === "session.next") { setView("session"); return sessionStep(command === "session.previous" ? -1 : 1) }
    if (command === "settings.open") return setView("settings")
    if (command === "project.open") return editProfile("new")
    if (command === "model.choose") { setView("session"); document.querySelector('.ctl[data-menu="model"]').click(); return }
    if (command === "model.variant.cycle") { const i = EFFORTS.findIndex(e => e[0] === P.effort); P.effort = EFFORTS[(i + 1) % EFFORTS.length][0]; document.querySelector('.ctl[data-menu="reasoning"]').textContent = renderCtlLabel("reasoning"); return }
    if (command === "agent.cycle") { const choices = P.agents.filter(a => !a.hidden); const i = choices.findIndex(a => a.name === current().agent); current().agent = choices[(i + 1) % choices.length]?.name || "Maestro"; renderContext(current()); return }
    if (command === "input.focus") { setView("session"); document.querySelector(".composer input").focus(); return }
    if (command === "context.addSelection") { const text = getSelection().toString(); if (text) { current().contextFiles.push(`Selected lines: ${text.slice(0, 140)}`); renderCompose(current()); return } return chooseContext() }
    if (command === "review.toggle") { const panel = document.querySelector(".rail-panel.on").dataset.panel; if (panel !== "review") { current().railHidden = false; document.querySelector(".rail").style.display = ""; document.getElementById("viewSession").style.gridTemplateColumns = ""; document.querySelector('[data-panel="review"]').click(); return } return toggleReview() }
    if (command === "fileTree.toggle" || command === "file.open") { setView("session"); if (current().railHidden) toggleReview(); document.querySelector('[data-panel="review"]').click(); document.querySelector('#reviewSubTabs [data-sub="all"]').click(); return }
    if (command === "terminal.toggle") { setView("session"); return toggleTerminal() }
    if (command === "sidebar.toggle") { const side = document.querySelector(".side"), workspace = document.querySelector(".workspace"); side.hidden = !side.hidden; workspace.style.gridTemplateColumns = side.hidden ? "minmax(0,1fr)" : ""; return }
    if (command === "theme.scheme.cycle") return document.getElementById("schemeToggle").click()
    if (command === "theme.cycle") return actions.appearance()
    if (command === "tab.close") return document.querySelector('.rail-panel.on').dataset.panel === "editor" ? closeFileTab() : document.querySelector("#chatTabs .chat-tab.on .chat-tab-x").click()
    if (command === "tab.reopenClosed") { if (current().closedFileTab) return focusEditor(current().closedFileTab); const id = P.closedSessionIDs?.at(-1); if (id) openSession(id); return }
    if (command.startsWith("view.")) return setView(command.slice(5))
  }
  Object.keys(titles).forEach(key => COMMANDS.push([`view.${key}`, "Settings", `Open ${titles[key]}`, descriptions[key]]))

  const priorOpen = applyOpenSession
  applyOpenSession = function() {
    priorOpen()
    if (!current()) return
    renderTerminal(current())
    const rail = document.querySelector(".rail")
    rail.style.display = current().railHidden ? "none" : ""
    document.getElementById("viewSession").style.gridTemplateColumns = current().railHidden ? "minmax(0,1fr)" : ""
  }
  const priorSwitch = switchProfile
  switchProfile = function(id) {
    P.openSessionID = openSessionID
    priorSwitch(id)
    if (P.openSessionID && P.sessions.some(s => s.id === P.openSessionID && !P.closedSessionIDs?.includes(s.id))) openSessionID = P.openSessionID
    renderChatSessions(); applyOpenSession()
  }
  document.addEventListener("click", e => {
    if (e.target instanceof Element && e.target.closest(".dock-host")) queueMicrotask(persist)
  }, true)
  const baseHash = applyHash
  removeEventListener("hashchange", baseHash)
  applyHash = function() {
    const url = new URL(location.href)
    const profile = url.searchParams.get("profile")
    if (profile && PROFILES[profile] && profile !== P.id) switchProfile(profile)
    const [view, sub] = url.hash.slice(1).split("/")
    if (view === "session" && P.sessions.some(s => s.id === sub)) {
      openSession(sub)
      history.replaceState(null, "", url.href)
      return
    }
    baseHash()
  }
  addEventListener("hashchange", applyHash)
  const globalToasts = document.getElementById("toasts")
  document.body.append(globalToasts)
  globalToasts.style.position = "fixed"
  globalToasts.style.right = "24px"; globalToasts.style.bottom = "24px"

  // Subsequent blocks extend this single profile-owned preview controller.

  // Subsequent blocks extend this single profile-owned preview controller.
  window.Mock = { modal, persist, renderPage, renderOpenPage, runHooks, actions, icon, esc, field, textarea, select, button, badge, defaults, createSession, download, renderWorkspaces, submit: submitMessage, start: session => startTurn(P, session, session.prompt || session.title), stop: stopRun }
  renderProfileSwitcher()
  renderAgents()
  renderSettings(document.querySelector("#settingsNav .on")?.dataset.sec || "permissions")
  const remembered = localStorage.getItem("orchestra-profile")
  if (remembered && PROFILES[remembered] && remembered !== P.id) switchProfile(remembered)
  applyOpenSession()
  applyHash()
})()
