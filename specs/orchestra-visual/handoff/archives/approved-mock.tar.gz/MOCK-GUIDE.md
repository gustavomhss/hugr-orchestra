# Orchestra — interactive mock guide

## Scope

Open `app.html` in Chrome. This is a local interactive preview, not a connected
Orchestra client. Provider connections, MCP discovery, LLM turns, hooks, pipelines
and scheduled execution use sample data. No command is executed and no remote PR
is created. File import/export and downloads use the browser's real file APIs.

The existing UI vocabulary comes from the product. The added navigation and
workflows below also encode explicit owner decisions; they are not claims that
these production screens or APIs already exist.

## Rework chapters

All proposed Orchestra screens are now marked **Orchestra · Rework pendente**
in the mock. Every page added in the latest capability round needs a focused
rework. Earlier custom screen proposals are marked too. `CHAPTERS.md` records
the inventory, reuse boundaries and chapter status.

**One chapter at a time. No chapter is active yet.** Prototype interactivity and
passing behavior checks do not mean the new screens have final design approval.
Providers, Shortcuts, agents, workspaces and the App Dock browser already have
OpenCode counterparts; the marker identifies Orchestra's proposed screen or
dedicated destination rather than claiming those capabilities are new.

## Decisions to preserve

- **One repository = one profile.** Each profile owns agent configuration,
  permissions, model choices, providers, skills, LLM plugins, hooks, pipelines,
  schedules, workspaces, conversations and its Dock session.
- **Profile picker stays at the bottom of the sidebar.** Its square card opens
  an upward menu. Navigation scrolls separately so this card remains visible.
- **Sessions belong to Chat.** Horizontal browser-style tabs sit at the top of
  the central area, below the window toolbar and above conversation/Review.
  Closing a tab preserves session history; deleting requires its own dialog.
- **Dock is Orchestra's browser.** It appears both as a dedicated view and as
  Chat's Apps tab. Both render the same profile-owned browser session.
- **Glass has one source.** Sidebar, session strip and active tab use the shared
  `--glass-*` variables. Highlights must follow their own rounded element bounds.
- **Branch text is amber.** It remains subordinate to the session title.
- **Model logo belongs to the current/last principal turn.** Manufacturer first,
  router fallback, then neutral symbol. Composer changes configure the next turn.
  Running pulses, stopped stays static, waiting for a human response bounces.
- **Playback is on by default in the mock.** `?motion=auto` previews reduced-motion
  accessibility instead. Production defaults should respect system preferences.
- Desktop is the current target. No mobile navigation work is scheduled.

## Sidebar capabilities

### Agents

Create/configure an agent: name, description, primary/subagent/all mode, model,
system instructions, turn allowance and per-tool permissions. Save commits the
draft to this profile; Cancel discards it. Tool permissions can inherit profile
defaults or have an explicit override. A profile or agent Deny blocks that tool in
the preview. Existing conversations keep their executed model identities.

### MCP

Add/edit a stdio command or HTTP endpoint; enable/disable a server and inspect its
tools. HTTP URLs are validated. Sample commands containing `invalid` show an Error
state; editing them demonstrates recovery. Discovery/connection is simulated.

### Skills

Create/read/edit/remove focused instructions and enable them per profile. Enabled
skills appear in the effective context as available capabilities. An explicit
`@review` or `/skill Code review` request loads that skill's instructions for the
simulated turn.

### Plugins

These are **LLM behavior plugins**, not desktop UI plugins or MCP servers.
Caveman has lite/full/ultra intensity. Enabling/disabling or configuring it changes
the simulated answer style. Custom behavior instructions are included in the
effective system context. Every profile has its own activation and configuration.

### Hooks

Configure Session start, Before prompt, Before tool, After tool and Session idle
events. Actions are Add instruction, Record event or Run command. Tests and turns
record when a hook fired. Add instruction contributes to the effective context;
Run command is logged without external execution. Background work retains its
originating profile's hooks even after switching profiles.

### Providers and models

Connect via a sample API key, OAuth flow or local endpoint. Add a custom
OpenAI-compatible endpoint. Credentials entered into connection dialogs are not
saved; non-secret connection metadata is. Disconnect preserves endpoint settings
and blocks new turns on that route. Choose the route for new turns and enable or
disable models in Settings. Historical logos do not follow that next-turn setting.

### Shortcuts

Edit by pressing a combination, reject conflicts, save per profile and reset to
defaults. Bindings perform the action: command palette, new/close session tab,
model picker, input focus and thinking-effort cycle. A replaced binding does not
continue firing its old default.

### CI/CD

Create/edit pipelines with a branch, manual/push/PR trigger, commands and optional
deployment to Preview/Staging/Production. Run/Stop controls the simulated job;
logs update and can be downloaded. Failed checks skip deployment. A cancelled job
cannot complete later. A pipeline's timer is keyed by profile and pipeline ID.
Real repository-event triggers and deployment workers are production integration.

### Agendar

Create/edit a task, prompt, agent, future date and Once/Every hour/Daily/Weekly
cadence. Pause/resume it or Execute now. Execution creates a session on that
profile, records the run and advances recurring dates; one-off work disables
after dispatch. Dates are shown in the local browser timezone. The preview does
not install a background scheduling daemon.

### .env — keep it simple

- Open an explicitly selected local file, or start from sample keys.
- Show/hide values, add, edit and remove keys; duplicate or invalid names fail.
- View the current file and download an updated `.env`.
- Support `export`, quoted values, inline comments and multiline quoted values.
- Preserve untouched source lines/comments when exporting an imported file.
- Values remain in the current page, not in persisted profile configuration.
  Download is an explicit file export, not a silent repository overwrite.
- A new profile starts with an empty environment-key list.

No secret-manager service, vault, deployment integration or automatic `.env` scan
is introduced by this screen.

## Chat behavior

Each session owns its transcript additions, draft, attachments, selected context,
task records, files/diffs, editor selection, terminal output and pending prompts.
Switching tabs restores that session. Review and Context are projections of its
data, not a reused demonstration for unrelated sessions.

Sending appends an admitted user entry and streams a clearly labeled sample
answer. Caveman and loaded instructions affect this preview. A request for work
such as update/build/refactor can produce a generated virtual diff in Review;
this is never a write to the repository. Stop cancels the actual preview timer,
marks its tasks cancelled and prevents late output.

Question supports single choice, multiple choice, free text and skip. Empty
answers are rejected. Waiting drives the bouncing logo. Permission uses the same
waiting vocabulary and policy; a Deny never becomes a fake failed test.

Steer/Queue is explicit. Prompts received during execution or a human wait remain
pending. Steers are promoted at the next turn boundary; one queued input is
promoted when work would otherwise become idle, then continuation is reevaluated.
Stopped work retains pending prompts for an explicit Resume.

Files/images can be attached and previewed before or after submission. Images
can also be pasted. Context files are selected from the current session. Context
reports approximate current-window tokens separately from cumulative spending.
Raw messages and session exports are inspectable.

Task details expose agent/model/tool/failure data and can open a child session.
File selection changes the actual displayed diff; opening/reopening a file tab
shows that file's sample source. Terminal is a separate session preview, never
the Dock.

## Menus and results

- Session `…`: rename, share, export, archive/unarchive, delete with confirmation.
- Share link identifies profile and session; Copy falls back to selecting the
  field if clipboard permission is unavailable.
- PR: editable proposal, branch/base, result dialog and Markdown download.
- Metrics CSV, session JSON, diff, pipeline logs and `.env` create real downloads.
- Workspaces are profile-owned and editable; selecting one affects new sessions.
- New profile starts from current configuration, with fresh sessions, browser
  tabs and environment keys. Profile metadata/configuration is persisted locally.
- The command palette executes its listed actions and finds this profile's
  sessions and current session's files.

## Implementation and verification

`app.html` owns the original shell, glass tokens, fixtures and browser Dock.
`mock-features.js` adds the complete profile-owned flows through one preview
controller. Both are classic scripts so the local-file mock works without a dev
server or bundler. The real repository is not changed by this mock.

Run from this directory:

```sh
node --check mock-features.js
node check.mjs
node trace.mjs
```

`configflows`, `sessionflows`, `menuflows` and `edgeflows` exercise real controls,
native forms, actual browser file objects and the preview timers. They do not
duplicate the implementation. Motion checks use Chromium's real animation
timeline and separately verify reduced motion and mock playback override.

Calibration fixtures proved that removing a light color token and sharing one
history array across sessions makes the respective checks fail. Screenshots cover
all added pages in dark/light, with viewport and profile-card bounds checked.
