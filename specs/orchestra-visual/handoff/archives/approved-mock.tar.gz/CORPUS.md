# Orchestra mock — requirements corpus

## This is a lift, not a plan

The order is inverted on purpose. The mock shipped first; this corpus was cut
afterwards, from the code and from the checks that were written against it. Every
clause below states behaviour that `app.html` has **right now** and that
`check.mjs` asserts. Nothing here is aspirational.

The measured trigger: `app.html` had grown to six views, five session states and a
browser dock with no corpus, while the sibling App Dock component in the repo was
never mentioned in it.

**A clause that names no check is not a lift, it is a wish.** The witness layer is
`check.mjs`:

```
node check.mjs            # behaviour checks and manifest drift checks
node check.mjs --list     # every registered check id
node check.mjs dock       # one group
```

`check.mjs` carries a **drift gate**: it fails if the app emits a check id that
`MANIFEST` does not register, or if a registered id never ran. So this document
cannot cite a check that does not exist, and renaming a check cannot silently drop
it out of the spec. Run the harness before believing this file.

The corpus is generated from the same ids the harness registers: `clauses[]` and
`unwanted[]` per invariant, one requirement per clause, one guard per unwanted, and
one golden per requirement naming the shipped check.

**Current inventory:** 25 invariants, **318 checks**, **139
requirements** (111 positive clauses + 28 guards), 0 declared divergences.

---

## Source of truth for copy

`app.html` is an interactive mock. Inherited product copy is checked against the
shipped literals below. New capability pages and workflow copy also express owner
design decisions, documented in `MOCK-GUIDE.md`; the contract group does not claim
that these new production screens already ship. It lifts its named literals from:

- `packages/app/src/i18n/en.ts` — `ui.permission.*` is in `packages/ui/src/i18n/en.ts`
- `packages/app/src/pages/session/apps-panel.tsx` — the App Dock's own hardcoded copy

`contract.key-*` asserts the key still resolves to the expected literal.
`contract.in-mock-*` asserts the mock actually shows it. A key whose value is a
template (`Files Changed {{count}}`) is satisfied by the mock rendering the
substituted head.

Override with `EN_TS=` / `UI_TS=` if the repo moves.

---

## I1 — The session state has one source

`STATES` is a single record. The permission dock, the message tail, the plan
checklist, the task rail badge and the Home "Sessions by impact" row are all
projections of it, so no two surfaces can disagree.

### Requirements

- **R1.1** The session shall project its five states — `idle`, `running`,
  `permission`, `error`, `denied` — consistently across dock, message tail, plan
  and task badge. *(goldens: `state.idle`, `state.running`, `state.permission`,
  `state.error`, `state.denied`)*
- **R1.2** The plan's last step shall agree with the tail it precedes. *(golden:
  `state.checklist-matches-tail`)*
- **R1.3** The Home row for the open session shall carry the same live label the
  session view shows. *(goldens: `state.running`, `state.permission`, `state.error`,
  `state.denied` — each asserts `livePill`)*
- **R1.4** The task rail badge shall count running and blocked tasks, not total. *(goldens:
  `state.running` = 3, `state.error` = 1, `state.idle` = 0)*

### Guards

- **R1.G1** If a session state is entered, then no surface shall still render the
  previous state's message tail.
- **R1.G2** If validation has failed, then the plan shall not read as still
  implementing. *(witness: `state.checklist-matches-tail`)*

---

## I2 — Permission is one decision, shown in two places

The Settings defaults and agent overrides resolve into one effective tool choice.
An inherited permission follows the profile. Explicit Deny blocks execution;
effective Allow proceeds and effective Ask opens the dock.
disappears.

### Requirements

- **R2.1** The permission dock shall be visible in exactly the `permission` state. *(golden:
  `permission.dock-in-permission-state`)*
- **R2.2** `Allow once` and `Allow always` shall each resolve the request and
  resume the run. *(goldens: `permission.allow-once-resumes`,
  `permission.allow-always-resumes`)*
- **R2.3** The always-grant shall persist across a reload. *(golden:
  `permission.allow-always-persists`)*
- **R2.4** The Settings table shall offer the product's fourteen tools with their
  real titles. *(goldens: `permission.tool-count-is-14`, plus the
  `contract.key-settings.permissions.tool.*` checks)*
- **R2.5** `bash` shall default to `ask`, which is what the dock implies. *(golden:
  `permission.settings-bash-asks`)*
- **R2.6** The dock actions shall be the product's three, with its copy. *(goldens:
  `contract.key-ui.permission.deny`, `contract.key-ui.permission.allowAlways`,
  `contract.key-ui.permission.allowOnce`)*

### Guards

- **R2.G1** If effective `bash` policy is not `ask`, then the session dock shall not ask for
  approval. *(witness: `permission.allowing-bash-drops-the-dock`)*
- **R2.G2** If a command was declined, then the run shall not be reported as a
  failing test. *(witness: `permission.deny-is-not-test-failure`)*

---

## I3 — Denial is not a failed test

A declined command never ran. Denial is its own state, and it says so.

### Requirements

- **R3.1** `Deny` shall produce the `denied` state, distinct from `error`. *(golden:
  `permission.deny-is-not-test-failure`)*
- **R3.2** The denial message shall state that the command never ran. *(golden:
  `permission.denial-says-nothing-ran`*

---

## I4 — The Dock is the App Dock browser

`packages/app/src/pages/session/apps-panel.tsx` is an embedded browser, not a
terminal. The mock reproduces its chrome and shows **its own** empty state, because
a static page has no `window.api`.

### Requirements

- **R4.1** With no native host, the Dock body shall show the component's own empty
  state, verbatim. *(goldens: `dock.empty-state-is-the-components-own`,
  `contract.literal-*` for the two sentences)*
- **R4.2** Controls that need `appDockCommand` — back, forward, reload, open —
  shall be disabled. *(golden: `dock.native-nav-disabled`)*
- **R4.3** Controls that are pure UI state shall stay live. *(golden:
  `dock.pure-ui-controls-stay-live`)*
- **R4.4** The url bar shall carry the component's thirteen controls. *(golden:
  `dock.urlbar-has-the-real-controls`)*
- **R4.5** A tab shall render the favicon initial, the title, a literal `Pinned`
  for pinned tabs and `♪` for audible ones. *(goldens: `dock.pinned-label-renders`,
  and the profile switch in `mirroring.profile-switch` which exercises the audible
  tab)*
- **R4.6** Tabs shall use a roving tabindex and the active tab shall scale to
  `0.985`. *(goldens: `dock.roving-tabindex`, `dock.active-tab-scales`)*
- **R4.7** Downloads shall offer `Cancel` while progressing and `Open` when
  completed; cancelling shall move the row to `cancelled`. *(goldens:
  `dock.downloads-offer-cancel`, `dock.downloads-offer-open`,
  `dock.download-cancel-sets-state`)*
- **R4.8** Creating a browser profile shall slugify the name and reject a
  duplicate. *(goldens: `dock.profile-created-from-slug`,
  `dock.duplicate-profile-rejected`)*

### Guards

- **R4.G1** The Dock shall not present a terminal.
- **R4.G2** If no native host is present, then navigation controls shall not be
  clickable. *(witness: `dock.native-nav-disabled`)*

---

## I5 — One dock session, two mounts

The Dock view and the session rail's `Apps` tab are the same component over one
state. Twelve fields are compared field-by-field after every mutation.

### Requirements

- **R5.1** Both mounts shall agree on tabs, active tab, browser profile, bookmark,
  find text and open-state, fullscreen, tab menu contents, address, downloads,
  the disabled back button and the pinned marks. *(goldens: `mirroring.initial`,
  `mirroring.select-tab`, `mirroring.bookmark`, `mirroring.new-tab`,
  `mirroring.profile-switch`, `mirroring.profile-switch-back`, `mirroring.find-open`,
  `mirroring.find-value`, `mirroring.find-close`, `mirroring.library-history`,
  `mirroring.library-downloads`, `mirroring.fullscreen`, `mirroring.fullscreen-off`,
  `mirroring.tab-menu`, `mirroring.duplicate-from-menu`)*
- **R5.2** A keystroke shall keep focus in the mount that received it. *(golden:
  `mirroring.focus-stays-in-the-mount`)*
- **R5.3** The tab menu shall be positioned inside each mount's own content box. *(golden:
  `mirroring.menu-inside-its-own-content`)*

### Guards

- **R5.G1** The two mounts shall never disagree on a session field.
- **R5.G2** The tab menu's offset shall not be stored as shared pixel state, because
  the two mounts have different geometry (1164px against 396px).
- **R5.G3** Focus shall not be stolen into the mount the user is not looking at.

---

## I6 — Copy is the product's copy

See "Source of truth for copy" above.

### Requirements

- **R6.1** Every lifted i18n key shall still resolve to its expected literal. *(goldens:
  the 48 `contract.key-*` checks)*
- **R6.2** Every lifted literal shall be present in `app.html`. *(goldens: the 48
  `contract.in-mock-*` checks)*
- **R6.3** The App Dock's hardcoded copy shall be present verbatim. *(goldens: the
  6 `contract.literal-*` checks)*

---

## I7 — Sample data is declared, never passed off as measured

### Requirements

- **R7.1** The Home footer shall state that the metrics are sample data. *(golden:
  `home.kpi-provenance-declared`)*

### Guards

- **R7.G1** Find-in-page shall not report a match count when there is no page
  behind the empty state. *(witness: `dock.find-reports-no-invented-count`)*

---

## I8 — No control is dead

A button is either wired or explicitly disabled with a reason.

### Requirements

- **R8.1** No button shall be simultaneously un-wired and enabled. *(golden:
  `coverage.no-dead-buttons`)*

> This check found one real defect during the lift: `New workspace` was dead. It
> is now wired. See card **W8**.

---

## I9 — Every view and state is addressable

### Requirements

- **R9.1** Each of the six views shall be reachable by hash alone. *(goldens: the six
  `deeplink.view-*` checks)*
- **R9.2** A named agent shall be reachable as `#agents/<name>`. *(golden:
  `deeplink.agent-page`)*
- **R9.3** Each of the five session states shall be reachable as `#session/<state>`
  and shall agree with the switcher. *(goldens: the five `deeplink.state-*` checks)*

---

## I10 — The chrome fits its viewport

### Requirements

- **R10.1** The chrome shall not overflow horizontally. *(golden:
  `narrow.chrome-does-not-overflow`)*
- **R10.2** The window controls shall stay on one line. *(golden:
  `narrow.window-controls-stay-on-one-line`)*
- **R10.3** The composer shall sit inside the conversation pane. *(golden:
  `narrow.composer-inside-the-pane`)*

### Guards

- **R10.G1** Mock-only chrome shall yield before the product chrome wraps. *(witness:
  `narrow.mock-chrome-yields`)*
- **R10.G2** The sidebar and the rail shall yield rather than squeeze the
  conversation. *(witness: `narrow.sidebar-and-rail-yield`)*

---

## I11 — Every painting rule has a light counterpart

This is the rule that broke 105 times before it was written down.

### Requirements

- **R11.1** Every base rule that paints `color`, `background`, `border-color` or
  `box-shadow` shall have a `[data-scheme="light"]` counterpart or use painting
  tokens explicitly defined for light, except where it is enumerated as
  scheme-independent. *(golden: `theme.painting-rules-have-light`)*

---

## I12 — The DOM stays intact

### Requirements

- **R12.1** Div nesting inside the workspace shall balance. *(golden:
  `dom.div-balance`)*
- **R12.2** The stylesheet shall still parse in the browser, and shall still hold
  its selector rules. *(goldens: `dom.stylesheet-parsed`, `dom.selector-rules`)*

### Guards

- **R12.G1** Two elements shall not share an id. *(witness: `dom.no-duplicate-ids`)*

---

## I13 — The composer menus commit what they show

Three menus on the composer, one renderer each, so the label cannot disagree with
the check mark inside the open menu.

### Requirements

- **R13.1** The model dialog shall group by provider and carry the product's
  search placeholder. *(goldens: `composer.model-groups-by-provider`,
  `composer.model-search-filters`)*
- **R13.2** Picking a row shall move the label and the check mark together. *(goldens:
  `composer.model-pick-commits`, `composer.model-pick-moves-check`)*
- **R13.3** The reasoning control shall offer four levels with the product's tooltips. *(goldens:
  `composer.effort-has-four-levels`, `composer.effort-pick-commits`,
  `contract.key-model.tooltip.reasoning.allowed`, `contract.key-model.tooltip.reasoning.none`)*
- **R13.4** Unchecking a subagent model shall change the label and the hint. *(goldens:
  `composer.subagent-deny-changes-label`, `composer.subagent-hint-follows-state`)*

### Guards

- **R13.G1** A click outside shall close the popover. *(witness:
  `composer.outside-click-closes`)*

---

## I14 — Sending appends to the transcript

### Requirements

- **R14.1** Sending a non-empty message shall append it to the timeline. *(golden:
  `composer.send-appends-message`)*

### Guards

- **R14.G1** Sending an empty message shall not append. *(witness:
  `composer.send-empty-is-refused`)*

---

## I15 — The command palette runs what it lists

### Requirements

- **R15.1** The palette shall open on the product's binding and placeholder, and the
  placeholder shall differ per view. *(goldens: `palette.opens`,
  `palette.placeholder-follows-view`, `deeplink.view-session`)*
- **R15.2** It shall group into `Commands`, `Files` and `Sessions`. *(golden:
  `palette.groups`)*
- **R15.3** An unmatched query shall read `No results found`. *(golden:
  `palette.no-results-copy`)*
- **R15.4** Arrow keys shall move the selection. *(golden: `palette.arrow-selection`)*
- **R15.5** `Enter` shall carry out the selected command. *(golden:
  `palette.command-runs`)*

---

## I16 — The Review rail follows the selected file

### Requirements

- **R16.1** The rail shall offer the product's two sub-tabs, and `Context` shall
  render the product's context statistics. *(goldens: `rail.context-tab-renders-stats`,
  `contract.key-session.files.all`, `contract.key-session.review.filesChanged`)*
- **R16.2** Selecting a file shall swap the diff. *(golden:
  `rail.file-select-swaps-diff`)*
- **R16.3** A file with no changes shall say so rather than show an empty diff. *(goldens:
  `rail.all-files-has-no-diff`, `rail.back-to-changed-restores-a-diff`)*

---

## I17 — Home actions navigate

### Requirements

- **R17.1** The range control shall move the measurement window, not just the
  highlight. *(golden: `home.range-moves-the-window`)*
- **R17.2** All eight rows shall be wired: sessions to the session, models to the
  Models settings section. *(goldens: `home.every-row-navigates`,
  `home.session-row-opens-session`, `home.model-row-opens-models`)*

---


---

## I18 — A profile is the root of state

One repository is one profile, and a profile owns everything that belongs to it:
the permission table, the agent roster, the composer's model and effort, the
subagent allow-list, the KPI history, the session list and the dock's tabs. The
sidebar carries the list the way the real sidebar carries its project list.

### Requirements

- **R18.1** The sidebar shall list the profiles with their branch, and mark the
  active one. *(goldens: `profile.starts-on-a-profile`, `profile.switch-marks-active`)*
- **R18.2** Switching shall swap the profile's sessions, in the sidebar and on the
  dashboard alike. *(goldens: `profile.sessions-follow-the-profile`,
  `profile.switch-swaps-sessions`)*
- **R18.3** Switching shall swap the KPI window. *(golden: `profile.switch-swaps-kpis`)*
- **R18.4** Switching shall swap the composer's model and effort. *(goldens:
  `profile.switch-swaps-composer`, `profile.effort-none-is-a-real-value`)*
- **R18.5** Switching shall swap the dock's tabs, in both mounts. *(goldens:
  `profile.switch-swaps-dock`, plus the fifteen `mirroring.*` field checks, which
  would fail if the two mounts disagreed after a switch)*
- **R18.6** Switching shall swap the agent roster. *(goldens:
  `profile.switch-swaps-agents`, `profile.roster-is-per-profile`)*
- **R18.7** Switching shall swap the permission table. *(goldens:
  `profile.switch-swaps-permissions`, `profile.permission-table-is-per-profile`)*
- **R18.8** Switching shall swap the spend breakdown, and the dashboard shall name
  the active project. *(goldens: `profile.switch-swaps-spend`,
  `profile.kicker-names-the-profile`)*
- **R18.11** A third profile shall switch independently of the first two. *(golden:
  `profile.third-profile-switches`)*
- **R18.9** A switch shall be reversible. *(golden: `profile.switch-is-reversible`)*
- **R18.10** The active profile shall survive a reload. *(golden: `profile.persists`)*

### Guards

- **R18.G1** A profile that denies `bash` shall never show a permission dock for
  it. *(witness: `profile.session-state-per-profile` — canonical asks, local-app does not)*

- **R18.G2** Switching a profile shall not navigate away from the view the user
  was on. *(caught during the build: `setState` wrote the hash, which fired
  `hashchange` and pulled the user into the session view. `profile.switch-marks-active`
  asserts the switch completed; the view assertion is the one the screenshot caught.)*


---

## I19 — Sessions are a browser tab strip across the top of the chat

Sessions are not navigation. The profile decides which sessions exist; the chat
carries them as a horizontal tab strip across the top of the session view — above
the conversation *and* the side panel, the way a browser puts its tabs above the
viewport. The strip is inside the session view, never the window toolbar.

The sidebar is the material reference: its gradient, blur, border and reflection
are defined once in `--glass-background`, `--glass-filter`, `--glass-border` and
`--glass-shadow`. The session strip and active tab use these same tokens in both
themes. Selection must not introduce a separate glass palette.

### Requirements

- **R19.1** The session list shall live inside the chat as a top strip, and neither
  the sidebar nor the window toolbar shall carry one. *(goldens:
  `chat.sessions-live-in-the-chat`, `chat.strip-is-not-the-toolbar`,
  `chat.sidebar-has-no-session-block`)*

- **R19.5** The strip shall span the conversation and the side panel together, and
  sit above both. *(goldens: `chat.strip-spans-conversation-and-rail`,
  `chat.strip-sits-at-the-top-of-the-session-view`)*

- **R19.6** The strip shall open a new session on the active profile. Closing its
  tab shall preserve the session in Home history, where it can be reopened.
  *(goldens: `chat.new-session-adds-to-the-active-profile`,
  `chat.close-session-removes-its-tab`, `chat.closed-session-reopens-from-history`)*
- **R19.7** Selecting a tab and closing it shall be independent button controls,
  without nesting an interactive control inside another.
  *(golden: `chat.close-button-is-independent`)*
- **R19.2** The chat shall list the active profile's sessions. *(goldens:
  `chat.lists-the-active-profile-sessions`, `chat.sessions-follow-the-profile`)*
- **R19.3** The transcript header shall name the open session, and choosing another
  shall rename it. *(goldens: `chat.header-names-the-open-session`,
  `chat.choosing-a-session-renames-the-transcript`, `chat.chosen-session-stays-chosen`)*
- **R19.4** Each session shall open with its own prompt and subtitle. *(golden:
  `chat.session-prompt-is-per-session`)*

### Guards

- **R19.G1** The chat shall not claim a title the session list does not carry. *(witness:
  `chat.choosing-a-session-renames-the-transcript`)*

- **R19.G2** Switching profile shall re-point the chat at that profile's sessions,
  not leave the previous profile's rows on screen. *(witness:
  `chat.sessions-follow-the-profile`)*

---

## I20 — The profile is chosen from the card at the foot of the sidebar

The repo list is a menu, opened from the identity card below the toolbar — the
place the account card already was. It is not a permanent block in the nav.

### Requirements

- **R20.1** The card shall name the active project, its agent count and its branch.
  *(golden: `profile.card-shows-the-active-project`)*
- **R20.2** The card shall sit below the nav, at the foot. *(golden:
  `profile.card-lives-at-the-foot`)*
- **R20.3** The card's menu shall list the projects and close on an outside click. *(golden:
  `profile.menu-lists-the-projects`)*

### Guards

- **R20.G1** The menu shall be positioned against the card, not against the whole
  sidebar. *(caught during the build: the menu was a sibling of the card, so
  `bottom: calc(100% + 6px)` resolved against the `aside` and rendered at y = -61,
  off-screen, while every behavioural check still passed. The screenshot caught it;
  `profile.menu-lists-the-projects` only proved it toggled.)*


---

## I21 — Session tabs show the model's manufacturer and execution state

**Product decision:** the tab icon identifies the manufacturer of the model used
by the session's principal execution, not the company routing its requests and
not whichever composer choice was changed most recently. Subagent models do not
replace the principal session icon.

The real contracts already identify a model with `Model.Ref` (`id`, `providerID`)
on the session and assistant messages. `providerID` identifies the delivery
connection; it is not an authoritative manufacturer field. Model catalog metadata
and recognized model identifiers can establish the manufacturer. The mock uses an
explicit catalog and recognized vendor namespaces, plus optional explicit
manufacturer metadata for sample custom models. It does not infer ownership from
the display name or an OpenAI-compatible transport.

### Resolution order

1. Resolve manufacturer from explicit metadata, known catalog entry or recognized
   vendor namespace. Use its logo if available.
2. If manufacturer is unknown or lacks an asset, use the delivery provider/router
   logo: OpenCode, OpenRouter or another known provider.
3. If neither identity has an asset, show the neutral model symbol.

Examples: Claude via OpenRouter still shows Anthropic; GPT via OpenCode shows
OpenAI; DeepSeek via OpenRouter shows DeepSeek. An unknown custom model via
OpenRouter shows OpenRouter. A recognized manufacturer without an available logo
also falls back to the router. Unknown names are never assigned a fabricated brand.

The mock embeds original paths from
`packages/ui/src/assets/icons/provider/{anthropic,openai,deepseek,google,opencode,openrouter}.svg`.
The neutral symbol is not a vendor mark. SVG symbols are inline, so local-file
preview needs neither network requests nor an external sprite load. The tooltip
states the model, route and activity, including when the visible mark is a fallback.

### Activity vocabulary

| Session condition | Icon motion |
|---|---|
| Executing the principal turn | Gentle pulse in opacity and scale; 2.4-second cycle |
| Stopped, idle, failed or denied | Static; preserves the last used model identity |
| Waiting for the user's answer | Vertical basketball bounce; 1.15-second cycle |

Waiting takes precedence over running. The bounce includes a floor-contact squash,
quick rebound, decelerating ascent, accelerating descent and a synchronized ground
shadow. It does not move or resize the tab, title or branch. Selecting a tab does
not start execution. A running background tab continues its pulse; a selected idle
tab remains static. Answering the request returns to pulse when execution resumes,
or stops movement when execution ends.

In this mock, `permission` exercises the waiting state; `waitingForResponse` is the
shared visual flag. **Production integration requirement:** both permission prompts
and question prompts must drive that flag; copying only the permission mapping
would miss actual question waits. This is a documented integration contract, not a
claim that the static mock implements the production question lifecycle.

Each sample session owns its current/last executed `model` reference. The profile's
composer choice configures the next turn. Changing it alone leaves current icons
unchanged; submitting a new turn records that selection on the current session.
A new session displays its configured model statically until it runs.

### Requirements

- **R21.1** A recognized manufacturer with an asset shall take precedence over the
  delivery router. *(goldens: `logos.manufacturer-before-router`,
  `logos.transport-does-not-imply-manufacturer`)*
- **R21.2** Unknown manufacturers or missing manufacturer assets shall fall back
  to the router, then to the neutral symbol. *(goldens:
  `logos.missing-brand-uses-router`, `logos.unknown-model-uses-router`,
  `logos.unknown-route-is-neutral`)*
- **R21.3** Each tab shall render its own session's model mark, and model records
  shall remain profile-owned. *(goldens: `logos.each-tab-owns-its-model`,
  `logos.svg-marks-render`, `logos.routes-and-models-are-profile-owned`)*
- **R21.4** A new execution shall record the chosen model on that session; a new
  session shall show its configured model statically. *(goldens:
  `logos.send-records-the-new-model`, `logos.new-session-shows-configured-model-statically`)*
- **R21.5** Running shall pulse gently, while stopped states remain static.
  *(goldens: `motion.running-pulses`, `motion.pulse-is-subtle`,
  `motion.stopped-states-are-static`)*
- **R21.6** Waiting shall bounce with ascent, landing squash and ground shadow;
  answering shall return to execution motion. *(goldens:
  `motion.waiting-bounces`, `motion.bounce-has-ascent-and-impact`,
  `motion.bounce-has-ground-shadow`, `motion.answer-returns-to-pulse`)*
- **R21.7** In the mock's `?motion=auto` accessibility preview, the system's reduced-motion preference shall suppress both logo motion
  and ground-shadow motion. *(goldens: `motion.reduced-preference-is-active`,
  `motion.reduced-motion-is-static`)*
- **R21.8** The static mock shall play pulse and bounce by default even when
  reduced motion is enabled, so the owner can assess the requested animation
  without depending on launchers preserving query parameters. `?motion=auto`
  explicitly previews the system preference instead.
  This is a preview-only override, not a change to production accessibility defaults.
  *(goldens: `motion.preview-enables-pulse`, `motion.preview-enables-bounce`)*

### Guards

- **R21.G1** Changing the composer choice shall not rewrite a currently executing
  or historical model identity. *(witness: `logos.composer-choice-is-not-current-turn`)*
- **R21.G2** Tab selection shall not be interpreted as model execution.
  *(witness: `motion.selection-is-not-execution`)*

Motion tests use real Chromium with `prefers-reduced-motion: no-preference`
explicitly set through DevTools emulation. This prevents ambient macOS Reduce
Motion from silently removing the animation coverage. A separate browser run
forces reduced motion and verifies that suppression also works. Keyframe checks
sample the actual Web Animations timeline, not a duplicate animation formula.

---

## I22 — Capability configuration is complete and profile-owned

The added capability pages are the owner's mock design. Their operational scope
and production integration boundaries are recorded in `MOCK-GUIDE.md`.

### Requirements

- **R22.1** MCP, Skills, LLM Plugins, Hooks, CI/CD, Agendar, .env, Providers and
  Shortcuts shall each be navigable, with the profile card remaining visible at
  the foot. *(goldens: `config.toolbar-routes-all-requested-views`,
  `config.profile-card-remains-visible-at-bottom`)*
- **R22.2** Skills shall be toggled and edited through working profile controls.
  *(goldens: `config.skill-toggle-changes-profile`, `config.skill-save-commits`)*
- **R22.3** Agent instructions and turn allowance shall save; MCP configuration
  shall validate URLs and add a sample server. *(goldens:
  `config.agent-editor-saves-profile-config`, `config.mcp-rejects-invalid-url`,
  `config.mcp-adds-server`)*
- **R22.4** Plugins shall configure LLM behavior, and hook tests shall record their
  event. *(goldens: `config.plugins-are-llm-behavior`, `config.hook-test-records-event`)*
- **R22.5** Provider connection shall produce connected metadata without persisting
  the entered credential. *(golden: `config.provider-connects-without-saving-credential`)*
- **R22.6** Shortcuts shall reject duplicate assignments and commit valid bindings.
  *(goldens: `config.shortcut-conflicts-are-rejected`, `config.shortcut-save-commits`)*
- **R22.7** The .env manager shall add/edit/reveal keys and import an actual browser
  File. *(goldens: `config.env-add-edit-and-reveal`, `config.env-opens-a-real-file`)*
- **R22.8** Scheduling shall save recurrence and dispatch a session for Execute now.
  *(goldens: `config.schedule-saves-recurrence`, `config.schedule-run-creates-session`)*
- **R22.9** Pipeline execution shall record its sample logs. *(golden:
  `config.pipeline-run-records-logs`)*

### Guards

- **R22.G1** Configuration edits shall not leak between profiles. *(witness:
  `config.configuration-is-profile-isolated`)*
- **R22.G2** Cancelling an editor shall not commit its draft. *(witness:
  `config.cancel-preserves-skill`)*

---

## I23 — Conversations and execution belong to their session

### Requirements

- **R23.1** Submission shall record a user entry, stream its own response and restore
  that conversation after tab switching. *(goldens:
  `session.submit-records-own-user-message`, `session.stream-completes-own-response`,
  `session.return-restores-the-conversation`)*
- **R23.2** Review and Context shall render session-owned data. *(golden:
  `session.review-and-context-are-session-owned`)*
- **R23.3** File attachments shall be loaded, previewed and kept on the submitted
  message. *(goldens: `session.attachment-is-loaded-and-owned`,
  `session.attachment-preview-shows-content`, `session.attachment-is-on-the-message`)*
- **R23.4** A question shall wait for the user, reject an empty answer, and resume
  after choices and free text are supplied. *(goldens:
  `session.question-waits-for-user`, `session.empty-answer-is-rejected`,
  `session.question-answer-resumes`)*
- **R23.5** Queued input shall stay pending until its idle boundary, then drain.
  *(goldens: `session.queue-is-admitted-without-early-promotion`,
  `session.queue-drains-at-idle-boundary`)*
- **R23.6** Caveman shall affect the sample answer and instruction hooks shall
  contribute to system context. *(goldens: `session.caveman-affects-the-response`,
  `session.hooks-contribute-system-context`)*
- **R23.7** Completed tasks shall expose their own result details. *(golden:
  `session.completed-tasks-have-details`)*
- **R23.8** A disconnected provider shall block a new turn. *(golden:
  `session.disconnected-provider-blocks-new-turn`)*

### Guards

- **R23.G1** Stop shall prevent late response output. *(witness:
  `session.stop-prevents-late-response`)*
- **R23.G2** History shall not leak into another session. *(witness:
  `session.history-does-not-leak-across-tabs`)*

---

## I24 — Menus perform their named actions

### Requirements

- **R24.1** Renaming shall update tabs/history and treat its title as text, not
  markup. *(goldens: `menus.rename-updates-tabs-and-history`,
  `menus.titles-are-text-not-markup`)*
- **R24.2** Share links shall identify both profile and session. *(golden:
  `menus.share-identifies-profile-and-session`)*
- **R24.3** Archiving shall preserve session history. *(golden:
  `menus.archive-preserves-session-history`)*
- **R24.4** File tabs shall open their own content, close and reopen. *(goldens:
  `menus.file-opens-its-own-content`, `menus.close-and-reopen-file-tab`,
  `menus.reopen-restores-editor`)*
- **R24.5** PR creation shall yield a result dialog, and exports shall create a
  browser download. *(goldens: `menus.pull-request-has-a-result-dialog`,
  `menus.exports-create-downloads`)*
- **R24.6** Terminal preview shall record its command and simulated output.
  *(golden: `menus.terminal-records-preview-output`)*
- **R24.7** Palette/settings, custom bindings and new-profile actions shall execute.
  *(goldens: `menus.palette-opens-settings`, `menus.custom-shortcut-executes`,
  `menus.new-profile-opens-a-real-form`)*

### Guards

- **R24.G1** A replaced shortcut shall not keep firing its old default. *(witness:
  `menus.old-shortcut-does-not-fire`)*

---

## I25 — Edge cases retain their ownership and data

### Requirements

- **R25.1** .env import shall parse comments and quoted multiline values and retain
  untouched file text. *(goldens: `edge.env-parses-comments-and-multiline`,
  `edge.env-preserves-untouched-file`)*
- **R25.2** Pipeline logs shall update deployment results, skip deployment after
  failed checks and stay cancelled after Stop. *(goldens:
  `edge.pipeline-deploys-and-refreshes-open-logs`, `edge.failed-checks-skip-deployment`,
  `edge.pipeline-stop-cancels-completion`)*
- **R25.3** Custom provider configuration shall be owned and retained when
  disconnected. *(goldens: `edge.custom-provider-has-own-config`,
  `edge.disconnect-preserves-provider-config`)*
- **R25.4** Background hook execution shall stay with its originating profile.
  *(golden: `edge.background-hooks-stay-with-owner`)*
- **R25.5** Profile Deny shall block a shell request. *(golden:
  `edge.profile-deny-blocks-shell`)*
- **R25.6** New profiles shall start with fresh .env/conversations/browser tabs and
  persist their profile metadata. *(goldens:
  `edge.new-profile-does-not-copy-env-or-conversations`, `edge.new-profile-is-persisted`)*

### Guards

- **R25.G1** A schedule shall reject a past dispatch time. *(witness:
  `edge.schedule-rejects-past-time`)*

---

## Declared divergence

**None.** The one that was declared at the first cut has been closed: the real
sidebar's `Help` footer item (`sidebar.help`) is now in the mock, and
`contract.in-mock-sidebar.help` verifies it rather than excusing it. The ledger
exists for the case where a check finds something the code *should* do and does
not — writing the feature to satisfy the check would be smuggling new behaviour
into a lift, and the gap would have to be named instead.

---

## Promoted from backlog

The profile refactor was excluded from the first cut because it had not shipped.
It has since landed, and is now **I18** with checks in the `profile` group.

---

## Work-package cards

Every requirement and every golden is scheduled by exactly one card.

| Card | Covers | Checks | State |
|---|---|---|---|
| **W1** Single source of session state | R1.1–R1.4, R1.G1–R1.G2 | 6 | shipped |
| **W2** Permission as one decision | R2.1–R2.6, R2.G1–R2.G2 | 9 | shipped |
| **W3** Denial semantics | R3.1–R3.2 | 2 | shipped |
| **W4** App Dock browser contract | R4.1–R4.8, R4.G1–R4.G2 | 13 | shipped |
| **W5** One dock session, two mounts | R5.1–R5.3, R5.G1–R5.G3 | 17 | shipped |
| **W6** Copy provenance | R6.1–R6.3 | 102 | shipped |
| **W7** Sample-data honesty | R7.1, R7.G1 | 2 | shipped |
| **W8** No dead controls | R8.1 | 1 | shipped |
| **W9** Deep-linkable state | R9.1–R9.3 | 12 | shipped |
| **W10** Chrome fits viewport | R10.1–R10.3, R10.G1–R10.G2 | 5 | shipped |
| **W11** Theme completeness | R11.1 | 1 | shipped |
| **W12** DOM integrity | R12.1–R12.2, R12.G1 | 4 | shipped |
| **W13** Composer menus | R13.1–R13.4, R13.G1 | 9 | shipped |
| **W14** Sending appends | R14.1, R14.G1 | 2 | shipped |
| **W15** Command palette | R15.1–R15.5 | 6 | shipped |
| **W16** Review rail | R16.1–R16.3 | 4 | shipped |
| **W17** Home actions | R17.1–R17.2 | 4 | shipped |
| **W18** Profile as the root of state | R18.1–R18.11, R18.G1–R18.G2 | 18 | shipped |
| **W19** Session tab strip at the top of the chat | R19.1–R19.7, R19.G1–R19.G2 | 15 | shipped |
| **W20** Profile card at the foot | R20.1–R20.3, R20.G1 | 4 | shipped |
| **W21** Model identity and activity in session tabs | R21.1–R21.8, R21.G1–R21.G2 | 23 | shipped |
| **W22** Profile capability configuration | R22.1–R22.9, R22.G1–R22.G2 | 19 | shipped |
| **W23** Session history and execution | R23.1–R23.8, R23.G1–R23.G2 | 18 | shipped |
| **W24** Menus and export flows | R24.1–R24.7, R24.G1 | 14 | shipped |
| **W25** Ownership and data edge cases | R25.1–R25.6, R25.G1 | 12 | shipped |

The composer, palette, rail and Home checks are claimed by I13–I17 and scheduled
by W13–W17. Check counts in cards can overlap where a shared witness is used;
the manifest provides the unique inventory.

---

## Traceability

```
25 invariants
  111 positive clauses     -> R1.1..R25.6
  28 guards                -> R*.G*
  139 requirements         -> 111 + 28
318 checks registered     -> every requirement cites >= 1
  0 declared divergences
  0 ratcheted
  0 dangling               -> no requirement without a card, no card without a requirement
```

Verified by two commands, both of which exit non-zero on failure:

```
node check.mjs    # behaviour checks + the manifest drift gate
node trace.mjs    # traceability: every cited check exists, every check is cited
```
