# Orchestra — screen rework chapters

## Current decision

Every proposed Orchestra screen is **rework pending**. The current implementation
is an interactive prototype, not an approved final design. This applies to every
capability page added in the latest round, including MCP and CI/CD.

**Active chapter: none.** The owner chooses the next chapter. IDs below identify
work packages; they do not start work or impose an execution order.

In the mock, each listed screen carries `Cxx · Orchestra · Rework pendente`.
An amber dot and tooltip identify its sidebar destination. The marker describes
the proposed screen, not the provenance of every underlying feature.

## Inventory

| Chapter | Screen | Orchestra proposal / reuse boundary | Status |
| --- | --- | --- | --- |
| C01 | MCP | Dedicated per-profile management screen. MCP infrastructure and product vocabulary are already part of OpenCode. | Rework pending |
| C02 | Skills | Dedicated per-profile management screen; do not classify the Skills concept itself as Orchestra-only. | Rework pending |
| C03 | LLM Plugins | Per-profile LLM behavior/instructions screen. Distinct from OpenCode's general plugin mechanism. | Rework pending |
| C04 | Hooks | Dedicated per-profile event/automation management screen. | Rework pending |
| C05 | Providers | Dedicated per-profile destination. OpenCode already has a Providers settings panel. | Rework pending |
| C06 | Shortcuts | Dedicated per-profile destination. OpenCode already has a Shortcuts settings panel. | Rework pending |
| C07 | CI/CD | Per-profile pipelines, run logs and deployment screen. | Rework pending |
| C08 | Agendar | Per-profile one-off and recurring task scheduling screen. | Rework pending |
| C09 | .env | Dedicated environment-file editor screen. | Rework pending |
| C10 | Home / KPIs | Orchestra dashboard for impact, usage and spending; not the original OpenCode Home. Earlier round. | Rework pending |
| C11 | Agents | Dedicated roster/configuration screen. Agents already exist in OpenCode. Earlier round. | Rework pending |
| C12 | Workspaces | Dedicated per-profile management screen. Workspaces already exist in OpenCode. Earlier round. | Rework pending |
| C13 | Dock | Dedicated navigation destination reusing the existing App Dock browser. Does not classify Chat's Apps tab or its native browser as new. Earlier round. | Rework pending |

C01–C09 cover **all pages added in the latest capability round**. C10–C13 record
earlier Orchestra-specific screen proposals so they remain identifiable too.
Chat and Settings retain their inherited screen classification.

This inventory concerns the screen proposals in this mock. Existing settings
panels, core capabilities and alternate OpenCode versions must not be mistaken
for absent features merely because the mock introduces a new navigation entry.

## One chapter at a time

1. The owner selects one chapter and its scope. Mark only that chapter active.
2. Rework that screen's layout, copy, interactions and relevant states. Record
   which parts reuse OpenCode and which parts need Orchestra implementation.
3. Validate the chapter and obtain the owner's visual/functional acceptance.
4. Mark it accepted, update this register and its visible marker, then select
   the next chapter. Keep every other chapter pending until selected.

Do not launch a cross-screen redesign while a chapter is active. Shared changes
must be required by that chapter and explicitly scoped; they do not implicitly
approve or start the remaining chapters.

## References

- `mock-features.js`: `orchestraChapters`, visible markers and sidebar dots.
- `MOCK-GUIDE.md`: preserved decisions and current prototype behavior.
- Local source: `packages/app/src/components/settings-v2/dialog-settings-v2.tsx`
  mounts Providers and Shortcuts; `packages/app/src/i18n/en.ts` contains MCP,
  Agents and workspace vocabulary; `packages/app/src/pages/session/apps-panel.tsx`
  implements the browser reused by Dock.

Rework status is a design/workflow decision. Existing behavior checks do not
constitute chapter acceptance.
