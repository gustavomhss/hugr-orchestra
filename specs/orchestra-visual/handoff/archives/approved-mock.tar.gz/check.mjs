// check.mjs — the witness layer for the Orchestra mock corpus.
//
// Every requirement in CORPUS.md cites a check id defined here. A clause that
// names no check is not a lift, it is a wish. This file is what makes the corpus
// a lift: it asserts behaviour that is in app.html right now.
//
//   node check.mjs            run everything
//   node check.mjs dock       run one group
//   node check.mjs --list     list groups and check ids
//
// Requires chrome-headless-shell. Override with CHROME=/path/to/binary.

import { spawnSync } from "node:child_process"
import { readFileSync, existsSync, writeFileSync, unlinkSync } from "node:fs"
import { dirname, resolve } from "node:path"
import { fileURLToPath } from "node:url"

const HERE = dirname(fileURLToPath(import.meta.url))
const APP = resolve(HERE, "app.html")
const CHROME =
  process.env.CHROME ||
  `${process.env.HOME}/Library/Caches/ms-playwright/chromium_headless_shell-1217/chrome-headless-shell-mac-x64/chrome-headless-shell`

if (!existsSync(APP)) { console.error(`missing ${APP}`); process.exit(2) }
if (!existsSync(CHROME)) { console.error(`missing chrome-headless-shell at ${CHROME}\nset CHROME=`); process.exit(2) }

const src = readFileSync(APP, "utf8")
const LIGHT = src.replace('<html lang="en"', '<html lang="en" data-scheme="light"')

// Each group is one page load: checks inside a group must not fight over state,
// so anything that mutates gets its own file written next to app.html and removed
// after. Groups are listed in dependency-free order.
const GROUPS = {
  // ---------------------------------------------------------------- static
  dom: `
    // every div inside the workspace balances, so no element silently reparents.
    // clone without <script>/<style>: body.innerHTML would otherwise scan the app's
    // own source and report template-literal ids as duplicates
    const bare = document.body.cloneNode(true)
    bare.querySelectorAll("script,style").forEach(n => n.remove())
    const html = bare.innerHTML
    const start = html.indexOf('<div class="workspace">')
    const seg = html.slice(start)
    let d = 0
    for (const m of seg.matchAll(/<(\\/)?div\\b[^>]*?(\\/)?>/g)) { if (m[2]) continue; d += m[1] ? -1 : 1 }
    ok("dom.div-balance", d === 0, "workspace div depth=" + d)
    // Read actual attributes; matching /id=/ also matches data-id on controls.
    const ids = [...bare.querySelectorAll("[id]")].map(e => e.id)
    const dup = ids.filter((v, i) => ids.indexOf(v) !== i)
    ok("dom.no-duplicate-ids", dup.length === 0, "dups=" + [...new Set(dup)].join(","))
    // CSSOM agrees with the source: a rule silently dropped by a parse error
    // still leaves a balanced stylesheet, so count both and compare
    const rules = [...document.styleSheets[0].cssRules]
    const selRules = rules.filter(r => r.selectorText).length
    ok("dom.stylesheet-parsed", rules.length > 400, "cssRules=" + rules.length)
    ok("dom.selector-rules", selRules > 300, "selectorRules=" + selRules)`,

  theme: `
    // Every base rule that paints must have a light counterpart, otherwise the
    // surface is unreadable in one theme. This is the rule that broke 105 times.
    const sheets = [...document.styleSheets].flatMap(s => [...s.cssRules])
    const light = new Set(), lightTokens = new Set(), base = []
    for (const r of sheets) {
      if (!r.selectorText) continue
      for (const one of r.selectorText.split(",")) {
        const t = one.trim()
        if (t.startsWith('[data-scheme="light"]')) {
          light.add(t.slice('[data-scheme="light"]'.length).trim())
          if (t === '[data-scheme="light"]') for (const property of r.style) {
            if (property.startsWith("--")) lightTokens.add(property)
          }
        }
        else base.push({ sel: t, css: r.style.cssText })
      }
    }
    const paints = b => /(?:^|[;{])\\s*(?:color|background|border-color|box-shadow)\\s*:/.test(b)
    const allowed = new Set(["html", "body", ".ic", ".traffic i", ".traffic i:nth-child(2)",
      ".traffic i:nth-child(3)", ".ck li:before", ".live:before", ".zen-ws-dot", ".tool-ind i",
      ".workspace", ".perm-tool .seg", ".palette-foot kbd", ".perm-table", ".toggle",
      ".zen-tab-section-label", ".rail-diff .ln"])
    // Token-based surfaces need every painting value covered by a light token.
    const tokensCover = css => {
      const values = [...css.matchAll(/(?:^|;)\\s*(?:color|background|border-color|box-shadow)\\s*:\\s*([^;]+)/g)].map(m => m[1].trim())
      return values.length > 0 && values.every(value => {
        if (["transparent", "inherit", "currentcolor", "none"].includes(value.toLowerCase())) return true
        const tokens = [...value.matchAll(/var\\((--[a-zA-Z0-9-]+)\\)/g)].map(m => m[1])
        return tokens.length > 0 && tokens.every(token => lightTokens.has(token)) && !/#|rgba?\\(|hsla?\\(/i.test(value)
      })
    }
    const missing = base.filter(b => paints(b.css) && !light.has(b.sel) && !allowed.has(b.sel) && !tokensCover(b.css))
    ok("theme.painting-rules-have-light", missing.length === 0,
       "missing=" + missing.map(m => m.sel).join(","))`,

  profile: `
    // a profile is one repository and owns everything that belongs to it
    const vis = () => document.querySelector('[id^=view]:not([hidden])').id
    const go = id => {
      if (document.getElementById("profileMenu").hidden) document.getElementById("profileCard").click()
      document.querySelector('#profileMenu [data-profile="' + id + '"]').click()
    }
    const shell = () => ({
      active: document.querySelector("#profileMenu [data-profile].on")?.dataset.profile,
      name: document.getElementById("profileName").textContent,
      branch: document.getElementById("profileMeta").textContent.split(" · ")[1],
      sessions: document.querySelectorAll("#chatTabs [data-session]").length,
      sessionNames: [...document.querySelectorAll("#sessionList [data-session]")].map(b => b.textContent.replace(/\\d+k$/, "")),
      tokens: document.querySelector("#kpiGrid .kpi-value")?.textContent,
      model: document.querySelector('.ctl[data-menu=model]')?.textContent,
      effort: document.querySelector('.ctl[data-menu=reasoning]')?.textContent,
      dockTabs: [...document.querySelectorAll("#dockBody .zen-tab")].map(t => t.textContent),
      activeTab: document.querySelector("#dockBody .zen-tab.is-active")?.textContent,
      agents: [...document.querySelectorAll("#agentsBody .agent b")].map(b => b.textContent),
      bash: document.querySelector('[data-tool=bash] button.on')?.textContent,
    })

    document.querySelector('[data-view=home]').click()
    const base = shell()
    const card = document.getElementById("profileCard")
    ok("profile.card-shows-the-active-project",
       card.querySelector("#profileName").textContent === "orchestra-canonical" &&
       card.querySelector("#profileMeta").textContent.includes("3 agents"),
       card.textContent.replace(/\s+/g, " ").trim().slice(0, 40))
    ok("profile.card-lives-at-the-foot",
       card.getBoundingClientRect().top > document.querySelector(".side-nav").getBoundingClientRect().top,
       "card is below the nav")
    ok("profile.menu-lists-the-projects", (() => {
      card.click()
      const items = document.querySelectorAll("#profileMenu [data-profile]").length
      const open = !document.getElementById("profileMenu").hidden
      document.body.click()
      return open && items === 3 && document.getElementById("profileMenu").hidden
    })(), "items=" + document.querySelectorAll("#profileMenu [data-profile]").length)
    ok("profile.starts-on-a-profile", base.active === "canonical" && base.name === "orchestra-canonical",
       "active=" + base.active + " name=" + base.name)
    ok("profile.sessions-follow-the-profile", base.sessions === 3, "sessions=" + base.sessions)

    go("local-app")
    const local = shell()
    ok("profile.switch-marks-active", local.active === "local-app" && local.name === "local-app", JSON.stringify(local.active))
    ok("profile.switch-swaps-sessions", local.sessions === 2, "sessions=" + local.sessions)
    ok("profile.switch-swaps-kpis", local.tokens !== base.tokens, base.tokens + " -> " + local.tokens)
    ok("profile.switch-swaps-composer", local.model === "GPT-5 Codex" && local.effort === "Medium",
       local.model + "/" + local.effort)
    ok("profile.switch-swaps-dock", JSON.stringify(local.dockTabs) !== JSON.stringify(base.dockTabs),
       JSON.stringify(local.dockTabs))
    ok("profile.switch-swaps-agents",
       JSON.stringify(local.agents) !== JSON.stringify(base.agents) && !local.agents.includes("Atlas"),
       JSON.stringify(local.agents))
    ok("profile.switch-swaps-permissions", local.bash === "Deny", "bash=" + local.bash)
    const spend = () => [...document.querySelectorAll("#modelRows .chip")].map(c => c.textContent)
    ok("profile.switch-swaps-spend", JSON.stringify(spend()) !== JSON.stringify(spend().slice(0, spend().length - 1)) || spend().length < 4,
       "spend=" + spend().join(","))
    ok("profile.kicker-names-the-profile",
       document.getElementById("kicker").textContent.includes("local-app"),
       document.getElementById("kicker").textContent)

    go("pr-sandbox")
    const sandbox = shell()
    ok("profile.third-profile-switches", sandbox.active === "pr-sandbox" && sandbox.sessions === 1,
       sandbox.active + " sessions=" + sandbox.sessions)
    ok("profile.effort-none-is-a-real-value", sandbox.effort === "None", "effort=" + sandbox.effort)

    go("canonical")
    const back = shell()
    ok("profile.switch-is-reversible",
       back.tokens === base.tokens && back.model === base.model &&
       JSON.stringify(back.dockTabs) === JSON.stringify(base.dockTabs) &&
       JSON.stringify(back.agents) === JSON.stringify(base.agents) &&
       back.bash === base.bash,
       JSON.stringify({ tokens: back.tokens, model: back.model, bash: back.bash }))

    // the session's live state belongs to the profile too
    ok("profile.session-state-per-profile", (() => {
      document.querySelector('[data-view=session]').click()
      document.querySelector('[data-state=permission]').click()
      const a = document.getElementById("permDock").hidden === false
      go("local-app")
      // local-app denies bash, so the same state cannot ask for approval
      const b = document.getElementById("permDock").hidden === true
      go("canonical")
      document.querySelector('[data-view=home]').click()
      return a && b
    })(), "canonical asks, local-app does not")

    // the profile survives a reload
    ok("profile.persists", (() => {
      go("local-app")
      const stored = localStorage.getItem("orchestra-profile")
      go("canonical")
      return stored === "local-app"
    })(), "stored=" + localStorage.getItem("orchestra-profile"))

    // every profile's roster and table are non-empty, so the swap is demonstrable
    document.querySelector('[data-view=agents]').click()
    go("pr-sandbox")
    ok("profile.roster-is-per-profile", document.querySelectorAll("#agentsBody .agent").length === 1,
       "agents=" + document.querySelectorAll("#agentsBody .agent").length)
    document.querySelector('[data-view=settings]').click()
    ok("profile.permission-table-is-per-profile",
       document.querySelectorAll("#settingsBody .perm-tool").length === 14,
       "tools=" + document.querySelectorAll("#settingsBody .perm-tool").length)`,

  edgeflows: `
    const nav = key => document.querySelector('[data-mx-nav="' + key + '"]').click()
    const click = (action, id) => {
      const selector = '[data-mx-action="' + action + '"]' + (id ? '[data-id="' + id + '"]' : "")
      const control = [...document.querySelectorAll(selector)].find(e => e.getBoundingClientRect().width > 0)
      if (!control) throw new Error("Missing edge flow control " + selector)
      control.click()
    }
    const form = () => document.querySelector('.mx-dialog[open] form')
    const field = (name, value) => { form().elements.namedItem(name).value = value }
    const switchTo = id => { document.getElementById('profileCard').click(); document.querySelector('#profileMenu [data-profile="' + id + '"]').click() }
    nav("env")
    const content = '# keep header\\nexport URL="https://example.test/#fragment" # keep this\\nMULTILINE="first\\nsecond"\\nCOUNT=12 # count\\nEMPTY=\\n'
    const input = document.querySelector('[data-mx-env]'), files = new DataTransfer()
    files.items.add(new File([content], '.env', { type: 'text/plain' }))
    input.files = files.files; input.dispatchEvent(new Event('change', { bubbles: true }))
    await new Promise(resolve => setTimeout(resolve, 60))
    ok("edge.env-parses-comments-and-multiline", P.envRecords.find(r => r.key === 'URL').value.endsWith('#fragment') && P.envRecords.find(r => r.key === 'MULTILINE').value === 'first\\nsecond' && P.envRecords.find(r => r.key === 'COUNT').value === '12')
    click("env-preview")
    ok("edge.env-preserves-untouched-file", document.querySelector('.mx-dialog pre').textContent === content)
    click("close-dialog")
    nav("cicd")
    click("pipeline-edit", "checks")
    field("environment", "Staging"); form().elements.namedItem('deploy').checked = true; form().requestSubmit()
    click("pipeline-run", "checks")
    click("pipeline-logs", "checks")
    await new Promise(resolve => setTimeout(resolve, 1950))
    ok("edge.pipeline-deploys-and-refreshes-open-logs", P.pipelines[0].logs.includes('Deploy to Staging: preview complete') && document.querySelector('[data-mx-pipeline-log]').textContent.includes('Deploy to Staging'))
    click("close-dialog")
    click("pipeline-edit", "checks"); field("command", "bun test --fail"); form().requestSubmit()
    click("pipeline-run", "checks")
    await new Promise(resolve => setTimeout(resolve, 1950))
    ok("edge.failed-checks-skip-deployment", P.pipelines[0].status === 'Failed' && P.pipelines[0].logs.includes('skipped due to failed checks'))
    click("pipeline-run", "checks"); click("pipeline-stop", "checks")
    await new Promise(resolve => setTimeout(resolve, 1950))
    ok("edge.pipeline-stop-cancels-completion", P.pipelines[0].status === 'Cancelled')
    nav("schedule"); click("schedule-edit")
    field("name", "Past time"); field("prompt", "Review the project"); field("date", "2000-01-01T12:00"); form().requestSubmit()
    ok("edge.schedule-rejects-past-time", document.querySelector('.mx-dialog').open && document.querySelector('.mx-error').textContent.includes('futuro'))
    click("close-dialog")
    nav("providers"); click("provider-pick"); click("provider-custom")
    field("name", "Local gateway"); form().requestSubmit()
    ok("edge.custom-provider-has-own-config", P.providers.some(p => p.id === 'local-gateway' && p.endpoint.includes('localhost')))
    click("provider-disconnect", "local-gateway")
    ok("edge.disconnect-preserves-provider-config", P.providers.find(p => p.id === 'local-gateway').status === 'Disconnected' && P.providers.find(p => p.id === 'local-gateway').endpoint.includes('localhost'))
    switchTo("local-app"); nav("hooks"); click("hook-toggle", "evidence")
    const local = P, localRuns = local.hooks.find(h => h.id === 'evidence').runs
    switchTo("canonical"); document.querySelector('[data-view="session"]').click(); document.querySelector('[data-act="newsession"]').click()
    const session = P.sessions.find(s => s.id === openSessionID)
    document.querySelector('.composer input').value = 'Summarize the current context.'; document.querySelector('.send').click()
    switchTo("local-app")
    await new Promise(resolve => setTimeout(resolve, 2200))
    ok("edge.background-hooks-stay-with-owner", session.replyCount === 1 && local.hooks.find(h => h.id === 'evidence').runs === localRuns)
    switchTo("canonical"); document.querySelector('[data-view="settings"]').click()
    document.querySelector('[data-tool="bash"] [data-v="deny"]').click()
    document.querySelector('[data-view="session"]').click(); document.querySelector('[data-act="newsession"]').click()
    document.querySelector('.composer input').value = 'Run bun test for this session.'; document.querySelector('.send').click()
    ok("edge.profile-deny-blocks-shell", P.sessions.find(s => s.id === openSessionID).live === 'denied' && document.getElementById('permDock').hidden)
    document.getElementById('profileCard').click(); click("profile-new")
    field("name", "Fresh project"); field("path", "Documents/fresh-project"); field("branch", "dev"); form().requestSubmit()
    ok("edge.new-profile-does-not-copy-env-or-conversations", P.name === 'Fresh project' && P.envRecords.length === 0 && P.sessions.length === 1 && P.sessions[0].title === 'New session' && Object.values(P.dock.tabs).flat().length === 0)
    ok("edge.new-profile-is-persisted", JSON.parse(localStorage.getItem('orchestra-mock-complete-v1'))[P.id].name === 'Fresh project')`,

  sessionflows: `
    const active = () => P.sessions.find(s => s.id === openSessionID)
    const click = action => {
      const b = [...document.querySelectorAll('[data-mx-action="' + action + '"]')].find(e => e.getBoundingClientRect().width > 0)
      if (!b) throw new Error("Missing session action " + action)
      b.click()
    }
    const send = text => { document.querySelector(".composer input").value = text; document.querySelector(".send").click() }
    const settle = async predicate => {
      for (let i = 0; i < 100 && !predicate(); i++) await new Promise(resolve => setTimeout(resolve, 60))
      if (!predicate()) throw new Error("Preview turn did not settle")
    }
    const selectSession = id => document.querySelector('#chatTabs [data-session="' + id + '"] .chat-tab-select').click()
    document.querySelector('[data-act="newsession"]').click()
    const session = active(), ownID = session.id
    send("Summarize the changes carefully.")
    ok("session.submit-records-own-user-message", session.extras.length === 1 && session.extras[0].role === "user")
    await settle(() => !session.executing)
    ok("session.stream-completes-own-response", session.extras.some(e => e.role === "assistant" && !e.streaming && e.text.length > 30) && session.live === "idle")
    ok("session.caveman-affects-the-response", session.extras.at(-1).plugin.includes("Caveman") && session.extras.at(-1).text.startsWith("Context reviewed:"))
    selectSession("s2")
    ok("session.history-does-not-leak-across-tabs", document.querySelectorAll('.scroll .mx-extra').length === 0 && active().id !== ownID)
    ok("session.review-and-context-are-session-owned", document.getElementById('fileList').textContent.includes('session-recovery') && document.querySelector('.ctx-stats').textContent.includes('Session recovery'))
    selectSession(ownID)
    ok("session.return-restores-the-conversation", document.querySelectorAll('.scroll .mx-extra').length === 2 && document.querySelector('.scroll .mx-extra p').textContent === "Summarize the changes carefully.")
    const transfer = new DataTransfer()
    transfer.items.add(new File(["Evidence for this session."], "evidence.txt", { type: "text/plain" }))
    const fileInput = document.querySelector('[data-mx-attachment-input]')
    fileInput.files = transfer.files; fileInput.dispatchEvent(new Event('change', { bubbles: true }))
    await settle(() => session.attachments.length === 1)
    ok("session.attachment-is-loaded-and-owned", session.attachments[0].content === "Evidence for this session." && document.querySelector('.mx-attachment').textContent.includes('evidence.txt'))
    click("attachment-view")
    ok("session.attachment-preview-shows-content", document.querySelector('.mx-dialog[open]').textContent.includes("Evidence for this session."))
    click("close-dialog")
    send("Give a focused summary of the attached evidence.")
    click("stop-run")
    const count = session.extras.length
    await new Promise(resolve => setTimeout(resolve, 900))
    ok("session.stop-prevents-late-response", !session.executing && session.live === "idle" && session.extras.length === count && session.taskRecords.every(t => t.status === "cancelled"))
    ok("session.attachment-is-on-the-message", session.extras.at(-1).attachments[0].name === "evidence.txt" && session.attachments.length === 0)
    send("Ask me which approach to choose.")
    ok("session.question-waits-for-user", session.live === "question" && !document.getElementById('questionDock').hidden && document.querySelector('#chatTabs .on .chat-tab-icon').dataset.activity === "waiting")
    click("question-answer")
    ok("session.empty-answer-is-rejected", !document.querySelector('#questionDock .mx-error').hidden && session.live === "question")
    click("question-multiple")
    const choices = document.querySelectorAll('#questionDock input[type="checkbox"]')
    choices[0].checked = true; choices[2].checked = true
    document.querySelector('#questionDock textarea').value = "Keep the change small."
    click("question-answer")
    await settle(() => !session.executing)
    ok("session.question-answer-resumes", session.live === "idle" && session.extras.some(e => e.text.includes("Focused change") && e.text.includes("Tests first") && e.text.includes("Keep the change small.")))
    click("delivery-mode")
    const form = document.querySelector('.mx-dialog[open] form')
    form.elements.namedItem('delivery').value = "Queue"; form.requestSubmit()
    const replies = session.replyCount
    send("First queued demonstration.")
    send("Follow up after the first turn.")
    ok("session.queue-is-admitted-without-early-promotion", session.pendingPrompts.length === 1 && !session.extras.some(e => e.text === "Follow up after the first turn."))
    await settle(() => !session.executing && session.pendingPrompts.length === 0)
    ok("session.queue-drains-at-idle-boundary", session.replyCount === replies + 2 && session.extras.some(e => e.text === "Follow up after the first turn."))
    ok("session.hooks-contribute-system-context", session.hookEvents.some(e => e.event === "Before prompt") && document.querySelector('.ctx-pre').textContent.includes("Read project instructions"))
    ok("session.completed-tasks-have-details", session.taskRecords[0].status === "completed" && session.taskRecords[0].output.includes("Simulated execution complete"))
    const route = session.model.providerID
    P.providers = P.providers.filter(p => p.id !== route)
    send("Describe the current context.")
    ok("session.disconnected-provider-blocks-new-turn", session.live === "error" && !session.executing && session.extras.at(-1).text.includes("Connect this session's provider"))`,

  menuflows: `
    const click = action => {
      const b = [...document.querySelectorAll('[data-mx-action="' + action + '"]')].find(e => e.getBoundingClientRect().width > 0)
      if (!b) throw new Error("Missing menu action " + action)
      b.click()
    }
    const more = () => [...document.querySelectorAll('.head-actions button')].find(b => b.textContent.trim() === "•••").click()
    const form = () => document.querySelector('.mx-dialog[open] form')
    const original = P.sessions.find(s => s.id === openSessionID)
    more(); click("rename-session")
    form().elements.namedItem('title').value = "<b>Scoped title</b>"; form().requestSubmit()
    ok("menus.rename-updates-tabs-and-history", document.querySelector('#chatTabs .on .chat-tab-title').textContent === original.title && document.getElementById('sessionRows').textContent.includes(original.title))
    ok("menus.titles-are-text-not-markup", !document.querySelector('#chatTabs .chat-tab-title b') && original.title === "<b>Scoped title</b>")
    more(); click("share-session")
    const link = new URL(form().elements.namedItem('link').value)
    ok("menus.share-identifies-profile-and-session", link.searchParams.get('profile') === P.id && link.hash.includes(original.id))
    click("close-dialog")
    more(); click("archive-session"); form().requestSubmit()
    ok("menus.archive-preserves-session-history", original.archived && P.sessions.includes(original) && !document.querySelector('#chatTabs [data-session="' + original.id + '"]'))
    const target = P.sessions.find(s => s.id === openSessionID)
    runPaletteItem({ kind: "file", title: target.fileRecords[0].path })
    ok("menus.file-opens-its-own-content", document.querySelector('.rail-panel.on').dataset.panel === "editor" && document.querySelector('.editor pre').textContent.includes(target.title))
    runPaletteItem({ kind: "command", id: "tab.close" })
    ok("menus.close-and-reopen-file-tab", document.querySelector('#railTabs [data-panel="editor"]').hidden)
    runPaletteItem({ kind: "command", id: "tab.reopenClosed" })
    ok("menus.reopen-restores-editor", !document.querySelector('#railTabs [data-panel="editor"]').hidden && document.querySelector('.rail-panel.on').dataset.panel === "editor")
    runPaletteItem({ kind: "command", id: "review.toggle" })
    click("pr-create")
    form().elements.namedItem('title').value = "Scoped review proposal"; form().requestSubmit()
    await new Promise(resolve => setTimeout(resolve, 20))
    ok("menus.pull-request-has-a-result-dialog", document.querySelector('.mx-dialog[open]').textContent.includes("Pull request preview") && target.pullRequest.title === "Scoped review proposal")
    click("pr-download")
    ok("menus.exports-create-downloads", Mock.downloads.at(-1).name.endsWith('-pr.md') && Mock.downloads.at(-1).size > 0)
    click("close-dialog")
    runPaletteItem({ kind: "command", id: "terminal.toggle" })
    const terminalForm = document.querySelector('[data-mx-terminal]')
    terminalForm.querySelector('input').value = "bun run build"; terminalForm.requestSubmit()
    ok("menus.terminal-records-preview-output", target.terminalLines.join(' ').includes('bun run build') && target.terminalLines.join(' ').includes('No shell command executed'))
    runPaletteItem({ kind: "command", id: "settings.open" })
    ok("menus.palette-opens-settings", !views.settings.hidden)
    document.querySelector('[data-mx-nav="shortcuts"]').click()
    click("shortcut-edit")
    form().elements.namedItem('binding').value = "⌘J"; form().requestSubmit()
    dispatchEvent(new KeyboardEvent('keydown', { key: 'j', metaKey: true }))
    ok("menus.custom-shortcut-executes", !document.getElementById('palette').hidden)
    dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }))
    dispatchEvent(new KeyboardEvent('keydown', { key: 'k', metaKey: true }))
    ok("menus.old-shortcut-does-not-fire", document.getElementById('palette').hidden)
    runPaletteItem({ kind: "command", id: "project.open" })
    ok("menus.new-profile-opens-a-real-form", !!form() && form().elements.namedItem('path'))
    click("close-dialog")`,

  configflows: `
    const go = key => document.querySelector('[data-mx-nav="' + key + '"]').click()
    const click = (action, id) => {
      const selector = '[data-mx-action="' + action + '"]' + (id ? '[data-id="' + id + '"]' : "")
      const visible = [...document.querySelectorAll(selector)].find(e => e.getBoundingClientRect().width > 0)
      if (!visible) throw new Error("Missing visible control: " + selector)
      visible.click()
    }
    const form = () => document.querySelector('.mx-dialog[open] form')
    const fill = (name, value) => { form().elements.namedItem(name).value = value }
    const save = () => form().requestSubmit()
    const allViews = ["mcp", "skills", "plugins", "hooks", "cicd", "schedule", "env", "providers", "shortcuts"]
    ok("config.toolbar-routes-all-requested-views", allViews.every(key => {
      go(key)
      return !views[key].hidden && views[key].querySelector('[data-mx-body]').children.length > 0
    }))
    const side = document.querySelector('.side').getBoundingClientRect()
    const card = document.getElementById('profileCard').getBoundingClientRect()
    ok("config.profile-card-remains-visible-at-bottom", card.bottom <= side.bottom && card.top > side.top + side.height / 2)
    go("skills")
    const skill = P.skills[0], before = skill.enabled
    click("skill-toggle", skill.id)
    ok("config.skill-toggle-changes-profile", skill.enabled !== before)
    click("skill-edit", skill.id)
    const oldName = skill.name
    fill("name", "Discard this draft")
    click("close-dialog")
    ok("config.cancel-preserves-skill", skill.name === oldName)
    click("skill-edit", skill.id)
    fill("name", "Precise review")
    save()
    ok("config.skill-save-commits", P.skills.find(s => s.id === skill.id).name === "Precise review" && !document.querySelector('.mx-dialog').open)
    go("plugins")
    click("plugin-edit", "caveman")
    fill("intensity", "ultra")
    save()
    ok("config.plugins-are-llm-behavior", P.llmPlugins.find(p => p.id === "caveman").intensity === "ultra")
    go("hooks")
    click("hook-test", P.hooks[0].id)
    ok("config.hook-test-records-event", P.hooks[0].runs === 1 && P.hooks[0].lastRun.includes("No command executed"))
    go("mcp")
    click("mcp-edit")
    fill("name", "Invalid URL demo"); fill("transport", "http"); fill("endpoint", "not a URL")
    save()
    ok("config.mcp-rejects-invalid-url", document.querySelector('.mx-dialog').open && !document.querySelector('.mx-error').hidden)
    fill("endpoint", "https://mcp.example.test/new")
    save()
    ok("config.mcp-adds-server", P.mcpServers.some(s => s.name === "Invalid URL demo" && s.status === "Connected"))
    go("providers")
    click("provider-connect", "google")
    fill("credential", "sample-never-persist-this-secret"); save()
    ok("config.provider-connects-without-saving-credential",
       P.providers.some(p => p.id === "google" && p.status === "Connected") &&
       !localStorage.getItem("orchestra-mock-complete-v1").includes("sample-never-persist-this-secret"))
    go("shortcuts")
    click("shortcut-edit", "New session")
    fill("binding", P.shortcuts["Command palette"]); save()
    ok("config.shortcut-conflicts-are-rejected", document.querySelector('.mx-dialog').open && !document.querySelector('.mx-error').hidden)
    fill("binding", "⌘⇧J"); save()
    ok("config.shortcut-save-commits", P.shortcuts["New session"] === "⌘⇧J")
    go("env")
    click("env-edit")
    fill("key", "PREVIEW_TEST"); fill("value", "hello world"); save()
    click("env-reveal", "PREVIEW_TEST")
    ok("config.env-add-edit-and-reveal", P.envRecords.some(r => r.key === "PREVIEW_TEST" && r.value === "hello world" && r.revealed))
    const input = document.querySelector('[data-mx-env]')
    const transfer = new DataTransfer()
    transfer.items.add(new File(['# sample\\nexport DEMO_KEY="new value"\\nPORT=4096\\n'], ".env", { type: "text/plain" }))
    input.files = transfer.files
    input.dispatchEvent(new Event("change", { bubbles: true }))
    await new Promise(resolve => setTimeout(resolve, 60))
    ok("config.env-opens-a-real-file", P.envRecords.length === 2 && P.envRecords[0].key === "DEMO_KEY" && P.envRecords[0].value === "new value")
    document.querySelector('[data-view="agents"]').click()
    click("agent-edit", "Maestro")
    fill("system", "Use explicit evidence."); fill("steps", "12"); save()
    ok("config.agent-editor-saves-profile-config", P.agents[0].system === "Use explicit evidence." && P.agents[0].steps === 12)
    go("schedule")
    click("schedule-edit")
    fill("name", "Evening check"); fill("prompt", "Review the latest changes."); fill("cadence", "Weekly"); save()
    ok("config.schedule-saves-recurrence", P.schedules.some(s => s.name === "Evening check" && s.cadence === "Weekly"))
    const schedule = P.schedules.find(s => s.name === "Evening check")
    click("schedule-run", schedule.id)
    ok("config.schedule-run-creates-session", P.sessions[0].title === "Evening check" && schedule.runs === 1)
    go("cicd")
    click("pipeline-run", "checks")
    await new Promise(resolve => setTimeout(resolve, 1950))
    ok("config.pipeline-run-records-logs", P.pipelines[0].status === "Passed" && P.pipelines[0].logs.includes("Simulated run"))
    document.getElementById("profileCard").click()
    document.querySelector('#profileMenu [data-profile="local-app"]').click()
    ok("config.configuration-is-profile-isolated",
       P.skills[0].name === "Code review" && P.llmPlugins[0].intensity === "full" && P.shortcuts["New session"] === "⌘N" &&
       !P.schedules.some(s => s.name === "Evening check"))`,

  modellogos: `
    const resolve = resolveSessionLogo
    ok("logos.manufacturer-before-router",
       resolve({ id: "claude-3.5-sonnet", providerID: "opencode" }).logo === "anthropic" &&
       resolve({ id: "openai/gpt-5", providerID: "openrouter" }).logo === "openai" &&
       resolve({ id: "deepseek/deepseek-chat", providerID: "openrouter" }).logo === "deepseek")
    ok("logos.missing-brand-uses-router",
       resolve({ id: "custom", manufacturer: "unlisted-maker", providerID: "openrouter" }).logo === "openrouter" &&
       resolve({ id: "custom", manufacturer: "custom-lab", providerID: "opencode" }).logo === "opencode")
    ok("logos.unknown-model-uses-router",
       resolve({ id: "my-claude-looking-alias", providerID: "openrouter" }).source === "provider")
    ok("logos.unknown-route-is-neutral",
       resolve({ id: "custom", providerID: "unknown-router" }).logo === "neutral" &&
       resolve({ id: "constructor", providerID: "toString" }).logo === "neutral")
    ok("logos.transport-does-not-imply-manufacturer",
       resolve({ id: "private-model", providerID: "openrouter", api: "openai-compatible" }).logo === "openrouter")
    const icons = () => [...document.querySelectorAll("#chatTabs .chat-tab-icon")]
    ok("logos.each-tab-owns-its-model",
       icons().map(i => i.dataset.logo).join("/") === "anthropic/openai/deepseek")
    ok("logos.svg-marks-render",
       icons().every(i => {
         const svg = i.querySelector("svg")
         const symbol = document.querySelector(svg.querySelector("use").getAttribute("href"))
         return !!symbol?.querySelector("path") && svg.getBBox().width > 0 && svg.getBBox().height > 0
       }))
    const current = () => document.querySelector("#chatTabs .chat-tab.on .chat-tab-icon")
    document.querySelector('.ctl[data-menu="model"]').click()
    document.querySelector('#pop [data-pick="gpt-5-codex"]').click()
    document.body.click()
    ok("logos.composer-choice-is-not-current-turn", current().dataset.logo === "anthropic")
    document.querySelector(".composer input").value = "Run the next turn with Codex"
    document.querySelector(".send").click()
    ok("logos.send-records-the-new-model",
       current().dataset.logo === "openai" && current().title.includes("gpt-5-codex") &&
       icons()[1].title.includes("openai/gpt-5") && icons()[2].dataset.logo === "deepseek")
    const switchTo = id => {
      document.getElementById("profileCard").click()
      document.querySelector('#profileMenu [data-profile="' + id + '"]').click()
    }
    switchTo("local-app")
    const local = icons().map(i => i.dataset.logo).join("/")
    switchTo("pr-sandbox")
    ok("logos.routes-and-models-are-profile-owned",
       local === "openai/opencode" && current().dataset.logo === "openrouter")
    switchTo("canonical")
    document.querySelector('[data-act="newsession"]').click()
    ok("logos.new-session-shows-configured-model-statically",
       current().dataset.logo === "openai" && current().dataset.activity === "idle" &&
       getComputedStyle(current().querySelector("svg")).animationName === "none")`,

  logomotion: `
    const current = () => document.querySelector("#chatTabs .chat-tab.on .chat-tab-icon")
    const svg = () => current().querySelector("svg")
    const motion = () => getComputedStyle(svg()).animationName
    ok("motion.running-pulses", current().dataset.activity === "running" && motion() === "model-pulse",
       "activity=" + current().dataset.activity + " animation=" + motion() + " reduced=" + matchMedia("(prefers-reduced-motion: reduce)").matches)
    const sample = (element, offset) => {
      const animation = element.getAnimations()[0]
      if (!animation) throw new Error("Expected a live CSS animation")
      animation.pause()
      animation.currentTime = Number(animation.effect.getTiming().duration) * offset
      const css = getComputedStyle(element)
      return { opacity: Number(css.opacity), matrix: new DOMMatrixReadOnly(css.transform) }
    }
    const low = sample(svg(), 0)
    const high = sample(svg(), .5)
    ok("motion.pulse-is-subtle",
       high.opacity > low.opacity && low.opacity >= .65 && high.opacity <= 1 &&
       low.matrix.a >= .95 && high.matrix.a <= 1.04 && low.matrix.m42 === 0 && high.matrix.m42 === 0)
    document.querySelector('#chatTabs [data-session="s2"] .chat-tab-select').click()
    const background = document.querySelector('#chatTabs [data-session="s1"] .chat-tab-icon')
    ok("motion.selection-is-not-execution",
       motion() === "none" && background.dataset.activity === "running" &&
       getComputedStyle(background.querySelector("svg")).animationName === "model-pulse")
    document.querySelector('#chatTabs [data-session="s1"] .chat-tab-select').click()
    // A question producer can mark waiting without changing the provider identity.
    const session = P.sessions.find(s => s.id === "s1")
    session.waitingForResponse = true
    updateSessionLogo(session)
    const questionWait = current().dataset.activity === "waiting" && motion() === "model-bounce"
    session.waitingForResponse = false
    updateSessionLogo(session)
    document.querySelector('[data-state="permission"]').click()
    ok("motion.waiting-bounces", questionWait && current().dataset.activity === "waiting" && motion() === "model-bounce")
    const floor = sample(svg(), 0)
    const apex = sample(svg(), .46)
    const impact = sample(svg(), .94)
    ok("motion.bounce-has-ascent-and-impact",
       floor.matrix.m42 - apex.matrix.m42 >= 6 && impact.matrix.m42 > apex.matrix.m42 &&
       impact.matrix.d < .95 && impact.matrix.a > 1 && apex.matrix.d >= .98)
    ok("motion.bounce-has-ground-shadow",
       getComputedStyle(current(), "::after").animationName === "model-bounce-shadow" &&
       getComputedStyle(current(), "::after").content !== "none")
    document.querySelector(".perm-once").click()
    ok("motion.answer-returns-to-pulse", current().dataset.activity === "running" && motion() === "model-pulse")
    const stopped = ["idle", "error", "denied"].every(state => {
      document.querySelector('[data-state="' + state + '"]').click()
      return current().dataset.activity === "idle" && motion() === "none" && svg().getAnimations().length === 0
    })
    ok("motion.stopped-states-are-static", stopped)`,

  logopreview: `
    const icon = () => document.querySelector("#chatTabs .chat-tab.on .chat-tab-icon")
    const animated = () => getComputedStyle(icon().querySelector("svg")).animationName
    ok("motion.preview-enables-pulse",
       matchMedia("(prefers-reduced-motion: reduce)").matches &&
       document.documentElement.dataset.motion === "full" && animated() === "model-pulse")
    document.querySelector('[data-state="permission"]').click()
    ok("motion.preview-enables-bounce", animated() === "model-bounce" &&
       getComputedStyle(icon(), "::after").animationName === "model-bounce-shadow")`,

  logoreduced: `
    ok("motion.reduced-preference-is-active", matchMedia("(prefers-reduced-motion: reduce)").matches)
    const icon = () => document.querySelector("#chatTabs .chat-tab.on .chat-tab-icon")
    const reduced = ["running", "permission"].every(state => {
      document.querySelector('[data-state="' + state + '"]').click()
      return getComputedStyle(icon().querySelector("svg")).animationName === "none" &&
        getComputedStyle(icon(), "::after").animationName === "none"
    })
    ok("motion.reduced-motion-is-static", reduced)`,

  chatsessions: `
    // sessions belong to the chat, not to the sidebar, and the transcript header
    // has to name the session that is actually open
    ok("chat.sessions-live-in-the-chat",
       !!document.getElementById("chatTabs") && !document.getElementById("chatSessions") && !document.getElementById("sessionList"),
       "chatTabs=" + !!document.getElementById("chatTabs") + " leftColumn=" + !!document.getElementById("chatSessions"))
    const side = document.querySelector(".side")
    const strip = document.getElementById("chatTabs")
    const convBox = document.querySelector(".conv-pane").getBoundingClientRect()
    const railBox = document.querySelector(".rail").getBoundingClientRect()
    ok("chat.strip-spans-conversation-and-rail",
       strip.getBoundingClientRect().width >= convBox.width + railBox.width - 12,
       "strip=" + Math.round(strip.getBoundingClientRect().width) +
       " conv=" + Math.round(convBox.width) + " rail=" + Math.round(railBox.width))
    ok("chat.strip-sits-at-the-top-of-the-session-view",
       strip.getBoundingClientRect().top < convBox.top,
       "stripTop=" + Math.round(strip.getBoundingClientRect().top) + " convTop=" + Math.round(convBox.top))
    ok("chat.strip-is-not-the-toolbar",
       !strip.closest(".chrome") && strip.closest("#viewSession") !== null,
       "strip is inside the session view, not the chrome")
    ok("chat.sidebar-has-no-session-block",
       !/Sessions/.test(side.querySelector(".side-nav").textContent) &&
       !side.querySelector("#sessionList, .side-sess"),
       "sidebar still lists sessions")
    const rows = () => [...document.querySelectorAll("#chatTabs [data-session]")]
    ok("chat.lists-the-active-profile-sessions", rows().length === 3, "rows=" + rows().length)
    const titleOf = () => document.getElementById("convTitle").textContent
    ok("chat.header-names-the-open-session", titleOf() === rows()[0].querySelector(".chat-tab-title").textContent,
       "header=" + titleOf())
    ok("chat.choosing-a-session-renames-the-transcript", (() => {
      const before = titleOf()
      rows()[1].click()
      const after = titleOf()
      const want = rows()[1].querySelector(".chat-tab-title").textContent
      return before !== after && after === want
    })(), "header now " + titleOf())
    ok("chat.session-prompt-is-per-session", (() => {
      const prompt = document.getElementById("msgPrompt").textContent
      const sub = document.getElementById("convSub").textContent
      rows()[2].click()
      return prompt !== document.getElementById("msgPrompt").textContent &&
             sub !== document.getElementById("convSub").textContent
    })(), "each session opens with its own prompt")
    ok("chat.chosen-session-stays-chosen", (() => {
      rows()[1].click()
      const id = document.querySelector("#chatTabs .chat-tab.on").dataset.session
      return document.getElementById("convTitle").textContent ===
        document.querySelector('#chatTabs [data-session="' + id + '"] .chat-tab-title').textContent
    })())
    ok("chat.new-session-adds-to-the-active-profile", (() => {
      const n0 = rows().length
      document.querySelector('[data-act="newsession"]').click()
      return rows().length === n0 + 1 && rows()[0].querySelector(".chat-tab-title").textContent === "New session"
    })(), "rows=" + rows().length)
    ok("chat.close-session-removes-its-tab", (() => {
      const n0 = rows().length
      const x = document.querySelector("#chatTabs .chat-tab.on .chat-tab-x")
      const id = x.dataset.close
      const historyCount = document.querySelectorAll("#sessionRows [data-session]").length
      x.click()
      return rows().length === n0 - 1 &&
        document.querySelectorAll("#sessionRows [data-session]").length === historyCount &&
        [...document.querySelectorAll("#sessionRows [data-session]")].some(r => r.dataset.session === id)
    })(), "closing the tab preserves its session in Home history")
    ok("chat.closed-session-reopens-from-history", (() => {
      const ids = new Set(rows().map(r => r.dataset.session))
      const row = [...document.querySelectorAll("#sessionRows [data-session]")].find(r => !ids.has(r.dataset.session))
      if (!row) return false
      row.click()
      const selected = document.querySelector("#chatTabs .chat-tab.on")
      return selected?.dataset.session === row.dataset.session && titleOf() === "New session"
    })())
    ok("chat.close-button-is-independent", (() => {
      const tab = document.querySelector("#chatTabs .chat-tab.on")
      const close = tab.querySelector("button[data-close]")
      return !!close && !close.closest('[role="tab"]') && tab.querySelector('[role="tab"]').tagName === "BUTTON"
    })())
    // Restore the initial tab set before checking a round trip between profiles.
    document.querySelector("#chatTabs .chat-tab.on .chat-tab-x").click()
    // a profile switch re-points the chat at that profile's sessions
    ok("chat.sessions-follow-the-profile", (() => {
      document.querySelector('[data-profile="local-app"]').click()
      const n = rows().length
      const names = rows().map(r => r.querySelector(".chat-tab-title").textContent)
      document.querySelector('[data-profile="canonical"]').click()
      const back = rows().map(r => r.querySelector(".chat-tab-title").textContent)
      return n === 2 && !names.includes("Approval flow refactor") && back.includes("Approval flow refactor")
    })(), "after switch: " + rows().map(r => r.querySelector(".chat-tab-title").textContent).join(" / "))`,

  deeplink: `
    // every view and every session state must be addressable by hash alone
    const viewsWanted = ["home", "session", "agents", "settings", "dock", "workspaces"]
    for (const v of viewsWanted) {
      location.hash = v
      dispatchEvent(new HashChangeEvent("hashchange"))
      const shown = [...document.querySelectorAll('[id^=view]:not([hidden])')].map(e => e.id)
      ok("deeplink.view-" + v, shown.length === 1 && shown[0] === "view" + v[0].toUpperCase() + v.slice(1),
         "hash=" + v + " showed=" + shown)
    }
    location.hash = "agents/atlas"
    dispatchEvent(new HashChangeEvent("hashchange"))
    ok("deeplink.agent-page", document.querySelector("#agentsBody b")?.textContent === "Atlas",
       "b=" + document.querySelector("#agentsBody b")?.textContent)
    const statesWanted = { idle: "", running: "running", permission: "needs input", error: "failed", denied: "denied" }
    for (const [st, live] of Object.entries(statesWanted)) {
      location.hash = "session/" + st
      dispatchEvent(new HashChangeEvent("hashchange"))
      const on = [...document.querySelectorAll("#stateSwitch button.on")].map(b => b.dataset.state).join(",")
      ok("deeplink.state-" + st, on === st && document.getElementById("livePill").textContent === live,
         "switcher=" + on + " live=" + document.getElementById("livePill").textContent)
    }`,

  narrow: `
    // the chrome is a 3-column grid; the mock-only state switcher must yield
    // before the window controls wrap out of the bar
    const c = document.querySelector(".chrome")
    ok("narrow.chrome-does-not-overflow", c.scrollWidth <= c.clientWidth,
       "scrollW=" + c.scrollWidth + " clientW=" + c.clientWidth)
    ok("narrow.window-controls-stay-on-one-line",
       Math.round(document.querySelector(".chrome-actions").getBoundingClientRect().height) <= 30,
       "actionsH=" + Math.round(document.querySelector(".chrome-actions").getBoundingClientRect().height))
    ok("narrow.mock-chrome-yields",
       getComputedStyle(document.getElementById("stateSwitch")).display === "none")
    ok("narrow.sidebar-and-rail-yield",
       getComputedStyle(document.querySelector(".side")).display === "none" &&
       getComputedStyle(document.querySelector(".rail")).display === "none")
    const comp = document.querySelector(".composer").getBoundingClientRect()
    const pane = document.querySelector(".conv-pane").getBoundingClientRect()
    ok("narrow.composer-inside-the-pane", comp.bottom <= pane.bottom + 1 && comp.left >= pane.left - 1,
       "composer=" + Math.round(comp.bottom) + " pane=" + Math.round(pane.bottom))`,

  coverage: `
    // No dead controls: a button is either wired or explicitly disabled.
    // the app wires some controls directly (querySelector), which no ancestor
    // scan can see, so also ask whether the app's own script selects this
    // button's id or class
    const script = [...document.scripts].map(x => x.textContent).join(String.fromCharCode(10))
    const selected = el => {
      const toks = [el.id, ...[...el.classList], ...[...el.attributes].map(a => a.name)]
        .filter(Boolean)
      return toks.some(t => script.includes('"' + t) || script.includes("'" + t) ||
                           script.includes("." + t) || script.includes("#" + t))
    }
    const dead = []
    for (const b of document.querySelectorAll("button")) {
      if (b.disabled) continue
      const w = b.closest("[data-view],[data-panel],[data-sub],[data-file],[data-range],[data-state],[data-m],[data-dl],[data-lib],[data-act],[data-move],[data-pick],[data-sub],[data-open],[data-r],[data-sec],[data-tool],[data-v],[data-goto],.msg-actions,.head-actions,.block-head,.foot,.rail-panel,.dock-host,.settings-nav,#sideNav,#railTabs,#rangeSwitch,#stateSwitch,#fileList,#pop,#paletteList,#settingsBody,.dock-host,.side-nav,.msg-actions,.head-actions,.block-head,.foot")
      const inline = b.getAttribute("data-view") || b.getAttribute("data-panel") || b.getAttribute("data-act") ||
                     b.getAttribute("data-sec") || b.getAttribute("data-goto") || b.getAttribute("data-dl") ||
                     b.getAttribute("data-open") || b.getAttribute("data-lib") || b.getAttribute("data-m") ||
                     b.getAttribute("data-pick") || b.getAttribute("data-sub") || b.getAttribute("data-sub2") ||
                     b.getAttribute("data-r") || b.getAttribute("data-v") || b.getAttribute("data-tool") ||
                     b.getAttribute("data-file") || b.getAttribute("data-range") || b.getAttribute("data-state")
      if (!w && !inline && !selected(b)) dead.push(b.textContent.trim().slice(0, 24) || "(icon)")
    }
    ok("coverage.no-dead-buttons", dead.length === 0, "dead=" + dead.join("|"))`,
}

// -------------------------------------------------------------------------
// interactive groups: a body of probe source run after load
const SCRIPT_GROUPS = {
  state: `
    // I1: every surface is a projection of one STATES record
    const read = () => ({
      plan: !document.getElementById("msgPlan").hidden,
      perm: !document.getElementById("permDock").hidden,
      pending: !document.getElementById("tailPending").hidden,
      running: !document.getElementById("tailRunning").hidden,
      error: !document.getElementById("tailError").hidden,
      denied: !document.getElementById("tailDenied").hidden,
      live: document.getElementById("livePill").textContent,
      ck: document.getElementById("ckLast").textContent,
      ckBad: document.getElementById("ckLast").classList.contains("bad"),
      badge: document.getElementById("tabTasksBadge").textContent,
      states: [...document.querySelectorAll("#stateSwitch button")].filter(b => b.classList.contains("on")).map(b => b.dataset.state).join(","),
    })
    const want = {
      idle:       { plan:false, perm:false, pending:false, running:false, error:false, denied:false, live:"",             badge:"0", ckBad:false },
      running:    { plan:true,  perm:false, pending:false, running:true,  error:false, denied:false, live:"running",      badge:"3", ckBad:false },
      permission: { plan:true,  perm:true,  pending:true,  running:false, error:false, denied:false, live:"needs input",  badge:"3", ckBad:false },
      error:      { plan:true,  perm:false, pending:false, running:false, error:true,  denied:false, live:"failed",       badge:"1", ckBad:true },
      denied:     { plan:true,  perm:false, pending:false, running:false, error:false, denied:true,  live:"denied",       badge:"3", ckBad:true },
    }
    for (const [name, w] of Object.entries(want)) {
      document.querySelector('[data-state=' + name + ']').click()
      const r = read()
      const bad = Object.entries(w).filter(([k, v]) => r[k] !== v).map(([k, v]) => k + "=" + r[k] + " want " + v)
      ok("state." + name, bad.length === 0 && r.states === name, bad.join(",") || "switcher=" + r.states)
    }
    // the plan's last step must not still read "implementing" after a failure
    document.querySelector('[data-state=error]').click()
    ok("state.checklist-matches-tail", document.getElementById("ckLast").textContent.includes("failed"),
       document.getElementById("ckLast").textContent)`,

  permission: `
    // I2/I3/I4: one decision, denial is distinct, "always" is remembered
    const dock = document.getElementById("permDock")
    document.querySelector('[data-state=permission]').click()
    ok("permission.dock-in-permission-state", !dock.hidden)
    document.querySelector(".perm-once").click()
    ok("permission.allow-once-resumes", dock.hidden && !document.getElementById("tailRunning").hidden)
    document.querySelector('[data-state=permission]').click()
    document.querySelector(".perm-deny").click()
    ok("permission.deny-is-not-test-failure",
       !document.getElementById("tailDenied").hidden && document.getElementById("tailError").hidden,
       "denied=" + !document.getElementById("tailDenied").hidden + " error=" + !document.getElementById("tailError").hidden)
    ok("permission.denial-says-nothing-ran",
       /never ran|declined/i.test(document.getElementById("tailDenied").textContent),
       document.getElementById("tailDenied").textContent.slice(0, 60))
    document.querySelector('[data-state=permission]').click()
    document.querySelector(".perm-always").click()
    ok("permission.allow-always-resumes", dock.hidden && !document.getElementById("tailRunning").hidden)
    ok("permission.allow-always-persists",
       (JSON.parse(localStorage.getItem("orchestra-perm-always") || "[]")).includes("bun test *"),
       localStorage.getItem("orchestra-perm-always"))
    // settings and the dock are the same decision
    document.querySelector('[data-view=settings]').click()
    const bash = document.querySelector('[data-tool=bash] button.on')
    ok("permission.settings-bash-asks", bash && bash.textContent === "Ask", "bash=" + (bash && bash.textContent))
    const tools = [...document.querySelectorAll("#settingsBody .perm-tool")].length
    ok("permission.tool-count-is-14", tools === 14, "tools=" + tools)
    document.querySelector('[data-tool=bash] [data-v=allow]').click()
    ok("permission.allowing-bash-drops-the-dock",
       document.getElementById("permDock").hidden, "perm still shown")
    document.querySelector('[data-tool=bash] [data-v=ask]').click()`,

  dock: `
    // I5: apps-panel.tsx contract, native gating, honest empty state
    const B = document.getElementById("dockBody")
    const q = s => B.querySelector(s), qa = s => [...B.querySelectorAll(s)]
    ok("dock.empty-state-is-the-components-own",
       q(".zen-empty strong").textContent === "Browser needs OpenCode Desktop." &&
       q(".zen-empty span").textContent === "Native browser tabs are unavailable in web app.",
       q(".zen-empty").textContent.trim().slice(0, 70))
    const off = s => q(s).disabled
    ok("dock.native-nav-disabled",
       off('[data-act=back]') && off('[data-act=forward]') && off('[data-act=reload]') && q('button[type=submit]').disabled,
       "back/fwd/reload/open must be off with no appDockCommand")
    const on = s => !q(s).disabled
    ok("dock.pure-ui-controls-stay-live",
       on('[data-act=bookmark]') && on('[data-act=find]') && on('[data-act=zoomin]') && on('[data-act=full]') && on('[data-lib=downloads]'))
    ok("dock.urlbar-has-the-real-controls", qa(".zen-urlbar button").length === 13, "buttons=" + qa(".zen-urlbar button").length)
    ok("dock.pinned-label-renders", qa(".zen-tab-pinmark").length === 1, "pinmarks=" + qa(".zen-tab-pinmark").length)
    ok("dock.roving-tabindex",
       q('.zen-tab.is-active').getAttribute("tabindex") === "0" &&
       qa('.zen-tab').filter(t => t.getAttribute("tabindex") === "-1").length === qa('.zen-tab').length - 1)
    ok("dock.active-tab-scales", getComputedStyle(q(".zen-tab.is-active")).transform.includes("0.985"),
       getComputedStyle(q(".zen-tab.is-active")).transform)
    // downloads: progressing offers Cancel, completed offers Open
    q('[data-lib=downloads]').click()
    ok("dock.downloads-offer-cancel", !!q('[data-dl=cancel]'), "no cancel button")
    ok("dock.downloads-offer-open", !!q('[data-dl=open]'), "no open button")
    q('[data-dl=cancel]').click()
    ok("dock.download-cancel-sets-state",
       qa(".zen-dl")[1].textContent.includes("cancelled") && !q('[data-dl=cancel]'))
    // find must not invent a count with no page behind it
    q('[data-act=find]').click()
    const fi = q('[data-act=findinput]'); fi.value = "docs"
    fi.dispatchEvent(new Event("input", { bubbles: true }))
    ok("dock.find-reports-no-invented-count", q(".zen-find span").textContent === "", "span=" + q(".zen-find span").textContent)
    // profile form validates the slug
    q('[data-act=findclose]').click()
    q('[data-act=newprofile]').click()
    const di = q('[data-act=profiledraft]'); di.value = "Team Space"
    di.dispatchEvent(new Event("input", { bubbles: true }))
    q(".zen-profile-form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }))
    const opts = qa('[data-act=profile] option').map(o => o.textContent)
    ok("dock.profile-created-from-slug", opts.includes("Team Space") && q('[data-act=profile]').value === "team-space",
       opts.join("/"))
    q('[data-act=newprofile]').click()
    const di2 = q('[data-act=profiledraft]'); di2.value = "team-space"
    di2.dispatchEvent(new Event("input", { bubbles: true }))
    const before = qa('[data-act=profile] option').length
    q(".zen-profile-form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }))
    ok("dock.duplicate-profile-rejected", qa('[data-act=profile] option').length === before,
       before + " -> " + qa('[data-act=profile] option').length)`,

  mirroring: `
    // I6: one dock session, two mounts; geometry and focus are per-mount
    const A = document.getElementById("dockBody"), B = document.getElementById("railDockBody")
    if (!document.getElementById("viewSession").hidden) document.querySelector('[data-panel=apps]').click()
    const fields = r => ({
      tabs: [...r.querySelectorAll(".zen-tab")].map(t => t.dataset.tab).join(","),
      active: r.querySelector(".zen-tab.is-active")?.dataset.tab,
      profile: r.querySelector("[data-act=profile]").value,
      bm: r.querySelector("[data-act=bookmark]").classList.contains("is-active"),
      find: r.querySelector("[data-act=findinput]")?.value || "-",
      full: r.querySelector("[data-act=full]").textContent,
      menu: [...r.querySelectorAll(".zen-menu button")].map(x => x.textContent).join("/") || "-",
      addr: r.querySelector("[data-act=address]").value,
      dl: r.querySelectorAll(".zen-dl").length,
      backOff: r.querySelector("[data-act=back]").disabled,
      pins: r.querySelectorAll(".zen-tab-pinmark").length,
    })
    const V = A.getBoundingClientRect().width ? A : B
    const diff = () => { const a = fields(A), b = fields(B); return Object.keys(a).filter(k => JSON.stringify(a[k]) !== JSON.stringify(b[k])) }
    const check = n => { const d = diff(); ok("mirroring." + n, d.length === 0, "diverge=" + d.join(",")) }
    check("initial")
    V.querySelector("[data-tab=t2]").click(); check("select-tab")
    V.querySelector("[data-act=bookmark]").click(); check("bookmark")
    V.querySelector("[data-act=newtab]").click(); check("new-tab")
    const ps = V.querySelector("[data-act=profile]"); ps.value = "work"
    ps.dispatchEvent(new Event("change", { bubbles: true })); check("profile-switch")
    const pb = (A.getBoundingClientRect().width ? A : B).querySelector("[data-act=profile]"); pb.value = "personal"
    pb.dispatchEvent(new Event("change", { bubbles: true })); check("profile-switch-back")
    V.querySelector("[data-act=find]").click(); check("find-open")
    const fi = V.querySelector("[data-act=findinput]"); fi.focus(); fi.value = "granted"
    fi.dispatchEvent(new Event("input", { bubbles: true }))
    const landed = document.activeElement.closest(".dock-host")
    ok("mirroring.focus-stays-in-the-mount", landed === V,
       landed === null ? "focus fell to " + document.activeElement.tagName : (landed === V ? "stayed" : "moved to the other mount"))
    check("find-value")
    V.querySelector("[data-act=findclose]").click(); check("find-close")
    V.querySelector("[data-lib=history]").click(); check("library-history")
    V.querySelector("[data-lib=downloads]").click(); check("library-downloads")
    V.querySelector("[data-act=full]").click(); check("fullscreen")
    V.querySelector("[data-act=full]").click(); check("fullscreen-off")
    V.querySelector("[data-tab=t1]").dispatchEvent(new MouseEvent("contextmenu", { bubbles: true })); check("tab-menu")
    const pos = r => {
      const m = r.querySelector(".zen-menu"), c = r.querySelector(".zen-content")
      if (!m || !c || !r.getBoundingClientRect().width) return null
      const q1 = m.getBoundingClientRect(), b = c.getBoundingClientRect()
      return q1.left >= b.left && q1.top >= b.top && q1.right <= b.right && q1.bottom <= b.bottom
    }
    ok("mirroring.menu-inside-its-own-content", pos(V) === true, "visible mount in-bounds=" + pos(V))
    V.querySelector(".zen-menu button:nth-child(1)").click(); check("duplicate-from-menu")`,

  composer: `
    // I7/I10: contract labels, and no control that does nothing
    const ctl = k => document.querySelector('.ctl[data-menu=' + k + ']')
    const all = k => [...document.querySelectorAll(".ctl[data-menu]")].find(b => b.dataset.menu === k)
    ctl("model").click()
    ok("composer.model-groups-by-provider",
       [...document.querySelectorAll("#pop .pop-group")].map(g => g.textContent).join("/") === "Anthropic/OpenAI/Google/Alibaba",
       [...document.querySelectorAll("#pop .pop-group")].map(g => g.textContent).join("/"))
    ok("composer.model-search-filters", (() => {
      const f = document.querySelector("#pop [data-filter]"); f.value = "haiku"
      f.dispatchEvent(new Event("input", { bubbles: true }))
      return [...document.querySelectorAll("#pop [data-pick]")].filter(b => !b.hidden).map(b => b.dataset.pick).join() === "claude-3.5-haiku"
    })())
    document.querySelector("#pop [data-pick=gpt-5-codex]").click()
    ok("composer.model-pick-commits", all("model").textContent === "GPT-5 Codex", all("model").textContent)
    ok("composer.model-pick-moves-check", document.querySelector("#pop .pop-item.on").dataset.pick === "gpt-5-codex")
    ctl("reasoning").click()
    ok("composer.effort-has-four-levels", document.querySelectorAll("#pop [data-pick]").length === 4)
    document.querySelector("#pop [data-pick=low]").click()
    ok("composer.effort-pick-commits", all("reasoning").textContent === "Low", all("reasoning").textContent)
    ctl("subagent").click()
    const before = document.querySelectorAll("#pop [data-sub]").length
    document.querySelector("#pop [data-sub=qwen3-coder]").click()
    ok("composer.subagent-deny-changes-label", all("subagent").textContent === "5 models", all("subagent").textContent)
    ok("composer.subagent-hint-follows-state",
       /denied for subagents/.test(document.querySelector("#pop .pop-note").textContent) && before === 6)
    document.body.click()
    ok("composer.outside-click-closes", document.getElementById("pop").hidden)
    // palette
    dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true }))
    const P = document.getElementById("palette"), I = document.getElementById("paletteInput")
    ok("palette.opens", !P.hidden)
    ok("palette.placeholder-follows-view",
       I.placeholder === "Search files, commands, and sessions", I.placeholder)
    ok("palette.groups", [...P.querySelectorAll(".palette-group")].map(g => g.textContent).join("/") === "Commands/Files/Sessions")
    I.value = "zzzz"; I.dispatchEvent(new Event("input", { bubbles: true }))
    ok("palette.no-results-copy", P.querySelector(".palette-empty")?.textContent === "No results found")
    I.value = ""; I.dispatchEvent(new Event("input", { bubbles: true }))
    I.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true }))
    I.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true }))
    ok("palette.arrow-selection", P.querySelectorAll(".palette-item")[2].classList.contains("sel"))
    I.value = "cycle color scheme"; I.dispatchEvent(new Event("input", { bubbles: true }))
    I.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }))
    ok("palette.command-runs", document.documentElement.dataset.scheme === "light", "scheme=" + (document.documentElement.dataset.scheme || "dark"))
    document.getElementById("schemeToggle").click()
    // range really moves the window
    document.querySelector('[data-view=home]').click()
    const tok = () => document.querySelector("#kpiGrid .kpi-value").textContent
    const first = tok()
    document.querySelector('[data-range="7d"]').click()
    const seven = tok()
    document.querySelector('[data-range="all"]').click()
    const allt = tok()
    ok("home.range-moves-the-window", new Set([first, seven, allt]).size === 3, [first, seven, allt].join(" | "))
    ok("home.kpi-provenance-declared", /sample data/.test(document.querySelector(".foot").textContent))
    // rail
    document.querySelector('[data-view=session]').click()
    const on = () => document.querySelector(".rail-panel.on").dataset.panel
    document.querySelector('[data-panel=context]').click()
    ok("rail.context-tab-renders-stats", document.querySelectorAll("#settingsBody, .ctx-stat").length > 0 && on() === "context")
    document.querySelector('[data-panel=review]').click()
    ok("rail.file-select-swaps-diff", (() => {
      const a = document.getElementById("diffBody").textContent
      document.querySelector('[data-file="src/types/approval.ts"]').click()
      return a !== document.getElementById("diffBody").textContent && document.getElementById("editorTabName").textContent === "approval.ts"
    })())
    document.querySelector('#reviewSubTabs [data-sub="all"]').click()
    ok("rail.all-files-has-no-diff", (() => {
      document.querySelector('[data-file="package.json"]').click()
      return document.querySelector(".rail-diff").classList.contains("empty")
    })())
    document.querySelector('#reviewSubTabs [data-sub="changed"]').click()
    ok("rail.back-to-changed-restores-a-diff", !document.querySelector(".rail-diff").classList.contains("empty"))
    // home rows
    document.querySelector('[data-view=home]').click()
    // the row list is the active profile's sessions plus the model rows, so the
    // count is compared against the sidebar rather than a fixed number
    const rows = [...document.querySelectorAll(".row[data-goto]")]
    const chatSessions = document.querySelectorAll("#chatTabs [data-session]").length
    const modelRows = document.querySelectorAll("#modelRows .row").length
    ok("home.every-row-navigates",
       rows.length === chatSessions + modelRows && modelRows >= 1,
       "rows=" + rows.length + " chat=" + chatSessions + " modelRows=" + modelRows)
    rows.find(r => r.dataset.session).click()
    ok("home.session-row-opens-session", document.querySelector('[id^=view]:not([hidden])').id === "viewSession")
    document.querySelector('[data-view=home]').click()
    rows.find(r => r.dataset.goto === "settings/models").click()
    ok("home.model-row-opens-models",
       document.querySelector('[id^=view]:not([hidden])').id === "viewSettings" &&
       document.querySelector("#settingsNav button.on").dataset.sec === "models")
    // send appends to the transcript
    document.querySelector('[data-view=session]').click()
    const n0 = document.querySelectorAll("#viewSession .scroll .msg").length
    const input = document.querySelector(".composer input"); input.value = "also update the spec"
    document.querySelector(".send").click()
    ok("composer.send-appends-message",
       document.querySelectorAll("#viewSession .scroll .msg").length === n0 + 1 &&
       /also update the spec/.test(document.querySelector("#viewSession .scroll .msg:last-child p").textContent))
    input.value = ""; document.querySelector(".send").click()
    ok("composer.send-empty-is-refused", document.querySelectorAll("#viewSession .scroll .msg").length === n0 + 1)`,
}

// ---------------------------------------------------------------- the runner

export { GROUPS, SCRIPT_GROUPS, MANIFEST, HASH }

// The manifest is the corpus's index: every requirement in CORPUS.md cites an id
// from this list. The runner fails if the app emits an id that is not registered
// here, or if a registered id never ran — so the corpus cannot cite a check that
// does not exist, and a renamed check cannot silently drop out of the spec.
const MANIFEST = {
  dom: ["dom.div-balance", "dom.no-duplicate-ids", "dom.stylesheet-parsed", "dom.selector-rules"],
  theme: ["theme.painting-rules-have-light"],
  coverage: ["coverage.no-dead-buttons"],
  state: ["state.idle", "state.running", "state.permission", "state.error", "state.denied",
          "state.checklist-matches-tail"],
  permission: ["permission.dock-in-permission-state", "permission.allow-once-resumes",
               "permission.deny-is-not-test-failure", "permission.denial-says-nothing-ran",
               "permission.allow-always-resumes", "permission.allow-always-persists",
               "permission.settings-bash-asks", "permission.tool-count-is-14",
               "permission.allowing-bash-drops-the-dock"],
  dock: ["dock.empty-state-is-the-components-own", "dock.native-nav-disabled",
         "dock.pure-ui-controls-stay-live", "dock.urlbar-has-the-real-controls",
         "dock.pinned-label-renders", "dock.roving-tabindex", "dock.active-tab-scales",
         "dock.downloads-offer-cancel", "dock.downloads-offer-open",
         "dock.download-cancel-sets-state", "dock.find-reports-no-invented-count",
         "dock.profile-created-from-slug", "dock.duplicate-profile-rejected"],
  mirroring: ["mirroring.initial", "mirroring.select-tab", "mirroring.bookmark",
              "mirroring.new-tab", "mirroring.profile-switch", "mirroring.profile-switch-back",
              "mirroring.find-open", "mirroring.focus-stays-in-the-mount", "mirroring.find-value",
              "mirroring.find-close", "mirroring.library-history", "mirroring.library-downloads",
              "mirroring.fullscreen", "mirroring.fullscreen-off", "mirroring.tab-menu",
              "mirroring.menu-inside-its-own-content", "mirroring.duplicate-from-menu"],
  profile: ["profile.card-shows-the-active-project", "profile.card-lives-at-the-foot",
            "profile.menu-lists-the-projects", "profile.starts-on-a-profile",
            "profile.sessions-follow-the-profile",
            "profile.switch-marks-active", "profile.switch-swaps-sessions",
            "profile.switch-swaps-kpis", "profile.switch-swaps-composer",
            "profile.switch-swaps-dock", "profile.switch-swaps-agents",
            "profile.switch-swaps-permissions", "profile.switch-swaps-spend",
            "profile.kicker-names-the-profile", "profile.third-profile-switches",
            "profile.effort-none-is-a-real-value", "profile.switch-is-reversible",
            "profile.session-state-per-profile", "profile.persists",
            "profile.roster-is-per-profile", "profile.permission-table-is-per-profile"],
  edgeflows: ["edge.env-parses-comments-and-multiline", "edge.env-preserves-untouched-file",
              "edge.pipeline-deploys-and-refreshes-open-logs", "edge.failed-checks-skip-deployment",
              "edge.pipeline-stop-cancels-completion", "edge.schedule-rejects-past-time",
              "edge.custom-provider-has-own-config", "edge.disconnect-preserves-provider-config",
              "edge.background-hooks-stay-with-owner", "edge.profile-deny-blocks-shell",
              "edge.new-profile-does-not-copy-env-or-conversations", "edge.new-profile-is-persisted"],
  sessionflows: ["session.submit-records-own-user-message", "session.stream-completes-own-response",
                 "session.caveman-affects-the-response", "session.history-does-not-leak-across-tabs",
                 "session.review-and-context-are-session-owned", "session.return-restores-the-conversation",
                 "session.attachment-is-loaded-and-owned", "session.attachment-preview-shows-content",
                 "session.stop-prevents-late-response", "session.attachment-is-on-the-message",
                 "session.question-waits-for-user", "session.empty-answer-is-rejected",
                 "session.question-answer-resumes", "session.queue-is-admitted-without-early-promotion",
                 "session.queue-drains-at-idle-boundary", "session.hooks-contribute-system-context",
                 "session.completed-tasks-have-details", "session.disconnected-provider-blocks-new-turn"],
  menuflows: ["menus.rename-updates-tabs-and-history", "menus.titles-are-text-not-markup",
              "menus.share-identifies-profile-and-session", "menus.archive-preserves-session-history",
              "menus.file-opens-its-own-content", "menus.close-and-reopen-file-tab", "menus.reopen-restores-editor",
              "menus.pull-request-has-a-result-dialog", "menus.exports-create-downloads",
              "menus.terminal-records-preview-output", "menus.palette-opens-settings",
              "menus.custom-shortcut-executes", "menus.old-shortcut-does-not-fire", "menus.new-profile-opens-a-real-form"],
  configflows: ["config.toolbar-routes-all-requested-views", "config.profile-card-remains-visible-at-bottom",
                "config.skill-toggle-changes-profile", "config.cancel-preserves-skill", "config.skill-save-commits",
                "config.plugins-are-llm-behavior", "config.hook-test-records-event", "config.mcp-rejects-invalid-url",
                "config.mcp-adds-server", "config.provider-connects-without-saving-credential",
                "config.shortcut-conflicts-are-rejected", "config.shortcut-save-commits", "config.env-add-edit-and-reveal",
                "config.env-opens-a-real-file", "config.agent-editor-saves-profile-config",
                "config.schedule-saves-recurrence", "config.schedule-run-creates-session",
                "config.pipeline-run-records-logs", "config.configuration-is-profile-isolated"],
  modellogos: ["logos.manufacturer-before-router", "logos.missing-brand-uses-router",
              "logos.unknown-model-uses-router", "logos.unknown-route-is-neutral",
              "logos.transport-does-not-imply-manufacturer", "logos.each-tab-owns-its-model",
              "logos.svg-marks-render", "logos.composer-choice-is-not-current-turn",
              "logos.send-records-the-new-model", "logos.routes-and-models-are-profile-owned",
              "logos.new-session-shows-configured-model-statically"],
  logomotion: ["motion.running-pulses", "motion.pulse-is-subtle",
              "motion.selection-is-not-execution", "motion.waiting-bounces",
              "motion.bounce-has-ascent-and-impact", "motion.bounce-has-ground-shadow",
              "motion.answer-returns-to-pulse", "motion.stopped-states-are-static"],
  logoreduced: ["motion.reduced-preference-is-active", "motion.reduced-motion-is-static"],
  logopreview: ["motion.preview-enables-pulse", "motion.preview-enables-bounce"],
  chatsessions: ["chat.sessions-live-in-the-chat", "chat.strip-spans-conversation-and-rail",
                 "chat.strip-sits-at-the-top-of-the-session-view", "chat.strip-is-not-the-toolbar",
                 "chat.sidebar-has-no-session-block",
                 "chat.lists-the-active-profile-sessions", "chat.header-names-the-open-session",
                 "chat.choosing-a-session-renames-the-transcript",
                 "chat.session-prompt-is-per-session", "chat.chosen-session-stays-chosen",
                 "chat.sessions-follow-the-profile", "chat.new-session-adds-to-the-active-profile",
                 "chat.close-session-removes-its-tab", "chat.closed-session-reopens-from-history",
                 "chat.close-button-is-independent"],
  deeplink: ["deeplink.view-home", "deeplink.view-session", "deeplink.view-agents",
             "deeplink.view-settings", "deeplink.view-dock", "deeplink.view-workspaces",
             "deeplink.agent-page", "deeplink.state-idle", "deeplink.state-running",
             "deeplink.state-permission", "deeplink.state-error", "deeplink.state-denied"],
  narrow: ["narrow.chrome-does-not-overflow", "narrow.window-controls-stay-on-one-line",
           "narrow.mock-chrome-yields", "narrow.sidebar-and-rail-yield",
           "narrow.composer-inside-the-pane"],
  composer: ["composer.model-groups-by-provider", "composer.model-search-filters",
             "composer.model-pick-commits", "composer.model-pick-moves-check",
             "composer.effort-has-four-levels", "composer.effort-pick-commits",
             "composer.subagent-deny-changes-label", "composer.subagent-hint-follows-state",
             "composer.outside-click-closes", "palette.opens", "palette.placeholder-follows-view",
             "palette.groups", "palette.no-results-copy", "palette.arrow-selection",
             "palette.command-runs", "home.range-moves-the-window", "home.kpi-provenance-declared",
             "rail.context-tab-renders-stats", "rail.file-select-swaps-diff",
             "rail.all-files-has-no-diff", "rail.back-to-changed-restores-a-diff",
             "home.every-row-navigates", "home.session-row-opens-session",
             "home.model-row-opens-models", "composer.send-appends-message",
             "composer.send-empty-is-refused"],
}

const isMain = process.argv[1] && import.meta.url.endsWith(process.argv[1].split("/").pop())
const arg = isMain ? process.argv[2] : undefined
const ALL = [...Object.keys({ ...GROUPS, ...SCRIPT_GROUPS }), "contract"]
const pick = !isMain ? [] : arg && arg !== "--all" ? arg.split(",") : ALL
const decode = (s) =>
  s.replace(/&quot;/g, '"').replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")

const WIDTH = { narrow: 380 }

function render(body, hash, group) {
  const probe = `<script>
    const out = []
    const ok = (id, pass, detail = "") => out.push({ id, pass: !!pass, detail: String(detail) })
    addEventListener("load", () => setTimeout(async () => {
      try { await (async function(){${body}})() }
      catch (e) { out.push({ id: "HARNESS-THREW", pass: false, detail: e.message }) }
      for (const e of window.__e || []) out.push({ id: "app.boot-error", pass: false, detail: e })
      document.title = "##" + JSON.stringify(out)
    }, 120))
  </script>`
  const file = resolve(HERE, ".__probe.html")
  const probeURL = `file://${file}${group === "logoreduced" ? "?motion=auto" : ""}#${hash}`
  const trap = `<script>window.__e=[];addEventListener("error",e=>window.__e.push(e.message+" @"+e.lineno+":"+e.colno))</script>`
  writeFileSync(file, src.replace("<head>", "<head>" + trap).replace("</body>", probe + "</body>"))
  const w = WIDTH[group] ?? 1440
  const command = group === "logomotion" ? process.execPath : CHROME
  const args = group === "logomotion" ? [resolve(HERE, "browser-motion-probe.mjs"), CHROME, probeURL] : [
    "--headless", "--disable-gpu", `--window-size=${w},900`,
    ...(["logoreduced", "logopreview"].includes(group) ? ["--force-prefers-reduced-motion"] : []),
    `--virtual-time-budget=${["sessionflows", "edgeflows"].includes(group) ? 18000 : 4000}`, "--dump-dom", probeURL,
  ]
  const r = spawnSync(command, args, { encoding: "utf8", timeout: 90000, maxBuffer: 64 * 1024 * 1024 })
  try { unlinkSync(file) } catch {}
  const m = /<title>##(.*?)<\/title>/s.exec(r.stdout || "")
  if (!m) return [{ id: "probe.harness", pass: false, detail: "chromium produced no payload" }]
  try { return JSON.parse(decode(m[1])) }
  catch (e) { return [{ id: "probe.harness", pass: false, detail: "bad payload: " + e.message }] }
}

// A Node-side check: the mock's user-visible copy must be the product's copy.
// The source of truth is packages/app/src/i18n/en.ts on branch dev, so the
// literals are lifted from there rather than restated here.
const EN_TS = process.env.EN_TS ||
  "/Users/gustavoschneiter/Documents/HuGR/orchestra-canonical/packages/app/src/i18n/en.ts"
const UI_TS = process.env.UI_TS ||
  "/Users/gustavoschneiter/Documents/HuGR/orchestra-canonical/packages/ui/src/i18n/en.ts"

// each entry names the i18n key and the literal that key must resolve to
const CONTRACT = [
  [UI_TS, "ui.permission.deny", "Deny"],
  [UI_TS, "ui.permission.allowAlways", "Allow always"],
  [UI_TS, "ui.permission.allowOnce", "Allow once"],
  [EN_TS, "palette.search.placeholder", "Search files, commands, and sessions"],
  [EN_TS, "palette.empty", "No results found"],
  [EN_TS, "palette.group.commands", "Commands"],
  [EN_TS, "palette.group.files", "Files"],
  [EN_TS, "session.tab.review", "Review"],
  [EN_TS, "session.tab.context", "Context"],
  [EN_TS, "session.tab.tasks", "Tasks"],
  [EN_TS, "session.review.filesChanged", "Files Changed"],
  [EN_TS, "session.files.all", "All files"],
  [EN_TS, "settings.permissions.title", "Permissions"],
  [EN_TS, "settings.permissions.description", "Control what tools the server can use by default."],
  [EN_TS, "settings.permissions.action.allow", "Allow"],
  [EN_TS, "settings.permissions.action.ask", "Ask"],
  [EN_TS, "settings.permissions.action.deny", "Deny"],
  [EN_TS, "settings.permissions.tool.doom_loop.title", "Doom Loop"],
  [EN_TS, "settings.permissions.tool.external_directory.title", "External Directory"],
  [EN_TS, "settings.permissions.tool.todowrite.title", "Todo Write"],
  [EN_TS, "settings.permissions.tool.webfetch.title", "Web Fetch"],
  [EN_TS, "command.model.choose", "Choose model"],
  [EN_TS, "command.sidebar.toggle", "Toggle sidebar"],
  [EN_TS, "command.file.open", "Open file"],
  [EN_TS, "command.review.toggle", "Toggle review"],
  [EN_TS, "command.terminal.toggle", "Toggle terminal"],
  [EN_TS, "command.settings.open", "Open settings"],
  [EN_TS, "command.session.new", "New session"],
  [EN_TS, "command.session.archive", "Archive session"],
  [EN_TS, "command.agent.cycle", "Cycle agent"],
  [EN_TS, "command.model.variant.cycle", "Cycle thinking effort"],
  [EN_TS, "command.input.focus", "Focus input"],
  [EN_TS, "command.context.addSelection", "Add selection to context"],
  [EN_TS, "command.fileTree.toggle", "Toggle file tree"],
  [EN_TS, "command.tab.close", "Close tab"],
  [EN_TS, "context.breakdown.title", "Context Breakdown"],
  [EN_TS, "context.stats.usage", "Usage"],
  [EN_TS, "model.provider.anthropic", "Anthropic"],
  [EN_TS, "model.provider.openai", "OpenAI"],
  [EN_TS, "model.provider.google", "Google"],
  [EN_TS, "model.provider.meta", "Meta"],
  [EN_TS, "model.tag.latest", "Latest"],
  [EN_TS, "model.tag.free", "Free"],
  [EN_TS, "model.tooltip.reasoning.allowed", "Allows reasoning"],
  [EN_TS, "model.tooltip.reasoning.none", "No reasoning"],
  [EN_TS, "workspace.new", "New workspace"],
  [EN_TS, "sidebar.settings", "Settings"],
  [EN_TS, "sidebar.help", "Help"],
  // the App Dock's own copy, which is hardcoded in apps-panel.tsx rather than i18n
  [null, "apps-panel.tsx", "Browser needs OpenCode Desktop."],
  [null, "apps-panel.tsx", "Native browser tabs are unavailable in web app."],
  [null, "apps-panel.tsx", "New tab"],
  [null, "apps-panel.tsx", "Find in page"],
  [null, "apps-panel.tsx", "Close others"],
  [null, "apps-panel.tsx", "Close right"],
]

// Declared divergences: named, deliberate gaps. The skill forbids smuggling
// unimplemented behaviour in as a lift, so a check that finds one lands here
// with a reason instead of being made to pass by writing the feature.
const DIVERGENCES = {}

// the contract group is generated from the table, so its manifest is too
const contractIds = () => [
  ...CONTRACT.filter(c => c[0]).map(c => "contract.key-" + c[1]),
  ...CONTRACT.filter(c => c[0]).map(c => "contract.in-mock-" + c[1]),
  ...CONTRACT.filter(c => !c[0]).map(c => "contract.literal-" + c[2].replace(/[^A-Za-z]+/g, "-").toLowerCase()),
]
MANIFEST.contract = contractIds()
if (isMain && arg === "--list") {
  for (const [g, ids] of Object.entries(MANIFEST)) {
    console.log(`${g} (${ids.length})`)
    ids.forEach(id => console.log("  " + id))
  }
  console.log(`\n${Object.values(MANIFEST).flat().length} checks registered`)
  process.exit(0)
}

function checkContract() {
  const rows = []
  const files = new Map()
  const en = new Map()
  for (const [file] of CONTRACT) {
    if (!file) continue
    if (!files.has(file)) files.set(file, readFileSync(file, "utf8"))
    for (const m of files.get(file).matchAll(/^\s*"([^"]+)":\s*(.+?),?$/gm)) {
      try { en.set(m[1], JSON.parse(m[2].replace(/,$/, ""))) } catch {}
    }
  }
  for (const [file, key, literal] of CONTRACT) {
    if (file) {
      const actual = en.get(key)
      const pass = actual === literal || (actual && String(actual).split("{{")[0].trim() === literal.split("{{")[0].trim())
      rows.push({ id: "contract.key-" + key, pass,
                  detail: actual === undefined ? "key not found in en.ts"
                    : pass ? "" : "en.ts=" + actual + " does not match the expected literal" })
    } else {
      rows.push({ id: "contract.literal-" + literal.replace(/[^A-Za-z]+/g, "-").toLowerCase(),
                  pass: src.includes(literal), detail: src.includes(literal) ? "" : "absent from app.html" })
    }
  }
  // and every lifted literal must actually be present in the mock
  for (const [file, key, literal] of CONTRACT) {
    if (!file) continue
    const id = "contract.in-mock-" + key
    if (DIVERGENCES[id]) { rows.push({ id, pass: true, detail: "DECLARED DIVERGENCE" }); continue }
    rows.push({ id: "contract.in-mock-" + key, pass: src.includes(literal),
                detail: src.includes(literal) ? "" : "literal absent from app.html" })
  }
  return rows
}

const HASH = {
  dom: "home", theme: "home", coverage: "session/running", narrow: "session/running",
  deeplink: "home", profile: "home", chatsessions: "session/running",
  modellogos: "session/running", logomotion: "session/running", logoreduced: "session/running",
  logopreview: "session/running",
  configflows: "home",
  sessionflows: "session/running", menuflows: "session/running",
  edgeflows: "home",
  state: "session/running", permission: "session/permission",
  dock: "dock", mirroring: "session/running", composer: "session/running",
}

let failed = 0
for (const g of pick) {
  const body = GROUPS[g] ?? SCRIPT_GROUPS[g]
  if (g === "contract") {
    const rows = checkContract()
    console.log(`\n-- contract ${"-".repeat(46)}`)
    for (const r of rows) {
      if (!r.pass) failed++
      const mark = r.detail === "DECLARED DIVERGENCE" ? "DIVG" : r.pass ? "PASS" : "FAIL"
      console.log(`  ${mark}  ${r.id}${r.detail && mark !== "DIVG" ? `  -- ${r.detail}` : ""}`)
    }
    for (const d of rows.filter(r => r.detail === "DECLARED DIVERGENCE"))
      console.log(`        reason: ${DIVERGENCES[d.id]}`)
    // same drift gate as every other group
    const ran = new Set(rows.map(r => r.id))
    const registered = new Set(contractIds())
    for (const id of ran) if (!registered.has(id)) { console.log(`  FAIL  manifest.contract.unregistered -- ${id}`); failed++ }
    for (const id of registered) if (!ran.has(id)) { console.log(`  FAIL  manifest.contract.never-ran -- ${id}`); failed++ }
    continue
  }
  if (!body) { console.log(`?? unknown group ${g}`); failed++; continue }
  const rows = render(body, HASH[g] ?? "home", g)
  console.log(`\n── ${g} ${"─".repeat(Math.max(0, 58 - g.length))}`)
  for (const r of rows) {
    if (!r.pass) failed++
    console.log(`  ${r.pass ? "PASS" : "FAIL"}  ${r.id}${r.detail ? `  — ${r.detail}` : ""}`)
  }
  // drift gate: the manifest is what the corpus cites, so it must equal reality
  const ran = new Set(rows.map(r => r.id).filter(i => !i.startsWith("HARNESS") && !i.startsWith("probe.") && !i.startsWith("app.")))
  const registered = new Set(MANIFEST[g] ?? [])
  for (const id of ran) if (!registered.has(id)) { console.log(`  FAIL  manifest.${g}.unregistered — ${id} ran but is not cited anywhere`); failed++ }
  for (const id of registered) if (!ran.has(id)) { console.log(`  FAIL  manifest.${g}.never-ran — ${id} is cited but did not execute`); failed++ }
}

if (isMain) {
  console.log(`\n${pick.length} group(s) run, ${failed} failure(s)`)
  process.exit(failed ? 1 : 0)
}
export { failed as failures }
