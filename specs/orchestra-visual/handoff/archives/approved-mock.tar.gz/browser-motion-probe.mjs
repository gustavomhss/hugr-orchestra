// Run motion checks in a real browser with an explicit media preference.
// macOS can supply Reduce Motion to headless Chromium, so an unqualified run
// may correctly disable animations instead of exercising their keyframes.
import { spawn } from "node:child_process"
import { writeFileSync } from "node:fs"

const [chrome, url, screenshot] = process.argv.slice(2)
if (!chrome || !url) throw new Error("Expected Chromium executable and probe URL")

const browser = spawn(chrome, ["--headless", "--disable-gpu", "--window-size=1440,900", "--remote-debugging-port=0", "about:blank"], { stdio: ["ignore", "ignore", "pipe"] })
const timeout = setTimeout(() => { browser.kill(); process.exit(1) }, 30000)
const address = await new Promise((resolve, reject) => {
  let output = ""
  browser.stderr.on("data", chunk => {
    output += chunk
    const match = /DevTools listening on (ws:\/\/[^\s]+)/.exec(output)
    if (match) resolve(match[1])
  })
  browser.on("error", reject)
  browser.on("exit", code => reject(new Error(`Chromium exited before DevTools was ready: ${code}`)))
})

const socket = new WebSocket(address)
const pending = new Map()
let nextID = 0
socket.addEventListener("message", event => {
  const response = JSON.parse(event.data)
  if (!response.id) return
  const request = pending.get(response.id)
  if (!request) return
  pending.delete(response.id)
  if (response.error) return request.reject(new Error(response.error.message))
  request.resolve(response.result)
})
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true })
  socket.addEventListener("error", reject, { once: true })
})

function command(method, params = {}, sessionId) {
  return new Promise((resolve, reject) => {
    const id = ++nextID
    pending.set(id, { resolve, reject })
    socket.send(JSON.stringify({ id, method, params, sessionId }))
  })
}

try {
  const target = await command("Target.createTarget", { url: "about:blank" })
  const attached = await command("Target.attachToTarget", { targetId: target.targetId, flatten: true })
  await command("Emulation.setEmulatedMedia", { features: [{ name: "prefers-reduced-motion", value: "no-preference" }] }, attached.sessionId)
  await command("Page.navigate", { url }, attached.sessionId)
  const deadline = Date.now() + 15000
  while (Date.now() < deadline) {
    const title = await command("Runtime.evaluate", { expression: "document.title", returnByValue: true }, attached.sessionId)
    if (title.result.value?.startsWith("##")) {
      if (screenshot) {
        const image = await command("Page.captureScreenshot", { format: "png", captureBeyondViewport: false }, attached.sessionId)
        writeFileSync(screenshot, Buffer.from(image.data, "base64"))
      }
      const dom = await command("Runtime.evaluate", { expression: "document.documentElement.outerHTML", returnByValue: true }, attached.sessionId)
      process.stdout.write(dom.result.value)
      break
    }
    await new Promise(resolve => setTimeout(resolve, 50))
  }
} finally {
  clearTimeout(timeout)
  socket.close()
  browser.kill()
}
