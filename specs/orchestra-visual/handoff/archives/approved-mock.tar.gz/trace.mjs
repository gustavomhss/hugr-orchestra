// trace.mjs — the traceability gate for CORPUS.md.
//
// The corpus is only a lift if every check it cites exists, and only honest if
// every check that exists is claimed by some requirement. This expands the
// globs the corpus writes (`deeplink.view-*`) against the harness manifest and
// reports both directions.
//
//   node trace.mjs      exit 1 if anything is uncited, unknown, or dangling

import { readFileSync } from "node:fs"
import { resolve, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import { MANIFEST } from "./check.mjs"

const HERE = dirname(fileURLToPath(import.meta.url))
const md = readFileSync(resolve(HERE, "CORPUS.md"), "utf8")

const registered = new Set(Object.values(MANIFEST).flat())

// every backticked token that looks like a check id, glob or group name
const tokens = [...md.matchAll(/`([a-z]+\.[a-zA-Z0-9*-]+)`/g)].map(m => m[1])
// derive the prefix set from the check ids themselves, not from the group
// names: the `composer` group holds palette.*, home.* and rail.* checks, and a
// hand-written prefix list is how `profile` and then `chat` slipped through
const PREFIXES = [...new Set([...registered].map((id) => id.split(".")[0]))]
const isCheckish = (t) => PREFIXES.some((g) => t.startsWith(g + "."))

const expand = (t) => {
  if (!t.includes("*")) return [t]
  const re = new RegExp("^" + t.split("*").map(s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*") + "$")
  return [...registered].filter(id => re.test(id))
}

const cited = new Set()
for (const t of tokens) if (isCheckish(t)) for (const id of expand(t)) cited.add(id)

const unknown = [...cited].filter(c => !registered.has(c))
const uncited = [...registered].filter(r => !cited.has(r))

// a card must exist for every requirement: every "R<n>.<n>" and "R<n>.G<n>" in
// the body has to appear in the work-package table
// requirements appear in the body as **R1.1** and in the cards as ranges
// like "R1.1–R1.4" or "R2.G1–R2.G2"; both must resolve to the same set
const cards = md.slice(md.indexOf("## Work-package cards"))
const bodyReqs = new Set([...md.matchAll(/\*\*(R\d+\.(?:G)?\d+)\*\*/g)].map(m => m[1]))
// "R1.1".."R1.4" and "R5.G1".."R5.G3" both have to expand; a guard id carries a
// G before the number, so the prefix is split off before the digits are parsed
const expandReq = (a, b) => {
  const split = id => { const [g, n] = id.split("."); return [g, n.startsWith("G") ? "G" : "", n.replace(/^G/, "")] }
  const [ga, pa, na] = split(a), [gb, pb, nb] = split(b)
  if (ga !== gb || pa !== pb) return [a, b]
  const width = na.length
  const out = []
  for (let i = Number(na); i <= Number(nb); i++) out.push(`${ga}.${pa}${String(i).padStart(width, "0")}`)
  return out
}
const cardReqs = new Set([...cards.matchAll(/R\d+\.(?:G)?\d+/g)].map(m => m[0]))
// no capture groups here: m[1]/m[2] would be the ids without their leading R
for (const m of cards.matchAll(/(R\d+\.(?:G)?\d+)[–-](R\d+\.(?:G)?\d+)/g))
  for (const r of expandReq(m[1], m[2])) cardReqs.add(r)
const reqs = new Set([...bodyReqs])
const cardless = [...bodyReqs].filter(r => !cardReqs.has(r))

// a card that names checks that do not exist
const cardIds = [...cards.matchAll(/`([a-z]+\.[a-zA-Z0-9*-]+)`/g)].map(m => m[1])
const cardUnknown = cardIds.filter(t => isCheckish(t) && expand(t).some(id => !registered.has(id)))

const report = (label, list) => {
  if (!list.length) return console.log(`  PASS  ${label}`)
  console.log(`  FAIL  ${label} (${list.length})`)
  list.slice(0, 12).forEach(x => console.log(`          ${x}`))
  if (list.length > 12) console.log(`          ... and ${list.length - 12} more`)
}

console.log("traceability — CORPUS.md against check.mjs\n")
report("every cited check exists", unknown)
report("every registered check is claimed by a requirement", uncited)
report("every requirement has a work-package card", cardless)
report("no card cites a check that does not exist", cardUnknown)

console.log(`\n${registered.size} registered · ${cited.size} cited · ${bodyReqs.size} requirements · ${uncited.length} orphans`)
process.exit(unknown.length + uncited.length + cardless.length + cardUnknown.length ? 1 : 0)
