# Orchestra visual-identity copy

## Approved retention decision

The visual-identity work explicitly approves the designer's literal copy and the
official `HumanGuardrail` brand. `ORCHESTRA_COPY` in `orchestra.ts` owns the new
`orchestra.*` namespace. Every locale dictionary, including English, imports and
spreads that same copy. These strings are intentionally retained English, with
the designer's literal `Agendar` label also preserved.

This is an approved brand/navigation/rework-copy retention decision, not a claim
that the new namespace is translated or that any locale is fully translated.
No translation corpus was used and no new translations were invented. Existing
English keys and copy, locale translations, and localized native labels retain
their existing values. Feature code continues to use typed i18n keys.

The integration source used `Human Guardrail` for the new descriptor; the brief's
explicit official-brand spelling, `HumanGuardrail`, is used here. All other new
values are copied byte-for-byte, including placeholders and the footer newline.

## Classification

- **Product and official brand names:** `orchestra.brand.name`,
  `orchestra.brand.descriptor` retain `Orchestra` and `HumanGuardrail`.
- **Acronyms:** `orchestra.nav.mcp`, `orchestra.nav.cicd` retain `MCP` and `CI/CD`.
- **Code token:** `orchestra.nav.env` retains `.env`.
- **Approved English navigation copy:** `orchestra.nav.chat`,
  `orchestra.nav.agents`, `orchestra.nav.skills`, `orchestra.nav.plugins`,
  `orchestra.nav.hooks`, `orchestra.nav.dock`, `orchestra.nav.workspaces`,
  `orchestra.nav.providers`, `orchestra.nav.shortcuts`, `orchestra.nav.search`.
  These are explicitly approved visual-reference labels, not a claim of
  established borrowing in every locale.
- **Approved designer literal:** `orchestra.nav.schedule` retains `Agendar` as
  supplied; it is not classified as English.
- **Approved English profile copy:** `orchestra.profile.choose`,
  `orchestra.profile.empty` retain repository-profile and empty-state copy.
- **Approved English rework notice:** `orchestra.rework.pending`,
  `orchestra.rework.body` retain the notice and preserve `{{title}}` and
  `{{chapter}}`.
- **Dynamic title template:** `orchestra.rework.title` retains `{{title}}`.
- **Approved English brand tagline:** `orchestra.sidebar.footer` retains its
  copy and newline.
- **Approved English activity status:** `orchestra.model.running`,
  `orchestra.model.waiting`, `orchestra.model.idle` retain status copy.
- **Dynamic model/provider/activity template:** `orchestra.model.tooltip`
  retains `{{model}}`, `{{provider}}`, `{{activity}}`, and separators.

All 26 keys belong only to this new namespace. Dictionary composition is static;
there is no locale-specific runtime branch. Existing key and placeholder parity
tests apply to the composed dictionaries without exceptions.
