# Orchestra visual identity verification ledger

**Formal acceptance: pending — performance and visual/native coverage.**
Evidence snapshot: 2026-10-01, including the owned final static capture after
the lead's production UI, package and native checks. The lead reports all 11 production UI tests, 750 app unit
tests, 43 browser tests and app/E2E/desktop typechecks passed. Desktop identity
is an approved design reference; these checks do not establish final acceptance.

Document owner: `visual-evidence`, worktree `identity-review`. This ledger is
ready for lead integration and later evidence updates. The lead's current
`specs/orchestra-visual/MIGRATION.md` was read without editing it.

## Evidence index

Paths below use these absolute roots:

- `WT`: `/Users/gustavoschneiter/Documents/HuGR/_worktrees`.
- `LEAD`: `WT/orchestra-identity`.
- `TMP`: `/var/folders/lt/z11pyzhj0m17vn798jkk69hh0000gn/T/opencode`.
- `BASELINE`: `TMP/orchestra-identity-baseline`.
- `REFERENCE`: `/Users/gustavoschneiter/Downloads/orchestra-replica-static`.
- `FAILURES`: `LEAD/packages/app/e2e/orchestra/e2e/test-results`.
- `CURRENT`: `LEAD/packages/app/e2e/test-results/orchestra`.
- `CAPTURE`: `TMP/visual-evidence-final`.

| ID | Source / artifact | Evidenced scope |
| --- | --- | --- |
| E01 | `LEAD/specs/orchestra-visual/MIGRATION.md`; base `5e4bea3b519c04cebfb787e98dfa171f5771d25c` | Frozen identity and acceptance contract; no chapter promotion |
| E02 | `REFERENCE/{app.html,mock-features.js,MOCK-GUIDE.md,CHAPTERS.md}`; `BASELINE/reference-glass.json` | Approved reference geometry, computed glass values and pending chapter register |
| E03 | `BASELINE/README.md`, `BASELINE/stream.{json,log}` | Unchanged production benchmark, exact baseline argv/environment and observations |
| E04 | `BASELINE/{build,typecheck-serial}.{json,log}`, `BASELINE/bundle.json`, `BASELINE/bundle/`; `BASELINE/{dark,light}-{ltr,rtl}-{idle,running}.png` | Historical baseline build/typecheck/inventory and screenshots; not integrated acceptance |
| E05 | `BASELINE/{analyzer-controls,oracle,identity-calibrations-corrected}.{json,log}`, `BASELINE/identity-pending-results/` | Bounded calibration, deliberate blanking/geometry/glass rejection, and expected unchanged-base identity failure |
| E06 | `FAILURES/.last-run.json`; four case directories listed below | Preserved first integrated failure snapshot, error context, failure screenshot and video |
| E07 | `TMP/fix-glass-{optimizer.json,real-probe.ts,compiled.css,browser-proof.json}`, `TMP/fix-glass-{dark,light}-{en,ar}.png` | Candidate stylesheet proof on real-app production output, including scoped mutation assertions; not a final rebuilt bundle |
| E08 | `TMP/fix-glass-compositor.json` | Static two-message compositing reasons; SwiftShader environment; no timing benchmark |
| E09 | Lead asset comparisons and manifest diffs recorded below | Exact asset preservation and scoped dependency inspection |
| E10 | `LEAD/packages/app/e2e/orchestra/{playwright.config.ts,identity.spec.ts}`, `LEAD/packages/app/package.json` | Dedicated production harness and deterministic reference assertions; source inspection is not execution evidence |
| E11 | `WT/fix-locales/packages/app/src/i18n/{orchestra.ts,orchestra-copy.md}`; `LEAD/packages/app/src/i18n/{orchestra.ts,en.ts}` | Historical unapproved descriptor typo; integrated shared copy has 27 keys and the correct spaced descriptor |
| E12 | First lead task handoff: first-after metrics | First-after observations retained; raw after-run attachment pending |
| E13 | `CURRENT/.last-run.json`; current production UI result supplied by lead | Inspected manifest says `passed`; lead reports all 11 UI tests passed; CLI log attachment pending |
| E14 | Current lead package-check report; `LEAD/packages/app/test-browser/orchestra/{titlebar-tab-order,prompt-model-selection}.test.ts` | 750 unit / 43 browser tests and app/E2E/desktop typechecks reported passed; runtime cases moved to browser lane; raw logs pending |
| E15 | Current lead real-Electron/ASAR and App Dock report | Electron 42.3.3 asset HTTP/SHA checks and bounded native bridge/bounds/cleanup observations; raw evidence attachment pending |
| E16 | Current lead filtered streaming benchmark report | New slower SwiftShader sample recorded below; raw logger output not yet persisted |
| E17 | `CAPTURE/{REPORT.md,run.json,source-graph.json,geometry.json,comparison.json,controls.json,cleanup.json}` and indexed PNGs | Owned final static capture of existing lead bundle: all four geometry/glass/upward-menu cases passed, theme persistence verified, remaining real fidelity differences measured |
| E18 | `CAPTURE/{panels.ts,panels.json,panels-cleanup.json}`; populated review and web Apps PNGs | Original fixture/backend plus one AST-copied file-diff input; real open-panel geometry and selected file captured; no native bridge emulated |

Historical baseline package typecheck/build results belong to the unchanged base
(E03–E05); current integrated check results are recorded separately in E13–E15.
CLI output/raw logger records for the current runs are not yet persisted; the
lead will attach them. The run-state manifest does not contain test counts,
argv, benchmark metrics or full stdout. Those details remain explicitly
lead-reported until their logs are attached.

## Before / first-after / filtered-after performance

Baseline: `identity-verify`, unchanged base above; Bun 1.3.14, Node 22.17.1,
darwin, Playwright 1.59.1, Chromium 147.0.7727.15. Selected V2 streaming test:
`streams assistant text in v2 with review pane closed`. Workload: 18 history
turns, 64 deltas, event batch 1, CPU throttle 1, new layout enabled, review pane
closed, one worker, zero retries, CPU and visual profiling disabled.

| Metric | Before (E03) | First after (E12) | Filtered after (E16) | State |
| --- | --- | --- | --- | --- |
| Initial content observed | 0.417 s (416.956 ms) | 1.397 s | 1145.763 ms | Still slower than baseline; unresolved regression |
| RAF callback gap p95 | 33.4 ms | 50 ms | 200 ms | Worse than both earlier samples; unresolved regression |
| Throughput | 3.8913 deltas/s | 3.880 deltas/s | 3.87543 deltas/s | Lower observed throughput |
| Completion observed | 16.447 s | 16.494 s | 16514.3 ms | Slower observed completion |

Both after samples are supplied by the lead, not new measurements by this
document owner. Attaching raw logs, argv, filter/environment and bundle identity
remains pending. The newest filtered sample additionally reports progress-window
RAF gap p95 **250 ms**, **8.483 callbacks/s**, `longTaskCount=0`, geometry blank
samples 0, bottom drift 0 and `rowReplaced=false`. Zero long tasks or geometry
failures do not negate the callback-gap regression.

Keep the first-after sample and the newer sample separately. Initial content is
less slow in the newer run than in the first after, but still regressed versus
baseline; completion, throughput and RAF gaps are worse. No statistically
established cause or hardware-performance improvement is claimed. Repeat the
fixed workload with complete run metadata; performance acceptance remains open.

Baseline logs report 64 delivered deltas, zero pending, geometry blank samples
zero, bottom drift zero, and no row/markdown replacement. Visual metrics were
null because visual profiling was disabled: these are renderer/geometry
observations, not proof of presented-pixel stability. E08 identifies
`ANGLE_SWIFTSHADER` and software compositing; do not infer hardware-GPU, native
desktop or compositor performance from these artifacts.

## Preserved failures and current production/test-runtime state

E06 records `"status": "failed"` and these geometry cases:

| Case | Directory under `FAILURES` | Expected filter; received |
| --- | --- | --- |
| dark English / LTR | `orchestra-identity-dark-en-d75b1-y-and-upward-profile-portal-chromium` | `blur(8px) brightness(0.74) saturate(0.9)`; `none` |
| dark Arabic / RTL | `orchestra-identity-dark-ar-dded0-y-and-upward-profile-portal-chromium` | `blur(8px) brightness(0.74) saturate(0.9)`; `none` |
| light English / LTR | `orchestra-identity-light-e-a6f38-y-and-upward-profile-portal-chromium` | `blur(16px) brightness(1.04) saturate(0.96)`; `none` |
| light Arabic / RTL | `orchestra-identity-light-a-2544c-y-and-upward-profile-portal-chromium` | `blur(16px) brightness(1.04) saturate(0.96)`; `none` |

Each historical `error-context.md` reports `Error: glass fingerprint`. Those
assertions stopped at glass comparison, before later profile-portal checks;
the original failures are retained as history, not the current UI verdict.
The dark/en failure screenshot
and dark/en candidate screenshot were inspected, along with the unchanged-base
dark/LTR idle screenshot. Final reference-to-production fidelity review remains
pending.

E07 reproduces the optimizer dropping standard `backdrop-filter` with the old
declaration order. Prefix-first output retains both declarations. The candidate
probe injects compiled replacement CSS into existing production output, checks
dark/light × en/ar, and rejects deliberate `none` filter and 27px avatar
mutations. This is bounded candidate evidence, not a rerun of the final
production identity suite. E13 records the subsequent production run state:

```json
{
  "status": "passed",
  "failedTests": []
}
```

The lead reports all **11 production UI tests passed**. The old E06 manifest
still reports failed tests, preserving both directions of the run-state record.
This pass closes the recorded automated UI failure on the current integration;
final screenshot/native coverage and performance acceptance remain pending.

The new dedicated E10 config builds production (`bun run build`) then serves
Vite preview on default port 4313; `reuseExistingServer: false`, one worker,
zero retries, line reporter and output directory `CURRENT`. Entry script:
`bun run test:orchestra`, from `packages/app`.
The general Playwright config uses a development server; fallback to that lane
does not establish production-bundle acceptance.

The actual earlier unit-runtime failures were
`getContextId cannot be used under non-hydrating context` and a nonreactive SSR
memo. Reactive store/transition cases now live under `test-browser/orchestra`
and run in the existing browser-condition lane; pure selection/order cases stay
under `src`. The lead reports the relocated browser cases passed, with package
results below. These were runtime-lane errors, not the historical glass failure.

| Current package check (E14) | Lead-reported result | Evidence attachment |
| --- | --- | --- |
| App unit tests | 750 passed | Raw CLI log pending |
| App browser tests | 43 passed | Raw CLI log pending |
| App typecheck | Passed | Raw CLI log pending |
| App E2E typecheck | Passed | Raw CLI log pending |
| Desktop typecheck | Passed | Raw CLI log pending |

### Real Electron / native App Dock observation

The lead reports real **Electron 42.3.3** packaged-ASAR checks: identity assets
returned **HTTP 200** and identity SHA-256 matched. App Dock's x coordinate
changed **440 → 540** and correctly updated `nativeBridge`; width **934** and
height **468** stayed unchanged. Duplicate/cleanup checks reported **0** (E15).
These bounded native observations supplement the browser checks. They do not
close the remaining native visual/coverage matrix or provide hardware timing
evidence; raw probe output and visual artifacts remain to be attached.

## Preservation and dependency inspection

At inspection, each reference asset was compared directly with
`LEAD/packages/app/public/orchestra/<filename>`. All three `cmp` comparisons
returned exit 0; SHA-256 values match each pair:

| Asset | Reference and integrated SHA-256 |
| --- | --- |
| `hugr-horizontal-compact-inverse.svg` | `c236a1b9b198be20efb76ea1cc10044288036af5783f6a0c84b661437a9a9251` |
| `hugr-horizontal-compact-primary.svg` | `4efd3719f8f2e0bbfb9604f05f996bc8fdec950d7364bcda6415b4fd2c433810` |
| `mtn-src.jpg` | `757674475d2ace543feacc04f136f267996691413f6349944b5ec66c2bd86c08` |

Comparison control: primary versus inverse reference SVG returned exit 1,
`differ: char 325, line 1`; the instrument detects different bytes. Preservation
is exact for these assets, not a claim of whole-screen pixel identity.

`git diff --exit-code <base> -- package.json bun.lock` in `LEAD` returned exit 0.
`git diff <base> -- packages/app/package.json` returned the single added
`test:orchestra` script. That known script addition is the positive diff control.
No new runtime dependencies are declared in the inspected root/app manifests;
app runtime and dev dependency declarations are unchanged. This verifies those
manifests and the root lockfile, not a whole-runtime performance claim.

## Problem ownership and integration state

Branch/worktree mapping was checked with `git worktree list --porcelain`.

| Owner branch | Worktree under `WT` | Owned correction / evidence | State |
| --- | --- | --- | --- |
| `fix-glass` | `fix-glass` | `packages/app/src/orchestra/{theme,shell,tabs,session}.css`; optimizer/filter and avatar styling | Approved correction; current production UI passed; performance/fidelity acceptance pending |
| `fix-locales` | `fix-locales` | `packages/app/src/i18n` dictionaries, common `ORCHESTRA_COPY`, retention note | Corrected shared copy integrated; 27 keys and spaced descriptor inspected; package checks reported passed |
| `fix-test-runtime` | `fix-test-runtime` | Pure `src` tests and reactive/transition `test-browser/orchestra` tests | Runtime cases moved to browser lane; 750 unit / 43 browser passes reported; logs pending |
| `fix-profile-races` | `fix-profile-races` | `src/orchestra/sidebar.tsx`, `test-browser/orchestra/profile-races.test.ts`; picker/settings lifetime guards | Guards present in lead source; current UI passed; broader rendered/native race coverage pending |
| `desktop-check` | `identity-brand` | Desktop/native Dock acceptance evidence; compact SVG evidence | Real Electron/ASAR/native bridge observations reported; final visual/native coverage pending |
| `visual-evidence` | `identity-review` | Only `specs/orchestra-visual/VERIFICATION.md` | Ledger ready for lead integration/update |

Lead owns integration, imports, startup branding, localization authority and
final acceptance. Completed checks above do not close the remaining performance
and visual/native acceptance items.

### Descriptor and intentional common copy

Approved descriptor is exactly **`Human Guardrail`**, including its space
(E01, E10 assertions, integrated shared-copy source). The historical `fix-locales` candidate and its
retention note instead say `HumanGuardrail`; that agent typo was **not approved**.
The lead corrected it: current `LEAD/packages/app/src/i18n/orchestra.ts` uses
`Human Guardrail` and contains **27 common keys**, including
`orchestra.brand.caption: "OpenCode, evolved."`. The descriptor correction is
integrated, not still pending.

Common `orchestra.*` keys intentionally retain approved English brand/navigation,
profile, rework and activity copy across locales. Designer literal `Agendar`,
product names, acronyms and `.env` retain their reference spelling; placeholders
and the footer newline remain part of the copy contract. Existing localized
common/native keys continue to provide their translations. Shared-key coverage
is not a claim of new translations or full locale translation.

## Pending acceptance ledger

Deterministic reference contracts compare geometry, normalized computed CSS,
assets and real animation state. They do not establish pixel identity for live
data, fonts, native controls or unreviewed screens.

### Final static capture, 2026-10-01

E17–E18 serve the existing lead `dist` on owned port **4314**, Chromium
**147.0.7727.15**, **1400×900**, DPR **1**. Owned previews were closed and retained
main/final supplemental port-release checks passed. Production entry HTML/JS/CSS hashes and the current
E2E source stayed unchanged. No rebuild or source/gate change; no CPU profiling
or streaming benchmark was run. Only two static messages, plus permission
events or one file-diff input, were seeded using the original shared fixture and
AST-copied current E2E helpers/assertions. Temporary diagnostic DOM mutations
are labeled separately and restored.

Actual capture locations, relative to `CAPTURE`:

- `app-{dark,light}-{ltr,rtl}-{chat,sidebar,header,brand,menu,permission}.png`.
- `reference-{dark,light}-{ltr,rtl}-{chat,sidebar,header,brand,menu,permission}.png`.
- `app-dark-{ltr,rtl}-toggle-{light,dark}.png`.
- `app-{dark,light}-ltr-{review-populated,review-panel,apps-web,apps-panel}.png`.
- `source-graph.json`, `geometry.json`, `panels.json`, `comparison.json` and
  `controls.json` retain actual source identity, classes, root colors, rectangles,
  pseudo-layer paint, first-file metadata and calibrated diagnostic comparisons.

All four dark/light × LTR/RTL cases passed the unchanged current geometry,
glass and upward-profile-portal assertions. Shared palette and glass match the
same-viewport reference; sidebar/toolbar/gutter are **230/45/6**. Open LTR
conversation is `(255,114) 690×767`, rail `(951,114) 430×767`, gap 6px; outer
rectangles match the reference. Selected `changed.ts` row is `(975,289) 223×28`.
Avatar is **28×28**; official logo **121×32**, at `(40,81)` in LTR and `(1239,81)`
in RTL. Descriptor text is exactly **`Human Guardrail`**, 11px/14px at y=115.
Menus end at y=754 above picker top 762, through a portal, in all four cases.
Live downward-menu and `none`-filter mutations were rejected and restored.
Dark→light→dark persisted through `opencode-color-scheme` and fresh-page restore
in both writing directions; caption and brand remained correct.

Real remaining identity differences, documented in `CAPTURE/REPORT.md`:

1. Opaque `#root` hides the reference's outer radial gradient. A temporary
   transparent-root control restores the measured reference margin pixels in
   both themes; production remains unchanged.
2. Descriptor/navigation/caption inherit weight **440**, reference **400**.
   Descriptor width is **89.359375px** versus **88.96875px**, with the same font
   family/browser; a 400-weight control recovers the reference width.
3. Profile metadata row is **24px** high versus **12px**, and card **66px** versus
   **46px**. Different repository/path/account copy is data, but inherited
   line-height is a genuine style difference.
4. Light theme button is transparent with `rgb(129,138,149)` foreground rather
   than reference `rgba(40,56,74,0.08)` fill and `rgb(95,104,116)` foreground.
   Toggle behavior/storage work; resting paint still differs.
5. With matching open-panel outer geometry, actual composer is `(285,811) 630×54`
   versus reference `(286,766) 628×98`. Production's pseudo-border reserves no
   real 1px inset; preserved editor/control and virtualizer-header layout differ.
   This needs a fidelity decision, not a whole-frame equality claim.
6. Populated production review keeps a file tree plus split diff within the
   430px rail; captured code wraps into one/two-character columns, unlike the
   reference's stacked file list and wider diff. This is a real current layout
   gap; whether it is inherited or newly introduced is not established here.

Reference RTL goldens are the original English mock forced RTL, not an approved
Arabic translation. Real session/model attribution, avatar variant/path,
messages, changed-file count, permission pattern and mock preview state controls
are data/runtime differences. Web Apps reports desktop-required behavior with
no native bridge; screenshots do not represent native browser contents.
Remaining native visual coverage and existing performance regression stay open.

| Acceptance item | Current evidence | Remaining state |
| --- | --- | --- |
| Final production performance | Baseline, first-after sample and worse filtered-after SwiftShader RAF gaps | Pending raw after-run attachment, repeat and regression resolution |
| Current production UI and package checks | All 11 production UI tests, 750 unit / 43 browser tests and app/E2E/desktop typechecks reported passed; E13 manifest inspected | Checks passed on current integration; raw CLI/build evidence attachment pending; formal acceptance remains open |
| Dark/light × LTR/RTL geometry and glass | Current production UI pass plus E17 four-case calibrated captures; paired reference screenshots and exact 230/45/6 geometry | Captures complete; typography/root/button/editor fidelity decisions and native visual coverage pending |
| Frame, continuous background, palette and shared glass | E17 confirms 12px margin, 13px frame radius, preserved mountain asset and matching glass/palette; opaque root still hides outer radial paint | Pending correction/acceptance of measured fidelity differences |
| Bottom profile picker, upward portal, navigation scroll | Current production UI pass, lifetime guards and E17 actual upward portals in all four cases | Covered assertions/captures passed; broader lifetime/native interaction coverage pending |
| Session tabs, close/history/new/profile selection | Passing package/browser checks and integrated guards | Broader navigation, tab memory, admission and native workflow coverage pending |
| Executed-model ownership, activity and reduced motion | Current UI pass; manufacturer/router/neutral contract; 2.4s pulse and 1.15s wait bounce | Covered assertions passed; remaining mutation, question and native coverage pending |
| Native controls and App Dock boundaries | Electron 42.3.3 ASAR report and native bounds observation; E18 real web Apps shell retains 430px rail and desktop-required state | Bounded evidence recorded; browser captures do not close native visual coverage |
| Cold slice review and lead file review | Contract requires both | Pending final reviewed integration evidence |

### Chapter register

**All chapters remain rework pending; active chapter: none** (E01–E02).

| Chapter | Screen | State |
| --- | --- | --- |
| C01 | MCP | Rework pending |
| C02 | Skills | Rework pending |
| C03 | LLM Plugins | Rework pending |
| C04 | Hooks | Rework pending |
| C05 | Providers | Rework pending |
| C06 | Shortcuts | Rework pending |
| C07 | CI/CD | Rework pending |
| C08 | Agendar | Rework pending |
| C09 | .env | Rework pending |
| C10 | Home / KPIs | Rework pending |
| C11 | Agents | Rework pending |
| C12 | Workspaces | Rework pending |
| C13 | Dock | Rework pending |

Existing Providers/Shortcuts settings and native App Dock reuse do not approve
their Orchestra screen chapters. Chat and Settings retain inherited
classification.

For later updates, the lead can append evidence IDs with integrated bundle/source
identity, command, package working directory, environment, exit status, raw log,
screenshots and relevant mutation witness, then update only the corresponding
acceptance row. Keep failed artifacts, first-after metrics and the newer filtered
regression sample; append the lead's raw CLI/logger evidence without replacing
their provenance or promoting any chapter.
