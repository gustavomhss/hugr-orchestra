# Visual delivery — scoped pass

2026-10-01 · `visual-evidence` / `identity-review`.
Current lead bundle: `index-SSqENClG.js`, `index-BYCg7dah.css`.
Lead reports 14 production E2E passes; this delivery verifies the bounded static matrix.

Artifact root:
`/var/folders/lt/z11pyzhj0m17vn798jkk69hh0000gn/T/opencode/visual-evidence-delivery`.
PNG paths below are relative to that root.

| Case | Chat | Profile menu | Permission | Populated review |
| --- | --- | --- | --- | --- |
| Dark LTR | `app-dark-ltr-chat.png` | `app-dark-ltr-menu.png` | `app-dark-ltr-permission.png` | `app-dark-ltr-review-populated.png` |
| Dark RTL | `app-dark-rtl-chat.png` | `app-dark-rtl-menu.png` | `app-dark-rtl-permission.png` | `app-dark-rtl-review-populated.png` |
| Light LTR | `app-light-ltr-chat.png` | `app-light-ltr-menu.png` | `app-light-ltr-permission.png` | `app-light-ltr-review-populated.png` |
| Light RTL | `app-light-rtl-chat.png` | `app-light-rtl-menu.png` | `app-light-rtl-permission.png` | `app-light-rtl-review-populated.png` |

All four cases pass current geometry/glass/upward-menu assertions and the six previously recorded fixes:

- Sampled margin RGB matches reference exactly; frame text weights are 400.
- Profile card 46px; metadata row 12px.
- Light theme button resting foreground/fill matches reference.
- Composer 628×98px with 690px conversation; editor/placeholder share grid cell 1/1.
- Review is stacked, preview 398px wide with readable populated diff.
- Closed sidebar occupies 0px height; long filename stays contained with ellipsis.

The root paint, typography, profile, toggle, composer and review findings from
`visual-evidence-final/REPORT.md` are closed for this capture scope. Prior real
broken captures reject the same comparison predicates.

Additional PNGs: `app-{dark,light}-{ltr,rtl}-review-sidebar-closed.png` and
same-viewport `reference-{dark,light}-{ltr,rtl}-chat.png`; identity crops and
theme-cycle captures are included. `checks.json`, `geometry.json`, `panels.json`
and `source-graph.json` retain actual values, classes, source hashes and assets.

1400×900, DPR 1, original two-message fixtures, existing bundle; no injected CSS,
rebuild or benchmark. Source font-face/control/data differences are allowed;
whole-frame pixel identity and native contents are outside this scoped pass.
Owned port 4314 was released; cleanup manifests record exit 0. Older gallery is preserved.
