# Independent review of the component CI evidence

Reviewed 2026-11-28 UTC. Read-only review through GitHub: run metadata, job logs, snapshot diffs, selected tests, preloads, workflow and relevant process/harness source. This is an independent assistant evidence review, not a native Lucy run or customer acceptance.

## Verdict

**Supported, with scope made explicit:** “57 selected component/integration tests passed in two Linux CI runs. The Maestro run exercised native Omni process execution. These results do not establish a live native Orchestra/model/team run, whole-SOL delivery, customer acceptance, or delivery capacity.”

“Some genuine process spawning” is defensible. “57 native end-to-end tests passed,” “the team is qualified,” “689 agents ran,” or a throughput forecast would overstate this evidence.

## Identity and results

Both runs used `test-ci`, attempt 1, on Ubuntu 24.04 x64 with Bun 1.3.14. Run metadata and the checkout log independently agree on each head SHA. Each snapshot is exactly one commit ahead of pinned base `ff7f50b591494aba05b3c917379d633cc2d7176e`; the sole changed file is a new `.ci-run.json`. There are no test, workflow or product-source edits in either snapshot. [Core commit/diff](https://github.com/gustavomhss/hugr-orchestra/commit/d849914c420a9d0c6f651bd3da82ad48f1ef4ff3), [Maestro commit/diff](https://github.com/gustavomhss/hugr-orchestra/commit/5bb945e62eb68d913c212eb00027893b1def26e0).

| Lane | Exact evidence | Observed result | Selected files |
|---|---|---|---|
| Core | [Run 46162430182](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162430182), [job 141032496133](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162430182/job/141032496133), head `d849914c420a9d0c6f651bd3da82ad48f1ef4ff3` | 39 pass, 0 fail, 295 expectations, 3 files; test step and workflow success | relay-workflow-evaluator (17), relay-workflow-binding (17), relay-hook-session (5) |
| Maestro | [Run 46162432277](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162432277), [job 141032502440](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162432277/job/141032502440), head `5bb945e62eb68d913c212eb00027893b1def26e0` | 18 pass, 0 fail, 117 expectations, 3 files; test step and workflow success | v2-workflow-review (6), v2-atlas (11), v2-workflow-plan-e2e (1) |

Combined: **57 pass, 0 fail, 412 expectations across six selected files**. The pass markers agree with the summaries and source registrations. No skipped/todo test markers appear; no skip/only registrations were found in the six selected sources. Auxiliary workflow steps were conditionally skipped, so do not say “no workflow steps were skipped.”

The applicable Bun command runs directly under Bash `-e -o pipefail`, with no `continue-on-error` or success-forcing wrapper. The Effect helper rethrows failures. I found no evidence of masking selected-test failures. The workflow's `|| true` is in the separate branch-cleanup job, not the tests. [Pinned workflow](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/.github/workflows/test-ci.yml), [Effect test helper](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/packages/core/test/lib/effect.ts).

## Omni and nonce evidence

Both requests set `ORCHESTRA_EXPERIMENTAL_OMNI_SPAWNER=strict`; both logs show that setting and `ORCHESTRA_OMNI_CONTROL=declared`. Each job has one generated 32-character nonce and exactly one verdict carrying that same nonce:

- Core: `f402470d7755ee990ffde6307dfcc451` — **not applicable**; no declaring test ran, no Omni spawn, no delegation. Core proves nothing about Omni spawning.
- Maestro: `dd47b27e90d3439f95902dd58ba3874f` — **pass**; 6 declaring tests in `v2-workflow-review.test.ts`, **689 aggregate Omni spawn counts, 0 delegations**.

The preload deletes the nonce from the environment before tests load; it checks every declaring test's own counter delta and rejects absent expected spawning or strict-mode delegation. The six review tests use real Git operations and temporary worktrees. [Positive control](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/script/test-omni-control.ts), [per-test expectations](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/packages/core/test/fixture/omni-expect.ts), [review tests](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/test/v2-workflow-review.test.ts).

**Keep the counter's meaning narrow.** The 689 figure is process-wide instrumentation across the Maestro run, not a per-agent measure or solely the six review tests. The collection path increments before calling `omni.run`, so it is not an independent audit of 689 successfully completed OS processes. Real Git test results and the positive control support genuine native process execution. [Counter implementation](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/packages/core/src/omni-spawner.ts).

Both jobs restored Omni binaries from the same source-keyed Linux x64 cache; the build-on-cache-miss step was skipped. These runs did not freshly compile native binaries or publish a per-binary digest. [Binary action](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/.github/actions/omni-binaries/action.yml).

## What remains unproved

The tests exercise genuine controls through fixtures and injected boundaries:

- Core settlement uses real shell/Git operations and ledger files through its harness, with constructed session/binding identity and stub judge configuration. Core hooks use an explicit fake LLM that emits “Done.” plus injected/no-op execution layers. [Evaluator](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/packages/core/test/relay-workflow-evaluator.test.ts), [arm harness](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/relay/test/arm-harness.ts), [hooks](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/packages/core/test/relay-hook-session.test.ts).
- Atlas tests inject seats, agents, permissions and session state. The plan test writes completed Maestro/Archie tool and assistant messages into its test database; its plan concerns a fixture CSV export. Its “e2e” filename does not establish model-authored planning or a live task dispatch. [Atlas tests](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/test/v2-atlas.test.ts), [plan test](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/test/v2-workflow-plan-e2e.test.ts).

Consequently, this evidence does not establish authenticated model execution, real Archie/Lucy participation, the full native runtime path, SOL requirements coverage or implementation, or sustainable team capacity. The logged test durations and process counter cannot support a delivery-rate estimate. The host-offline status was supplied in the review brief; this reviewer did not independently inspect the device.

**Action:** retain these runs as a component qualification baseline. The outstanding proof still requires an available authenticated native host, a bounded real SOL work packet executed by the actual seats, retained task/model/review records, the resulting code and acceptance evidence, and measurements across representative repeated work. Do not convert this baseline into team or customer acceptance.
