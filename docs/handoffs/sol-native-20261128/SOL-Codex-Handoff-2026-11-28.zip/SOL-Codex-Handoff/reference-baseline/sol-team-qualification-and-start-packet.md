# SOL — supplier qualification and starting agreement

**Review draft.** The proposal remains the complete SOL, including integration, migration, stabilization and handover. The current records propose three AI engineers, a four-month central target inside a three-to-six-month envelope, and seven calendar days of initial discovery included in that envelope. Staffing capacity and the forecast remain unvalidated. This packet records no completed team qualification, customer approval or SOL proof run. [D: `/planning`, `/closure`; C: `/programme`]

## 1. Qualification evidence to assemble

Use the existing `supplier_qualification` fields and the role register; retain evidence once and reference it. Assess the team's coverage collectively, and attribute each person's contribution separately.

| Evidence | What the reviewer needs | Existing record |
|---|---|---|
| Comparable delivery | An attributable example of modernization or a comparable integrated delivery; original context, personal contribution, actual outcome and limits. Use a public artifact or a permitted private/redacted record. A repository's existence alone establishes no person's contribution. | `supplier_qualification.relevant_experience`, `comparable_delivery_context`, `qualifying_evidence_refs`, `relevance_and_limits` |
| Modern .NET and React/TypeScript | A versioned working API and client, meaningful validation/error behavior, persisted results, and review of the implementation decisions. Attribute implementation and review to the people being qualified. Evidence from a .NET-only reference supports backend capability only. | `supplier_qualification.proposed_team_contribution`; each role's `relevant_experience_ref` |
| Migration and integration | An attributable mapping/reconciliation example, treatment of conflicting or repeated writes, integration dependencies, and a recovery or transition decision. State explicitly when evidence is a reference exercise rather than prior production delivery. | `migration-lead.relevant_experience_ref`; `supplier_qualification.relevance_and_limits` |
| Security, operation and transfer | Evidence of bounded permissions, credential custody, failed-control handling, deployment/recovery and another person's successful use of delivered instructions. Identify any uncovered responsibility. | `security-lead` and `operations-lead` evidence references |
| Native Orchestra method | Exact runtime/source revision, actual runners and evaluator configuration, native execution traces, current candidate checks, independent evidence review and unresolved limits. Source inspection, CI, synthetic scenarios and live native execution must remain distinguishable. | `supplier_qualification.qualifying_evidence_refs`; P: `/runRecordTemplate` |
| Capacity and independence | Named coverage, confirmed allocation over relevant dates, other commitments, review effort, substitutes and conflicts. Agent count and generated artifacts establish no human availability. | C: `/people`; R: `/roles`, decision `people-capacity` |

The supplier reviewer should be able to trace each material claim to an artifact and the proposed member's role. Where historical evidence is unavailable, qualify only the bounded responsibility demonstrated in a witnessed exercise and record the remaining gap. A machine-generated exercise qualifies the observed method; it does not establish a named engineer's experience.

### Evidence available before SOL access

The current evidence comes from the Orchestra repository and its two observed Linux CI runs. It qualifies the selected component behavior only. No external reference project has been selected or executed for this packet. A later .NET/React supplier exercise would need an explicitly selected, permitted source with a recorded revision and expected outcomes; it would remain separate from SOL qualification. Choose such an exercise only if it answers a specific team-capability gap. Keep delivery examples and customer-facing claims within the actual SOL rebuild scope.

The prepared native campaign can first establish a real, attributed planning return on available Orchestra materials once an authorized host and model exist. The complete live chain still needs its own execution and receipts. No source-inspection finding or component test is credited as a model-driven task, integration or Atlas update.

Retain actual commands, outputs, source/configuration identities, candidate and integration identities, reviewer findings, failed attempts and untested behavior using the existing run-record fields. Live model claims require the actual configured models; injected verdicts remain labelled. The proposed SOL composition requires all mandatory checks, the frozen non-empty panel of one to three distinct models with overall and all five axis assessments, current evidence, applicable independent review and retained authority. The inspected native majority ballot alone does not demonstrate that composition. [P: `/decisionPolicy`, `/resultPolicy`]

Store observed component and any later reference findings under `supplier_qualification.qualifying_evidence_refs`, with their scope and limits. Leave the SOL cases `UNRUN` until their own prerequisites and observed executions exist. Reference success cannot establish SOL completeness, a 40-agent capacity level or the programme forecast. [P: `/executionPrerequisites`, `/qualificationBoundary`, `/completionRule`]

## 2. Three-person coverage proposal

These are **proposed coverage slots**, not named appointments or verified capabilities. Confirm the people and rebalance responsibilities using evidence and actual capacity.

| Proposed slot | Primary coverage using existing role IDs | Specific capability to establish |
|---|---|---|
| Engineer A | `engineering-lead` | Modern .NET architecture; React/TypeScript integration; actual Orchestra bindings and effective acceptance controls. |
| Engineer B | `migration-lead` | Source behavior analysis; data mapping and reconciliation; integration dependency management and transition planning. |
| Engineer C | `operations-lead`, `security-lead` | Environment isolation, access/data routes, delivery operations, recovery and receiving exercises. |

Assign `delivery-lead` explicitly to one qualified person after accounting for forecast, issue, customer and coordination effort. Role combinations are possible only when the allocation and required independence hold. A gap calls for revised coverage or documented supporting capacity before that responsibility is needed; the complete SOL scope stays visible. [D: `/people`]

Review is a separately allocated responsibility in `people.assignments`. For each item, record a competent reviewer who did not author that item, any conflict, and the expected-outcome source. Another team member may supply this review when independence and capacity are demonstrable. If every available reviewer contributed to the implementation or lacks the relevant competence, secure independent review before acceptance. Record customer business, service/data and receiving authorities through `business-owners`, `service-data-owners` and `receiving-lead`; supplier execution cannot substitute for their retained decisions.

### Private execution annex

Use `people.private_execution_annex_ref` for one controlled annex. Preserve the existing fields:

- In `/roles`: `id`, `named_person`, `substitute`, `confirmed_capacity`, `relevant_experience_ref`, `independence_constraints`, `state`.
- In `/people/assignments`: `responsibility`, `responsible_person`, `deputy`, `relevant_capability`, `availability`, `allocated_effort`, `needed_by`, `independence_or_capacity_constraints`, `confirmed_by`, `confirmed_at`.
- In `/client_participation`: `phase`, `owner`, `substitute`, `expected_effort`, `needed_by`, `response_expectation`, `availability_confirmed`, `record_refs`.

`availability` should specify actual dates, working hours/timezone, absences and competing commitments; `allocated_effort` should separate implementation, review and delivery/operations duties so the same hours are not counted twice. Deputies need confirmed capability and availability. Keep names, exact hours and private evidence in the annex accessible to authorized participants; the public proposal can retain role IDs. Qualification remains open until `customer_reviewer`, `review_outcome` and `reviewed_at` record an actual review. [C: `/people`, `/supplier_qualification`; R: `/roles`, `/client_participation`]

## 3. Starting assignment ready for discussion

**Proposed initial work:** reconcile permitted SOL sources with actual operations; establish an initial installation/capability, integration and data map; record sources, unknowns and owners; agree two or three business priorities and how they will be measured; inspect access and native-adoption readiness; prepare the first evidence-based forecast review. Continuing discovery, the complete rebuild, migration, stabilization and handover remain in scope. Seven days do not promise all ten proof cases or the 40-agent test. [C: `/initial_work`, `/business_priorities`, `/programme`; D: `/planning`]

Before the corresponding activity begins, record the exact source revision, environment, permitted actions and data destinations, authorizer and evidence of authority, expiry/revocation terms, execution owner, stops and resumption authority. Use the existing access, qualification and stop records. Preserve the existing component/rights inventory through `programme-records-template.json#/components`. Direction support, access, bounded qualification, ordinary-work admission and each production change retain separate decisions. [C: `/access`, `/qualification`, `/limits_stop_and_escalation`, `/separate_decisions`]

### First review — proposed 60-minute agenda

Hold at the checkpoint after the first seven calendar days from the jointly agreed programme start. The actual date, chair, participants and decision owners require agreement.

| Minutes | Review and tangible output | Existing output ID |
|---|---|---|
| 0–10 | Initial scope/dependency map, confirmed business priorities, unknowns and their owners. | `scope-and-unknowns` |
| 10–20 | Named role coverage, capability evidence, allocated capacity, customer participation and unresolved independence gaps. | `readiness-and-proof` |
| 20–35 | Exact reference/native/SOL evidence identities and boundaries; observed outcomes, valid reviews, adverse findings, unrun work and access blockers. | `readiness-and-proof` |
| 35–50 | Forecast against actual scope, dependency path, access, review/integration capacity and transition windows; uncertainties and revision triggers. | `first-forecast-review` |
| 50–60 | Record the permitted next scope, decider, evidence, limits, unresolved holds and next review. | `next-decision` |

### Conditions for the decisions

| Decision | Conditions to record |
|---|---|
| Accept the team for a bounded assignment | Three actual people are identified; their relevant contributions are supported; all required responsibilities, deputies and independent reviews have feasible capacity; limits are explicit; the customer reviewer records the outcome. Capability gaps remain visible rather than being averaged into a team score. |
| Agree Day 1 (`programme-start`) | Initial discovery scope, source/evidence access needed to begin, responsible owners, team/customer participation, start date and first checkpoint are jointly confirmed. Full proof completion is not a prerequisite for beginning authorized discovery. |
| Authorize SOL qualification (`qualification`) | Exact permitted source/data/environment, selected cases, actual runners/models, independent expected outcomes, mandatory checks/holds, resource limits, permitted fault injection, execution authority and stop/revocation terms are recorded. |
| Continue or authorize the next bounded step | The authorized decider records evidence, remaining conditions and permitted scope. Missing permission or a failed control holds the affected work; unrelated authorized work may continue within its own conditions. |
| Admit ordinary SOL work | Applicable adoption claims are supported and every mandatory functional, safety, deterministic, model, freshness, independent-review and authority condition holds. A valid negative or inconclusive experiment remains useful evidence without releasing held work. |

The review does not validate a fixed completion date merely by occurring. Record forecast changes from actual evidence, keep full scope visible and retain the weekly/material-change review cadence. [C: `/next_admission_decision`; R: `/decisions`; P: `/resultPolicy`; D: `/planning`]

## 4. Inputs and who can supply them

| Can be completed from current source/native work | Requires the user/team or customer |
|---|---|
| Public repository/revision/licence references; native source and CI observations with precise scope; actual runner/model/configuration identities; real reference-run traces, artifact digests, outcomes and documented limitations; links to the existing four source records. The attached evidence index and both CI run links have been added; add later facts only when inspected or observed. | **Team:** the three identities, role selection, personal contributions and permitted evidence, availability/allocation, deputies and conflicts. **Customer:** SOL sources and owners, business priorities/baselines, data/model permissions, integration availability, acceptance criteria and retained authorities. **Joint:** start and review dates, effort/response expectations, qualification bounds, stop/resumption arrangements and actual review/decision records. |

The accompanying JSON is a **complete review draft using the existing charter fields**, with proposed content merged into the full starting charter. It includes the access, participation, stop and separate-decision sections. Programme records remain a separate referenced record; this draft does not publish or replace the website source. Open factual fields must be populated with evidence; the proposal text in this packet is ready for review without inventing those facts.

## Source records

- **C:** [start-charter-template.json](https://orchestra-sol.pairedcat32.chatgpt.site/assets/programme/start-charter-template.json) — starting assignment, people, supplier review, qualification, first review and separate decisions.
- **R:** [programme-records-template.json](https://orchestra-sol.pairedcat32.chatgpt.site/assets/programme/programme-records-template.json) — role IDs, capacity, customer participation, data routes, component rights and decision IDs.
- **D:** [delivery-standard.json](https://orchestra-sol.pairedcat32.chatgpt.site/assets/programme/delivery-standard.json) — complete scope, planning assumptions, role combination/independence, forecast and closure rules.
- **P:** [proof-plan.json](https://orchestra-sol.pairedcat32.chatgpt.site/assets/assurance/proof-plan.json) — prerequisites, native composition, evidence/result policy and SOL proof cases.

Proposal source revision: `67bcc70cca847a06208d4a696cae563d77aec1ed`, published version 29. No Site source file was edited for this packet. The linked website may change after this record.
