# Observed execution and remaining proof

**Status:** the selected component baseline passed. The complete live native campaign is blocked and has not run. All SOL acceptance cases remain unrun.

## 1. What actually executed

The source baseline is `gustavomhss/hugr-orchestra`, default branch `dev`, revision `ff7f50b591494aba05b3c917379d633cc2d7176e`. Each qualification snapshot is exactly one commit ahead of that baseline and adds only its `.ci-run.json` request. No product or workflow implementation changed. Both existing `test-ci` workflows executed on `ubuntu-24.04`; both test jobs and their cleanup jobs concluded successfully.

| Recorded fact | Core | Maestro |
|---|---|---|
| Snapshot SHA | `d849914c420a9d0c6f651bd3da82ad48f1ef4ff3` | `5bb945e62eb68d913c212eb00027893b1def26e0` |
| Run ID | [46162430182](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162430182) | [46162432277](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162432277) |
| Test job ID | `141032496133` | `141032502440` |
| Reported tests | 39 pass; 0 fail | 18 pass; 0 fail |
| Assertions | 295 | 117 |
| Selected test files | 3 | 3 |
| Test-runner duration | 3.19 seconds | 5.56 seconds |
| Omni positive control | Not applicable; no declaring test ran, no Omni spawn or delegation | Pass; 6 declaring tests; 689 instrumented spawn operations; 0 delegated |
| Uploaded workflow artifacts | None | None |

The 57 passes describe the selected six-file scope, not repository-wide coverage. The durations are test-runner durations, not delivery throughput, semantic-evaluator latency or complete programme timing. The 689 figure is an aggregate instrumentation count, **not 689 agents**, individual process-success receipts or concurrent-agent capacity. The counter increments before the native spawn call; the real Git operations and positive control establish actual native process execution within the selected scope. Both runs used the existing request timeout of 120,000 milliseconds; it was not raised for this campaign.

Both jobs restored native binaries from the same source-keyed cache. They did not freshly compile those binaries or publish individual binary digests.

The full job logs and metadata are preserved in this packet. No extra ledger artifact was uploaded by these workflows. Their nonce-bound Omni verdicts were inspected rather than treating installation of Omni binaries as proof of use.

## 2. What the checks support

### Core / Relay

`relay-workflow-evaluator.test.ts` exercises native transition/evaluation components with real filesystem, Git and command subprocess behavior. Observed cases include replay without a second evaluation charge, invalid-position holds, signed-receipt repair, invalid-HMAC refusal, durable completion and failed-check feedback. The suite uses seeded authority and deterministic checks; it does not call a live semantic judge.

`relay-workflow-binding.test.ts` exercises publication/materialization and source bindings. Passing cases cover refusal of foreign or stale bindings, current-step source isolation and checks that remain tied to the materialized workflow. Its publication and knowledge ports use controlled fixtures.

`relay-hook-session.test.ts` exercises real hook and Session admission/drain paths. Its permission host is a harness and its LLM is fake. The test result does not establish an actual provider conversation.

### Maestro / Atlas

`v2-workflow-review.test.ts` uses actual working-tree results and source/scope matching while testing durable review behavior. Its process-spawn declaration passed. Reviewer and governance inputs are seeded; this is not a live independent reviewer deciding a real delivery.

`v2-atlas.test.ts` checks ownership/source anchors, permissions and stale-source refusals with a Genesis fixture and mocked services. It does not establish that a live Atlas was generated or refreshed during this run.

`v2-workflow-plan-e2e.test.ts` exercises planning and attribution contracts with inserted task and assistant records. It deliberately retains a hold for an unpublished workflow. Its filename does not mean a live planning-to-integration chain completed.

The immutable source links for all six files are recorded in `evidence-status.json`. These limits are part of the evidence, not reasons to discard the useful component results.

## 3. Why the complete native campaign is still blocked

The connected-device inventory reported the available MacBook offline. No reachable authorized native host or authenticated live model was established through the available surfaces. This observation does not prove whether Orchestra is installed or configured on that machine.

At the pinned source, Relay's evaluator defaults to a `stub` backend. A live evaluator is configured through `relay.judge.*`, separately from provider credentials. The unconfigured default fails a judge rule with an explicit configuration message. The actual host configuration was not observed, so this report makes no claim that a particular deployed host is using that default. [Evaluator configuration](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/relay/src/judge/config.ts).

A full governed workflow also requires a real Atlas binding, a published workflow, fresh ownership/source context, the prescribed reviewable committed delta, and an actual session-bound plan presentation and owner reply. Those runtime records do not exist for this campaign. The user's authorization to prepare and pursue the proof remains valid; it cannot be substituted for records the native product has not yet produced. [Governed playbook](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/playbooks/maestro-run/governed/SKILL.md).

There is a concrete host-placement constraint: native `package-verification` launches Bun tests in its authority directory, while the repository instructions require tests in GitHub Actions. Therefore the complete campaign must use an authorized Linux Actions host, or a supported Actions-backed gate must first exist and be demonstrated. Merely reconnecting the Mac does not resolve that constraint. [Verification implementation](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/src/v2/workflow/settlement.ts), [repository instructions](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/AGENTS.md).

## 4. What has been made ready

The attached native packet identifies the supported host/API/CLI route, preserves genuine native approval and review ordering, and supplies a campaign request that can be admitted when the prerequisites are met. It requires actual task, model, gate, review, integration and knowledge receipts, including failures and holds. It does not manufacture those receipts.

The team packet maps the proposed three-person coverage, per-item independent review, availability and customer participation into the existing charter fields. Actual names, capability evidence, dates, customer decisions and availability remain open. Repository activity has not been used to invent an individual's professional track record.

The measurement plan defines how to progress through the proposed concurrency levels of 1, 4, 12, 24 and 40, counting accepted integrated outcomes and observing rework, downstream queues, human demand and the critical path. No capacity level has been measured. The complete-SOL target is preserved; the four-month planning target inside a three-to-six-month envelope is not yet a validated forecast.

## 5. What this packet cannot close

All ten `SOL-PROOF-*` cases remain `UNRUN` and their conclusions `NOT_ASSESSED`. Authorized SOL source, representative data, independent expected outcomes and operational decisions are not available in this campaign. The proposed SOL model composition, including its mandatory overall and axis assessments, still needs an actual binding and execution; the inspected native majority ballot alone does not establish that policy. [Current SOL proof plan](https://orchestra-sol.pairedcat32.chatgpt.site/assets/assurance/proof-plan.json).

No live native loop, production outcome, 40-agent concurrency result, fraction-of-a-second model decision, rare-intervention rate, named three-person capability, or complete-SOL delivery date is certified by the 57 tests. The next technical action is to admit the prepared request to a reachable, authorized native host with real model and evaluator configuration, then retain what it actually does.
