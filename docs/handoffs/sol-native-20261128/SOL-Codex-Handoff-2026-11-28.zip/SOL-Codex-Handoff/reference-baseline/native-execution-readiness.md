# Native Orchestra execution readiness

**Status: component baseline passed; live native campaign and SOL cases UNRUN.**

Inspected source: `gustavomhss/hugr-orchestra`, default branch `dev`, pinned to
`ff7f50b591494aba05b3c917379d633cc2d7176e`. Existing Linux checks succeeded:
[core run 46162430182](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162430182)
(39 passed) and
[Maestro run 46162432277](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162432277)
(18 passed), with zero failures. These establish their component coverage only.

The inventoried Mac device is offline. Inventory does not prove an installed
Orchestra runtime. Its actual runtime configuration, authenticated models,
checkout, Atlas state, and published workflows remain unobserved. SOL access is
unavailable. No native admission, live Task, review, authorization, integration,
or Atlas completion receipt has been produced by this qualification.

## Prerequisites and boundaries

| Required | Qualification condition |
| --- | --- |
| Native host | Reachable real, non-fixture Orchestra runtime at the intended revision, with Maestro seats and workflow host; no restart of an existing runtime. Qualification uses an isolated environment. |
| Linux Actions placement | Run the complete campaign in authorized GitHub Actions Linux. The mandatory package-verification host check directly starts `process.execPath test --timeout 30000 --reporter=junit …` in the authority directory, bounded to 55 seconds and checked against JUnit contents. It does not consume `ci_run` receipts. Reconnecting the Mac is insufficient. |
| Live seat models | Actual eligible model and authorized provider connection; subsequent provider-turn evidence must prove execution. Eligibility alone proves no model call. Normal Session routing supports Anthropic Messages, OpenAI Responses, and OpenAI-compatible chat. |
| Relay judge, when used | Source defaults are `backend: "stub"`, `model: "claude-sonnet-4-6"`, `votes: 1`. An unconfigured stub fails with an explicit message. Live judge controls require explicit `relay.judge.backend: "api"`, intended model, `apiKey`, and optional `baseURL` in Orchestra configuration. These are not inherited from provider authentication or process environment; do not repurpose Claude Code OAuth. Actual configuration is unobserved. |
| Governed repository state | Clean tracked and untracked tree; nonempty committed diff from the primary remote merge-base to HEAD, at most 262144 bytes. Record actual placement and baseline. A pinned default-branch checkout alone does not satisfy the delta requirement. |
| Atlas | Matching `maestro.atlas` project configuration, verified `TERRITORY-CATALOG.json` and `OWN-SNAPSHOT.json`, fresh anchored source, and complete exact units for the scope. No nearest-unit substitution. |
| Workflow | Actual published workflow/version and bound parameters from `maestro_workflows`. `archie_draft_workflow` saves only an unpublished draft; owner publication is separate. Final host controls include `package-verification` and `cold-review`. |
| Native owner control | An authentic presentation followed by the exact direct owner reply in that Session. This is a later presentation-bound product control, not a request to reconfirm broad chat authorization. |

Sources: [root instructions](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/AGENTS.md),
[host verification](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/src/v2/workflow/settlement.ts),
[Relay judge configuration](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/relay/src/judge/config.ts),
[model routes](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/playbooks/maestro-orchestra/engines/models/SKILL.md),
[Atlas contract](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/playbooks/maestro-orchestra/tools/atlas/SKILL.md).

## Supported entry routes

Attach explicitly to a known running server; do not use an implicit daemon start.
The variables below must contain observed placement and model identities.

These observations date from 28 November 2026. Recheck applicable instructions,
runtime/source identities and active ownership before admission. If the selected
runtime or source differs from the pinned baseline, retain both identities and
requalify affected controls; these CI results do not automatically cover a newer
build.

```bash
orchestra run --attach "$ORCHESTRA_CAMPAIGN_URL" \
  --dir "$ORCHESTRA_CAMPAIGN_DIRECTORY" --agent maestro \
  --model "$ORCHESTRA_CAMPAIGN_MODEL" --format json \
  < native-campaign-request.txt
```

Use `--session <returned-session-id>` to resume. Server authentication supports
`ORCHESTRA_SERVER_PASSWORD` and an optional username; keep secrets out of command
logs. `--auto` cannot approve owner-reply controls. For an interactive owner step:

```bash
orchestra attach "$ORCHESTRA_CAMPAIGN_URL" \
  --dir "$ORCHESTRA_CAMPAIGN_DIRECTORY" \
  --session "$ORCHESTRA_CAMPAIGN_SESSION"
```

Do not use `run --agent archie`: the CLI refuses a subagent as primary and falls
back. Maestro dispatches native `task` with `subagent_type: "archie"`.

| HTTP route | Contract |
| --- | --- |
| `POST /api/model/execution?location[directory]=<absolute-path>` | `{"context":{"type":"draft","agentID":"maestro"},"model":{"providerID":"<actual-provider>","id":"<actual-model>"}}`; returns ready, unsupported, or unavailable without model execution. |
| `POST /api/session` | `{"agent":"maestro","model":{"providerID":"<actual-provider>","id":"<actual-model>"},"location":{"directory":"<actual-path>"}}`; use the returned ID. |
| `POST /api/session/:sessionID/prompt` | `{"prompt":{"text":"<request>"}}`; durably admits input and schedules execution unless `resume: false`. Admission is not completion. |
| `POST /api/session/:sessionID/wait` | Waits for the Session drain to become idle. |
| `GET /api/session/:sessionID/history` or `/event` | Durable history or event stream for evidence. |

Sources: [CLI definitions](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/apps/cli/src/commands/commands.ts),
[run behavior](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/apps/cli/src/commands/handlers/run.ts),
[model API](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/packages/protocol/src/groups/model.ts),
[eligibility schema](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/packages/schema/src/model-execution.ts),
[Session API](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/packages/protocol/src/groups/session.ts).

## Genuine admission and approval order

Once prerequisites exist, use the proposed request file. The smallest live
qualification is a real Maestro-to-archie read-only Task and attributed return.
It does not prove worker, review, integration, or SOL execution.

For the governed workflow:

1. Load `maestro-run-governed` and `frame-request`; record actual admission with
   `methodVersion: "admit-request-v1"`. Runtime computes the outcome.
2. Read catalog; record plan revision with actual archie upstream attribution and
   published workflow binding; run permitted baseline checks; record context.
3. Record validation with observed checks, exact work card, and exact worker brief.
   Obtain the native plan-stage `maestro_request_review` receipt.
4. Before dispatch, establish the required native `relay-arm` as the workflow
   catalog directs: actual Session and label, without a hand-authored chain.
   On APPROVE, call `maestro_present_approval` and stop at its real presentation.
5. After the owner's direct `approve` or `aprovo`, record approval, grant
   authorization, and dispatch the exact approved Task in the required same turn.
   Do not synthesize the reply or reuse unrelated approval.
6. Require actual Relay gate evidence. Keep worker results uncommitted until the
   workflow settles.
7. On `WORKFLOW_CODE_REVIEW_REQUIRED`, request code-stage lucy review. Resume with
   the real task ID and byte-identical approved input; retain findings and retries.
8. Verify actual delta and Actions evidence; integrate only through the authorized
   route and retain its receipt. For board work, use the record/queue flow. Atlas
   writes must use supported doors and retain identity/freshness; memory is not
   automatic promotion to proven knowledge.

Sources: [governed procedure](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/playbooks/maestro-run/governed/SKILL.md),
[workflow catalog and arm contract](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/src/v2/tools/workflows.ts),
[verification and integration](https://github.com/gustavomhss/hugr-orchestra/blob/ff7f50b591494aba05b3c917379d633cc2d7176e/modules/maestro/coordination/playbooks/maestro-run/loop/SKILL.md).

## What remains possible without a live model

The successful pinned Linux component checks are legitimate preparatory evidence.
A genuine ephemeral native host may additionally return a readiness/refusal
result from `model.execution`; that is not a provider turn. Fixture-authored
messages, forced judge verdicts, injected reviews, and stub providers cannot fill
the live receipt index. Keep all live campaign and SOL cases UNRUN until their
actual executions exist. No duplicate test logs are included here.
