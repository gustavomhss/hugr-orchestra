# Capacity and evidence measurement plan

**Prospective plan; no capacity result recorded.** The outcome remains the complete SOL, including integration, migration, stabilization and handover. Three-engineer availability is unverified. The four-month target and three-to-six-month envelope remain planning assumptions, subject to scope, dependency and capacity evidence. This plan defines how to obtain that evidence. [D: `/planning`; P: `/capacityLadder`]

## 1. Establish native proof before measuring scale

First establish a version-bound native execution: independent expected outcomes, actual runners, the frozen required model panel, effective mandatory checks, independent review, integration and preserved evidence. Demonstrate the failure, recovery and freshness controls applicable to the intended workload. Source inspection or an unrelated successful CI job cannot replace this trace. An optional later .NET/React supplier exercise would qualify only its observed scope; no external reference project was selected here. SOL adoption requires permitted SOL-specific sources, data, environments and acceptance. [P: `/executionPrerequisites`, cases `SOL-PROOF-01`–`SOL-PROOF-07`]

The two selected `test-ci` runs completed successfully: **Core 39 passed, Maestro 18 passed; zero failures**. These are component/integration results, not a capacity measurement. The snapshots are:

| Request | Source identity |
|---|---|
| Shared pinned parent | `ff7f50b591494aba05b3c917379d633cc2d7176e` |
| Core request snapshot | `d849914c420a9d0c6f651bd3da82ad48f1ef4ff3` |
| Maestro request snapshot | `5bb945e62eb68d913c212eb00027893b1def26e0` |

See `EXECUTION-REPORT.md` and `evidence-status.json` for the actual runs, exact job scope, preserved logs and fixture limitations. Neither workflow uploaded separate artifacts. The results support only the behavior those checks exercised.

## 2. Define the denominator and useful measurements

Version the complete-SOL coverage register and record unresolved areas. An unknown total remains unknown; accepted items from one batch cannot establish programme percentage complete. Pre-register a representative mix of work classes and define each accepted integrated capability before counting it. Count the same capability once, even when multiple agents, retries or commits contribute. [D: `/closure`; R: `/coverage`]

| Measure | Record and interpretation |
|---|---|
| Accepted flow | Distinct integrated capabilities with current checks and acceptance per observation window, separated by work class; retain rejected, incomplete and blocked work. |
| Rework and first-pass yield | Corrections, repeated evaluations, invalidated evidence and human effort; first-pass accepted units divided by all units entering the declared acceptance cohort. |
| Review and integration queues | Arrivals, completions, backlog, oldest age, waiting-time distribution and downstream drain time; include owner holds and unavailable reviewers. |
| End-to-end time | Ready-to-accepted elapsed time, active work and waiting separately; distinguish model response, complete gate and complete delivery cycle. |
| Quality and recovery | Defects found during and after acceptance, false acceptance/rejection where labelled cases exist, failed mandatory controls, uncertain effects, safe holds and productive resumption. |
| Resource and human demand | Actual concurrency over time, model requests/tokens, compute and CI use, intervention count/duration, implementation, review, coordination and customer decision effort. |

Report cohort size, observation duration, failures, timeouts, retries, skips, cache hits, exclusions and missing observations. Retain all attempts in resource/rework denominators; explain differing metric denominators explicitly. [P: `/runRecordTemplate/measurements`, `SOL-PROOF-08`]

## 3. Increase concurrency through measured stages

Use the proposed ladder **1 → 4 → 12 → 24 → 40** concurrent runs. These numbers are proposed experiment levels, not established capacity. At one run, establish the complete acceptance cycle and instrumentation. At each subsequent level, preserve the declared work mix and evaluate accepted output, quality, human demand and queue behavior.

Before running, the responsible owners must ratify numerical quality, queue, resource and intervention limits, minimum observation duration and accepted sample size. The window must include complete acceptance cycles and downstream queue drain. Advance only when the lower level's supported capacity claim and applicable admission conditions hold. An accepted evidence record alone does not authorize increased load. Stop or reduce admission when a limit fails or queues cannot drain; retain the failed level and limiting stage. A demonstrated 40-run level supports that observed configuration and workload. Higher levels require their own measurements. [P: `/capacityLadder`, `SOL-PROOF-08`]

## 4. Preserve conditions and independent interpretation

Freeze and record source/candidate/base identities, dependencies, test data, runners, prompts/models, resource allocation and configuration digests. Bind each observation to the actual `executionTopology`: processes, role/process limits, shared queues, candidate ownership and integration authority. Demonstrate exclusivity across the observed scope; a process-local lock cannot establish multi-process exclusivity. Material changes reopen affected proofs.

Under-load fault injection requires its own bounded authorization. Include evaluator unavailability, failed integration and interrupted execution where permitted; record unexercised cases. Preserve required holds and current evidence through recovery. Keep `executionStatus`, `evidenceReview` and `claimConclusion` separate. Valid negative or inconclusive evidence is retained without admitting held work. [P: `/resultPolicy`, `SOL-PROOF-08`]

## 5. Convert observations into a conditional forecast

Update the forecast from remaining obligations, measured accepted flow by work class, rework, review/integration bottlenecks and the actual critical dependency path. Include customer decisions, access, external integrations, migration windows, stabilization and receiving capacity. Confirm the three engineers' real allocation before treating it as available capacity. Do not multiply task rate by agent count or preserve a date by reducing scope.

Any coordination-advantage claim needs a separate pre-agreed matched comparison with equivalent outcomes, resources and independent acceptance; include human work and uncontrolled differences. Review the programme forecast at the initial-discovery checkpoint, weekly and after material changes. Record the resulting completion range and uncertainty rather than an unconditional date. [P: `SOL-PROOF-09`; D: `/planning`]

**Sources:** P = [proof-plan.json](https://orchestra-sol.pairedcat32.chatgpt.site/assets/assurance/proof-plan.json); D = [delivery-standard.json](https://orchestra-sol.pairedcat32.chatgpt.site/assets/programme/delivery-standard.json); R = [programme-records-template.json](https://orchestra-sol.pairedcat32.chatgpt.site/assets/programme/programme-records-template.json). CI identities and completed outcomes above were verified from the actual GitHub run metadata and job logs retained in this packet. Capacity results remain unmeasured.
