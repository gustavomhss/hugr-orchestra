# SOL — execution and qualification packet

**28 November 2026 · Evidence collected; live native campaign not yet run.**

The intended delivery remains **the complete SOL**, including integration, migration, stabilization, ownership and handover. This packet advances the evidence and starting agreement for that delivery. It contains no price, customer approval, staffing verification or claim that SOL has been rebuilt.

## What changed

Two isolated Linux GitHub Actions runs executed six selected test files on the same Orchestra source revision. **57 tests passed; zero failed.** Their requests, full job logs, source comparisons and final run/job records are included. A separate assistant review checks the interpretation of that evidence; it is not native Lucy review or customer acceptance.

| Evidence | Observed result | Practical meaning |
|---|---|---|
| Core / Relay controls | 39 tests passed; 0 failed | Selected transition, signed-record, source-binding and Session-hook behavior passed in the test harness. |
| Maestro / Atlas controls | 18 tests passed; 0 failed | Selected review, ownership/freshness and planning-attribution behavior passed. Native process-spawn positive control also passed. |
| Live model-driven Orchestra campaign | Not run; host/model prerequisites unresolved | No claim that Maestro, planning, workers, Relay judges and independent review completed a live chain. |
| SOL acceptance and capacity | All ten SOL proof cases remain UNRUN | No SOL access or accepted 40-agent measurement has been established. |
| Three-engineer team | Coverage proposed; people/capacity unverified | Responsibilities and the evidence needed to qualify the actual people are ready for review. |

## Read this packet

1. **EXECUTION-REPORT.md** — exact observations, their limits and what is still blocking the live campaign.
2. **native-execution-readiness.md** and **native-campaign-request.txt** — the supported native route, prerequisites, genuine approval sequence and request ready for admission when the host is available.
3. **sol-team-qualification-and-start-packet.md** — responsibilities, individual evidence, customer participation and the first-review agenda.
4. **sol-start-charter-review-draft.json** — a complete review draft based on the existing charter. New proposed content and observed component evidence are included; unknown people, dates, permissions and decisions remain open.
5. **capacity-and-evidence-measurement-plan.md** — how to measure accepted output, quality, queues and critical-path constraints before making a capacity or date claim.
6. **component-evidence-review.md** — independent assistant review of the component evidence and its interpretation.

The `evidence/` directories retain the actual CI requests, logs, run/job metadata and source comparisons. `evidence-status.json` states the evidence boundary in machine-readable form. `SHA256SUMS.txt` identifies the packaged file bytes; it is an integrity index, not an approval or runtime signature.

## The next usable inputs

The first technical dependency is an authorized, reachable native host running inside Linux GitHub Actions, with an actual model connection and the intended Relay evaluator configuration. The current governed verification code runs its tests in the host's worktree, so a reconnected personal computer alone does not meet this repository's Actions-only test instruction. An existing supported Actions-backed verification adapter would also need to be evidenced before use; none was established in this investigation.

The first team dependency is the identity and real availability of the three proposed engineers, together with attributable delivery evidence. Customer SOL sources, operational owners, access permissions and expected business outcomes remain needed for SOL-specific work.

Campaign preparation is already authorized by the user's instruction. A later owner approval inside Orchestra is required only for the exact plan that the native product presents. No such presentation has occurred, and this packet does not impersonate that approval.

## Source identity

- Native source: [gustavomhss/hugr-orchestra at ff7f50b](https://github.com/gustavomhss/hugr-orchestra/tree/ff7f50b591494aba05b3c917379d633cc2d7176e).
- Core run: [46162430182](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162430182).
- Maestro run: [46162432277](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162432277).
- Proposal: [Orchestra / SOL](https://orchestra-sol.pairedcat32.chatgpt.site). The proposal checkout used for this packet was source revision `67bcc70cca847a06208d4a696cae563d77aec1ed`, published version 29. Website links are navigational and may later change; the CI evidence is pinned separately.

No product source, existing branch, active Genesis work, website or video was changed by this qualification exercise. Only two temporary CI-request snapshots were added; the existing workflow completed their cleanup.
