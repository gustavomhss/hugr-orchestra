# SOL / Orchestra — Codex handoff

**Prepared 28 November 2026. Owner: Gustavo. Returning coordinator: this ChatGPT conversation.**

## Use this package

Attach this ZIP in Codex, or extract it somewhere Codex can read. Paste the contents of `01-PASTE-IN-CODEX.txt`. The prompt is self-contained enough to begin from GitHub if the attachment is unavailable. The paths inside this package are relative; paths from the original ChatGPT workspace are not access instructions for Codex.

Codex's immediate assignment is to establish a real native Orchestra qualification run with evidence across the complete requested chain. The programme target remains the **whole SOL rebuild**, including integration, migration, stabilization, ownership and handover. No SOL access or implementation is implied by this handoff.

## Read in this order

| File | Purpose |
|---|---|
| `01-PASTE-IN-CODEX.txt` | Copyable execution mandate. |
| `02-CODEX-HANDOFF.md` | Scope, supported route, source drift, exact constraints, prerequisites and completion criteria. |
| `03-RESUME-CONTEXT.json` | Machine-readable starting state and source/evidence identities. |
| `04-CODEX-RETURN-TEMPLATE.json` | Empty return structure. Copy to `receipt-index.json` and fill only observed facts. |
| `reference-baseline/` | The previous execution packet, preserved byte-for-byte: reports, charter, request, CI logs and independent reviews. |
| `observations/` | Source-drift and open-PR snapshots taken while preparing this handoff. Refresh them before work. |
| `05-HANDOFF-REVIEW.md` | Independent review and the resolutions incorporated in this handoff. |

The outer `SHA256SUMS.txt` covers this package. The baseline folder also retains its original integrity index. These hashes identify files; they do not establish acceptance or authority.

## Current position

- **Observed:** 57 selected component/integration tests passed in two Linux Actions runs at native revision `ff7f50b591494aba05b3c917379d633cc2d7176e`.
- **New observation:** `dev` was `4f2aaca8d4420bf00e8b665add3d6c21f0b8a226` at 2026-11-28 16:12:14 UTC, 94 commits ahead. The existing 57 passes do not certify that newer source.
- **Not executed:** the live native campaign and all ten SOL proof cases.
- **Not verified:** three-engineer identities/capacity, 40-agent capacity and the proposed delivery forecast.

The earlier offline-device observation applies to the access available in ChatGPT at that time. Codex must assess its own actual access; do not inherit that observation as a permanent blocker.

## Return to ChatGPT

Codex should produce `CODEX-RETURN.md`, `receipt-index.json`, a sanitized `evidence/` directory and `SHA256SUMS.txt`, packaged as `CODEX-SOL-RETURN.zip`. Preserve durable GitHub/artifact links and exact native IDs. On return, Gustavo can attach that package here and say: **“O Codex terminou; continua a partir do CODEX-RETURN.”**

If the product reaches an authentic owner-approval step, Codex must present that specific step to Gustavo, including how to reach the correct Session. It must preserve or describe a supported safe resume route. An approval pause is not a completed qualification.

The returning ChatGPT session will verify the returned state and evidence, resume remaining work, and then decide which new evidence belongs in the proposal. The website and videos stay with this ChatGPT workstream.
