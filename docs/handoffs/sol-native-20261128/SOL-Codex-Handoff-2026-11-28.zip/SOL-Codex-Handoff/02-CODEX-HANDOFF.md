# Native Orchestra qualification — execution handoff

## 1. Assignment and authority

Gustavo asked this ChatGPT session to organize the completed work and hand it to Codex, which may have access to the native runtime and credentials unavailable in ChatGPT. Carry the authorized campaign forward autonomously within the constraints below. This is a continuation, not a request to restart discovery or rewrite the proposal.

**Immediate result:** a real, meaningful native qualification case that traverses planning, execution, Relay evaluation, independent native review, integration and source-bound Atlas evidence. Choose a bounded case supported by available materials; do not substitute a fixture transcript for any live stage. A read-only planning return is an intermediate milestone, not completion of this assignment.

**Programme outcome:** the complete SOL, including integration, migration, stabilization, ownership and handover. No MVP or partial-SOL delivery replaces it. The current three-to-six-month envelope and four-month central target remain unvalidated planning assumptions. Native qualification is evidence toward that programme, not a claim that SOL has been delivered.

No SOL source/data access, three-person roster or live native configuration was available to the preceding session. Inspect what is actually available to Codex. Do not infer authorization to access customer resources from this handoff alone. No price, website/video edit, customer communication, new commercial subscription or production cutover is part of the immediate assignment.

## 2. Read the source and separate versions

| Identity | Value and meaning |
|---|---|
| Canonical repository | `gustavomhss/hugr-orchestra`; default branch `dev`. Do not use Orchestra-SF. |
| Tested native baseline | `ff7f50b591494aba05b3c917379d633cc2d7176e`; Git tree `ab5b606a279dd052f87d9c778a631209d5afc56d`. |
| Core CI snapshot | `d849914c420a9d0c6f651bd3da82ad48f1ef4ff3`; only `.ci-run.json` added. |
| Maestro CI snapshot | `5bb945e62eb68d913c212eb00027893b1def26e0`; only `.ci-run.json` added. |
| Newer observed dev | `4f2aaca8d4420bf00e8b665add3d6c21f0b8a226`, observed 2026-11-28 16:12:14 UTC. Comparison reports 94 commits and 138 changed files beyond the tested baseline, including Omni/core and native review changes. |
| Actual campaign source | **To be selected and recorded by Codex after refreshing the remote and ownership.** Preserve both source and runtime build identities. |

The root `AGENTS.md` at the newer observed revision was read for this handoff. Re-read it and every applicable scoped instruction at your selected revision. The prior baseline remains useful historical evidence, but it does not automatically qualify newer code. Reuse current matching evidence where applicable; run focused new checks for concrete affected risks. Do not repeat all historical tests solely to reproduce their numbers.

Sources: [tested baseline](https://github.com/gustavomhss/hugr-orchestra/tree/ff7f50b591494aba05b3c917379d633cc2d7176e), [observed dev](https://github.com/gustavomhss/hugr-orchestra/tree/4f2aaca8d4420bf00e8b665add3d6c21f0b8a226), [comparison](https://github.com/gustavomhss/hugr-orchestra/compare/ff7f50b591494aba05b3c917379d633cc2d7176e...4f2aaca8d4420bf00e8b665add3d6c21f0b8a226), [instructions at that revision](https://github.com/gustavomhss/hugr-orchestra/blob/4f2aaca8d4420bf00e8b665add3d6c21f0b8a226/AGENTS.md).

## 3. Completed work to preserve

| Run | Observed selected result | Boundary |
|---|---|---|
| [Core 46162430182](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162430182), job `141032496133` | 39 pass, 0 fail, 295 assertions across three files. | Native transition, source-binding and Session-hook components; fixture participants. Omni positive control explicitly not applicable. |
| [Maestro 46162432277](https://github.com/gustavomhss/hugr-orchestra/actions/runs/46162432277), job `141032502440` | 18 pass, 0 fail, 117 assertions across three files. | Review, Own/Atlas and planning-attribution components. Omni positive control passed, reporting 689 aggregate instrumented spawn operations and zero delegation. |

Both runs used Linux `ubuntu-24.04`; both test steps and workflows succeeded. The 689 counter is not an agent count, concurrency level or independent receipt for each successfully completed OS process. The native binaries came from the source-keyed cache. The runs did not make a live model-driven native chain or upload separate workflow artifacts. Full logs and metadata are retained in `reference-baseline/evidence/`.

The historical reports, complete starting-charter draft, proposed three-engineer coverage, capacity plan and two independent assistant reviews are preserved under `reference-baseline/`. They contain no native Lucy approval or customer acceptance. All ten `SOL-PROOF-*` cases remain `UNRUN` / `NOT_ASSESSED`.

## 4. Protect concurrent work

Use an isolated checkout/worktree and your own branch from the appropriate current `dev`. Suggested branch: `sol-native-proof`; it has **not** been created by ChatGPT. If that name exists, inspect ownership and select a different permitted name. Ordinary branch names have at most three hyphen-separated words; temporary CI request naming follows the shipped CI tool.

Inspect open PRs and live worktrees before changing shared paths. The handoff observed active Genesis recovery and Atlas memory work (including PRs 1291, 1587 and 1588), Lucy work (1666, 1667, 1679 and related work), and Activity/Omni work. The recorded PR list is a snapshot, not a claim that those items remain open when you start. The known Genesis resume workstreams include `genesis-core-resume`, `genesis-interfaces-resume`, `genesis-s3-resume`, `genesis-runtime-resume` and `genesis-knowledge-resume`; refresh their status rather than taking them over.

No dedicated product branch, native Session, live model execution, open qualification PR or integration was produced by the preceding campaign. The two CI-request commits are evidence snapshots, not a work branch to develop on.

## 5. Establish a real execution environment

The offline-device finding is historical and limited to ChatGPT's then-available inventory. Inspect Codex's actual supported connections, runtime, repository placement and authorization. Prefer GitHub MCP for repository operations. Use authorized local or native capabilities when needed; Desktop Commander is not a prerequisite. Read configuration through supported routes and report identities/presence without exposing credential values.

All tests must run **in GitHub Actions, on Linux**. A normal Linux workstation is not an Actions runner. The earlier native `package-verification` directly launches tests in its authority directory; therefore place the full native campaign in authorized Linux Actions, unless current source has acquired a supported Actions-backed verification route that you can demonstrate. Never make a gate appear compliant by changing environment flags or bypassing the local-test guard. Non-test preparation, inspection, typechecks and guards follow current repository instructions.

Before using an ephemeral Actions host, establish how genuine owner approval can reach the same native Session and how durable evidence survives a pause. Record host lifetime, Session persistence, supported attachment/resume, expected expiry and cleanup ownership. Do not expose an unauthenticated server or copy credentials between unrelated authentication systems to make attachment work. If the environment cannot preserve the required state, resolve that supported route or return a concrete HOLD before dispatch.

The inspected Relay evaluator defaults to `stub`; an unconfigured stub fails judge rules. Actual evaluation uses explicit `relay.judge` configuration and a real intended model/API credential. Seat/provider authentication is separate. A valid Claude Code login or OAuth token must not be relabelled as a Relay API key. Readiness and successful prompt admission do not prove a provider turn.

Keep the actual native policy separate from the proposed SOL composition. The proposal requires all mandatory deterministic conditions, every required model's overall assessment and all five acceptance-axis assessments, current evidence, applicable independent review and authority. The inspected native majority ballot alone does not establish that composition. Record the policy actually executed and any gap; do not weaken a requirement or claim SOL policy qualification from a native-only result.

Current-source entry points to inspect:

- `modules/relay/src/judge/config.ts` — evaluator configuration and failure behavior.
- `modules/maestro/coordination/src/v2/workflow/settlement.ts` — host checks, review holds and package verification.
- `modules/maestro/coordination/src/v2/tools/workflows.ts` — published workflow and real `relay-arm` contract.
- `modules/maestro/coordination/playbooks/maestro-run/governed/SKILL.md` — admission, exact approval and authorization order.
- `modules/maestro/coordination/playbooks/maestro-orchestra/tools/atlas/SKILL.md` — exact units, source identities and freshness.
- `apps/cli/src/commands/commands.ts` and `apps/cli/src/commands/handlers/run.ts` — supported attach/run behavior.
- `packages/protocol/src/groups/session.ts` and `packages/protocol/src/groups/model.ts` — current Session/model contracts.

The historical CLI/API forms are in `reference-baseline/native-execution-readiness.md`. Revalidate against selected source. Explicitly attach to a known running host; do not silently start/restart an existing desktop or daemon. Maestro dispatches the native planning seat as a task; starting that subagent as the primary CLI agent is not equivalent.

## 6. Execute the full bounded native case

1. **Record readiness and scope.** Capture current source/runtime/host/configuration identities, authorized source and data, exact worktree, allowed paths and expected outcomes. Have Maestro obtain a real attributed read-only planning result. Select a useful bounded case on permitted material with an observable success condition and relevant negative control. Do not invent a SOL business scenario or choose an irrelevant toy product.
2. **Satisfy the real preconditions.** Inspect the published workflow/version/parameters, Atlas catalog and Own freshness, complete exact units and current governed diff requirement. The inspected contract required a clean tree and a nonempty committed delta of at most 262144 bytes before admission. That is the reviewable candidate/base; later worker edits remain uncommitted until settlement. Do not create an empty or irrelevant commit or prematurely commit worker output to satisfy a guard. A missing legitimate candidate or publication is a genuine HOLD.
3. **Follow native admission and review.** Use actual parent/child Task and Session records, upstream author attribution, catalog/context, plan revision, validation and native plan-stage review. Create the required native `relay-arm` with actual returned Session/label bindings in the order required by current source. Do not hand-author its chain or invent publication.
4. **Present the real plan.** The broad campaign is authorized. The native product may require Gustavo's exact direct reply to a specific presentation in the correct Session. Stop at that real presentation only when the control is reached; provide the actual Session, plan/input hashes and safe reply/resume instructions. Never issue `approve` or `aprovo` on his behalf or reuse an unrelated chat approval. If the host has expired, use the supported recovery/re-presentation path rather than fabricating continuity.
5. **Execute and retain evidence.** Dispatch the bounded worker using the approved input byte-for-byte when required. Preserve real model events, check attempts, Relay results, failure feedback, retry limits and expected negative-control holds. Obtain native code-stage review and resume the actual Task with identical bound input where the product requires it.
6. **Close through integration and knowledge.** Verify the actual delta and scope, applicable current Linux Actions checks, independent native review, authorized integration and its real receipt. Use supported Atlas write/read doors for justified source-bound knowledge or memory, verify freshness and an actual consumer read. A memory append is not automatic promotion to proven knowledge; report exactly which kind of evidence exists.
7. **Audit the result with fresh context.** Have an independent reviewer reconcile raw evidence, source bindings, scope, outcome, negative control, integration and remaining limits. This evidence audit supplements the required native review; it does not impersonate it.

If a necessary in-scope implementation defect is found, make the smallest adequate fix on your own branch, follow current guards and focused Linux CI, obtain independent review, and use the already-authorized PR/integration route. Respect actual repository authority; do not bypass required review or enable automatic merging to evade it. Required review or integration still pending means the affected work is partial. Do not expand into completing unrelated Genesis/Lucy features.

## 7. Team and scale boundaries

Use the existing charter and role register. Record attributable team identities, capability evidence and actual availability only when available from authorized sources. Leave unknowns open and name the missing input; they do not prevent useful technical preparation.

The proposed concurrency ladder is 1, 4, 12, 24 and 40. Its numerical limits, observation windows and sample sizes are not ratified in the current packet. First prove the complete native path. Record capacity readiness in the return. Any subsequent load measurement is a distinct bounded phase, permitted only when its representative workload, execution topology, operating limits and authority are actually bound; it is not required to return a completed native qualification. Measure accepted integrated output, queues, rework, human intervention and resource demand. Model latency and task count alone cannot validate the delivery forecast. A successful native case qualifies only its observed execution; capacity requires its own measurements.

## 8. Completion and return

Use `COMPLETE_NATIVE_QUALIFICATION` only if the chosen case has a real complete chain, current source/configuration bindings, measurable accepted output, an observed relevant negative control, required native reviews, authorized integration and verified Atlas evidence. Keep SOL qualification, team qualification and capacity conclusions separate. A valid failed experiment remains evidence but is not complete successful qualification.

Other outcomes are `PARTIAL`, `HOLD`, `WAITING_OWNER_APPROVAL` or `FAILED`. Explain the exact reason, last confirmed native stage, failed operation, retained evidence, remaining useful work and smallest external input. Continue independent authorized preparation while an affected path is blocked. Do not fabricate later records or return a generic plan as completed execution.

Return these files in **`CODEX-SOL-RETURN.zip`**:

- **`CODEX-RETURN.md`**: result first; chosen case and acceptance; real actions/results; source and runtime identities; changed files/commits/PRs; CI evidence; native stage coverage; failures/holds; remaining people/access/scale facts; exact next action for ChatGPT.
- **`receipt-index.json`**: copy the provided template and fill actual values. Preserve nulls and `UNRUN` where no record exists. Distinguish expected negative-control failure from an unexpected acceptance failure.
- **`evidence/`**: sanitized native event/history exports, approved work card/brief, source/configuration bindings, check/review/integration/Atlas outputs and logs. Retain failed attempts and unrun cases. Use durable URLs and SHA-256 digests where available; a runner's temporary path alone is not a durable handoff.
- **`SHA256SUMS.txt`**: final evidence/package file hashes. Do not hash secret credential values as a substitute for redaction.

At an owner pause, return the authentic presentation, actual Session/Task and last event IDs, active/expired host state, state persistence, expiration, exact safe resume command and the action Gustavo must take. Do not claim an old approval or incomplete chain survived an expired host without evidence.

Never place raw credentials, private customer data or personal team details in a public GitHub artifact. Use permitted destinations and annotate necessary redactions. Preserve enough non-secret identifiers to verify what actually ran. Do not alter the historical baseline to make the new result look stronger.

## 9. What ChatGPT resumes afterward

Gustavo will return the Codex package here. ChatGPT will verify source identity and actual receipts, continue any unfinished authorized work, reconcile team/forecast evidence and update the proposal with supported claims. Until then, the current website and the published video collection are outside this Codex assignment.
