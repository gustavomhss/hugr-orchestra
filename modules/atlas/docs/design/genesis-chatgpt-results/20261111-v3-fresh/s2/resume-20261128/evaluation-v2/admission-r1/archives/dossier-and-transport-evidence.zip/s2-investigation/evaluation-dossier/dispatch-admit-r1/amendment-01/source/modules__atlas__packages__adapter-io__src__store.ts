import { registerDiskStoreIdentity } from "./store-evaluation-identity.js"
import {
  closeSync,
  constants as fsConstants,
  existsSync,
  fstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  writeFileSync,
} from "node:fs"
import { dirname, join } from "node:path"
import type { Hash } from "@atlas/contracts"
import { asHash, id } from "@atlas/kernel"
import type { CasObject, StoreApi } from "@atlas/kernel"
import { emptyStore } from "@atlas/knowledge"
import type { StoreProjection } from "@atlas/knowledge"
import { isContainedIn } from "./containment.js"
import { readSidecarSet } from "./sidecar.js"
import type { SidecarTrust } from "./store-provenance.js"
import { commitSidecar, persistSidecar } from "./sidecar-commit.js"
import type { CommitDecision, CommitResult, SidecarBase, SidecarCtx } from "./sidecar.js"
export type CasPath = string
const EMPTY: Hash = asHash("")
const PROJECTION_BASE: SidecarBase = "projection"
const STAGING_BASE: SidecarBase = "staging"
const MAX_CAS_BYTES = 64 * 1024 * 1024
const O_READ_NO_SYMLINK = fsConstants.O_RDONLY | (fsConstants.O_NOFOLLOW ?? 0) | (fsConstants.O_NONBLOCK ?? 0)
function valuePath(casPath: CasPath, h: Hash): string {
  return join(casPath, h.slice(0, 2), h)
}
function sidecarDir(casPath: CasPath): string {
  return dirname(casPath)
}
function ctxFor(
  casPath: CasPath,
  base: SidecarBase,
  headSha: (() => string | undefined) | undefined,
  put: (o: unknown) => unknown,
  trusted: SidecarTrust | undefined,
): SidecarCtx {
  return { dir: sidecarDir(casPath), base, headSha, put, trusted }
}
export interface DiskStore extends StoreApi {
  /**
   * THE governed write door onto the projection: read → decide → publish, ATOMIC against every other
   * writer. `decide` receives the freshly-read projection and returns the whole decision; on a lost race it
   * is RE-RUN from scratch against the new snapshot, so it MUST be pure (no writes, no clock, no random) and
   * it MUST contain the gates, not just the state change.
   *
   * The gates are inside `decide` for a security reason, not an aesthetic one: the target-derived gates
   * (`governed-emit-incumbent.ts`) resolve authority from the incumbent ROW on this snapshot — its `scope`
   * and `tier`, with the ADR-0007 fallback to the authenticated bytes for a carrier-less row. Re-publishing
   * a decision computed against a STALE snapshot would apply a write that cleared its gates against a
   * projection that no longer exists: the confused deputy those gates were written to close, re-entered
   * through the back door of a retry, and reachable by ordinary contention rather than by an attack.
   *
   * `settled:false` is a VISIBLE refusal (contended, or an unreadable sidecar), never a silent no-op.
   */
  commitProjection<T>(decide: (projection: StoreProjection) => CommitDecision<T>): CommitResult<T>
  /** The SAME primitive over the candidate sidecar (ADR-0008) — one implementation, different file, so the
   *  two cannot drift in atomicity any more than they can in totality. THE ONLY staging door: `mine` adopted
   *  it (`cli/src/mine.ts`), and the weaker `persistStaging`/`loadStaging` pair it replaced has been deleted
   *  (see the file header). A caller that wants only to READ the staged head passes a decision that returns
   *  no `next` — `commitStaging((p) => ({ out: p }))` — which reads the snapshot and writes nothing. */
  commitStaging<T>(decide: (projection: StoreProjection) => CommitDecision<T>): CommitResult<T>
  /** Persist the whole `StoreProjection` durably (the mutable sidecar, NOT content-addressed).
   *  UNCONDITIONAL, therefore last-writer-wins BY DEFINITION — it carries no decision to re-run. It is
   *  atomic (no reader ever sees a prefix) but it is NOT the concurrency-safe door: a read-modify-write MUST
   *  go through `commitProjection`. THROWS rather than silently doing nothing on exhaustion. */
  persistProjection(projection: StoreProjection): void
  /** Read the durable `StoreProjection` back; `undefined` when none has been persisted yet. */
  loadProjection(): StoreProjection | undefined
}
export function createDiskStore(
  casPath: CasPath,
  headSha?: () => string | undefined,
  trusted?: SidecarTrust,
): DiskStore {
  // Self-referential so the sidecar commit can call THIS store's `put` (the CAS-before-projection ordering
  // invariant). The methods only run after the literal is bound, so the reference is never in the TDZ.
  const store: DiskStore = {
    put(obj: CasObject): Hash {
      // TWO serializations, and BOTH must be able to refuse. `id` runs the canonical preimage
      // (`canonical.ts`); `JSON.stringify` produces the stored bytes. They do NOT accept the same inputs,
      // and the gap between them is where this door used to break its own contract.
      //
      // MEASURED DEFECT (the `JSON.stringify` call used to sit BELOW this try, unguarded): KERNEL-8 excludes
      // the mutable side-indexes `grounding` / `status` / `freshness` from the preimage at EVERY level, so a
      // canonical-form violation parked in one of them never reaches the canonicalizer. `id` SUCCEEDS, this
      // catch never fires, and control fell through to a bare `JSON.stringify` that throws a raw engine
      // `TypeError` on a bigint or a cycle — out of a method whose own comment promised "never throw".
      // `grounding` is on EVERY `GroundedFact` and `governed-emit.ts` puts the WHOLE fact here, so the throw
      // came straight back out of `atlas-emit`; `@atlas/tools` `fault.ts` then files a `TypeError` as
      // `internal-fault` ("a defect in Atlas, not in your arguments") for bytes that were entirely the
      // caller's. Reachable from an in-process embedder, which gate 0 of `governed-emit.ts` names as in the
      // threat model in as many words. Both serializations are inside the try now, so the door has ONE
      // answer for "these bytes cannot be stored": the honest empty handle.
      let h: Hash
      let bytes: string
      try {
        // canonicalize → hash via the sealed seam; the caller never supplies the key (KERNEL-1/2a).
        h = id(obj)
        // the STORED bytes, produced BEFORE any directory is made — so a value that cannot serialize
        // leaves not one filesystem trace, exactly as a value that cannot canonicalize does.
        bytes = JSON.stringify(obj)
        // `JSON.stringify` is NOT total either, and its OTHER failure mode is silent: it ANSWERS
        // `undefined` — no throw — for a bare `undefined`, a top-level function or a top-level symbol.
        // Meanwhile `canonicalForm` maps `undefined` to `null`, so `id` happily returns an address for it.
        // Storing that answer writes a value that cannot be parsed back to the object it addresses, i.e. a
        // durable row that reads as absent — the bricked row a refusal is strictly better than. Same sentinel.
        if (typeof bytes !== "string") return EMPTY
      } catch {
        // malformed input (float / bigint / symbol / cyclic / an NFC key collision) → honest empty, write
        // nothing, never throw. This is the contract `index/cas.ts` already codes against (`if (h)`).
        return EMPTY
      }
      const path = valuePath(casPath, h)
      // content-keyed dedup: equal content already on disk ⇒ store nothing new (idempotent).
      if (!existsSync(path)) {
        mkdirSync(dirname(path), { recursive: true })
        writeFileSync(path, bytes, "utf8")
      }
      return h
    },

    get(h: Hash): CasObject | undefined {
      // total: any miss/malformed/tampered read ⇒ `undefined`, never a throw (KERNEL-7a).
      // SECURITY (billy PoC — path-traversal / read-amplification DoS): `h` may be attacker-controlled (the
      // `atlas node <addr>` read door reaches here over MCP/poke). A CAS key is EXACTLY 64 lowercase hex, so
      // reject anything else BEFORE `readFileSync` — the tamper re-hash guard below runs AFTER the read, too
      // late to stop an unbounded read (a `../`-traversal to /dev/zero would hang + OOM). Belt-and-suspenders:
      // also require the resolved value path to stay INSIDE the CAS root (no escape), treating either failure
      // as a plain miss (`undefined`), never a filesystem touch.
      if (!/^[0-9a-f]{64}$/.test(h)) return undefined
      const path = valuePath(casPath, h)
      // N14 (billy PoC — the residual symlink TOCTOU): N13 guarded with THREE separate path-based syscalls
      // (statSync → realpathSync → readFileSync), each re-resolving the symlink independently, so a concurrent
      // attacker who wins a sub-ms race could point `<cas>/<xx>/<H>` at a small in-CAS regular file during the
      // stat/realpath checks and swap it to `/dev/zero`/a FIFO before the read — re-opening the OOM. The fix is
      // an ATOMIC fd-based read: check and read share ONE inode, pinned by a single open descriptor.
      //   (1) Open the final component with O_RDONLY|O_NOFOLLOW|O_NONBLOCK. O_NOFOLLOW ⇒ a symlink AT the final
      //       component fails to open (ELOOP) ⇒ MISS — this alone kills the symlink-based OOM AND the integrity
      //       escape at the final component (in-cas OR out-of-cas target), atomically, in one syscall.
      //       O_NONBLOCK ⇒ opening a FIFO returns immediately instead of blocking on a writer.
      //   (2) fstatSync on the OPEN fd (not the path): a CAS object is ALWAYS a small REGULAR file, so a device/
      //       FIFO/dir/socket (isFile() false) or an oversized file is a MISS — decided on the pinned inode.
      //   (3) Read the bytes FROM THAT SAME fd, so a post-open symlink swap cannot redirect the read.
      //   (4) The realpathSync sandbox is KEPT for INTERMEDIATE components — O_NOFOLLOW only covers the FINAL
      //       component, so a symlinked intermediate dir `<xx>` still needs the cas-root containment check.
      // Total on every branch (→ undefined, never a throw/hang); the fd is ALWAYS closed (finally).
      let fd: number | undefined
      try {
        fd = openSync(path, O_READ_NO_SYMLINK) // final-component symlink ⇒ ELOOP ⇒ throw ⇒ miss
        const st = fstatSync(fd) // on the pinned inode, not a re-resolved path
        if (!st.isFile() || st.size > MAX_CAS_BYTES) return undefined // non-regular / oversized ⇒ never read
        // intermediate-component sandbox: the final component is provably NOT a symlink (O_NOFOLLOW opened it),
        // so any symlink resolved on the way to it is an intermediate dir — the bytes must still live inside cas.
        // Asked of `isContainedIn`, the ONE containment predicate (containment.ts), rather than the string
        // comparison `real !== realCas && !real.startsWith(realCas + sep)` this used to be. NOT a live bypass
        // here and not described as one: `path` is `valuePath(casPath, h)`, a literal extension of `casPath`, so
        // there is no second source and no spelling that can diverge — probing the built module found exactly one
        // divergence and it was a FALSE MISS (a case-variant CAS root read as an escape, i.e. fail-closed, and
        // reachable only with write access inside the CAS root already). It changes for one reason: one question
        // deserves one answer, and the inode predicate has no false miss to explain.
        if (!isContainedIn(casPath, path)) return undefined // intermediate escapes ⇒ miss
        const raw = readFileSync(fd, "utf8") // FROM THE fd — the inode is pinned, no re-resolve
        let parsed: CasObject
        try {
          parsed = JSON.parse(raw) as CasObject
        } catch {
          return undefined // corrupt bytes
        }
        let rehash: Hash
        try {
          rehash = id(parsed)
        } catch {
          return undefined
        }
        // tamper-safe: the mandatory re-hash-on-read — bytes whose `id !== key` read as absent (adapt-store-1).
        if (rehash !== h) return undefined
        return parsed
      } catch {
        return undefined // ELOOP (final-component symlink) / ENOENT / any fs error ⇒ plain miss
      } finally {
        if (fd !== undefined) {
          try {
            closeSync(fd)
          } catch {
            /* best-effort close; the miss/hit decision above is already made */
          }
        }
      }
    },

    commitProjection<T>(decide: (projection: StoreProjection) => CommitDecision<T>): CommitResult<T> {
      // The CAS door handed to the commit is THIS store's own `put`, so the bytes a decision depends on are
      // durable before the generation that references them is linked into existence.
      return commitSidecar(
        ctxFor(casPath, PROJECTION_BASE, headSha, (o) => store.put(o as CasObject), trusted),
        decide,
      )
    },

    commitStaging<T>(decide: (projection: StoreProjection) => CommitDecision<T>): CommitResult<T> {
      return commitSidecar(
        ctxFor(casPath, STAGING_BASE, headSha, (o) => store.put(o as CasObject), trusted),
        decide,
      )
    },

    persistProjection(projection: StoreProjection): void {
      persistSidecar(
        ctxFor(casPath, PROJECTION_BASE, headSha, (o) => store.put(o as CasObject), trusted),
        projection,
      )
    },

    loadProjection(): StoreProjection | undefined {
      return readSidecarSet(sidecarDir(casPath), PROJECTION_BASE, trusted).projection
    },
  }
  registerDiskStoreIdentity(store, casPath)
  return store
}
export function rehydrateProjection(store: DiskStore): StoreProjection {
  // pure read-back: reconstruct the projection from the durable sidecar, minting nothing — NEITHER
  // routeWrite/upsert NOR put. Missing sidecar ⇒ the empty projection (adapt-store-3, 12b).
  return store.loadProjection() ?? emptyStore()
}
