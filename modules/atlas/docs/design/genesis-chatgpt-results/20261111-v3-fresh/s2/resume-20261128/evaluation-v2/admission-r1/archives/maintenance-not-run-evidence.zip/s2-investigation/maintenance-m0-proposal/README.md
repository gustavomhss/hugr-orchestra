# M0 / S2-U1 — proposta operacional externa, NOT_RUN

Esta proposta inicia uma avaliação de manutenção distinta de d1. M0 exige nova preparação, nova identidade e duas decisões ADMIT exatas; nenhum voto ou estado de d1 é transferido. A primeira travessia e os 14 casos originais permanecem pré-requisitos separados, sem renomeação ou reclassificação. Nenhuma raiz U1, política, candidato, recibo de execução, produtor ou voto foi criado por este trabalho.

## Materiais

- `evaluation-plan.json`: proposta no formato `genesis-evaluation-plan/v1`, com os 13 entries, refs semânticas, aplicação/limites e obrigação original preservados; cinco witnesses novos e 39 pins de fontes/implementação/controle. SHA-256 `b2c5e3146d5d028fbd6b90d0eac99303262af0debd93ed51d1d89fee82823bc1`.
- `operator-plan.json`: sequência operacional completa, fonte perturbada, grafo congelado, regras de CAS, drift, restauração, política e recuperação. SHA-256 `c70dafc9ef266f82ee207673791c2968b87bf6d13ca4c179ce373b7c86aec6aa`. Este material é reservado ao operador/revisão e não integra os pacotes dos witnesses.
- `materialization-proposal.json`: 728 arquivos-base propostos, sendo os 716 preservados byte a byte e 12 adições. É um plano de cópia, não um recibo de materialização.
- `policies/`: seis políticas de admissão/manutenção para M0/M1/M2, cinco políticas de witnesses, a política de governança e a proposta de transições. As identidades futuras são placeholders explícitos.
- `command-templates/` e `operation-templates/`: 34 modelos de operações da CLI/helpers existentes, com controles, inventários e IDs futuros ainda por resolver. Não foram passados aos helpers.
- `witness-packets/` e `reader-queries/`: perguntas neutras e queries fixadas; não contêm respostas esperadas, valores do patch, hashes de corpos esperados ou material de juiz/oracle.
- `proposed-generations.json`, `placeholder-catalog.json`, `static-schema-review.json` e `proposal-summary.json`: escolhas de gerações, lacunas tipadas, conferência estática e limites.

## Witnesses e limites

| ID novo | Raiz / momento | Modo | Index | Read | Bytes de corpo totais |
| --- | --- | --- | ---: | ---: | ---: |
| S2-U1-W0 | M0 admitido | deep | 1 | 2 | 64.000 |
| S2-U1-W1 | M0 temporariamente em drift | routine | 1 | 2 | 16.000 |
| S2-U1-W2 | M1 admitido após parada/retomada | deep | 1 | 2 | 64.000 |
| S2-U1-W3 | M1 temporariamente em drift na restauração | routine | 1 | 2 | 16.000 |
| S2-U1-W4 | M2 admitido, após reúso final e leitor reiniciado | deep | 1 | 2 | 64.000 |

Cada ID representa um caso/orçamento. O dispatcher deve criar um contexto independente novo e registrar seu identificador real no momento do despacho. Nenhuma identidade de agente foi inventada. W2 cobre o consumo após a recuperação; W4 cobre restauração após reúso e reinício do leitor. Por isso não há witness adicional de recuperação.

As queries deep pedem os corpos L1/L2 desktop-web, limitados a 32.000 bytes cada. As queries routine usam L1 desktop-web e L1 app-session, limitados a 8.000 bytes cada. As perguntas não identificam a resposta esperada nem classificam uma chave como afetada ou fora do alcance. A finalidade de comparação pertence ao operador.

O runtime cobra tentativas index/read antes da seleção; uma recusa não autoriza reset de orçamento. A proposta não concede IDs substitutos, retries incertos ou ampliação automática de limites. A associação de witness a etapa/raiz está nas políticas propostas e no cronograma externo: o runtime copia a lista finita comum para cada plano target e não impõe sozinho essa associação cronológica.

## Raízes e sequência

As três raízes propostas são irmãs: `s2-u1-baseline` (M0), `s2-u1-changed` (M1) e `s2-u1-restored` (M2), sob o scratch atual. Elas continuam inexistentes. A raiz inicial `s2-evaluation` e `s2-corpus` permanecem intactas.

1. Depois dos pré-requisitos, congelar plano/controles; materializar M0 sem estado copiado; executar prepare CAS-only original. Aprender os IDs do resultado real.
2. Inicializar M0 e provisionar somente autoridade de admissão, separadamente. Obter duas novas decisões exatas para todo o candidato e admitir. Executar W0 por index/read.
3. Provisionar manutenção em M0 e observar reúso com inputs idênticos. A geração proposta para esse pedido é distinta, mas não será inicializada se o runtime devolver reúso.
4. Materializar M1 dos arquivos-base, aplicar apenas o patch congelado e preservar M0 coerente. Para observar invalidação real, aplicar temporariamente o patch também na própria raiz admitida M0, executar W1 e restaurar imediatamente os bytes originais de M0, com recibos das duas mudanças.
5. Usar M0 como autoridade/store e M1 como fonte: capture, produções nativas reais, semântica específica para resultados alterados, prepare do target e duas novas decisões ADMIT. Finalize privado ainda usa o CAS de M0, lendo os payloads de decisão no namespace de M1.
6. Somente depois de prepare **e** finalize, congelar o inventário completo do CAS de M0 e copiá-lo para `M1/.atlas/cas`, verificando membros, tamanhos e hashes. Não copiar marcador, política, projeção, orçamento, staging ou locks. Não há cópia de CAS pré-update nesta proposta.
7. Parar deliberadamente com target, decisões, finalização e cópia CAS duráveis, antes do init/admit de M1. Retomar em processo novo, verificar tudo e continuar sem nova produção, callback, prepare ou finalize. Inicializar/admitir M1 pela CLI original e executar W2. Usar o manifest realmente emitido, não o manifest privado como substituto.
8. Para invalidação durante restauração, repor temporariamente os bytes originais na própria M1 admitida, executar W3 e restaurar seus bytes alterados. M1 volta a ficar coerente antes de funcionar como autoridade de M2.
9. Materializar M2 dos arquivos-base originais. Usar M1 como autoridade/store, M2 como fonte: capture, produções/semântica necessárias, prepare, duas novas decisões e finalize. Copiar o CAS completo pós-finalize de M1 para M2, inicializar e admitir M2.
10. Executar reúso exato em M2, reiniciar o leitor e executar W4. Reconciliar os recibos reais com o grafo original e os controles, sem inferir contagens de produção a partir do alcance estático.

Uma raiz antiga coerente pode servir seu próprio snapshot antigo. Isso não comprova comportamento de uma raiz nova. A sonda de drift modifica a raiz selecionada pelo leitor; jamais usa respostas de M0/d1 como fallback para M1/M2. As mudanças temporárias das raízes de autoridade são restauradas antes de seus próximos usos.

## Gerações e IDs desconhecidos

Foram propostas cinco gerações distintas por SHA-256 de rótulos explícitos do operador: M0, M1, M2 e os dois pedidos de reúso. São escolhas prospectivas de geração, não IDs de candidato nem inicializações observadas. As gerações target ficam fixadas antes do prepare de cada target.

IDs CAS de candidatos/planos/manifests, hashes dos preparados futuros, outputs, capturas, bindings e evidências continuam como tokens `{{...}}`. Tokens terminados em `_ARRAY` representam arrays JSON a serem preenchidos com os registros reais, não strings executáveis. O catálogo explica suas fontes. Não há decisões sintéticas ou marcadores fabricados nos modelos.

## Dependências e limites materiais

O instalador atual `install-evaluation-policy.py` fixa d1, a raiz `s2-evaluation` e suas políticas. Ele não serve para M0. É necessário um mecanismo de instalação específico de U1, revisado separadamente, ou uma escrita explícita do operador com verificações e recibo equivalentes. Não foi inventado um comando para um instalador inexistente, e o instalador fixado não foi alterado.

O transporte de leitura deve vincular cada novo witness à raiz/candidato/geração/política corretos. Um bridge preso a d1 não pode ser reutilizado silenciosamente. Os modelos usam as portas originais index/read e os helpers corrigidos, sem executar qualquer um deles.

Os controles comuns permanecem ligados ao mapa de compatibilidade existente. Esta linhagem principal congela o registro original e a perturbação de fonte. Se for necessária execução adicional de uma variante de receita/aresta/metadata/blocked, ela exige proposta e evidência próprias; não se altera silenciosamente o registro fixado em M0 nem se apresenta o mapa estático como execução S2.

A conferência foi de JSON, hashes, campos e leitura das interfaces db9. Não chamou validador nativo, kernel ID ou Atlas. Políticas e comandos com placeholders são deliberadamente incompletos para execução. Não houve parecer, voto ou afirmação de qualificação; toda execução U1 continua futura.
