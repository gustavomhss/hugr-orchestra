#!/usr/bin/env python3
"""DRAFT_NOT_RUN: install exact supplied U1 policy bytes on an already initialized root.

No Atlas invocation, identity computation, approval generation, root initialization,
CAS write, budget reset or automatic rollback. This is explicit local configuration.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import sys
import uuid
from u1_operator_common import (ACTOR, GOVERNANCE_SHA, HERE, admission_evidence, encode,
    json_ref, new_external_directory, read_ref, regular, require, resolve_context,
    sha, snapshot_state, stamp, state_inventory, validate_policy, write_new)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def atomic_policy(path, data):
    temporary = path.with_name(path.name + '.' + str(uuid.uuid4()) + '.tmp')
    write_new(temporary, data)
    os.replace(temporary, path)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha256', required=True)
    args = parser.parse_args()
    request_path, request_bytes, request = json_ref({'path': str(args.request), 'sha256': args.request_sha256})
    require(request['schema'] == 'genesis-s2-u1-policy-install-request/v1', 'policy install request schema')
    context = resolve_context(request, Path(__file__).resolve())
    root = context['root']
    require(request['purpose'] in ['admit','maintenance','witness'], 'policy purpose')
    policy_path, policy_bytes, policy = json_ref(request['policy'])
    validate_policy(policy, context, request['purpose'], request.get('witness_id'))
    governance_path, governance_bytes = read_ref(request['governance'])
    require(sha(governance_bytes) == GOVERNANCE_SHA, 'exact declared governance bytes required')
    sources = context['sources'] + [stamp(request_path), stamp(policy_path), stamp(governance_path), stamp(Path(__file__).resolve())]
    if request['purpose'] != 'admit':
        sources += admission_evidence(request['admission_receipt'], context)
    current = root / '.atlas/evaluation-policy.json'
    previous = regular(current).read_bytes() if current.exists() else None
    require((None if previous is None else sha(previous)) == request['previous_evaluation_policy_sha256'], 'unexpected previous policy; no overwrite')
    if previous is not None:
        old = json.loads(previous)
        require(all(old[k] == policy[k] for k in ['schema','root','evaluationPlan','obligationSet','evaluationCandidate','generation','scope','actor']), 'existing authority identity differs')
    governed = root / '.atlas/policy.json'
    require(not governed.exists() or regular(governed).read_bytes() == governance_bytes, 'existing governance bytes differ')
    before, before_snapshots = state_inventory(root)
    require(any(row['path'] == 'cas' and row['kind'] == 'directory' for row in before), 'existing CAS directory required')
    output = new_external_directory(request['output_dir'], 'policy')
    write_new(output / 'request-used.json', request_bytes)
    snapshot_state(output, 'before', before, before_snapshots)
    start = {'schema': 'genesis-s2-u1-policy-install-start/v1', 'started_at': now(), 'root': str(root),
        'candidate_id': context['candidate_id'], 'generation': context['marker']['generation'],
        'purpose': request['purpose'], 'witness_id': request.get('witness_id'), 'inputs': sources,
        'policy_intended': stamp(policy_path), 'governance_intended': stamp(governance_path)}
    write_new(output / 'start.json', encode(start))
    failure = None
    try:
        require(state_inventory(root)[0] == before, 'state changed before installation')
        if not governed.exists():
            atomic_policy(governed, governance_bytes)
        if previous != policy_bytes:
            atomic_policy(current, policy_bytes)
        require(regular(current).read_bytes() == policy_bytes and regular(governed).read_bytes() == governance_bytes, 'installed bytes differ')
    except Exception as error:
        failure = str(error)
    try:
        after, after_snapshots = state_inventory(root)
        snapshot_state(output, 'after', after, after_snapshots)
        allowed = {'policy.json','evaluation-policy.json'}
        protected_equal = [r for r in before if r['path'] not in allowed] == [r for r in after if r['path'] not in allowed]
        cas_equal = [r for r in before if r['path'] == 'cas' or r['path'].startswith('cas/')] == [r for r in after if r['path'] == 'cas' or r['path'].startswith('cas/')]
        budgets_equal = [r for r in before if r['path'].startswith('evaluation-budget-')] == [r for r in after if r['path'].startswith('evaluation-budget-')]
        require(protected_equal and cas_equal and budgets_equal, 'protected state/CAS/budgets changed during installation')
        require((root / '.atlas/evaluation-store.json').read_bytes() == context['marker_bytes'], 'marker changed')
    except Exception as error:
        after = None
        protected_equal = cas_equal = budgets_equal = False
        failure = (failure + '; ' if failure else '') + str(error)
    result = {'schema': 'genesis-s2-u1-policy-installation/v1', 'state': 'INSTALLED_EXACT_DECLARED_BYTES' if failure is None else 'FAILED_OR_UNCERTAIN_NO_RETRY',
        'started_at': start['started_at'], 'ended_at': now(), 'root': str(root), 'candidate_id': context['candidate_id'],
        'generation': context['marker']['generation'], 'purpose': request['purpose'], 'witness_id': request.get('witness_id'),
        'policy_sha256': sha(policy_bytes), 'governance_sha256': sha(governance_bytes),
        'before': before, 'after': after, 'protected_state_unchanged': protected_equal, 'cas_unchanged': cas_equal,
        'budgets_unchanged': budgets_equal, 'error': failure, 'inputs': sources, 'installer': stamp(Path(__file__).resolve()),
        'atlas_executed': False, 'approval_created': False, 'budget_reset': False, 'automatic_retry': False, 'automatic_rollback': False,
        'limit': 'Explicit supplied local policy configuration on existing runtime identity. Nominal actor is not authenticated. Original runtime evidence is checked; kernel/CAS IDs are not recomputed here. Partial effects require inspection.'}
    write_new(output / 'receipt.json', encode(result))
    print(json.dumps(result, ensure_ascii=False))
    return 0 if failure is None else 1


if __name__ == '__main__':
    raise SystemExit(main())
