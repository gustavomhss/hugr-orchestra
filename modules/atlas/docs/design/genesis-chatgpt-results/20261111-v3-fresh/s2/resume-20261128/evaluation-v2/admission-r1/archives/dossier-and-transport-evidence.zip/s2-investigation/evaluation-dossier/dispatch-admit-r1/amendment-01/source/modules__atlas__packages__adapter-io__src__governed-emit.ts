import { assertOperationalDiskStore, assertEvaluationDiskStore } from "./store-evaluation-identity.js"
import { isEvaluationPayload } from "./okf-store.js"
import { assertEvaluationComposition } from "./ownership-evaluation-policy.js"
import type { EvaluationAccess } from "./ownership-evaluation-policy.js"
import type { CasObject } from "@atlas/kernel"
import type { Hash, NodeKey } from "@atlas/contracts"
import { upsert } from "@atlas/knowledge"
import type {
  Candidate,
  CurrentNode,
  GroundedFact,
  NegationNode,
  TransitionNode,
  TestVacuityNode,
  WriteRequest,
  WriteOrigin,
} from "@atlas/knowledge"
import { emitNegation, type NegationEmitDeps } from "./governed-emit-negation.js"
import { emitTransition } from "./governed-emit-transition.js"
import { emitTestVacuity } from "./governed-emit-test-vacuity.js"
import { claimNormOf, relationCarriers, resolveWriteIdentity } from "./governed-emit-identity.js"
import type { EmitOut, TruthGate } from "@atlas/tools"
import {
  evalShapeGate,
  evalTruthGate,
  evalAuthzGate,
  evalRatifyGate,
  deriveFastPathVerdicts,
} from "./governed-emit-gates.js"
import type { DiskStore } from "./store.js"
import type { CommitResult } from "./sidecar.js"
import { commitRefusalOf } from "./governed-emit-address.js"
import { REJECTED_CONTENDED, REJECTED_MALFORMED_TIER, REJECTED_UNREADABLE_STORE } from "./governed-emit-reasons.js"
import type { AtlasPolicy } from "./policy.js"
import { REJECTED_UNTRUSTED_STORE } from "./read-provenance.js"
import { ownershipAttachmentRefusal } from "./ownership-attachment.js"
import { emissionClaimReceipt, retainClaimReceipt, stripClaimReceipt, REJECTED_CLAIM_RECEIPT } from "./claim-receipt.js"
import type { GovernedEmitOptions } from "./claim-receipt.js"
export function createGovernedEmit(deps: GovernedEmitDeps): {
  readonly emit: (node: GroundedFact, at: Hash, opts?: GovernedEmitOptions) => EmitOut
} {
  const emit = (input: GroundedFact, at: Hash, opts?: GovernedEmitOptions): EmitOut => {
    try {
      if (deps.evaluation === undefined) assertOperationalDiskStore(deps.store)
      else assertEvaluationDiskStore(deps.store, deps.evaluation.root)
    } catch { return { emitted: false, rejected: "evaluation-operation-denied" } }
    if (typeof input !== "object" || input === null || Array.isArray(input))
      return { emitted: false, rejected: REJECTED_MALFORMED_TIER }
    if (deps.evaluation !== undefined) {
      try {
        assertEvaluationComposition(deps.evaluation.root, deps.evaluation)
        deps.evaluation.assert("admit")
      } catch { return { emitted: false, rejected: "evaluation-operation-denied" } }
      if (input.kind !== "advisory" || !("ownership" in input))
        return { emitted: false, rejected: "evaluation-only-ownership-admission" }
    }
    if (deps.evaluation === undefined && [...(deps.store.loadProjection()?.current.values() ?? [])]
      .some((row) => isEvaluationPayload(row) || isEvaluationPayload(deps.store.get(row.contentHash as Hash))))
      return { emitted: false, rejected: "evaluation-operation-denied" }
    const raw = stripClaimReceipt(input)
    const origin = deps.origin
    const claimReceipt = origin === "promoted" ? opts?.claimReceipt : undefined
    if (claimReceipt !== undefined && raw.kind !== "advisory" && raw.kind !== "predicate") {
      return { emitted: false, rejected: REJECTED_CLAIM_RECEIPT }
    }
    // #99b N2 — a negation re-routes to `emitNegation` (its own gate ladder, §4), branched before gate 0; `at` unused.
    if (raw.kind === "negation") return emitNegation(deps, raw as NegationNode)
    // #234 D4 — a transition re-routes to `emitTransition` (its own gate ladder), branched before gate 0. It
    // carries authz + anchor gates but NO HEAD truth gate: a transition grounds on PAST revs (D-T2), which the
    // main gate-1 would always drift-reject. `at` unused (the transition's grounding is stamped, not re-checked).
    if (raw.kind === "transition") return emitTransition(deps, raw as TransitionNode)
    // #95 D5 — a test-vacuity re-routes to `emitTestVacuity` (its own gate ladder), branched before gate 0. It
    // carries the HEAD truth gate (the relation ladder — a test-vacuity grounds on the current test file, so `at`
    // IS used, unlike a transition) PLUS produced-only (the forge guard: its witness is not door-re-derivable).
    if (raw.kind === "test-vacuity") return emitTestVacuity(deps, raw as TestVacuityNode, at)

    // 0. WELL-FORMED PAYLOAD (the SHAPE gate — `GateName:'shape'`) — `tier`, `scope`, the `kind`/`check`
    //    pair, relation well-formedness, addressability, and — LAST, AUTHOR-12, closes the 2026-07-25
    //    dogfood's raw TypeError — grounding well-formedness, in that fixed order. EXTRACTED to `evalShapeGate`
    //    (WP-10.A3.ADAPTER — see that file's header): a store-less `check` leg folds the identical function.
    //    `Tier`/`scope` are TYPE-ONLY: nothing upstream validates them (`atlas emit` is `JSON.parse` + a
    //    cast; the MCP `node` schema declares a bare `object`), so this is the FIRST place an arbitrary
    //    payload can be refused. Read ONCE and the snapshot carried — re-reading `raw.tier` at each gate
    //    would let a property whose value changes between reads clear this gate as `T2` and route as
    //    something else (a TOCTOU unreachable over the CLI/MCP wires but reachable through the exported
    //    library entry point). Gating a snapshot and persisting that same snapshot means what was checked
    //    is exactly what is stored.
    const shapeVerdict = evalShapeGate(raw, origin)
    if (!shapeVerdict.pass) {
      return { emitted: false, rejected: shapeVerdict.result.reason ?? shapeVerdict.result.gate }
    }
    const { node, tier, scope, family, contentHash } = shapeVerdict
    // Only trusted promoted-origin OPTIONS can supply provenance; payload carriers were stripped above.
    const receipt = claimReceipt !== undefined
      ? emissionClaimReceipt(deps.store, node, String(contentHash), claimReceipt) : undefined
    if (receipt !== undefined && "rejected" in receipt) return { emitted: false, rejected: receipt.rejected }

    // 1. TRUTH DOOR — re-derive the citation; a non-HOLDS verdict persists nothing.
    const truthVerdict = evalTruthGate(node, at, deps.gate)
    if (!truthVerdict.pass) {
      return { emitted: false, rejected: truthVerdict.reason ?? truthVerdict.gate }
    }

    // Identity/route read `.slot`, while stored facts carry `predicateSlot`. Preserve that mapping;
    // relations use endpoint identity instead, but still need the candidate view for ratification.
    const candidateView = {
      ...node,
      slot: node.kind === "advisory" || node.kind === "predicate" ? node.predicateSlot : undefined,
    } as unknown as Candidate

    // AUTHZ (`GateName:'authz'`, gates 2 / 2.1 / 2.25) — actor-in-declared-scope, then the ARCH-9 anchor
    //    binding (ADR-0010 open item 3: gate 2 asks whether the actor is in the scope this write DECLARES;
    //    the author picks that string, while the READ projection scopes on the DERIVED `primaryAnchor` and
    //    never reads the row's scope at all — nothing bound the two before this gate), then the FOUR
    //    incumbent-derived gates (the write's TARGET decides which gate it must clear, never the write
    //    itself; see `governed-emit-incumbent.ts` for the confused-deputy narrative). EXTRACTED to
    //    `evalAuthzGate` (WP-10.A3.ADAPTER): a store-less `check` leg folds the identical function.
    //
    //    `targetKey`/`primaryAnchor` are resolved here (ADR-0015 D2: a RELATION binds on `endpointA`, its
    //    SUBJECT, via `relationKey`; an intrinsic fact binds on `primaryAnchorId`, which THROWS
    //    `DegenerateAnchorError` on a degenerate grounding — the door's existing behaviour, unchanged) and
    //    reused by the WriteRequest below — one identity, one read.
    //
    //    2.25's incumbent-derived sub-gates need the LIVE incumbent, so `evalAuthzGate` runs PER COMMIT
    //    ATTEMPT, inside the closure below — re-evaluated on every retry against whatever the projection
    //    resolves at THAT attempt (ADR-0007: a decision must never be published against a snapshot that has
    //    since acquired a billy-ratified T0 incumbent). Gates 2/2.1 do not depend on the incumbent at all —
    //    folding them into the same per-attempt call is behaviour-preserving (deterministic given the same
    //    payload/policy/actor, so a retry recomputes an IDENTICAL verdict for those two) and keeps the whole
    //    AUTHZ bucket as ONE fold, matching the store-less leg's single pass.
    const { primaryAnchor, targetKey } = resolveWriteIdentity(node, candidateView)

    // ── THE ATOMIC COMMIT (stages 2 → 4) ────────────────────────────────────────────────────────────────
    // Everything from here down is ONE decision, taken against ONE snapshot of the projection and published
    // as a whole or not at all. The old shape — rehydrate, gate, upsert, `persistProjection` — was a
    // read-modify-whole-file-write with no lock and no compare-and-swap: 8 concurrent `atlas emit`s over a
    // 1000-node store silently lost 1–5 nodes in 6/6 measured trials, each writer exiting 0 with
    // `status: ok`, and a single emit onto a torn sidecar erased 402 nodes down to 1. See `sidecar.ts`.
    //
    // The callback is re-run FROM SCRATCH when another writer publishes first, and it contains the GATES,
    // not merely the upsert. That is a security requirement, not an implementation detail:
    // `incumbentRefusal` resolves target authority from the incumbent ROW on THIS snapshot (ADR-0007), so
    // re-publishing a decision taken against a snapshot that has since acquired a billy-ratified T0
    // incumbent — or acquired a `scope` carrier where there was none — would apply a write that never faced
    // the gate it now owes. That is the confused deputy, re-entered through the back door of a retry.
    // The commit's CAS door is the SECOND addressability leg (gate 0.5) and is NOT redundant with the first:
    // MEASURED, a bigint in `grounding` canonicalizes fine and still reaches `sidecar-commit.ts`'s CAS_EMPTY
    // guard through this door — where it refuses by THROWING. Caught here and re-filed as a decision.
    let committed: CommitResult<EmitOut>
    try {
      committed = deps.store.commitProjection<EmitOut>((projection) => {
        const incumbent: CurrentNode | undefined = projection.current.get(targetKey)
        const authzVerdict = evalAuthzGate({
          policy: deps.policy,
          actor: deps.actor,
          scope,
          tier,
          node,
          candidateView,
          primaryAnchor,
          incumbent,
          store: deps.store,
        })
        if (!authzVerdict.pass) {
          return { out: { emitted: false, rejected: authzVerdict.result.reason ?? authzVerdict.result.gate } }
        }
        // ARCH-9: the class the RESOURCE carries. Absent on a CREATE (nothing to derive from — ARCH-D3b, the
        // OPEN owner DEFINE) and on a refusal (the write does not reach `route` at all).
        const derivedTier = authzVerdict.derivedTier
        try {
          if (deps.evaluation === undefined) assertOperationalDiskStore(deps.store)
          else assertEvaluationDiskStore(deps.store, deps.evaluation.root)
        } catch { return { out: { emitted: false, rejected: "evaluation-operation-denied" } } }
        const ownershipRefusal = ownershipAttachmentRefusal(node, deps.store, deps.ownershipInput, deps.evaluation)
        if (ownershipRefusal !== undefined) return { out: { emitted: false, rejected: ownershipRefusal } }

        // RATIFY (`GateName:'ratify'`, gate 2.5) — the KNOW-8/KNOW-18 tier-ratification gate, BETWEEN authz
        //    and upsert. EXTRACTED to `evalRatifyGate`. The fast-path `route` auto-accepts a grounded ∧
        //    lowRisk ∧ T2 ∧ advisory ∧ ¬contested fact (the common case — straight to upsert, unchanged
        //    behavior). A T0 / predicate / contested fact routes to FULL ratification: it commits ONLY with
        //    a valid KNOW-8 token, and a T0 fact requires the `billy` token. The token is env-sourced by the
        //    composition root (never the payload). Absent/invalid ⇒ REJECTED fail-closed, nothing persisted
        //    — this is the door that was previously bypassing the human+billy gate. ARCH-9: the route is
        //    selected by `strictestTier(derived, declared)` when the door could derive a class from the
        //    incumbent, and by the declared class alone on a CREATE. See `ratifyCtxFor`.
        const ratifyVerdict = evalRatifyGate({
          candidateView,
          derivedTier,
          origin: Object.hasOwn(node, "ownership") ? "composed" : origin,
          ratifyToken: deps.ratifyToken,
          // ARCH-D3b (INV-AUTH-15) — DEVIVED fast-path verdicts. `lowRisk` from the TRUTH gate the write
          // already cleared (`truthVerdict.pass`, sealed above); `contested` from a CONFLICTING NODE —
          // the incumbent at this `(anchor, slot)` carries DIFFERENT bytes than this write (KNOW-18b).
          verdicts: deriveFastPathVerdicts(truthVerdict.pass, false),
        })
        if (!ratifyVerdict.pass) {
          return { out: { emitted: false, rejected: ratifyVerdict.reason ?? ratifyVerdict.gate } }
        }

        // 3. ROUTE + UPSERT — the KNOW-15 write-decision over the rehydrated projection (mine.ts parity).
        //    IDENTITY IS MINTED, NEVER TRUSTED — the routing/dedup `nodeKey` is RECOMPUTED from the content
        //    via the frozen `nodeKey(node)` formula (KNOW-15b: hash(primaryAnchorId ‖ slot[‖ check])), the same
        //    seam that mints `contentHash`/`primaryAnchor` below. The author-supplied payload `node.id` is NEVER
        //    used for routing — trusting it would let an author spoof/collide/dodge another node's identity.
        //    `contentHash` is the address gate 0.5 already minted from THIS SAME snapshot — the value is a pure
        //    function of `node`, which is frozen for the whole call, so a retry re-uses it rather than paying
        //    `id` again per attempt. It is also the only reason a violation can no longer escape from in here.
        const claimNorm = claimNormOf(node, family)
        const req: WriteRequest = {
          nodeKey: targetKey, // the SAME minted key the incumbent guard above resolved — one identity, one read
          contentHash: contentHash as unknown as string,
          family, // the CHECKED discriminant (gate 0), never the raw `node.kind` — see `familyOf`
          claimNorm,
          ...(receipt !== undefined && "receipt" in receipt
            ? { claimEvidenceByClaim: Object.fromEntries([[claimNorm, receipt.receipt]]) } : {}),
          ...((node.kind === "advisory" || node.kind === "predicate") && node.provenance !== undefined
            ? { provenanceByClaim: { [claimNorm]: node.provenance } }
            : {}),
          // ── ADJACENCY carrier (ADDITIVE) — carry the computed primary anchor + the R3-optional slot onto
          //    the node so a later sibling-adjacency scan reads them off the projection (WP-B); NOT read here.
          //    `predicateSlot` is R3-optional; conditional spread keeps `slot` ABSENT (exactOptionalPropertyTypes).
          primaryAnchor, // the SAME value gate 2.1 bound the declared scope against — computed once
          ...((node.kind === "advisory" || node.kind === "predicate") && node.predicateSlot !== undefined
            ? { slot: node.predicateSlot }
            : {}),
          // Only promote-origin seals surviving gate 0's operator/forgery strips reach this request.
          // A relation also requires its shape-valid witness; content re-verification remains read-owned.
          // Provenance only, never identity/authz. The CAS fact below retains the witness for reverify.
          ...(node.seal !== undefined ? { seal: node.seal } : {}),
          // ── RELATION carrier (ADDITIVE — ADR-0015 D2) — a `family:'relation'` write stamps its endpoint pair
          //    + kind on the ROW so the read-side `relationsOf` fold indexes it by both endpoints. Empty for a
          //    non-relation. `primaryAnchor` above is `endpointA` for a relation (the subject), by construction.
          ...relationCarriers(node),
          // ── GOVERNANCE carrier (ADDITIVE — ADR-0007) — stamp the `(scope, tier)` pair onto the ROW so the
          //    incumbent guard above can resolve target authority off the projection instead of off the CAS
          //    bytes. These are the GATE-0 SNAPSHOT values, not `raw.*`: what was validated is what is stored,
          //    and it is the same snapshot `put` writes into CAS below — so the row and its bytes agree by
          //    construction, which is exactly what the corroboration check above requires.
          scope, // the gate-0 narrowed const (`isScope` proved it a non-empty string), never the raw field
          tier,
          ...(opts?.replace === true ? { replace: true as const } : {}), // R8 — the operator's `--replace`, never the payload
        }
        const next = retainClaimReceipt(upsert(projection, req).store, req)
        // DEDUP may know these bytes but no longer retain this claim (e.g. after a replacement).
        if (receipt !== undefined && !next.current.get(targetKey)?.claims.includes(claimNorm)) {
          return { out: { emitted: false, rejected: REJECTED_CLAIM_RECEIPT } }
        }

        // 4. DURABLE PERSIST — the content-addressed bytes FIRST, then the projection sidecar that references
        //    them (INVARIANT: the CAS bytes ARE the fact, so driftFacts/doctor can read them back). The order is
        //    now enforced BY the commit rather than by two adjacent statements a later edit could swap: `put`
        //    names the objects the protocol writes before it links the generation in. A failing `put`
        //    (disk-full / permission) throws before any sidecar byte, so the sidecar can NEVER reference a
        //    contentHash whose bytes are absent from CAS.
        // AUTHOR-14 (ADDITIVE) — `targetKey` is the SAME minted identity the incumbent guard above already
        // resolved and the WriteRequest's `nodeKey` above carries onto the durable row (one identity, one
        // read — no re-mint). Stamped onto the receipt so the LINK door (`atlas-link`, which addresses a
        // node BY nodeKey — see `governed-link.ts`'s `proj.current.get(a/b)`) can consume it with no
        // separate query. Cast mirrors the existing `id: contentHash` line just above: `targetKey` is typed
        // `string` here (ADR-0015 D2 — a relation's targetKey is a `relationKey`, not a `nodeKey`), while
        // `EmitOut.nodeKey` is branded `NodeKey`; the door already trusts this value as an address (it is
        // the live map key `projection.current` is keyed by), so the brand is asserted, not re-derived.
        return {
          out: { emitted: true, id: contentHash, nodeKey: targetKey as unknown as NodeKey },
          next,
          put: [node as CasObject],
        }
      })
    } catch (e) {
      // ONLY a REFUSAL is re-filed (unaddressable-CAS-object; closed-slot, gate 3.5); every other throw propagates UNCHANGED — laundering one hides a broken disk behind a verdict. `commitRefusalOf` says why.
      return { emitted: false, rejected: commitRefusalOf(e) }
    }
    // 5. THE COMMIT'S OWN REFUSALS — visible, never silent, and door-wide rather than incumbent-derived
    //    (neither discloses anything about a node). `contended`: other writers published on all 64 attempts;
    //    nothing was written and no gate was bypassed. `unreadable store`: the sidecar exists but no
    //    generation parses, so the incumbent cannot be read — refuse rather than treat "corrupt" as "empty",
    //    which is the amplification that turned a torn read into a 402-node erasure. Both rank strictly
    //    above the silent loss they replace.
    //    `untrusted` (the THIRD `CommitRefusal` member) was collapsed into `unreadable store` here, and that
    //    was not a cosmetic mislabel: `unreadable store` tells the operator to restore
    //    `.atlas/projection.*.json` from a backup, which for a COMMITTED store is the wrong diagnosis, the
    //    wrong fix, and hides the only thing they need to know (`git rm -r --cached .atlas/…`). The store
    //    layer had the named refusal all along; now it uses the SAME constant as the read doors.
    if (committed.settled) return committed.out
    const commitRefusal =
      committed.refusal === "contended"
        ? REJECTED_CONTENDED
        : committed.refusal === "untrusted"
          ? REJECTED_UNTRUSTED_STORE
          : REJECTED_UNREADABLE_STORE
    return { emitted: false, rejected: commitRefusal }
  }
  return { emit }
}
