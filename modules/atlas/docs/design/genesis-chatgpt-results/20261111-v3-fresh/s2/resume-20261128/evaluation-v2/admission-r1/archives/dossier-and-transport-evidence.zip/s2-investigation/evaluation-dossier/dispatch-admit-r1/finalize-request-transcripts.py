"""Deterministic request transport accounting. No judge or Atlas invocation.

The previously fixed through34 transcript is retained. Later messages have an
explicit observed order, because a missing delivery and corrections make wave
number alone insufficient. Failed activations stay in the ledger, not requests.
"""
from pathlib import Path
import hashlib
import json
import sys

D=Path(__file__).resolve().parent
R=D/'root-captures'
include_closing='--with-closing' in sys.argv
assert not include_closing, 'Closing is queued only. Root owns final activation; use staged PENDING files and append actual delivered root triggers after receipt.'
L=[json.loads(x) for x in (D/'transport-ledger.jsonl').read_text().splitlines()]

def sha(b):return hashlib.sha256(b).hexdigest()
def ident(p):
 b=p.read_bytes();return {'path':str(p),'utf8_bytes':len(b),'sha256':sha(b)}
def record_for(j,p):
 b=p.read_bytes();matches=[r for r in L if r.get('target')=='/root/'+j and r.get('request_path')==str(p) and r.get('request_sha256')==sha(b)]
 assert matches,(j,str(p),'missing actual invocation record')
 return matches
def capture(name):
 p=R/name;o=json.loads(p.read_bytes());v=o.get('request') or {'path':o['request_path'],'utf8_bytes':o['request_utf8_bytes'],'sha256':o['request_sha256']}
 q=Path(v['path']);assert ident(q)==v,(name,'request identity mismatch')
 return q
def save_new_or_same(p,b):
 if p.exists():assert p.read_bytes()==b,(str(p),'existing immutable bytes differ')
 else:p.write_bytes(b)

J1=[
 ('wave35',D/'delta-release-01/035.txt',True),
 ('wave36-attempt01-unavailable',D/'delta-release-01/036.txt',False),
 ('activation35-36',D/'activation-triggers/035-036-s2_j1.txt',True),
 ('wave37',D/'delta-release-01/037.txt',True),
 ('wave36-full-retransmission02',R/'dispatcher-j1-wave-36-retransmission-02.txt',True),
 ('wave38',D/'delta-release-01/038.txt',True),
 ('recovery36-and-activation37-38',D/'activation-triggers/036-recovery-037-038-s2_j1.txt',True),
 ('wave39',D/'delta-reader-capture-01/039.txt',True),
 ('activation39',D/'activation-triggers/039-s2_j1.txt',True),
]
J2=[
 ('wave35',capture('j2-wave-35-send.json'),True),
 ('wave36',capture('j2-wave-36-send.json'),True),
 ('activation35-36',capture('j2-waves-35-36-activation.json'),True),
 ('wave37',capture('j2-wave-37-send.json'),True),
 ('wave38',capture('j2-wave-38-send.json'),True),
 ('activation37-38-successful-attempt02',capture('j2-waves-37-38-activation-attempt-02.json'),True),
 ('wave39-original-transcription',capture('j2-wave-39-send.json'),True),
 ('activation39',capture('j2-wave-39-activation.json'),True),
 ('wave39-E003-errata-full-retransmission',capture('j2-wave-39-e003-errata-send.json'),True),
 ('wave39-E003-correction-activation',capture('j2-wave-39-e003-errata-activation.json'),True),
]

# Exact correction reconciliation, without modifying either attempted request.
planned39=(D/'delta-reader-capture-01/039.txt').read_bytes()
actual39=J2[6][1].read_bytes()
omitted=b"     assert original_stream['path'] == admission_stdout.name\n"
assert planned39.count(omitted)==1
assert planned39.replace(omitted,b'',1)==actual39
e003=(D/'delta-reader-capture-01/bridge-state-capture.diff').read_bytes()
assert J2[8][1].read_bytes().count(e003)==1
assert J1[1][1].read_bytes()==J1[4][1].read_bytes()
negative=R/'j1-waves-35-36-ack.txt'
neg=json.loads(negative.read_bytes())
assert neg['received_by_wave']['36']['state']=='LITERAL_MESSAGE_NOT_AVAILABLE'
recovery=R/'j1-waves-36-37-38-recovery-ack.txt'
assert json.loads(recovery.read_bytes())['final_binding']=='NOT_ISSUED'

status=json.loads((D/'transport-status.json').read_bytes())
assert status['status']=='ALL_39_WAVES_ACCOUNTED_FOR','Wait for both complete receipt sets before sealing transcripts'
results=[]
for j,tail in [('s2_j1',J1),('s2_j2',J2)]:
 prefix_meta=json.loads((D/f'actual-requests/{j}-through-wave-34.json').read_bytes())
 prefix=Path(prefix_meta['path']).read_bytes()
 assert len(prefix)==prefix_meta['utf8_bytes'] and sha(prefix)==prefix_meta['sha256']
 assert sha(prefix)=={'s2_j1':'d0f12f9fcb6974f274d1f44e3300195a935618ab44f5db5e067ae02d22b3d6b8','s2_j2':'0d0a09abdbdaaf44c65c8523b3a9b7e85a46e2984d4d1c8d27985c59e8cfdeff'}[j]
 if include_closing:
  tail=tail+[('closing',D/'closing-with-a087.NOT_SENT.txt',True)]
 for _,p,_ in tail:record_for(j,p)
 for view in ['submitted','receipt-confirmed']:
  parts=[prefix];spans=list(prefix_meta['message_spans']);at=len(prefix)
  for label,p,confirmed in tail:
   if view=='receipt-confirmed' and not confirmed:continue
   b=p.read_bytes();spans.append({'label':label,**ident(p),'byte_start':at,'byte_end':at+len(b),'receipt_status':'REVIEWER_ACKNOWLEDGED' if confirmed else 'REVIEWER_REPORTED_LITERAL_UNAVAILABLE','source_invocation_records':record_for(j,p)})
   parts.append(b);at+=len(b)
  body=b''.join(parts);suffix='with-closing' if include_closing else 'through39'
  out=D/'actual-requests'/f'{j}-{view}-{suffix}.txt'
  save_new_or_same(out,body)
  meta={'schema':'s2-actual-request-transcript/v2','target':'/root/'+j,'view':view,'closing_included':include_closing,'artifact':ident(out),'literal_concatenation':'Exact files in observed request order; no separator or newline added; boundaries mapped separately.','scope':'submitted includes the actual attempted J1wave36 whose literal was unavailable to the reviewer. receipt-confirmed omits only that unsuccessful delivery attempt; all explicitly withdrawn-but-received transcriptions, correction messages and actual activations remain in sequence. Failed activation calls remain ledger evidence and are not included.','prefix':ident(D/f'actual-requests/{j}-through-wave-34.txt'),'message_spans':spans,'unavailable_original_attempt':ident(D/'delta-release-01/036.txt') if j=='s2_j1' else None,'negative_receipt_evidence':ident(negative) if j=='s2_j1' else None,'recovery_receipt_evidence':ident(recovery) if j=='s2_j1' else None,'host_message_id':None,'host_timestamp':None,'limitations':['External file hashes do not authenticate host serialization or reviewer identity.','Known request reconstruction errors and delivery failures remain explicit; omitted uniform evidence rows were not transported.','ACKs establish reported receipt, not semantic approval.'],'new_judgment':None}
  save_new_or_same(out.with_suffix('.json'),(json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode())
  results.append({'target':j,'view':view,**ident(out)})
print(json.dumps({'transcripts':results,'closing_included':include_closing,'correction39_exact_one_line_reconciled':True,'retransmission36_exact_bytes':True},ensure_ascii=False,indent=2))
