# Driver S2-U1 v2 — rascunho sem execução

`u1-evaluation-operation.mjs` prepara o uso das APIs existentes de avaliação v2, no runtime exato `db9b4235022c4df32fe3bfd4faeea8adcd69abb7`. Nenhum modo foi chamado. A única verificação executada foi `node --check`, sem carregar imports ou executar Atlas. Este rascunho não altera o candidato d1, o plano inicial, as perguntas, o oracle ou a raiz de consumo.

O driver depende de um futuro baseline M0 de manutenção, com seus próprios prepare, política e dois ADMIT. Seus bytes e o registro de receitas precisam ser adicionados aos pins de implementação desse plano **antes** do prepare. Ele exige que a cópia observada na fonte seja idêntica ao arquivo efetivamente executado. Também exige a capacidade real `evaluation-maintenance` emitida por `loadEvaluationAccess` para o baseline; não aceita apenas um objeto de contexto fornecido pelo chamador.

## Modos implementados no rascunho

- `capture`: captura bytes pelo observador tri-state real e por leitura limitada; reconcilia cada versão com o ID Atlas dos bytes, verifica estabilidade e chama `planOwnershipUpdate`. Preserva o universo completo em arquivos próprios e um inventário. O conjunto afetado vem do runtime, não de uma lista passada como resultado esperado.
- `prepare`: recebe essa captura, receitas declaradas e saídas nativas reais previamente seladas. Os callbacks sincronizados verificam inputs e dependências exatos e materializam somente a saída correspondente. `prepareEvaluationUpdate` continua responsável por planejamento, seleção de callbacks, identidade do target e recusa. O driver registra entrada, retorno e erro de cada callback em journal com fsync; o array `calls` do runtime é mantido separado.
- `finalize`: depois de duas decisões ADMIT novas e exatas, chama `finalizeEvaluationUpdate` e conserva o grafo privado. Não instala política, ativa projeção ou publica. Inicialização e `admit-target` permanecem operações separadas da CLI original.

O driver não cria agentes, não chama modelos, não fabrica reviews e não produz respostas. Os campos de identidade de agentes são registros externos do operador, sem autenticação implícita. Cada saída precisa conservar o despacho real, o pedido integral, a resposta original e os bytes produzidos. A conformidade sintática de um JSON não prova que uma produção nativa ocorreu.

## Trabalho ainda necessário antes de executar

1. Concluir a primeira travessia e os 14 casos do plano inicial.
2. Fixar o plano M0, registros e orçamentos finitos das sondas U1, gerações, políticas e protocolos de interrupção/retomada; preservar a obrigação original.
3. Revisar este driver e seu uso sob o guard de runtime. Fixar os seus bytes no plano de manutenção. Preparar comandos originais/recibos sem modificar a CLI S4.
4. Qualificar a ponte de produção nativa que exponha somente inputs declarados e dependências aceitas ao produtor. O rascunho `build-native-request.mjs` foi escrito e recebeu somente `node --check`; nenhum contexto foi materializado por ele. O snapshot global contém evidências de controle que não devem ser fornecidas como respostas/oracles ao produtor. O registro de receitas derivado das 13 entradas contém zero caminhos de oracle ou pacote de juiz.
5. Registrar cada produtor real e selar seu pedido/saída sem reescrever o corpo. Obter semântica nova, ligada ao resultado e aos hashes desses pedidos/respostas, antes de consumir resultados alterados como dependências aceitas.
6. Exercitar alteração, invalidação, rebuild, interrupção/retomada, restauração/rebind e reúso reais. Reutilizar controles comuns compatíveis conforme o briefing, identificando seu escopo e sem alegar execução S2 nova.

O rascunho suporta apenas os inputs `file:` efetivamente existentes neste baseline. Uma solicitação de membership não prevista recusa; não inventa uma lista vazia. Preserva snapshots e streams em diretórios novos. Não implementa retry automático nem rollback, e não chama o executor v1.

`recipe-registry.json` deriva somente as declarações dos recibos atuais: key, recipeInputKey, recipeVersion, declaredInputs, mandatoryInputs e required. O prompt de receita original não identifica por si só o novo driver; o pin separado é obrigatório. O registry ainda é DRAFT_NOT_RUN e não confere autoridade.

## Ponte de produção nativa em rascunho

`build-native-request.mjs` usa a captura real futura e `effectiveInputs` do runtime para preparar uma unidade na ordem do planner. Para uma dependência alterada, exige a saída nativa preservada e dois registros semânticos específicos do resultado. O pacote do produtor contém somente os inputs declarados daquela unidade, seu corpo anterior e os corpos das dependências selecionadas. Os textos dos pareceres não são copiados. O helper recusa caminhos reservados; não despacha agentes nem chama receitas, não escreve CAS e não produz prosa. Um recibo efetivo de admissão e sua emissão são necessários para descrever o baseline como admitido. Identidades de agentes continuam registros externos do operador, sem autenticação implícita.

Os dois executáveis localizam os pins na propriedade `implementation` do plano original guardado no CAS. Em alvos de rebuild, percorrem `original_plan` com checagem de integridade e ciclos. Isso corresponde ao código S4: os pins do plano geram observações, enquanto `candidate.implementation` guarda papéis de implementação nativa e não é o mapa de caminhos do plano. Essa correção está somente no rascunho futuro, sem alterar o runtime ou o candidato inicial.

## Configuração futura e inventários

`build-operation-config.py` também é rascunho sem execução; recebeu apenas compilação sintática Python em memória. Ele prepara comandos para as três raízes U1 declaradas, a CLI S4 original e os dois helpers acima. Exige inventários completos dos arquivos regulares fora de `.atlas`, hashes explícitos dos controles, os mesmos 1.170 arquivos do lock externo de runtime, e os bytes dos recibos nativos/capturas/reviews efetivamente usados. Política e marcador precisam estar instalados e coincidir antes das operações que exigem autoridade; o helper não os instala. O resultado é uma configuração marcada `NOT_RUN_CONFIGURATION_ONLY`, que só terá efeito mediante execução posterior pelo recorder/wrapper já fixados.

Nenhuma raiz U1, contexto de produtor, operação de manutenção ou resposta nativa foi criada durante esta preparação. Antes de congelar M0, esses rascunhos ainda precisam da conferência mecânica, do plano concreto e das decisões independentes aplicáveis.
