import { assertOperationalDiskStore } from "./store-evaluation-identity.js"
import type { Hash } from "@atlas/contracts"
import { DegenerateAnchorError } from "@atlas/knowledge"
import type { GroundedFact, StoreProjection } from "@atlas/knowledge"
import type { EmitOut } from "@atlas/tools"
import type { CommitRefusal } from "./sidecar.js"
import type { DiskStore } from "./store.js"
import { prepareClaimReceipts, REJECTED_QUARANTINED } from "./claim-receipt.js"
import type { GovernedEmitOptions } from "./claim-receipt.js"
export { REJECTED_CANDIDATE_UNREADABLE } from "./claim-receipt.js"
export const REJECTED_DEGENERATE_CANDIDATE =
  "degenerate anchor — the staged candidate's grounding names no single containing unit, so no identity can be minted for it"
export { REJECTED_QUARANTINED } from "./claim-receipt.js"
function isDegenerateAnchor(e: unknown): boolean {
  return e instanceof DegenerateAnchorError || (e as { name?: unknown } | null)?.name === "DegenerateAnchorError"
}
export function createGovernedPromote(deps: GovernedPromoteDeps): {
  readonly promote: (at: Hash, select?: PromoteSelect) => PromoteOut
} {
  const promote = (at: Hash, select?: PromoteSelect): PromoteOut => {
    assertOperationalDiskStore(deps.store) // Before even the staging read/lock; evaluation has its own exact admission route.
    // 1. READ STAGING — the store's own documented read-only decision. A decision with no `next` publishes
    //    nothing (`sidecar-commit.ts` returns before the CAS put), so this is a read that cannot write.
    const staged = deps.store.commitStaging<StoreProjection>((p) => ({ out: p }))

    // 2. AN UNREADABLE STAGING SIDECAR IS NOT AN EMPTY ONE. Treating "did not parse" as "0 candidates" is
    //    the amplification that once turned a torn read into a 402-node erasure, in the other direction: it
    //    would report a clean, complete promotion of nothing over a store whose candidates are still there
    //    and simply could not be read. The refusal is carried out whole, named, and `read:false`.
    if (!staged.settled) {
      return { read: false, refusal: staged.refusal, candidates: 0, promoted: 0, refused: 0, rows: [] }
    }

    // R2 — THE SELECTION, decided before any row reaches the door. A held row is never presented, even when named:
    // \"keep in staging\" must survive every pass. A named key no staged row carries is reported, not ignored.
    const all = [...staged.out.current.values()]
    const only = select?.only === undefined ? undefined : new Set(select.only)
    const held = select?.held ?? new Set<string>()
    const selected = all.filter((row) => only === undefined || only.has(row.nodeKey))
    const heldKeys = selected.filter((row) => held.has(row.nodeKey)).map((row) => row.nodeKey)
    const stagedKeys = new Set(all.map((row) => row.nodeKey))
    const unknown = only === undefined ? [] : [...only].filter((key) => !stagedKeys.has(key))

    const rows: PromotedRow[] = []
    for (const row of selected.filter((r) => !held.has(r.nodeKey))) {
      try {
        // Preflight ALL receipts and quarantine marks before presenting even the first claim.
        const prepared = prepareClaimReceipts(deps.store, row)
        if ("rejected" in prepared) {
          rows.push({ nodeKey: row.nodeKey, settled: false, rejected: prepared.rejected })
          continue
        }
        if (prepared.claims.some(({ fact }) => fact.kind === "advisory" && fact.quarantine !== undefined)) {
          rows.push({ nodeKey: row.nodeKey, settled: false, rejected: REJECTED_QUARANTINED })
          continue
        }
        // Authz, truth and ratification remain per-claim. Stop on refusal, without pretending that
        // separate successful emit commits can be rolled back as a cross-claim transaction.
        let out: EmitOut = { emitted: false }
        for (const claim of prepared.claims) {
          out = deps.emit(claim.fact, at, claim.receipt === undefined ? undefined : { claimReceipt: claim.receipt })
          if (!out.emitted) break
        }
        rows.push(
          out.emitted
            ? { nodeKey: row.nodeKey, settled: true, ...(out.id !== undefined ? { id: String(out.id) } : {}) }
            : {
                nodeKey: row.nodeKey,
                settled: false,
                ...(out.rejected !== undefined ? { rejected: out.rejected } : {}),
              },
        )
      } catch (e) {
        if (!isDegenerateAnchor(e)) throw e
        rows.push({ nodeKey: row.nodeKey, settled: false, rejected: REJECTED_DEGENERATE_CANDIDATE })
      }
    }

    // 5. THE FOLD — count fully settled rows, never individual claims or partially successful places.
    const promoted = rows.filter((r) => r.settled).length
    return {
      read: true,
      candidates: rows.length,
      promoted,
      refused: rows.length - promoted,
      rows,
      ...(heldKeys.length > 0 ? { held: heldKeys } : {}),
      ...(unknown.length > 0 ? { unknown } : {}),
    }
  }
  return { promote }
}
