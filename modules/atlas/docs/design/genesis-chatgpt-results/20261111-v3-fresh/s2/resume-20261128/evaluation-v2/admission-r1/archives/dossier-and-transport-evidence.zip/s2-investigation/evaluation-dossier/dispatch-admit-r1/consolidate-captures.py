"""Append capture provenance only; does not dispatch, judge or invoke Atlas."""
from pathlib import Path
import json, hashlib, re
D=Path(__file__).resolve().parent;L=D/'transport-ledger.jsonl'
old=[json.loads(x) for x in L.read_text().splitlines()]
def digest(p):
 b=p.read_bytes();return len(b),hashlib.sha256(b).hexdigest()
def append(row):
 def signature(x):
  return (x.get('event'),x.get('target'),x.get('wave'),x.get('waves'),x.get('request_sha256') or x.get('sha256'))
 sig=signature(row)
 if any(signature(x)==sig for x in old):return
 with L.open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
 old.append(row)
for p in sorted([*(D/'root-captures').glob('*j*-wave-*-send.json'),*(D/'root-captures').glob('*j*-wave-*-activation.json'),*(D/'root-captures').glob('*j*-waves-*-activation.json'),*(D/'root-captures').glob('*j*-waves-*-activation-attempt-*.json'),*(D/'root-captures').glob('*j*-wave-*-attempt-*-withdrawn.json'),*(D/'root-captures').glob('*j*-wave-*-correction-notice.json')]):
 o=json.loads(p.read_bytes())
 if 'request_path' not in o and 'request' in o:
  o={**o,'request_path':o['request']['path'],'request_utf8_bytes':o['request']['utf8_bytes'],'request_sha256':o['request']['sha256']}
 q=Path(o['request_path']);n,h=digest(q)
 assert n==o['request_utf8_bytes'] and h==o['request_sha256']
 append({'event':o.get('kind','ACTUAL_FOLLOWUP_TASK_SENT'),'target':o['target'],**({'waves':o['waves']} if 'waves' in o else {'wave':o['wave']}),'request_path':str(q),'request_utf8_bytes':n,'request_sha256':h,'source_capture':str(p),'source_capture_sha256':digest(p)[1],'observed_tool_result':o['observed_tool_result'],'host_message_id':o['host_message_id'],'host_timestamp':o['host_timestamp'],'limit':o.get('byte_attestation_limit',o.get('limit','Host serialized request bytes/IDs/timestamps not exposed.'))})
for p in sorted((D/'root-captures').glob('*j*-wave*-ack*.txt')):
 b=p.read_bytes();o=json.loads(b);judge=o['reviewer'];waves=o.get('waves') or [o['wave']]
 assert judge in ['/root/s2_j1','/root/s2_j2'] and o['kind']=='ACK_PARTIAL' and o['final_binding']=='NOT_ISSUED'
 for wave in waves:
  q=D/'acks'/f'{wave:03d}-{judge.rsplit("/",1)[1]}.txt'
  if q.exists() and q.read_bytes()!=b:
   # Preserve earlier missing-material ACKs; a later receipt is a distinct event.
   q=D/'acks'/f'{wave:03d}-{judge.rsplit("/",1)[1]}-{hashlib.sha256(b).hexdigest()[:16]}.txt'
  if q.exists():assert q.read_bytes()==b
  else:q.write_bytes(b)
  n,h=digest(q)
  append({'event':'ACK_CAPTURED_LITERAL','target':judge,'wave':wave,'path':str(q),'utf8_bytes':n,'sha256':h,'source':'root-captured exact host final response; source preserved. A consolidated ACK is copied identically for each covered wave, not rewritten.','source_capture':str(p),'host_message_id':None,'host_timestamp':None,'terminal_newline_added':False})
print(json.dumps({j:{e:sorted(x['wave'] for x in old if x.get('target')==j and x.get('event')==e) for e in ['ACTUAL_FOLLOWUP_TASK_SENT','ACK_CAPTURED_LITERAL']} for j in ['/root/s2_j1','/root/s2_j2']},indent=2))
