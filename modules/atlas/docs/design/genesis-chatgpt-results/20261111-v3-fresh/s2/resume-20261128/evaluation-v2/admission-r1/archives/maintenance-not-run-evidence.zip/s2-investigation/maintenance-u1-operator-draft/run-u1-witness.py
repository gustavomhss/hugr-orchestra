#!/usr/bin/env python3
"""DRAFT_NOT_RUN: bridge one actual U1 witness query to the original guarded CLI.

Policy installation is separate. No source answer, agent creation, vote, retry or
budget reset. Consistent original CLI refusals are forwarded literally; an invalid
guard/state capture prevents forwarding, including wrapper-only E002 failures.
"""
import argparse
import datetime
import json
from pathlib import Path
import re
import subprocess
import sys
from u1_operator_common import (BASE, HERE, INVESTIGATION, PINS, admission_evidence,
    encode, json_ref, new_external_directory, read_ref, regular, require,
    resolve_context, sha, stamp, state_capture_problems, validate_policy, write_new)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def capture(argv, directory, label):
    start = now()
    process = subprocess.run(argv, cwd=BASE, capture_output=True)
    stdout = directory / (label + '-stdout.txt')
    stderr = directory / (label + '-stderr.txt')
    write_new(stdout, process.stdout)
    write_new(stderr, process.stderr)
    write_new(directory / (label + '-invocation.json'), encode({'argv': argv, 'cwd': str(BASE),
        'started_at': start, 'ended_at': now(), 'exit_code': process.returncode, 'stdout': stamp(stdout), 'stderr': stamp(stderr)}))
    return process.returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha256', required=True)
    args = parser.parse_args()
    control_path, control_bytes, control = json_ref({'path': str(args.request), 'sha256': args.request_sha256})
    require(control['schema'] == 'genesis-s2-u1-witness-bridge-request/v1', 'U1 bridge request schema')
    context = resolve_context(control, Path(__file__).resolve())
    root = context['root']; case = control['witness_id']
    policy_path, policy_bytes, policy = json_ref(control['policy'])
    validate_policy(policy, context, 'witness', case)
    require((root / '.atlas/evaluation-policy.json').read_bytes() == policy_bytes, 'exact witness policy must already be installed')
    installation_path, installation_bytes, installation = json_ref(control['policy_installation_receipt'])
    require(installation['schema'] == 'genesis-s2-u1-policy-installation/v1'
            and installation['state'] == 'INSTALLED_EXACT_DECLARED_BYTES'
            and installation['root'] == str(root) and installation['candidate_id'] == context['candidate_id']
            and installation['generation'] == context['marker']['generation'] and installation['purpose'] == 'witness'
            and installation['witness_id'] == case and installation['policy_sha256'] == sha(policy_bytes)
            and installation['protected_state_unchanged'] is True and installation['cas_unchanged'] is True
            and installation['budgets_unchanged'] is True, 'actual U1 policy-installation evidence')
    installer = HERE / 'install-u1-policy.py'
    require(installation['installer'] == stamp(installer)
            and context['original_plan']['implementation'][context['scope']['source_paths'][installer.name]] == stamp(installer)['sha256'], 'installer identity')
    sources = context['sources'] + admission_evidence(control['admission_receipt'], context)
    dispatch_path, dispatch_bytes, dispatch = json_ref(control['dispatch'])
    require(dispatch['schema'] == 'genesis-s2-u1-actual-witness-dispatch/v1' and dispatch['state'] == 'ACTUAL_SPAWN_RECORDED', 'actual fresh witness dispatch required')
    agent = dispatch['native_agent_id']
    require(isinstance(agent, str) and agent.startswith('/root/') and agent.strip() == agent
            and dispatch['fork_turns'] == 'none' and dispatch['case_id'] == case
            and dispatch['root'] == str(root) and dispatch['candidate_id'] == context['candidate_id']
            and dispatch['generation'] == context['marker']['generation'], 'actual dispatch/context binding')
    packet_path, packet_bytes, packet = json_ref(dispatch['request_packet'])
    witness = context['scope']['witnesses'][case]
    require(sha(packet_bytes) == witness['packet_sha256'] and packet['witness_id'] == case
            and packet['mode'] == witness['mode'] and packet['limits'] == context['scope']['read_limits'][witness['mode']], 'frozen neutral witness packet')
    request_path, request_bytes, request = json_ref(control['consumer_request'])
    require(set(request) == {'kind','case_id','operation','query'} and request['kind'] == 'atlas-query'
            and request['case_id'] == case and request['operation'] in ['index','read']
            and {'mode': request['operation'], 'query': request['query']} in packet['queries'], 'literal query must be one frozen permitted request')
    operation_id = control['operation_id']
    require(isinstance(operation_id, str) and re.fullmatch(r'[A-Za-z0-9_.-]+', operation_id), 'operation id')
    output = new_external_directory(control['output_dir'], 'witnesses')
    write_new(output / 'control-used.json', control_bytes)
    write_new(output / 'consumer-request-original.txt', request_bytes)
    query_path = output / 'query.json'
    write_new(query_path, encode(request['query']))
    sources += [stamp(p) for p in [control_path, policy_path, installation_path, dispatch_path, packet_path,
        request_path, query_path, Path(__file__).resolve(), installer, root / '.atlas/evaluation-policy.json', root / '.atlas/policy.json']]
    sources += [stamp(path) for path in PINS]
    start = {'schema': 'genesis-s2-u1-reader-bridge-start/v1', 'started_at': now(), 'operation_id': operation_id,
        'case_id': case, 'native_agent_id': agent, 'root': str(root), 'candidate_id': context['candidate_id'],
        'generation': context['marker']['generation'], 'inputs': sources, 'query_semantics_equal_original': True,
        'limit': 'Actual host identity is supplied by the operator and not independently authenticated. Only a literal original reader response can be forwarded.'}
    write_new(output / 'bridge-start.json', encode(start))
    by_path = {}
    for row in sources + [stamp(output / 'bridge-start.json')]:
        require(row['path'] not in by_path or by_path[row['path']] == row, 'conflicting control hashes')
        by_path[row['path']] = row
    for row in control.get('additional_controls', []):
        path, _ = read_ref(row)
        actual = stamp(path)
        require(actual['path'] not in by_path or by_path[actual['path']] == actual, 'additional control conflicts')
        by_path[actual['path']] = actual
    command_request = {'schema': 'genesis-s2-u1-command-request/v1', 'mode': request['operation'],
        'authority_root': str(root), 'operation_id': operation_id, 'output_dir': str(output / 'runtime'),
        'candidate_id': context['candidate_id'], 'source_inventories': control['source_inventories'],
        'controls': list(by_path.values()), 'query': str(query_path), 'witness_id': case}
    command_request_path = output / 'command-request.json'
    write_new(command_request_path, encode(command_request))
    command = output / 'command.json'; runtime = output / 'runtime'
    try:
        config_exit = capture([sys.executable, str(INVESTIGATION / 'maintenance-plan/build-operation-config.py'),
            '--request', str(command_request_path), '--request-sha256', stamp(command_request_path)['sha256'],
            '--command-file', str(command)], output, 'configuration')
        require(config_exit == 0, 'configuration failed; Atlas not called')
        wrapper_exit = capture([sys.executable, str(INVESTIGATION / 'capture-state-operation.py'), str(command), str(runtime)], output, 'capture')
        receipt_path = regular(runtime / 'receipt.json')
        receipt = json.loads(receipt_path.read_bytes())
        capture_path = regular(runtime / 'state-capture.json')
        state = json.loads(capture_path.read_bytes())
        invalid = state_capture_problems(receipt, state, wrapper_exit)
        if receipt.get('operation_id') != operation_id or receipt.get('operation') != 'evaluation-' + request['operation']:
            invalid.append('runtime-receipt-operation')
        if receipt.get('corpus_root') != str(root) or receipt.get('candidate_id') != context['candidate_id']:
            invalid.append('runtime-receipt-root-candidate')
        if receipt.get('named_input_bytes_unchanged') is not True or receipt.get('external_byte_guard', {}).get('matched') is not True:
            invalid.append('external-byte-guard')
        require(not invalid, 'original response not forwarded: ' + ', '.join(invalid))
        raw = {}
        for name, filename in [('stdout','stdout.json'), ('stderr','stderr.txt')]:
            path = regular(runtime / filename); raw[name] = path.read_bytes()
            require(receipt['streams'][name]['path'] == filename and len(raw[name]) == receipt['streams'][name]['byte_length']
                    and sha(raw[name]) == receipt['streams'][name]['sha256'], 'original stream identity')
            raw[name].decode('utf-8', errors='strict')
        response = (f'Original Atlas CLI response for {case}; operation {request["operation"]}; exit_code={receipt["exit_code"]}.\n'
            f'BEGIN STDOUT UTF8 bytes={len(raw["stdout"])} SHA256={sha(raw["stdout"])}\n').encode() + raw['stdout']
        response += (f'\nEND STDOUT\nBEGIN STDERR UTF8 bytes={len(raw["stderr"])} SHA256={sha(raw["stderr"])}\n').encode() + raw['stderr'] + b'\nEND STDERR\n'
        write_new(output / 'reader-response.txt', response)
        finish = {'schema': 'genesis-s2-u1-reader-bridge-completion/v1', 'ended_at': now(), 'case_id': case,
            'native_agent_id': agent, 'operation_id': operation_id, 'root': str(root), 'candidate_id': context['candidate_id'],
            'generation': context['marker']['generation'], 'runtime_receipt': stamp(receipt_path), 'state_capture': stamp(capture_path),
            'response': stamp(output / 'reader-response.txt'), 'wrapper_exit_code': wrapper_exit,
            'original_runtime_exit_code': receipt['exit_code'], 'state_capture_consistent': True,
            'consumer_answer_created': False, 'automatic_retry': False, 'budget_reset': False}
        write_new(output / 'bridge-completion.json', encode(finish)); print(json.dumps(finish)); return 0
    except Exception as error:
        refusal = {'schema': 'genesis-s2-u1-reader-bridge-refusal/v1', 'state': 'RESPONSE_NOT_FORWARDED',
            'operation_id': operation_id, 'error': str(error), 'original_streams_retained': True,
            'effects_or_budget_undone': False, 'automatic_retry': False, 'budget_reset': False}
        write_new(output / 'bridge-refusal.json', encode(refusal)); print(json.dumps(refusal)); return 1


if __name__ == '__main__':
    raise SystemExit(main())
