from pathlib import Path
import sys, json, hashlib
D=Path(__file__).resolve().parent.parent
wave=int(sys.argv[1])
source=sys.argv[2] if len(sys.argv)>2 else 'root exact final response relay'
b=sys.stdin.buffer.read()
o=json.loads(b)
assert o['wave']==wave and o['reviewer']=='/root/s2_j1' and o['final_binding']=='NOT_ISSUED'
p=D/'acks'/f'{wave:03d}-s2_j1.txt'
if p.exists(): assert p.read_bytes()==b
else: p.write_bytes(b)
record={'event':'ACK_CAPTURED_LITERAL','target':'/root/s2_j1','wave':wave,'path':str(p),'utf8_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'source':source,'host_message_id':None,'host_timestamp':None,'terminal_newline_added':False}
ledger=D/'transport-ledger.jsonl'
old=[json.loads(x) for x in ledger.read_text().splitlines()]
if not any(x.get('event')==record['event'] and x.get('target')==record['target'] and x.get('wave')==wave for x in old):
 with ledger.open('a') as f: f.write(json.dumps(record,ensure_ascii=False)+'\n')
print(json.dumps(record,ensure_ascii=False))
