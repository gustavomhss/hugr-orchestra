import { assertOperationalDiskStore } from "./store-evaluation-identity.js"
import { isEvaluationPayload } from "./okf-store.js"
import type { Hash, Tier } from "@atlas/contracts"
import {
  isScope,
  linkSameAs,
  ratify,
  sameAsClassOf,
  sameAsEdgeState,
  stage,
  strictestTier,
  unlinkSameAs,
} from "@atlas/knowledge"
import type { Candidate, CurrentNode, GroundedFact } from "@atlas/knowledge"
import type { LinkOut } from "@atlas/tools"
import { actorInScope } from "./policy.js"
import type { AtlasPolicy } from "./policy.js"
import type { DiskStore } from "./store.js"
import {
  REJECTED_CONTENDED as COMMIT_CONTENDED,
  REJECTED_UNREADABLE_STORE as COMMIT_UNREADABLE_STORE,
} from "./governed-emit-reasons.js"
import { REJECTED_UNTRUSTED_STORE as COMMIT_UNTRUSTED } from "./read-provenance.js"
import { ALREADY_RETRACTED_REASON, NOT_LINKED_REASON, RETRACTED_PAIR_REASON } from "./governed-link-retract.js"
const REJECTED_SAME = "sameAs requires two distinct nodes"
const REJECTED_UNAUTHORIZED =
  "unauthorized: the actor must be in the scope of BOTH endpoints AND of every node in the equivalence " +
  "class this link merges — the sameAs relation is transitive, so the boundary is the class, not the edge " +
  "(KNOW-11). An endpoint that is not a current node is refused with this SAME string, deliberately: a " +
  "nodeKey with no row carries no scope, so no authority over it can be established, and reporting the two " +
  "apart would let any caller probe which nodeKeys exist. If a nodeKey here may simply be wrong, list the " +
  "territory with `atlas query <scope>` and check it against that before concluding a scope is missing."
const REJECTED_UNRATIFIED =
  "unratified: a sameAs link requires a ratifier, and the billy token when either endpoint is T0 (KNOW-8)"
const REJECTED_UNVERIFIABLE =
  "unverifiable endpoint: the stored fact of an endpoint — or of a node in the equivalence class this link " +
  "merges — is not readable from CAS, so its governance class and its scope cannot be confirmed; refused " +
  "fail-closed rather than defaulted"
const REJECTED_CONTENDED = COMMIT_CONTENDED
const REJECTED_UNREADABLE = COMMIT_UNREADABLE_STORE
function storedFact(deps: GovernedLinkDeps, node: CurrentNode): GroundedFact | undefined {
  return deps.store.get(node.contentHash as unknown as Hash) as GroundedFact | undefined
}
function rowAuthorized(deps: GovernedLinkDeps, node: CurrentNode, fact: GroundedFact | undefined): boolean {
  const authorityScope = node.scope === undefined ? fact?.scope : node.scope
  return isScope(authorityScope) && actorInScope(deps.policy, deps.actor, authorityScope)
}
function rowContradicted(node: CurrentNode, fact: GroundedFact): boolean {
  return node.scope !== undefined && fact.scope !== node.scope
}
export function createGovernedLink(deps: GovernedLinkDeps): {
  readonly link: (a: string, b: string, retract?: boolean) => LinkOut
} {
  /**
   * `retract` selects the MODE (A-D3 / task #83). ONE function, ONE gate ladder: the mode is read only at
   * stage 5 (which pure reducer to apply) and at the pair-state gate that sits immediately before it. Gates
   * 1–4 are byte-identical code for both modes, which is not a stylistic choice — it is the property. If
   * retraction ran its own ladder, an asymmetry could appear in it silently; here retracting a link that
   * merged a class containing a `T0` node requires the billy token for exactly the same reason, through
   * exactly the same lines, that asserting it did. An unratified actor cannot undo a ratified merge.
   */
  const link = (a: string, b: string, retract = false): LinkOut => {
    try { assertOperationalDiskStore(deps.store) } catch { return { linked: false, rejected: "evaluation-operation-denied" } }
    // 1. DISTINCT — a node never names itself (and there is no self-edge to withdraw either).
    if (a === b) return { linked: false, rejected: REJECTED_SAME }

    // ── THE ATOMIC COMMIT (stages 2 → 5) ────────────────────────────────────────────────────────────────
    // Every gate below is priced against ONE snapshot of the projection, and the edge is published against
    // that same snapshot or not at all. `rehydrateProjection` + `persistProjection` was a
    // read-modify-whole-file-write with no compare-and-swap, so a concurrent emit could land between the
    // read and the write and be erased by this door's whole-Map replacement — measured at 1–5 nodes lost per
    // 8-writer race, every writer reporting `status: ok` (see `sidecar.ts`).
    //
    // The callback re-runs FROM SCRATCH on a lost race, GATES INCLUDED — which matters MORE here than at the
    // emit door, because these gates are priced over the merged equivalence CLASS: a node that joins the
    // class between the snapshot and the commit changes both the authority set (`rowAuthorized` over every
    // member) and the ratify tier (`strictestTier` over every member's bytes), so re-publishing the old
    // `linkSameAs` would merge a class nobody was ever authorized over.
    const committed = deps.store.commitProjection<LinkOut>((proj) => {
      try { assertOperationalDiskStore(deps.store) } catch { return { out: { linked: false, rejected: "evaluation-operation-denied" } } }
      if ([...proj.current.values()].some((row) => isEvaluationPayload(row) || isEvaluationPayload(deps.store.get(row.contentHash as Hash))))
        return { out: { linked: false, rejected: "evaluation-operation-denied" } }

      // 2+3. AUTHORIZED ENDPOINTS (KNOW-11), FIRST LEG — ONE gate, ONE refusal [task #144]. Existence and
      //    authority are decided together and answered with the SAME bytes, because they cannot honestly be
      //    told apart to a caller: authority is carried by the ROW, so an endpoint with no row has no scope
      //    and no one can hold authority over it. Reporting `unknown node: X` separately let ANY caller —
      //    `actor: ''` included — read one bit about whether X is a current node, at keys it can name
      //    freely, which is the exact disclosure this door's header forbids. Runs before the class walk
      //    below so an actor with no authority over the nodes it NAMED learns nothing about the class behind
      //    them (the precedence rule in the header).
      //
      //    TOTALITY: the two `=== undefined` checks are load-bearing and must stay AHEAD of `rowAuthorized`
      //    in the `||` chain. Without them `storedFact`/`rowAuthorized` dereference `undefined.contentHash`
      //    and this door throws a `TypeError` out of a function its own header calls total — which the CLI's
      //    outer catch then re-labels as the CALLER's malformed input. Pinned at the unit (SCN-GL-2/2b) and
      //    at the process boundary (blackbox T3/T3b).
      //
      //    ANSWERED FROM THE ROWS, AND THAT ORDERING IS THE POINT (ADR-0007 carrier). This gate used to run
      //    AFTER the CAS read-back, because the scope it needs lived only in the bytes — so a caller with
      //    authority over NEITHER endpoint got `unverifiable endpoint` when an endpoint's bytes were pruned
      //    and `unauthorized` when they were healthy. Those two strings are a one-bit storage-health oracle
      //    over nodes the caller cannot touch, at keys it can name freely. SCN-GL-14 pinned exactly this
      //    precedence for the CLASS walk and could not pin it here, because the gate physically could not run
      //    before the read it depended on. With `scope` on the row it can, so it does.
      const nodeA = proj.current.get(a)
      const nodeB = proj.current.get(b)
      const factA = nodeA === undefined ? undefined : storedFact(deps, nodeA)
      const factB = nodeB === undefined ? undefined : storedFact(deps, nodeB)
      if (
        nodeA === undefined ||
        nodeB === undefined ||
        !rowAuthorized(deps, nodeA, factA) ||
        !rowAuthorized(deps, nodeB, factB)
      ) {
        return { out: { linked: false, rejected: REJECTED_UNAUTHORIZED } }
      }

      // 3.25 CLASS READ-BACK — both endpoints' stored facts, the source of the tier gate below. An endpoint
      //     whose bytes are gone has an unknowable tier, and one whose bytes CONTRADICT its row is a node the
      //     projection is misdescribing, so both are refused outright rather than defaulted (the same
      //     fail-closed stance, and the same corroboration rule, `governed-emit.ts`'s incumbent guard takes).
      //     `unverifiable endpoint` stays a DISTINCT reason (SCN-GL-7) — a pruned CAS is not a policy gap an
      //     admin should try to fix by granting a scope — and it is now reached ONLY by a caller already shown
      //     to hold authority over both endpoints, so it discloses nothing it has not earned.
      if (
        factA === undefined ||
        factB === undefined ||
        rowContradicted(nodeA, factA) ||
        rowContradicted(nodeB, factB)
      ) {
        return { out: { linked: false, rejected: REJECTED_UNVERIFIABLE } }
      }

      // 3.5 THE MERGED CLASS — resolved ONCE and consumed by BOTH remaining gates.
      //
      //    The relation is TRANSITIVE (`deriveSameAs` is a union-find), so linking a~b merges the WHOLE of a's
      //    class with the WHOLE of b's. Every gate on this door therefore has to be a gate on the CLASS; a gate
      //    on the EDGE is a gate on one arc of a graph whose reachability the link is extending. The tier gate
      //    below already learned that. The AUTHZ gate above had NOT: it read `factA.scope`/`factB.scope` only,
      //    which is the same defect one gate over, and it was live — policy `{secure:[alice], shared:[alice,
      //    mallory], mallory:[mallory]}`, alice links her `secure` node A to the `shared` node B, then mallory
      //    (who is nowhere near `secure`) links B to her own node M and `deriveSameAs` yields `{A,M}`: her node
      //    sits inside alice's `secure` class, and every read fold walks it, with no authority there ever
      //    granted. So the actor must hold authority in EVERY scope the merged class spans, each read off that
      //    member's OWN stored fact — the resource decides, never the request.
      //
      //    A key in `merged` that is not a CURRENT node is skipped: `sameAsClassOf` deliberately keeps dangling
      //    peers (a retired key is how two live nodes share one class), and a retired key has no readable scope,
      //    no readable class, and is served by no read fold — it is nobody's authority and nobody's governance
      //    weight. Everything reachable THROUGH it is itself in `merged` and is priced on its own fact.
      //
      //    A member that IS current but whose bytes are unreadable fails closed, exactly as `strictestTier`
      //    fails an unreadable class closed to `T0`: its scope cannot be confirmed, so no authority over it can
      //    be. It is reported `unverifiable`, not `unauthorized` — the SCN-GL-7 distinction, because an admin
      //    reading `unauthorized` would try to fix a pruned CAS by GRANTING a scope. Note this is strictly
      //    stronger than the previous tier-only treatment: before, an unreadable member merely forced billy;
      //    now no one, billy included, links across a class it cannot fully read.
      //
      //    Both passes are order-INDEPENDENT (all facts resolved, then all checked), so the reason returned
      //    never depends on the iteration order of the class.
      //    AUTHZ FIRST, BYTES SECOND — the same ordering as the endpoint gate above, for the same reason: a
      //    caller who cannot be shown to hold authority over every member must not be told which member's
      //    bytes are missing. The rows answer the authority question without any read at all.
      const merged = [...new Set([...sameAsClassOf(proj, a), ...sameAsClassOf(proj, b)])]
      const members = merged.map((key) => proj.current.get(key)).filter((m): m is CurrentNode => m !== undefined)
      const memberFacts = members.map((m) => storedFact(deps, m))
      if (!members.every((m, i) => rowAuthorized(deps, m, memberFacts[i]))) {
        return { out: { linked: false, rejected: REJECTED_UNAUTHORIZED } }
      }
      if (memberFacts.some((f, i) => f === undefined || rowContradicted(members[i]!, f))) {
        return { out: { linked: false, rejected: REJECTED_UNVERIFIABLE } }
      }
      const classFacts = memberFacts as readonly GroundedFact[]

      // 4. RATIFY (KNOW-8) — the SAME law emit runs, over the JOIN of every class this link MERGES.
      //
      //    Joining only `factA.tier` and `factB.tier` was a live two-hop bypass — billy equates a T0 node A with
      //    a T2 node B, then anyone links B to their own node M and lands inside A's class with no billy
      //    signature. The join runs over the same class resolved above; the endpoints seed it explicitly so the
      //    gate does not silently depend on `sameAsClassOf` including its own argument.
      const linkClass = classFacts.reduce<Tier>(
        (acc, f) => strictestTier(acc, f.tier),
        strictestTier(factA.tier, factB.tier),
      )
      const staged = stage({ tier: linkClass } as unknown as Candidate)
      if (!ratify(staged, { by: deps.ratifyToken ?? "" }).committed) {
        return { out: { linked: false, rejected: REJECTED_UNRATIFIED } }
      }

      // 4.5 PAIR STATE (A-D3 / task #83) — the ONLY mode-dependent gate, and it runs LAST on purpose.
      //
      //     PRECEDENCE IS THE GATE, again. Whether `{a,b}` is unlinked / linked / already-retracted is a fact
      //     about the stored relation, so answering it early would hand a caller a probe over pairs it has no
      //     authority on, at keys it can name freely — the same one-bit oracle the header's 3-before-3.25 rule
      //     exists to close. Placed after RATIFY, a caller learns the pair's state only once it has cleared
      //     authz over every scope the class spans AND produced the ratifier that class demands; anyone else
      //     gets `unauthorized` or `unratified` and learns nothing.
      //
      //     Both branches refuse rather than no-op, and the reasons say why (`governed-link-retract.ts`). The
      //     re-assert branch is load-bearing rather than tidy: `linkSameAs` is idempotent and a retraction
      //     never removes the peer from `sameAs`, so WITHOUT this the door would report `linked:true` for a
      //     re-link that changed nothing and that `deriveSameAs` goes on ignoring — a write door lying about
      //     its own effect, which is worse than having no retraction at all.
      const state = sameAsEdgeState(proj, a, b)
      if (retract && state === "absent") return { out: { linked: false, rejected: NOT_LINKED_REASON } }
      if (retract && state === "retracted") return { out: { linked: false, rejected: ALREADY_RETRACTED_REASON } }
      if (!retract && state === "retracted") return { out: { linked: false, rejected: RETRACTED_PAIR_REASON } }

      // 5. APPLY — the pure symmetric reducer for this mode. The DECISION is RETURNED, not written:
      //    publishing it is the commit's job, and only if this snapshot is still the head when the generation
      //    is linked in. `unlinkSameAs` APPENDS the retraction to both rows and removes nothing, so who
      //    asserted the edge and who withdrew it both survive in the projection.
      const next = retract ? unlinkSameAs(proj, a, b) : linkSameAs(proj, a, b)
      // `linked` reports that the governed link act SETTLED; `retracted` names WHICH act it was. A refused
      // act of either mode is `linked:false`, which is the one discriminator the handler, the CLI exit map
      // and the MCP `isError` mapping already key off — so a retraction's refusals are fail-closed-visible on
      // every transport with no new plumbing, and a SUCCESSFUL retraction is never mis-rendered as a refusal.
      return { out: retract ? { linked: true, a, b, retracted: true } : { linked: true, a, b }, next }
    })
    // 6. COMMIT — its own two refusals, visible and never silent. Identical in kind to the emit door's, and
    //    deliberately the SAME vocabulary: one protocol, one set of reason names.
    if (committed.settled) return committed.out
    const commitRefusal =
      committed.refusal === "contended"
        ? REJECTED_CONTENDED
        : committed.refusal === "untrusted"
          ? COMMIT_UNTRUSTED
          : REJECTED_UNREADABLE
    return { linked: false, rejected: commitRefusal }
  }
  return { link }
}
