import { genericOwnershipVisible, assertEvaluationComposition, phaseFilteredStore } from "./ownership-evaluation-policy.js"
import type { EvaluationAccess } from "./ownership-evaluation-policy.js"
import { createHandler, createInit, createQuery, createReconcile } from "@atlas/tools"
import type { ToolLegs, ToolLeg, NodeSource, MemoryEmitOut } from "@atlas/tools"
import type { MemoryEntry } from "@atlas/memory"
import type { MemoryEmit } from "./memory-emit.js"
import { build, createResolve, createDepgraph, createSymbolReverse, nodeHashOfPath } from "@atlas/index"
import type { Axes, FileTree, ScipOutput, SymbolReverseApi } from "@atlas/index"
import { driftDetect } from "@atlas/grounding"
import { currentNodes, deriveSameAs, deriveSubsumes, resolveFactFreshness } from "@atlas/knowledge"
import type { BoundHits, GroundedFact } from "@atlas/knowledge"
import type { Freshness, Hash, NodeKey } from "@atlas/contracts"
import type { FreshnessOracle } from "./pack-shape.js"
import { retrievalPack } from "./retrieval-model.js"
import type { CasPath, DiskStore } from "./store.js"
import { walkFileTree } from "./fs.js"
import { readScipOrEmpty, readScipIndexerName, planIndexers } from "./scip.js"
import type { LangId } from "./scip.js"
import { createIndexAdapter } from "./index-adapter.js"
import { createProjectionQueryIndex, underScope } from "./projection-query-index.js"
import { createDriftSource } from "./git-drift.js"
import { headSha } from "./run-git.js"
import { createGovernedEmit } from "./governed-emit.js"
import { ownershipInput } from "./ownership-input.js"
import { buildTargetEscapes } from "./escape/target-escapes.js"
import { buildDynamicReach } from "./escape/dynamic-reach.js"
import { createGovernedLink } from "./governed-link.js"
import { loadPolicy } from "./policy.js"
import { createDiskStore, rehydrateProjection } from "./store.js"
import type { SidecarTrust } from "./store-provenance.js"
import { UntrustedStoreError } from "./read-provenance.js"
import { foldAstUnits } from "./ast.js"
import { createForge } from "./git-forge.js"
import { createHistorySource } from "./git-history.js"
import { createSiteProposer } from "./llm.js"
const ALL_LANGS: readonly LangId[] = ["ts", "py", "go", "java", "rust", "rb"]
export function edgeModelVersion(): string {
  return planIndexers([...ALL_LANGS])
    .flatMap((p) => (p.version !== undefined ? [`${p.lang}@${p.version}`] : []))
    .sort()
    .join(",")
}
export function bindFreshnessOracle(axes: Axes, currentEdgeModel: string): FreshnessOracle {
  return (fact: GroundedFact): Freshness => {
    const base = driftDetect(fact.grounding, axes) // the sealed GROUND-1 oracle, ridden verbatim
    if (fact.kind === "advisory" || fact.kind === "predicate") return resolveFactFreshness(fact.kind, base)
    if (fact.kind !== "negation") return base // only a negation carries the edgeModel completeness clause
    return base === "FRESH" && fact.edgeModel === currentEdgeModel ? "FRESH" : "DRIFTED"
  }
}
export function assembleHandler(config: WireConfig): WiredHandler {
  assertEvaluationComposition(config.repoPath, config.evaluation)
  // The index-backing adapter (satisfies both frozen tools ports: MoveInIndex + QueryIndex) over the
  // frozen FS + SCIP outputs, driving @atlas/index. `nodeHashOfPath` is the sealed-kernel path→node keying
  // (= build's keying, `id({file})`) — the exact IndexAdapterDeps shape (cf s01 / index-adapter.test).
  // Fold sub-file AST item/block units onto the spatial FileTree BEFORE `build` (F1): `build` keys every
  // index node by `node.path` (build.ts `key: node.path`), so the folded `::`-chained unit paths become
  // resolvable index node keys — a symbol grounding re-derives FRESH and its `::` primaryAnchor lets
  // `deriveSubsumes` fire (module ⊃ function). `foldAstUnits` is SYNC and reads the module-level grammar
  // singletons; when the composition root has awaited `initAst()` (the bins do, before composeRuntime) it
  // folds real units, otherwise it is a safe additive NO-OP (file/dir nodes only) — so wire tests that never
  // warm up keep their exact prior behavior.
  // Capture the RAW (unfolded) tree so the sound-negation `dynamicReach` leg scans file bytes off the SAME
  // walk `build` folds (no second FS traversal, no divergent view). `fileTree` is the folded index input.
  //
  // DEDUP-COMPOSITION (#241) — every one of these ALREADY EXISTS on `config` when `composeRuntime` is the
  // caller (compose.ts builds all of them from this SAME `repoPath`/`scipPath` before calling this
  // function); `?? <rebuild>` is exercised ONLY by a bare WIRE assembly (no composition root — see the
  // "bare WIRE fake assembly" tests), which gets the exact prior behavior. See the `WireConfig` doc block
  // for the coherence obligation this places on callers, and `test/wire-precomputed-parity.test.ts` for the
  // guard that the two paths answer identically.
  const rawTree = config.rawTree ?? walkFileTree(config.repoPath)
  const fileTree = config.fileTree ?? foldAstUnits(rawTree)
  // DEGRADE gracefully on a fresh repo: a MISSING `.scip` dump (no `.atlas/index.scip` yet) is an empty
  // files-only index, never a throw. `readScipOrEmpty` is the ONE shared missing-file guard (scip.ts) — the
  // twin of the one `compose.ts` applies for the Axes build (COMPOSE-B).
  const scipOutput = config.scipOutput ?? readScipOrEmpty(config.scipPath)
  // #99 F1 — the indexer identity the collapsed-local gate trusts (raw dump `metadata.toolInfo.name`; the
  // frozen projection drops it). `undefined` on a missing/foreign dump ⇒ heuristic OFF (fail-closed). Bound
  // into the `createSymbolReverse` factory so the door's N0 feed carries `opaqueRefSources` under scip-typescript.
  const indexerName = config.indexerName ?? readScipIndexerName(config.scipPath)
  // `buildAxes`/`symbolReverseFor` key off the `fileTree`/`scipOutput` RESOLVED above (which may themselves
  // be a caller override), never off `config.repoPath`/`config.scipPath` directly — the coherence rule the
  // `WireConfig` doc block states: an overridden `fileTree` with no overridden `axes` REBUILDS `axes` from
  // that overridden `fileTree`, never silently serves a precomputed `axes` from a different tree.
  const buildAxes = (t: FileTree, s: ScipOutput): Axes => config.axes ?? build(t, s)
  const symbolReverseFor = (s: ScipOutput): SymbolReverseApi =>
    config.symbolReverse ?? createSymbolReverse(s, { indexerName })
  const index = createIndexAdapter({
    fileTree,
    scipOutput,
    build: buildAxes,
    createResolve,
    createDepgraph,
    createSymbolReverse: symbolReverseFor, // #99b N0 + #99 collapsed-local gate
    nodeHashOfPath, // THE index's own minting, imported — never a local copy of `id({file:p})` (KERNEL-1)
  })

  // GOVERNED DURABLE EMIT (COMPOSE-A): the emit leg persists through the governed path — the GROUND
  // truth-gate, the KNOW-11 owner-scoped authz gate (actor supplied by the composition root, fail-closed
  // to `''` when absent ⇒ every write denied), the KNOW-15 `upsert` write-decision, and durable persistence
  // (the projection sidecar + the whole fact into CAS) — over the DURABLE `createDiskStore(config.casPath)`,
  // not a throwaway in-memory map. This closes the former store-bridge TODO: the durable store is the real
  // one now. The actor is passed in via `config.actor` (resolved from env/git-config by compose.ts) — this
  // module NEVER reads `process.env` or a fact/payload for the actor (the spoof-guard boundary).
  // The ONE durable disk store this assembly rides — shared by the governed emit leg (the write side) AND
  // the projection query-readback (the read side), so `atlas query` reads back the very facts `atlas emit`
  // persists (WIRE-LOOP: emit→query is a closed loop over ONE store, never two divergent instances).
  // N11: inject the freshness-watermark seam — a cheap `git rev-parse HEAD` (no worktree). The store stamps
  // `builtAt` at each persist; the query index (below) compares it to live HEAD to flag a behind-HEAD read.
  const currentHead = (): string | undefined => headSha(config.repoPath)
  // PROVENANCE: threaded from the composition root onto the ONE store both doors ride (see `WireConfig`).
  const store = config.store ?? createDiskStore(config.casPath, currentHead, config.trusted)
  // TRAVEL-BY-REPROOF — the store every READ leg below uses. `config.readStore`, when supplied (the
  // composition root's `read-access.ts` decision), may be `store` verbatim (`trusted`) or a raw re-read
  // FILTERED to facts that replay `re-proven` (`tracked-provable`) — either way it is built ONCE, upstream,
  // never re-decided here. ABSENT (a bare WIRE fake assembly, no composition root) ⇒ falls back to `store`,
  // the EXACT prior behaviour every wire-only test relies on. WRITES always ride `store` — this split never
  // touches the write path.
  const readStore = phaseFilteredStore(config.readStore ?? store)

  // ADR-0016 M2b — the TWO v2 negation closure legs, built ONCE off the SAME `scipPath`/`repoPath`/`rawTree`
  // as the other emit-leg deps. Both-or-neither (a half-gate is never run): if either cannot be built SOUNDLY
  // (AST grammars not warmed — `assembleHandler` is sync and a wire-only fake never calls `initAst()` — or the
  // dump is unreadable) the door falls back to the sound `holeSources() ∩ S` blanket, exactly as #99b shipped.
  // DEDUP-COMPOSITION (#241): `compose.ts` already built these (off the SAME `scipPath`/`repoPath`/
  // `rawTree`) for its own promote leg — reuse them when supplied; a bare WIRE assembly still builds here.
  const negTargetEscapes =
    config.targetEscapes ?? buildTargetEscapes({ scipPath: config.scipPath, repoPath: config.repoPath })
  const negDynamicReach = config.dynamicReach ?? buildDynamicReach(rawTree)
  const escapeLegs =
    negTargetEscapes !== undefined && negDynamicReach !== undefined
      ? { targetEscapes: negTargetEscapes, dynamicReach: negDynamicReach }
      : {}

  const governedEmit = createGovernedEmit({
    store,
    ownershipInput: (key) => ownershipInput(config.repoPath, key),
    ...(config.evaluation === undefined ? {} : { evaluation: config.evaluation }),
    gate: config.seams.gate,
    policy: loadPolicy(config.repoPath),
    actor: config.actor ?? "",
    // The ratify token rides the SAME env-sourced, payload-free channel as the actor. Conditional spread
    // keeps it ABSENT (not `undefined`) when unset — `exactOptionalPropertyTypes`, so the door defaults to ''.
    ...(config.ratifyToken !== undefined ? { ratifyToken: config.ratifyToken } : {}),
    // #99b N2 — THE NEGATION LEG's channels. `symbolReverse` is the N0 completeness feed off the SAME
    // assembled index surface `blastRadius` rides; `axes`/`nodeHashOfPath` are the live structural rail the
    // abstention gate resolves the scope-Merkle and the `∩ S` containment against; `edgeModel` is the pinned
    // extractor release stamped onto an admitted negation (§3 clause 4). ABSENT `config.axes` (bare-WIRE fake)
    // ⇒ a negation abstains fail-closed, exactly as `--by dependency` fails closed there.
    symbolReverse: () => index.symbolReverse(),
    ...(config.axes !== undefined ? { axes: config.axes } : {}),
    nodeHashOfPath,
    edgeModel: edgeModelVersion(),
    // ADR-0016 M2b — the v2 target-relative legs (both or neither; empty spread ⇒ the sound blanket fallback).
    ...escapeLegs,
  })

  // GOVERNED sameAs LINK (WP-SAMEAS): the second governed write door — asserts a human `a ≡ b` equivalence
  // over the SAME durable disk store + admin policy + env-sourced actor/ratifyToken channels as emit. Four
  // fail-closed gates (distinct → both-known → authz-on-both → ratifier) before it persists a symmetric edge;
  // NON-destructive (never a merge). The projection it mutates is the SAME `store` the query readback rides,
  // so a linked edge surfaces on the very next `atlas query` (the WIRE-LOOP holds for link→query too).
  const governedLink = createGovernedLink({
    store,
    policy: loadPolicy(config.repoPath),
    actor: config.actor ?? "",
    ...(config.ratifyToken !== undefined ? { ratifyToken: config.ratifyToken } : {}),
  })

  // THE PER-FACT FRESHNESS ORACLE (ADR-0013 / REQ-TOOLS-6d amended). `driftDetect` over the composition
  // root's ALREADY-BUILT `Axes` — the very oracle over the very axes the WRITE door's truth-gate rides
  // (`compose.ts` `buildGate(axes)`), never a second freshness notion and never a git call on the read path.
  //
  // ABSENT `config.axes` (the bare WIRE fake assembly — no composition root) ⇒ the seam is NOT wired and
  // every row reads `DRIFTED`, fail-closed (`resolveFreshness`, pack-shape.ts). It does NOT fall back to the
  // stored `fact.freshness`, which no read path writes back and which therefore says `FRESH` forever.
  const axes = config.axes
  // The family-aware oracle (N4): `driftDetect` verbatim for every fact, PLUS the §3 clause-4 `edgeModel`
  // conjunct for a negation, against the current edge model at read (`edgeModelVersion()` — the same value the
  // door stamps at emit). ONE seam, branched on family — the query path and the negation read leg share it.
  const freshnessOracle = axes === undefined ? undefined : bindFreshnessOracle(axes, edgeModelVersion())

  // Seam-1: wrap the pure structural index-adapter with the durable projection readback, so a scope resolves
  // to its covering territory skeleton (from @atlas/index) FOLDED with the emitted facts under it (from CAS).
  // TRAVEL-BY-REPROOF: rides `readStore`, not `store` — for a `tracked-provable` repo this is the raw,
  // re-proof-filtered store (`read-access.ts`); for everything else it IS `store` (see `readStore` above).
  const queryIndex = createProjectionQueryIndex(index, readStore, currentHead, freshnessOracle, config.hits)

  const legs: ToolLegs = {
    "atlas-init": ((args) =>
      createInit(index, config.seams.heuristic).init((args as { path: string }).path)) satisfies ToolLeg,
    // Seam-3: the query leg's `Verdict.data` is the `{ pack, subsumes }` observability envelope. `subsumes`
    // is `deriveSubsumes` (its FIRST production call site — DP-2 resolution-at-read) filtered to the edges
    // whose BOTH endpoints are current nodes UNDER the covering scope, already deterministically sorted.
    "atlas-query": ((args) => {
      // PROVENANCE, BEFORE ANY MODE SPLIT (TRAVEL-BY-REPROOF: now `config.readRefusal`, not a blanket
      // `trusted` check — a `tracked-provable` repo has NO refusal here and falls through to a query over the
      // already-filtered `readStore`). `ok:true` + an empty pack is indistinguishable from "no knowledge
      // yet" — the silent-disappearance failure this product treats as the worst one available. Refusing here
      // (a throw the frozen handler converts into a structured rejected `Verdict`, TOOLS-2) covers EVERY read
      // mode from one line: putting it inside the `--by scope` branch would have left `--by dependency`
      // serving the same refused rows with no refusal, which is exactly how the seam was missed the first
      // time (`WireConfig.readRefusal` records the twin of this mistake for the store instance itself).
      if (config.readRefusal !== undefined) throw new UntrustedStoreError()
      const a = args as { scope: string; by?: string }
      // N2: `--by dependency|trigger` routes THROUGH the designed three-mode `createRetrieval` surface (INDEX-6),
      // NOT re-implemented here. `scope` (the default, and every MCP/wire-fake call) stays the byte-identical
      // pre-existing projection path below. The mode is marshal-validated ∈ {scope,dependency,trigger} (CLI).
      const by = a.by
      if (by === "dependency" || by === "trigger") {
        if (axes === undefined || freshnessOracle === undefined) {
          // No structural axes wired at this seam (bare WIRE fake assembly) — fail closed; the handler wraps
          // this throw into a structured rejected Verdict (TOOLS-2), never a raw throw at the user door.
          // The oracle is checked in the SAME breath because it is derived from the very same `axes`: this
          // branch is the one place a row could otherwise be served with the fail-closed default verdict,
          // and refusing is better than serving a whole pack of rows marked `DRIFTED` for a wiring reason.
          throw new Error("atlas query --by dependency|trigger needs the composition-root axes")
        }
        // retrievalPack rebuilds the read model FRESH from the live store each call — freshness parity w/ scope.
        return retrievalPack(axes, by, a.scope, readStore, freshnessOracle)
      }
      const scope = a.scope
      const pack = createQuery(queryIndex).query(scope)
      const proj = rehydrateProjection(readStore)
      const underKeys = new Set(
        currentNodes(proj)
          .filter((n) => n.primaryAnchor !== undefined && underScope(n.primaryAnchor, scope))
          .map((n) => n.nodeKey),
      )
      const subsumes = deriveSubsumes(proj).filter((s) => underKeys.has(s.broader) && underKeys.has(s.narrower))
      // WP-SAMEAS: the derived human equivalence edges, scoped EXACTLY like `subsumes` — both endpoints must
      // be current nodes UNDER the covering scope. `deriveSameAs` is transitive (union-find) + pre-sorted.
      const sameAs = deriveSameAs(proj).filter((e) => underKeys.has(e.a) && underKeys.has(e.b))
      return { pack, subsumes, sameAs }
    }) satisfies ToolLeg,
    "atlas-emit": ((args) =>
      governedEmit.emit(
        (args as { node: import("@atlas/knowledge").GroundedFact }).node,
        (args as { at: import("@atlas/contracts").Hash }).at,
        // R8: the schema declares `replace` as a boolean, so anything but `true` was refused before this line.
        (args as { replace?: unknown }).replace === true ? { replace: true } : undefined,
      )) satisfies ToolLeg,
    // WP-SAMEAS: the governed sameAs link leg — routes through the ONE handler like every other tool. Reads
    // the two nodeKeys off the marshalled `{a,b}` arg shape (CLI marshal.ts / MCP inputSchema both supply it).
    // [A-D3 / task #83] `retract` selects the MODE on the SAME leg and the SAME tool — no sixth tool, no
    // second leg, so CLI and MCP reach retraction through one code path and cannot diverge. Compared to the
    // literal `true`: the published schema declares `retract` as a boolean, so anything else is refused as
    // `malformed-args` at the door BEFORE this line, and the CLI marshaller hands over a real boolean.
    "atlas-link": ((args) =>
      governedLink.link(
        (args as { a: string }).a,
        (args as { b: string }).b,
        (args as { retract?: unknown }).retract === true,
      )) satisfies ToolLeg,
    "atlas-reconcile": ((args) =>
      createReconcile(
        createDriftSource({
          repoPath: config.repoPath,
          resolveAnchorAt: config.seams.resolveAnchorAt,
          // N10 — thread the content-addressed resolver so `driftAt` surfaces a pure rename (spread keeps it
          // ABSENT, not `undefined`, when a fake omits it — exactOptionalPropertyTypes).
          ...(config.seams.resolveBySubtreeAt !== undefined
            ? { resolveBySubtreeAt: config.seams.resolveBySubtreeAt }
            : {}),
          facts: config.seams.driftFacts,
        }),
        config.seams.classifier,
      ).reconcile(
        (args as { mergeBase: import("@atlas/contracts").Hash }).mergeBase,
        (args as { options?: import("@atlas/tools").ReconcileOptions }).options,
      )) satisfies ToolLeg,
    // WP-11.W8 — the governed MEMORY write door. A LITERAL top-level key (ARCH-3: a spread here would hide
    // the leg from `layer-guard.mjs`'s static scan while leaving it fully invocable), always present; the
    // body throws when `config.memoryEmit` is absent (bare WIRE fake assembly, no composition root), which
    // the frozen handler's existing catch converts to a structured rejected `Verdict` (TOOLS-2). On a real
    // composed runtime this folds `@atlas/memory`'s `MemoryVerdict` (from `createMemoryEmit`) into the
    // `MemoryEmitOut` shape `@atlas/tools` owns — `admitted:false` is the ONE discriminator `isFailClosedWrite`
    // keys off (mirrors `emitted`/`linked`), `refusal` is the named MEM gate, `rejected` is its human reason.
    "atlas-memory-emit": ((args) => {
      if (config.memoryEmit === undefined) {
        throw new Error("atlas-memory-emit: no memory write door composed at this seam")
      }
      const entry = (args as { entry: MemoryEntry }).entry
      const verdict = config.memoryEmit.emit(entry)
      if (verdict.ok) {
        return { admitted: true, record: verdict.record } satisfies MemoryEmitOut
      }
      return {
        admitted: false,
        refusal: verdict.refusal,
        rejected: `${verdict.refusal}: ${verdict.reason}`,
      } satisfies MemoryEmitOut
    }) satisfies ToolLeg,
  }

  // The DAG-pin references NOT wired as handler legs (frozen skeleton edges): the git-forge / history /
  // site-proposer seams. (The AST fold is now REALLY wired — the index FileTree pipeline above; the durable
  // disk store is REALLY wired — the emit leg.)
  void [createForge, createHistorySource, createSiteProposer]

  // N6: the READ-ONLY per-node projection source (TOOLS-10). `resolveNode(addr)` reads the whole fact back
  // from CAS by its CONTENT ADDRESS — the SAME durable store the query readback + governed emit ride (the CAS
  // bytes ARE the fact). READ-ONLY: it opens NO write path (writes funnel through the governed doors `atlas-emit`/`atlas-link`, TOOLS-1);
  // a miss ⇒ `undefined` (the handler renders a structured "no grounded node" rejection, never a throw).
  const nodes: NodeSource = {
    resolve: (nodeAddr) => {
      // PROVENANCE — the leg that goes AROUND `loadProjection`. Everything else on the read side rehydrates
      // the sidecar, where the tripwire lives; this one reads CAS by content address DIRECTLY, and `.atlas/cas/**`
      // is committed by the same `git add -f` that lands the sidecar (`isDurableStorePath` covers both). So a
      // committed blob came back WHOLE over `atlas node <addr>` with `ok:true`, with every write door denying.
      // It USED to return `undefined` here — fail-closed but indistinguishable from an ordinary miss —
      // because the frozen `resolveNode` did not wrap this call in a try/catch, so a throw would have escaped
      // as a raw exception at the user door. `resolveNode` now catches and attributes (packages/tools/src/
      // fault.ts), so the refusal can travel the channel `ToolLeg` already uses and reach EVERY transport
      // with its own discriminant instead of being flattened into "no grounded node at <addr>". The CLI
      // still refuses one frame up with the same reason; this is the backstop for every other caller.
      // TRAVEL-BY-REPROOF: `config.readRefusal` (case 3 / fail-closed), not a blanket `trusted` check. AND —
      // this leg goes AROUND `loadProjection` (see above), which is exactly why `readStore.get` (not plain
      // `store.get`) matters here for `tracked-provable`: `read-access.ts` builds `readStore.get` to answer
      // `undefined` for any content hash that is NOT among the re-proven current nodes' `contentHash`es, so
      // an attacker-committed CAS blob that never re-proves — reachable ONLY through this address-direct
      // leg, never through the filtered projection — is refused here too, not just in `loadProjection`.
      if (config.readRefusal !== undefined) throw new UntrustedStoreError()
      // SECURITY (billy PoC): `nodeAddr` is attacker-controllable over MCP/poke. A CAS content address is
      // EXACTLY 64 lowercase hex; anything else (a `../` traversal to an unbounded file like /dev/zero) is a
      // MISS — rejected BEFORE any filesystem read, so it can never hang/OOM. Defense-in-depth: `store.get`
      // re-applies the same charset + sandbox guard (store.ts). READ-ONLY: no write path (TOOLS-1).
      if (config.evaluation !== undefined) {
        assertEvaluationComposition(config.repoPath, config.evaluation)
        return undefined
      }
      const addr = String(nodeAddr)
      if (!/^[0-9a-f]{64}$/.test(addr)) return undefined
      const value = readStore.get(addr as unknown as Hash)
      if (!genericOwnershipVisible(value) || value === null || typeof value !== "object" || !("grounding" in value)) return undefined
      return value as GroundedFact
    },
  }

  // ONE handler over the five legs + the read-only per-node source — no per-entrypoint copy (WIRE-1).
  if (config.evaluation !== undefined) {
    // Evaluation consumers use only the budgeted ownership reader; no other tool is granted.
    for (const name of Object.keys(legs)) if (name !== "atlas-emit")
      (legs as Record<string, ToolLeg>)[name] = () => { throw new Error("evaluation-operation-denied") }
  }
  return createHandler(legs, nodes)
}
