# S2-U1 — conferência mecânica estática dos rascunhos

Esta conferência leu os seis rascunhos de `maintenance-plan/`, as interfaces relevantes do runtime `db9b4235022c4df32fe3bfd4faeea8adcd69abb7` e o plano S2-U1 preservado. Ela não executou Atlas, os helpers inspecionados, testes, produtores ou juízes. Nenhuma raiz U1, policy, candidato ou decisão foi criada. As fontes originais permaneceram idênticas em bytes.

O relatório integral é `report.json`: 98.799 bytes, SHA-256 `497a1343eb591b4b6286adf88da0d86b56ecbd0c0c8a53f436ee957f8ea40d27`. Ele contém identidade completa de cada fonte, trechos literais com números de linha, diferenças, condições de ocorrência e propostas. `snapshots/` preserva os textos efetivamente examinados. `collect_static_evidence.py` faz apenas leitura de arquivos, comparação de JSON, SHA/Git blob e `git show` dos objetos fixados; não importa código Atlas ou os drafts.

## Diferenças concretas

### MECH-01 — validação de caminho mais fraca que a CLI

`build-operation-config.py`, linhas 64–68, recusa somente os segmentos exatos `.atlas` e `.git`. Não aplica a equivalência Unicode NFC, a recusa de texto inteiramente branco, o tratamento sem distinção de maiúsculas desses segmentos nem a recusa de segmento terminado em ponto/espaço. `genesis-native-format.ts`, linhas 34–56, aplica essas condições.

Assim, um futuro caminho como `docs/.ATLAS/binding.json` ou `docs./binding.json` pode atravessar o preflight do configurador e ser recusado pela CLI original. Os exemplos são deduções das expressões presentes nas fontes; não foram executados. Não se afirma que algum caminho atual use essas formas.

**Proposta:** tornar `relative()` equivalente a `nativeText`/`nativePath`. Preservar os gates do runtime.

### MECH-02 — o pedido selado não é comparado com a receita aplicada

O builder emite `recipe: chosen.recipe` em `build-native-request.mjs`, linhas 179–188. Ao consumir uma saída anterior, suas linhas 108–154 conferem a linhagem, os inputs e as dependências, mas não comparam o campo `recipe` do pedido preservado com o registro aplicável. O driver também confere a linhagem nas linhas 182–191 e inputs/dependências nas linhas 215–229, sem essa comparação.

Portanto, um pedido selado com os mesmos inputs/dependências e um campo `recipe` divergente ou ausente não é distinguido por esses checks. O gate `recipeVersion` de db9 verifica a receita no registro e sua observação de fonte; ele não verifica esse campo do pedido do produtor. O plano S2-U1 exige correspondência da combinação input/dependency/recipe (S2-U1-PLAN.md, linhas 68–72).

O caminho normal do builder atual escreve a declaração esperada. Este achado identifica uma comparação ausente na leitura de registros fornecidos; não é uma alegação de que houve produção divergente.

**Proposta:** exigir igualdade exata do `producerRequest.recipe` com a entrada aplicável do registro antes de aceitar uma saída, incluindo no limite do callback. Se o schema ganhar referência explícita ao registro, congelar essa mudança e seus novos hashes antes de M0.

### MECH-03 — somente uma das duas formas de NativeReference é suportada

O configurador acessa diretamente `ref['payload_path']` em `build-operation-config.py`, linhas 174–179 e 217–226. Já o runtime admite tanto `{payload_path, sha256}` quanto `{commit, path, sha256}` (`genesis-native-format.ts`, linhas 59–75; `genesis-evaluation-binding.ts`, linhas 24–32). O driver usa corretamente `nativeReferencePath` ao finalizar.

Uma referência válida na segunda forma causa erro de chave na configuração, embora seja aceita pelo contrato db9. Não existe binding U1 nesta conferência, e um fluxo explicitamente limitado a referências locais por payload evita essa condição.

**Proposta:** implementar resolução e validação das duas formas ou declarar formalmente o subconjunto payload-only, com recusa clara da outra forma antes de gerar configuração. Esta é uma limitação de compatibilidade, não uma falha observada em uma admissão.

### MECH-04 — os arquivos gerados pelos helpers precisam de vínculo no recibo

`build-operation-config.py` inicia `output_files = []` e acrescenta somente o arquivo de saída de `prepare` pela CLI (linhas 196–208). Os modos dos helpers não acrescentam seus arquivos (linhas 233–259). O recorder fixado faz o inventário dos outputs somente dessa lista (`record-operation.py`, linhas 143–156); o wrapper captura o estado `.atlas`, não o diretório externo do driver.

Em especial, o modo capture salva `capture.json` e os arquivos de fontes capturadas, mas o stdout conserva apenas seu caminho, quantidade e plano, sem hash do inventário salvo (`u1-evaluation-operation.mjs`, linhas 138–160). O hash fixado em uma operação posterior prova quais bytes posteriores foram usados, mas sozinho não prova quais bytes o capture gravou originalmente.

Há cobertura parcial que deve ser preservada: stdout de prepare/finalize contém os objetos completos de resultado, e stdout do builder nativo já contém hashes de `producer-request.json` e `task.txt`. Não se afirma ausência geral de evidência ou perda de arquivos. A lacuna é o vínculo imediato dos demais outputs com seu recibo original.

**Proposta:** retornar no stdout de cada helper um inventário dos arquivos gerados com tamanho/SHA-256, ou preencher `output_files` com as saídas determinísticas e preservar imediatamente um inventário fechado. Manter recorder e wrapper fixados sem alteração; distinguir captura original de empacotamento posterior.

## Pontos conferidos que estão coerentes nas fontes atuais

**`original_plan` e `implementation`.** A passagem solicitada está correta. `prepareEvaluation` observa os arquivos enumerados em `plan.implementation` (`genesis-evaluation.ts`, linhas 69–72). O `candidate.implementation` é outro mapa, de papéis nativos (linhas 94–96). O plano produzido por rebuild omite `implementation` e guarda o CAS ID do plano anterior em `original_plan` (`evaluation-rebuild.ts`, linhas 198–213). Ambos os helpers percorrem essa cadeia com checagens de identidade/ciclo e consultam o mapa do plano inicial. O limite explícito de profundidade é suficiente para as duas transições propostas M0→M1→M2; não foi qualificado para cadeias arbitrárias.

**Assinaturas e separação dos objetos.** Os campos passados a `prepareEvaluationUpdate` e `finalizeEvaluationUpdate` correspondem às interfaces inspecionadas. O driver preserva o resultado completo em `prepare-result.json` para finalize e separa `target-prepared.json` no formato v2 aceito por init-store/admit-target. O configurador não inventa um modo rebuild/finalize da CLI.

**Receitas.** As 13 entradas do registro coincidem, em ordem, com os inputs e as dependências do prepared-03 já existente. Os `recipeVersion` correspondem às observações armazenadas; `recipeInputKey` está nos obrigatórios; os obrigatórios coincidem com os declarados. Todos são `file:` e não há segmento reservado segundo a expressão efetivamente usada pelo builder. Essa é comparação de dados, sem nova computação de candidato ou julgamento de conteúdo.

**Validade blocked.** O driver calcula um preview de ID para resultado supported, mas devolve a validade efetiva ao runtime. db9 recusa `blocked` antes de criar o resultado supported (`evaluation-rebuild.ts`, linhas 177–185). O preview não demonstra promoção de um resultado blocked. Contagens do journal, retornos de callback, `calls` do produto e chamadas nativas continuam distintas.

**Identidades dos rascunhos.** Os cinco arquivos enumerados em `draft-helper-inventory.json` têm tamanhos e SHA-256 iguais aos registrados. Os nove arquivos de runtime citados foram comparados byte a byte com os objetos Git do commit db9. Não se repetiram os checks sintáticos históricos anotados no inventário.

## Limites e sequência que ainda precisam ser fixados

Os IDs e orçamentos das sondas U1, o plano M0 e seus caminhos de implementação, as gerações, policies, produções reais e decisões futuras continuam pendentes. Esta conferência não torna o plano inicial d1 elegível para manutenção.

O driver trabalha no CAS da raiz de autoridade. A CLI de init/admit-target lerá o CAS da raiz target. A cópia de CAS já prevista pelo plano deve incluir os objetos novos do target e toda a linhagem exigida depois de prepare/finalize, antes de init/admit-target. Uma cópia feita somente antes do update não contém esses objetos novos.

O plano estático anterior ainda registra que o driver não existia; DRIVER-DRAFT.md descreve os rascunhos posteriores. Uma nota aditiva deve explicar essa cronologia, sem reescrever o registro histórico.

Nada neste diretório é parecer, voto, decisão ADMIT ou evidência de execução U1. As quatro diferenças acima são verificáveis nas fontes preservadas e não representam uma prova exaustiva de correção ou incorreção do sistema.
