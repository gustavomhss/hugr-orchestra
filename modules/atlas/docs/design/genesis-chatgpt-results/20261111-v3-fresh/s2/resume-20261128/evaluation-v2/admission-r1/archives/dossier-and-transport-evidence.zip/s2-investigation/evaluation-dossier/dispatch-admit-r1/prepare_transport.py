#!/usr/bin/env python3
"""Prepare literal requests only. This script sends no collaboration messages."""
from pathlib import Path
import json
import hashlib

ROOT=Path('/workspace/scratch/5cfbb6c803f1/s2-investigation/evaluation-dossier')
OUT=ROOT/'dispatch-admit-r1'
PIN='c9ee2edf05f8c07fef7ca0e86cb5abf52872f63abcc141efbcecdbc5f8589be9'
raw=(ROOT/'review-core/manifest.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()==PIN
m=json.loads(raw)
chunks=[c for c in m['chunks'] if c['tier']=='core' or c['group'] in m['mandatory_supplement_groups']]
assert len(chunks)==34
candidate='d1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30'
intro='''NOVA REVISÃO V2, MESMO JUIZ PERSISTENTE. Finalidade: isolated-evaluation-admission. Preserve integralmente o HOLD V1; esta revisão não o revoga.
Você receberá 34 ondas de material literal da seleção fixada e uma mensagem final de encerramento. Você continua sem ferramentas: não leia arquivos, não navegue, não execute código e não acione outros agentes. O transportador envia o mesmo material a ambos os juízes, preservando separação das respostas. Nenhum parecer de seu par será fornecido.
O candidato exato é d1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30; prepared SHA-256 bb3ee09693ef1ddfb89e548f3f5e0d38c4abaee5e6d253f129c7c6c1a9dbda0e; runtime db9b4235022c4df32fe3bfd4faeea8adcd69abb7. Manifesto da seleção: c9ee2edf05f8c07fef7ca0e86cb5abf52872f63abcc141efbcecdbc5f8589be9.
Sua revisão final deve cobrir TODAS as 13 entries e, em cada uma, exatamente ADMIT-EXACT-TRANSFORM, ADMIT-SOURCE-BINDINGS, ADMIT-SEMANTIC-SCOPE e ADMIT-ISOLATED-PLAN. Não transfira PASS histórico para ADMIT; não emita PASS de AC-01..10/runtime-import-binding, consumidor, manutenção ou campanha. Avalie por conta própria a lacuna intrínseca @noble/hashes, seu limite temporal e o guard externo proposto: o transportador não os declara resolvidos.
Até receber a mensagem FINAL-REQUEST-CLOSE, devolva somente ACK parcial e eventuais achados/dúvidas provisórios. Não produza binding nem voto final antes do fim. ACK confirma recebimento do texto apresentado; não equivale a verificação criptográfica dos hashes declarados sem ferramentas.
Formato breve de ACK: {"kind":"ACK_PARTIAL","reviewer":"sua identidade canônica real","wave":n,"received_chunk_order":n,"findings_partial":[],"missing_or_unreadable":[],"final_binding":"NOT_ISSUED"}. Preserve a independência do seu julgamento. Se material estiver insuficiente, diga exatamente o que falta; não invente evidência. Depois da última onda ainda aguarde o fechamento explícito.
'''
records=[]
for i,c in enumerate(chunks,1):
    payload=(ROOT/c['file']).read_bytes()
    assert len(payload)==c['utf8_bytes'] and hashlib.sha256(payload).hexdigest()==c['sha256']
    prefix=(intro if i==1 else '')+f'ONDA {i:02d}/34 — purpose isolated-evaluation-admission; candidate {candidate}.\nChunk original {c["order"]:03d}; UTF-8 bytes {c["utf8_bytes"]}; SHA-256 {c["sha256"]}.\nACK parcial somente; nenhum binding final nesta onda. Conteúdo literal completo abaixo; não há substituição por resumo.\nBEGIN_FIXED_CHUNK\n'
    message=prefix.encode()+payload+b'END_FIXED_CHUNK\n'
    path=OUT/'messages'/f'{i:03d}.txt';path.parent.mkdir(exist_ok=True);path.write_bytes(message)
    records.append(dict(wave=i,kind='material',message_file=str(path.relative_to(OUT)),message_utf8_bytes=len(message),message_sha256=hashlib.sha256(message).hexdigest(),chunk_order=c['order'],chunk_sha256=c['sha256'],chunk_utf8_bytes=len(payload),message_payload_byte_start=len(prefix.encode()),message_payload_byte_end=len(prefix.encode())+len(payload)))
closing='''FINAL-REQUEST-CLOSE — isolated-evaluation-admission.
As 34 ondas da seleção fixada foram fornecidas. Este fechamento pede seu parecer ORIGINAL e INDEPENDENTE; não é instrução para aprovar. Julgue o candidato d1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30 nos quatro critérios ADMIT de cada uma das 13 entries. V1 HOLD e todos os critérios/obrigações finais originais continuam intactos.
Se qualquer material necessário faltar, tiver sido truncado ou não puder ser sustentado, emita HOLD e identifique o pedido exato. Não adapte critérios para obter PASS. Não pressuponha que o controle externo proposto corrige a identidade intrínseca ou a captura histórica ausente. A adequação da lacuna @noble/hashes, reconciliação posterior e guard proposto é uma questão sua de julgamento.
Retorne um único objeto JSON, sem ferramentas, usando sua identidade canônica real em reviewer; purpose exatamente isolated-evaluation-admission; candidate_id exato; verdict global conforme seu julgamento; entries com TODAS as 13 chaves e seus contract/result/inputs exatos transportados. Cada entry deve conter criteria com os quatro IDs ADMIT exatos e o verdict que você decidir para cada critério. Acrescente findings e limits completos para explicar fundamentação e escopo. Nenhum verdict foi preenchido previamente pelo transportador.
Estrutura esperada (placeholders são instrução de formato, não votos):
{"reviewer":"<sua identidade real>","purpose":"isolated-evaluation-admission","candidate_id":"d1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30","verdict":"<seu parecer global>","entries":[{"key":"<chave real>","contract":"<ID exato>","result":"<ID exato>","inputs":"<inputs_id exato>","criteria":[{"id":"ADMIT-EXACT-TRANSFORM","verdict":"<seu parecer>"},{"id":"ADMIT-SOURCE-BINDINGS","verdict":"<seu parecer>"},{"id":"ADMIT-SEMANTIC-SCOPE","verdict":"<seu parecer>"},{"id":"ADMIT-ISOLATED-PLAN","verdict":"<seu parecer>"}]}],"findings":[],"limits":[]}
As 13 chaves são s2.l1.desktop-web, s2.l1.app-session, s2.l1.design-tui, s2.l2.desktop-web, s2.l2.app-session, s2.l2.design-tui, s2.l3.desktop-web, s2.l3.app-session, s2.l3.design-tui, s2.l4.desktop-web, s2.l4.design-tui, s2.l4.app-session, s2.l4.entry. Preserve seus IDs individuais. Não invente message IDs, timestamps de host, request_ref, response_ref ou hash da própria resposta. Os recibos de transporte e hashes do texto original serão calculados após o retorno, sem mudar os votos.
'''
message=closing.encode();path=OUT/'messages/035.txt';path.write_bytes(message)
records.append(dict(wave=35,kind='final-request-close',message_file='messages/035.txt',message_utf8_bytes=len(message),message_sha256=hashlib.sha256(message).hexdigest()))
full=b''.join((OUT/r['message_file']).read_bytes() for r in records);(OUT/'full-request-prepared.txt').write_bytes(full)
prepared=dict(schema='s2-original-admission-request-transport/v1',purpose='isolated-evaluation-admission',candidate_id=candidate,selection_manifest_sha256=PIN,recipients=['/root/s2_j1','/root/s2_j2'],state='PREPARED_NOT_SENT',messages=records,concatenation='Exact message bytes in numeric order; no separators added; boundaries fixed by each message_utf8_bytes.',full_request_utf8_bytes=len(full),full_request_sha256=hashlib.sha256(full).hexdigest(),host_message_ids='NOT_EXPOSED',host_send_timestamps='NOT_EXPOSED',limitations=['Script only prepares requests; real sends and ACKs require a separate ledger.','Content of the selected34 chunks is unchanged.','No judgment issued and no judge response shared with the other reviewer.'])
(OUT/'prepared-requests.json').write_text(json.dumps(prepared,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(full_request_utf8_bytes=len(full),full_request_sha256=hashlib.sha256(full).hexdigest(),waves=34,closing_message=35,state='PREPARED_NOT_SENT')))
