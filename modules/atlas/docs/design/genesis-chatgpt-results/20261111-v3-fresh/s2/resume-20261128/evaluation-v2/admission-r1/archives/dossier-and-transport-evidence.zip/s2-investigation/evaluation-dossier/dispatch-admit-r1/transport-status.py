"""Read-only transport accounting; emits no semantic or ADMIT judgment."""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent
rows=[json.loads(s) for s in (D/'transport-ledger.jsonl').read_text().splitlines()]
judges={}
for j in ['s2_j1','s2_j2']:
 out={'invocation_recorded_waves':[],'acknowledged_content_waves':[],'queued_without_activation':[],'missing_requests':[],'missing_ack':[],'negative_receipt_history':[],'recorded_attempt_failures':[],'base_request_bytes_excluding_corrections':0,'activation_bytes':0}
 for n in range(1,40):
  rr=[r for r in rows if r.get('target')=='/root/'+j and (r.get('wave')==n or n in r.get('waves',[]))]
  direct=[r for r in rr if r.get('event')=='ACTUAL_FOLLOWUP_TASK_SENT' or (r.get('tool')=='collaboration.followup_task' and r.get('observed_tool_result')=='empty visible return; no error')]
  queued=[r for r in rr if r.get('event') in ['ACTUAL_SEND_MESSAGE_QUEUED','ACTUAL_SEND_MESSAGE_QUEUED_WITH_TRANSCRIPTION_ERROR']]
  active=[r for r in rr if r.get('event') in ['ACTUAL_FOLLOWUP_ACTIVATION_SENT','ACTUAL_FOLLOWUP_ACTIVATION']]
  delivered=bool(direct or (queued and active))
  if queued and not active:out['queued_without_activation'].append(n)
  if delivered:
   out['invocation_recorded_waves'].append(n)
   source=(direct or [r for r in queued if r.get('event')=='ACTUAL_SEND_MESSAGE_QUEUED_WITH_TRANSCRIPTION_ERROR'] or queued)[0];p=Path(source.get('request_path') or D/source['request_file']);b=p.read_bytes()
   assert len(b)==source['request_utf8_bytes'] and hashlib.sha256(b).hexdigest()==source['request_sha256']
   out['base_request_bytes_excluding_corrections']+=len(b)
   for a in active:
    q=Path(a['request_path']);c=q.read_bytes();assert len(c)==a['request_utf8_bytes'] and hashlib.sha256(c).hexdigest()==a['request_sha256']
    if n==max(a.get('waves',[n])):out['activation_bytes']+=len(c)
  else:out['missing_requests'].append(n)
  positive=False
  for a in sorted((D/'acks').glob(f'{n:03d}-{j}*.txt')):
   o=json.loads(a.read_bytes());assert o['reviewer']=='/root/'+j and (o.get('wave')==n or n in o.get('waves',[])) and o['final_binding']=='NOT_ISSUED'
   detail=o.get('received_by_wave',{}).get(str(n),{})
   if not isinstance(detail,dict):detail={}
   if detail.get('state')=='LITERAL_MESSAGE_NOT_AVAILABLE':
    out['negative_receipt_history'].append({'wave':n,'path':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'state':detail['state']})
   else:positive=True
  if positive:out['acknowledged_content_waves'].append(n)
  elif delivered:out['missing_ack'].append(n)
  out['recorded_attempt_failures'].extend({'wave':n,'host_result':r.get('host_result',r.get('observed_tool_result'))} for r in rr if r.get('event') in ['FOLLOWUP_TASK_REJECTED','FOLLOWUP_ACTIVATION_FAILED'])
 judges[j]=out
ready=all(not x['missing_requests'] and not x['missing_ack'] for x in judges.values())
closing_targets=sorted({r['target'] for r in rows if r.get('event')=='ACTUAL_FINAL_REVIEW_REQUEST_SENT'})
report={'schema':'s2-transport-accounting/v2','status':'ALL_39_WAVES_ACCOUNTED_FOR' if ready else 'IN_PROGRESS','judges':judges,'closing_may_be_prepared_after_additional_ack-content_check':ready,'closing_sent':closing_targets==['/root/s2_j1','/root/s2_j2'],'closing_sent_targets':closing_targets,'judge_verdict':None,'limitation':'Invocation records do not establish receipt on their own. Negative receipt history remains preserved; recovery ACKs are distinct files. Digests attest external message files. Host does not expose serialization/delivery-byte digests. ACKs are receipt evidence, never approval. Final actual-request concatenations separately include correction/retransmission messages and boundaries.'}
(D/'transport-status.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
