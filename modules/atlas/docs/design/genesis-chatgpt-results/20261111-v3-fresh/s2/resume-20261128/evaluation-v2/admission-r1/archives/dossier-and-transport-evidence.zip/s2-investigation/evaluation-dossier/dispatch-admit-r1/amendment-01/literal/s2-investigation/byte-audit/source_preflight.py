"""Read/hash only. Inspect the exact files consumed by prepareNativePackage; never execute it."""
from pathlib import Path, PurePosixPath
import collections
import datetime
import hashlib
import json
import os
import re
import stat
import subprocess
import unicodedata

OUT = Path(__file__).resolve().parent
CORPUS = Path('/workspace/scratch/5cfbb6c803f1/s2-corpus')
RUNTIME = Path('/workspace/scratch/5cfbb6c803f1/s2-runtime')
PIN = 'bb2a931301d541692b11e5a7f1eab234cd9ed2fd'
RUNTIME_PIN = 'db9b4235022c4df32fe3bfd4faeea8adcd69abb7'
PACKAGE_PATH = 'modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2/native-package.json'
PACKAGE_SHA256 = '9356cefcb4a1db413e67869a855fd082536476fb18ff7784dde39f051e9b407b'
ENV = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}

def git(repo, *args):
    result = subprocess.run(['git', '-C', str(repo), *args], env=ENV, capture_output=True, check=False)
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8', errors='replace'))
    return result.stdout

def digest(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def tree(repo, revision):
    return {item.split(b'\t', 1)[1].decode(): item.split(b'\t', 1)[0].decode().split()[2] for item in git(repo, 'ls-tree', '-r', '-z', revision).split(b'\0') if item}

observed_head = git(CORPUS, 'rev-parse', 'HEAD').decode().strip()
runtime_head = git(RUNTIME, 'rev-parse', 'HEAD').decode().strip()
status_before = git(CORPUS, 'status', '--porcelain=v1').decode()
code_paths = [f'modules/atlas/packages/adapter-io/src/{name}' for name in ['genesis-native.ts', 'genesis-native-io.ts', 'genesis-native-format.ts', 'ownership-input.ts']]
code = {p: (RUNTIME / p).read_bytes() for p in code_paths}
source_limit = 2 * 1024 * 1024
transport_limit = 8 * 1024 * 1024
assert b'ownershipInputMaxBytes = 2 * 1024 * 1024' in code[code_paths[3]]
assert b'nativeMaxBytes = 8 * 1024 * 1024' in code[code_paths[1]]
package_bytes = (CORPUS / PACKAGE_PATH).read_bytes()
pack = json.loads(package_bytes)
requests = collections.defaultdict(list)

def add(path, role, artifact=None, sha256=None, git_blob_sha=None, commit=None, limit=transport_limit, byte_length=None, utf8=False):
    requests[path].append({'role': role, 'artifact': artifact, 'sha256': sha256, 'git_blob_sha': git_blob_sha, 'commit': commit, 'max_bytes': limit, 'byte_length': byte_length, 'utf8_required': utf8})

def preserve(ref, role, artifact=None):
    add(ref.get('payload_path', ref.get('path')), role, artifact, sha256=ref['sha256'], commit=ref.get('commit'))

add(PACKAGE_PATH, 'package', sha256=PACKAGE_SHA256, byte_length=332594, utf8=True)
preserve(pack['protocol_ref'], 'protocol_ref')
preserve(pack['contract']['oracle_ref'], 'contract.oracle_ref')
protocol_path = pack['protocol_ref'].get('payload_path', pack['protocol_ref'].get('path'))
for artifact in pack['artifacts']:
    key = artifact['key']
    for field in ['recipe_ref', 'producer_request_ref', 'producer_response_ref']:
        preserve(artifact[field], field, key)
    for field in ['semantic_review_refs', 'runtime_receipt_refs']:
        for ref in artifact[field]:
            preserve(ref, field, key)
    for ref in artifact['source_refs']:
        add(ref['path'], 'source_ref', key, sha256=ref['sha256'], git_blob_sha=ref['git_blob_sha'], commit=ref['commit'], limit=source_limit)
    for input_key in set(artifact['input_keys'] + ['file:' + protocol_path]):
        if not input_key.startswith('file:'):
            raise ValueError('Unexpected non-file input: ' + input_key)
        add(input_key[5:], 'file_input', key, limit=source_limit)
    add(str(PurePosixPath(PACKAGE_PATH).parent / artifact['body']['path']), 'body', key, sha256=artifact['body']['sha256'], byte_length=artifact['body']['byte_length'], utf8=True)

trees = {}
pin_errors = {}
for revision in {PIN} | {x['commit'] for rs in requests.values() for x in rs if x['commit']}:
    try:
        trees[revision] = tree(CORPUS, revision)
    except RuntimeError as error:
        pin_errors[revision] = str(error)

records = []
failures = []
for relative, roles in sorted(requests.items()):
    issues = []
    parts = relative.split('/')
    allowed = (unicodedata.normalize('NFC', relative) == relative and not re.search(r'[\\:*?"<>|\x00-\x1f\x7f]', relative) and all(part and part not in ['.', '..'] and part.lower() not in ['.git','.atlas'] and not re.search(r'[. ]$',part) for part in parts))
    if not allowed:
        issues.append('native-path-refused')
    p = CORPUS / relative
    data = None
    try:
        for n in range(1, len(parts) + 1):
            current = CORPUS.joinpath(*parts[:n])
            metadata = current.lstat()
            if stat.S_ISLNK(metadata.st_mode) or (n < len(parts) and not stat.S_ISDIR(metadata.st_mode)) or (n == len(parts) and not stat.S_ISREG(metadata.st_mode)):
                raise ValueError('native-file-kind: ' + str(current))
        before = p.stat()
        data = p.read_bytes()
        after = p.stat()
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            issues.append('changed-during-read')
    except (OSError, ValueError) as error:
        issues.append(str(error))
    actual_sha = digest(data) if data is not None else None
    actual_blob = blob(data) if data is not None else None
    if data is not None:
        for role in roles:
            if len(data) > role['max_bytes']:
                issues.append('over-limit:' + role['role'])
            if role['sha256'] is not None and role['sha256'] != actual_sha:
                issues.append('sha256-drift:' + role['role'])
            if role['git_blob_sha'] is not None and role['git_blob_sha'] != actual_blob:
                issues.append('git-blob-drift:' + role['role'])
            if role['byte_length'] is not None and role['byte_length'] != len(data):
                issues.append('length-drift:' + role['role'])
            if role['utf8_required']:
                try:
                    data.decode('utf-8', errors='strict')
                except UnicodeDecodeError:
                    issues.append('invalid-utf8:' + role['role'])
            if role['commit']:
                if role['commit'] not in trees:
                    issues.append('commit-unavailable:' + role['commit'])
                elif trees[role['commit']].get(relative) != actual_blob:
                    issues.append('pinned-commit-blob-drift:' + role['role'])
    role_names = sorted({r['role'] for r in roles})
    if PIN in trees and trees[PIN].get(relative) != actual_blob:
        issues.append('working-file-differs-from-head')
    record = {'path': relative, 'roles': role_names, 'artifact_keys': sorted({r['artifact'] for r in roles if r['artifact']}), 'byte_length': len(data) if data is not None else None, 'sha256': actual_sha, 'git_blob_sha': actual_blob, 'head_blob_sha': trees.get(PIN, {}).get(relative), 'pinned_commits': sorted({r['commit'] for r in roles if r['commit']}), 'input_limit': min(r['max_bytes'] for r in roles), 'expected_sha256': sorted({r['sha256'] for r in roles if r['sha256']}), 'expected_git_blob_sha': sorted({r['git_blob_sha'] for r in roles if r['git_blob_sha']}), 'issues': sorted(set(issues)), 'status': 'PASS' if not issues else 'DRIFT_OR_UNAVAILABLE'}
    records.append(record)
    if issues:
        failures.append(record)

final_head = git(CORPUS, 'rev-parse', 'HEAD').decode().strip()
status_after = git(CORPUS, 'status', '--porcelain=v1').decode()
global_issues = []
if observed_head != PIN or final_head != PIN:
    global_issues.append('corpus-head-mismatch-or-changed')
if runtime_head != RUNTIME_PIN:
    global_issues.append('runtime-head-mismatch')
if status_before != status_after:
    global_issues.append('corpus-status-changed-during-preflight')
report = {
    'schema': 'genesis-s2-source-preflight/v1',
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'command': 'python3 source_preflight.py',
    'operation': 'Read-only comparison of every file prepareNativePackage consumes against package hashes, body lengths, source Git blob identities, commit-pinned Git trees and the actual corpus working files.',
    'corpus': {'path': str(CORPUS), 'expected_head': PIN, 'observed_head_before': observed_head, 'observed_head_after': final_head, 'git_status_before': status_before, 'git_status_after': status_after},
    'runtime': {'path': str(RUNTIME), 'head': runtime_head, 'source_input_max_bytes': source_limit, 'transport_body_max_bytes': transport_limit, 'inspected_code': [{'path':p,'sha256':digest(b),'git_blob_sha':blob(b)} for p,b in code.items()]},
    'package_sha256': digest(package_bytes),
    'status': 'PASS_SOURCE_PREFLIGHT_ONLY' if not failures and not global_issues else 'DRIFT_OR_UNAVAILABLE',
    'unique_files_checked': len(records),
    'role_reference_counts': dict(collections.Counter(r['role'] for rs in requests.values() for r in rs)),
    'role_unique_file_counts': {role:sum(role in r['roles'] for r in records) for role in sorted({x['role'] for rs in requests.values() for x in rs})},
    'files_over_historical_256000_limit': [{'path':r['path'],'byte_length':r['byte_length'],'sha256':r['sha256']} for r in records if r['byte_length'] is not None and r['byte_length'] > 256000 and ('file_input' in r['roles'] or 'source_ref' in r['roles'])],
    'max_source_input_bytes': max(r['byte_length'] or 0 for r in records if 'file_input' in r['roles'] or 'source_ref' in r['roles']),
    'git_tree_pin_errors': pin_errors, 'global_issues': global_issues,
    'failures': failures, 'files': records,
    'limits': [
        'No prepare, binding, publication, consumer, Atlas runtime observation or product test executed.',
        'This preflight checks file bytes and Git tree binding only; it does not synthesize OwnershipInput.version or candidate IDs.',
        'The actual prepare must still enforce descriptor-bound reads, race checks, format validation and CAS writes.',
        'No .git object, index, ref, corpus source, package or frozen case was changed by this script; GIT_OPTIONAL_LOCKS=0 used for read-only Git commands.',
    ],
}
(OUT/'source-preflight.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key: report[key] for key in ['status','unique_files_checked','role_reference_counts','role_unique_file_counts','files_over_historical_256000_limit','max_source_input_bytes','global_issues','git_tree_pin_errors','failures']},indent=2))
