from pathlib import Path
import json,hashlib,sys,datetime
D=Path(__file__).resolve().parent;n=int(sys.argv[1]);mode=sys.argv[2];judge=sys.argv[3] if len(sys.argv)>3 else 's2_j1';assert judge in ['s2_j1','s2_j2']
assert mode in ['queued','activated']
if mode=='queued':
 p=(D/'delta-reader-capture-01/039.txt') if n==39 else D/'delta-release-01'/f'{n:03d}.txt' if 35<=n<=38 else (D/'delta-import-context-01/034.txt') if n==34 else D/('amendment-01' if n<=30 else 'delta-setup-01')/'messages'/f'{n:03d}.txt'
 event='ACTUAL_SEND_MESSAGE_QUEUED';observed='empty successful collaboration.send_message return; no error'
 T=D/'activation-triggers';T.mkdir(exist_ok=True)
 t=f'Ativação da onda{n:02d}: processe somente a mensagem literal ONDA{n:02d} já enfileirada nesta conversa. Responda ACK_PARTIAL conforme o cabeçalho, sem fechamento; final_binding=NOT_ISSUED.'
 q=T/f'{n:03d}-{judge}.txt'
 if q.exists():assert q.read_bytes()==t.encode()
 else:q.write_bytes(t.encode())
else:
 p=D/'activation-triggers'/f'{n:03d}-{judge}.txt';event='ACTUAL_FOLLOWUP_ACTIVATION_SENT';observed='empty successful collaboration.followup_task return; no error'
b=p.read_bytes();row={'event':event,'target':'/root/'+judge,'wave':n,'request_path':str(p),'request_utf8_bytes':len(b),'request_sha256':hashlib.sha256(b).hexdigest(),'observed_tool_result':observed,'host_message_id':None,'host_timestamp':None,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limit':'Literal queued wave and short activation trigger are two distinct requests. Both are preserved for concatenation. Host serialized request bytes/IDs/timestamps are not exposed.'}
L=D/'transport-ledger.jsonl';old=[json.loads(x) for x in L.read_text().splitlines()]
if not any(x.get('event')==event and x.get('target')==row['target'] and x.get('wave')==n for x in old):
 with L.open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
s=D/'dispatch-state.json';o=json.loads(s.read_bytes())
if mode=='activated':
 o.setdefault('last_actual_wave_by_judge',{})[judge]=n
 o.setdefault('pending_queued_wave_by_judge',{}).pop(judge,None)
else:o.setdefault('pending_queued_wave_by_judge',{})[judge]=n
s.write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps(row,ensure_ascii=False))
