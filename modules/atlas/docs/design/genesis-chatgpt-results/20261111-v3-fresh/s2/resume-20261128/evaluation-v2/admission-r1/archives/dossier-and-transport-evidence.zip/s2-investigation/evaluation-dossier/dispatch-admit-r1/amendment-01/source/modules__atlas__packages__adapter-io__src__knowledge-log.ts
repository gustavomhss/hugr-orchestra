import { assertOperationalStateDirectory, assertOperationalDiskStore, assertEvaluationDiskStore } from "./store-evaluation-identity.js"
import { assertEvaluationComposition } from "./ownership-evaluation-policy.js"
import type { EvaluationAccess } from "./ownership-evaluation-policy.js"
import { existsSync, mkdirSync, readdirSync, writeFileSync } from "node:fs"
import { dirname, join } from "node:path"
import { eventId } from "@atlas/kernel"
import type { Event } from "@atlas/kernel"
import type { CurrentNode, StoreProjection } from "@atlas/knowledge"
import type { Hash } from "@atlas/contracts"
import { createDurableLog, jsonlFiles, readDurableLogs } from "./durable-log.js"
import { blobPath, knowledgeShardPath, membersDir, segment } from "./layout.js"
import type { DiskStore } from "./store.js"
export type KnowledgeSource =
  | { readonly card?: string; readonly attempt?: string; readonly commit?: string }
  | { readonly migrated: true }
export interface KnowledgeEntry {
  readonly seat: string
  readonly row: CurrentNode
  readonly at: string
  readonly source: KnowledgeSource
}
export interface KnowledgeRead {
  readonly rows: ReadonlyMap<string, KnowledgeEntry>
  readonly rejected: number
  readonly unreadable?: true
}
export function appendKnowledge(repoPath: string, entry: KnowledgeEntry, blob: unknown, evaluation?: EvaluationAccess): void {
  if (evaluation === undefined) assertOperationalStateDirectory(join(repoPath, ".atlas"))
  else {
    assertEvaluationComposition(repoPath, evaluation)
    evaluation.assert("admit")
    const claim = `Evaluation-only ownership manifest for ${evaluation.scope}: ${evaluation.context.evaluationCandidate}`
    if (entry.row.claims.length !== 1 || entry.row.claims[0] !== claim || blob === null || typeof blob !== "object" ||
      !("claimNorm" in blob) || blob.claimNorm !== claim || !("ownership" in blob)) throw new Error("evaluation-log-authority")
  }
  const event: Omit<Event, "id"> = {
    seq: 0,
    nodeKey: entry.row.nodeKey as NonNullable<Event["nodeKey"]>,
    contentHash: entry.row.contentHash as Hash,
    fresh: true,
    supersedes: [],
    payload: entry,
  }
  createDurableLog(knowledgeShardPath(repoPath, entry.seat, entry.row.nodeKey)).append({ ...event, id: eventId(event) })
  const path = blobPath(repoPath, entry.row.contentHash)
  if (blob === undefined || existsSync(path)) return
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, JSON.stringify(blob))
}
export function readKnowledge(repoPath: string): KnowledgeRead {
  const seats = seatDirs(membersDir(repoPath))
  const reads = seats.dirs.map((dir) => {
    const files = jsonlFiles(join(membersDir(repoPath), dir, "knowledge"))
    const read = readDurableLogs(files.paths)
    const events = [...read.log.values()]
    const entries = events.flatMap((ev) => {
      const entry = ev.payload
      return isEntry(entry) && segment(entry.seat) === dir && entry.row.nodeKey === ev.nodeKey ? [entry] : []
    })
    return { entries, rejected: read.rejected + events.length - entries.length, unreadable: files.unreadable ?? read.unreadable }
  })
  const rows = new Map<string, KnowledgeEntry>()
  reads.flatMap((r) => r.entries).forEach((entry) => {
    const prior = rows.get(entry.row.nodeKey)
    if (prior === undefined || later(entry, prior)) rows.set(entry.row.nodeKey, entry)
  })
  const rejected = reads.reduce((n, r) => n + r.rejected, 0)
  return seats.unreadable === true || reads.some((r) => r.unreadable === true) ? { rows, rejected, unreadable: true } : { rows, rejected }
}
export function withKnowledgeLog(
  store: DiskStore,
  opts: { readonly repoPath: string; readonly seat: string; readonly source?: KnowledgeSource; readonly now?: () => string; readonly evaluation?: EvaluationAccess },
): DiskStore {
  // The card and attempt come from the host, through `ATLAS_CARD` and `ATLAS_ATTEMPT`, unless the caller names them.
  const source = opts.source ?? {
    ...(process.env.ATLAS_CARD === undefined ? {} : { card: process.env.ATLAS_CARD }),
    ...(process.env.ATLAS_ATTEMPT === undefined ? {} : { attempt: process.env.ATLAS_ATTEMPT }),
  }
  return {
    ...store,
    commitProjection(decide) {
      const checkPhase = () => {
        if (opts.evaluation === undefined) assertOperationalDiskStore(store)
        else { assertEvaluationComposition(opts.repoPath, opts.evaluation); opts.evaluation.assert("admit"); assertEvaluationDiskStore(store, opts.evaluation.root) }
      }
      checkPhase()
      const seen: { before?: StoreProjection; next?: StoreProjection | undefined } = {}
      const result = store.commitProjection((projection) => {
        checkPhase()
        const decision = decide(projection)
        seen.before = projection
        seen.next = decision.next
        return decision
      })
      if (!result.settled || seen.before === undefined || seen.next === undefined) return result
      const before = seen.before
      const at = (opts.now ?? (() => new Date().toISOString()))()
      ;[...seen.next.current.values()]
        .filter((row) => JSON.stringify(before.current.get(row.nodeKey)) !== JSON.stringify(row))
        .forEach((row) =>
          appendKnowledge(opts.repoPath, { seat: opts.seat, row, at, source }, store.get(row.contentHash as Hash), opts.evaluation),
        )
      return result
    },
  }
}
const later = (a: KnowledgeEntry, b: KnowledgeEntry): boolean =>
  a.at !== b.at ? a.at > b.at : a.row.contentHash > b.row.contentHash
function seatDirs(dir: string): { readonly dirs: readonly string[]; readonly unreadable?: true } {
  try {
    return {
      dirs: readdirSync(dir, { withFileTypes: true })
        .filter((e) => e.isDirectory())
        .map((e) => e.name)
        .sort(),
    }
  } catch (e) {
    if ((e as { code?: unknown } | null)?.code === "ENOENT") return { dirs: [] }
    return { dirs: [], unreadable: true }
  }
}
const isText = (v: unknown): v is string => typeof v === "string" && v.length > 0
function isEntry(v: unknown): v is KnowledgeEntry {
  if (v === null || typeof v !== "object") return false
  const o = v as Record<string, unknown>
  const row = o.row as Partial<CurrentNode> | null | undefined
  if (typeof o.seat !== "string" || !isText(o.at) || o.source === null || typeof o.source !== "object") return false
  return row !== null && typeof row === "object" && isText(row.nodeKey) && isText(row.contentHash)
}
