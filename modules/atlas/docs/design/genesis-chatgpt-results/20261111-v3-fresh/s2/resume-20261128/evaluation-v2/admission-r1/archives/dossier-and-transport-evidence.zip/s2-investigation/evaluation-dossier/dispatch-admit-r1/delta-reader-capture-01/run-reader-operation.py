#!/usr/bin/env python3
"""Execute one consumer-selected original Atlas CLI request and preserve its streams.

Operator bridge only. It creates no agent, answer, review or admission; it does
not read source/body files to answer a consumer and never resets budget state.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path('/workspace/scratch/5cfbb6c803f1')
ROOT = BASE / 's2-evaluation'
INVESTIGATION = BASE / 's2-investigation'
OUTPUT_BASE = BASE / 's2-execution/consumers'
CANDIDATE = 'd1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30'
GENERATION = '694110e9b70b62ca59fe3a0edf91157066f991bb79fcaab27a1b005320bc3488'
MARKER_SHA = 'b191a34d21a16337044e5a30f41fba19338feb3123dd606bf3d9e945e7158497'
GOVERNANCE_SHA = 'edc84d9c4809be52f1ccea1b72851aa54c11fa81777a890c988a05b00e97cf22'
PINS = {
    INVESTIGATION / 'operation-config.py': '4e7d3bd974b43df6310c46e1a1b70cfab34d509adeff1f06d72735c775f51e82',
    INVESTIGATION / 'capture-state-operation.py': 'b7022b3205d04f02b6fceaee94d2f7912f15271be6ee4b2e4d7c62ba0013a441',
    INVESTIGATION / 'record-operation.py': '0185ccf143d7a5d1112b573fd0405da899b27d112cb4c7b431e1cbb1da629b30',
    INVESTIGATION / 'install-evaluation-policy.py': 'bcc872714754ee469ab6ab337288e9f0994a5f64e902fc6d8d2a869395b9c4cb',
    INVESTIGATION / 'evaluation-authority/evaluation-policies-consumer.draft.json': '50ca61068826dd0f10570bc6a2c3b7cf1a927ed2805874dd519d97b34d06a83b',
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def regular(path):
    path = path.absolute()
    assert path.resolve(strict=True) == path and path.is_file()
    assert not path.is_symlink() and path.stat().st_nlink == 1
    return path


def stamp(path):
    path = regular(path)
    data = path.read_bytes()
    return {'path':str(path), 'byte_length':len(data), 'sha256':sha(data)}


def write_new(path, data):
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def capture(argv, directory, label):
    start = now()
    process = subprocess.run(argv, cwd=BASE, capture_output=True)
    end = now()
    stdout = directory / (label + '-stdout.txt')
    stderr = directory / (label + '-stderr.txt')
    write_new(stdout, process.stdout)
    write_new(stderr, process.stderr)
    record = {'argv':argv, 'cwd':str(BASE), 'started_at':start, 'ended_at':end,
              'exit_code':process.returncode, 'stdout':stamp(stdout), 'stderr':stamp(stderr)}
    write_new(directory / (label + '-invocation.json'), encode(record))
    return process.returncode


def state_capture_problems(receipt, state, wrapper_exit=None):
    """Check the fixed wrapper's evidence before forwarding any reader body.

    A real CLI refusal can have a nonzero exit and is still forwarded when its
    capture is consistent. A wrapper-only capture failure is not such a refusal.
    """
    problems = []
    if state.get('schema') != 'genesis-s2-runtime-state-capture/v1':
        problems.append('state-capture-schema')
    if state.get('operation_id') != receipt.get('operation_id'):
        problems.append('state-capture-operation')
    if state.get('wrapper_sha256') != PINS[INVESTIGATION / 'capture-state-operation.py']:
        problems.append('state-capture-wrapper-identity')
    if state.get('recorder_sha256') != PINS[INVESTIGATION / 'record-operation.py']:
        problems.append('state-capture-recorder-identity')
    if state.get('original_runtime_receipt_exists') is not True:
        problems.append('state-capture-missing-receipt')
    for side in ('before', 'after'):
        if state.get(side + '_matches_original_recorder_inventory') is not True:
            problems.append('state-capture-' + side + '-mismatch')
        if state.get('state_' + side) != receipt.get('state_files_' + side):
            problems.append('state-capture-' + side + '-inventory')
    if state.get('recorder_exit_code') != receipt.get('exit_code'):
        problems.append('state-capture-recorder-exit')
    if wrapper_exit is not None and wrapper_exit != receipt.get('exit_code'):
        problems.append('state-capture-wrapper-exit')
    return problems


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dispatch', type=Path, required=True)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--admission-receipt', type=Path, required=True)
    parser.add_argument('--admission-receipt-sha256', required=True)
    parser.add_argument('--operation-id', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    for path, expected in PINS.items():
        assert stamp(path)['sha256'] == expected, 'operator helper bytes changed: ' + str(path)
    dispatch_path = regular(args.dispatch)
    request_path = regular(args.request)
    admission_path = regular(args.admission_receipt)
    assert stamp(admission_path)['sha256'] == args.admission_receipt_sha256
    dispatch = json.loads(dispatch_path.read_bytes())
    assert dispatch['schema'] == 'genesis-s2-actual-consumer-dispatch/v1'
    assert dispatch['state'] == 'ACTUAL_SPAWN_RECORDED'
    case = dispatch['case_id']
    agent = dispatch['native_agent_id']
    assert isinstance(agent, str) and agent.startswith('/root/') and agent.strip() == agent
    assert dispatch['fork_turns'] == 'none'
    assert dispatch['candidate_id'] == CANDIDATE and dispatch['generation'] == GENERATION
    packet = regular(Path(dispatch['request_packet']['path']))
    assert stamp(packet)['sha256'] == dispatch['request_packet']['sha256']
    # The declaration records the actual host spawn supplied by the operator.
    # It is not an authenticated identity or an independently observed spawn.
    admission = json.loads(admission_path.read_bytes())
    assert admission['operation'] == 'evaluation-admit' and admission['exit_code'] == 0
    assert admission['returned_candidate_id'] == CANDIDATE
    assert admission['response_kind'] == 'evaluation-admission-attempt'
    assert admission['named_input_bytes_unchanged'] is True
    assert admission['external_byte_guard']['matched'] is True
    admission_capture = regular(admission_path.parent / 'state-capture.json')
    assert not state_capture_problems(admission, json.loads(admission_capture.read_bytes())), 'admission state capture inconsistent'
    admission_stdout = regular(admission_path.parent / 'stdout.json')
    original_stream = admission['streams']['stdout']
    assert original_stream['path'] == admission_stdout.name
    assert stamp(admission_stdout)['sha256'] == original_stream['sha256']
    assert admission_stdout.stat().st_size == original_stream['byte_length']
    admitted = json.loads(admission_stdout.read_bytes())
    assert admitted['candidate_id'] == CANDIDATE and admitted['generation'] == GENERATION
    assert admitted['emission']['ok'] is True and admitted['emission']['data']['emitted'] is True
    policies = json.loads((INVESTIGATION / 'evaluation-authority/evaluation-policies-consumer.draft.json').read_bytes())
    assert case in policies
    intended_policy = encode(policies[case])
    request_raw = request_path.read_bytes()
    request = json.loads(request_raw)
    assert set(request) == {'kind','case_id','operation','query'}
    assert request['kind'] == 'atlas-query' and request['case_id'] == case
    assert request['operation'] in ('index','read') and isinstance(request['query'],dict)
    assert args.operation_id and all(c.isalnum() or c in '-_.' for c in args.operation_id)
    out = args.output_dir.absolute()
    assert out.is_relative_to(OUTPUT_BASE) and out != OUTPUT_BASE
    assert not out.exists()
    out.parent.mkdir(parents=True, exist_ok=True)
    assert out.parent.resolve(strict=True) == out.parent
    out.mkdir()
    write_new(out / 'consumer-request-original.txt', request_raw)
    query_path = out / 'query.json'
    write_new(query_path, encode(request['query']))
    assert json.loads(query_path.read_bytes()) == request['query']
    prelude = {'schema':'genesis-s2-reader-bridge-attempt/v1','started_at':now(),
               'operation_id':args.operation_id,'case_id':case,'native_agent_id':agent,
               'dispatch':stamp(dispatch_path),'request':stamp(request_path),
               'packet':stamp(packet),'bridge':stamp(Path(__file__).absolute()),
               'admission_receipt':stamp(admission_path),'admission_stdout':stamp(admission_stdout),
               'admission_state_capture':stamp(admission_capture),
               'query':stamp(query_path),'query_semantics_equal_original':True,
               'limit':'Literal request/response operator bridge. No answer generation, agent creation, identity authentication, budget reset or raw-source substitute.'}
    write_new(out / 'bridge-start.json', encode(prelude))
    policy_exit = capture([sys.executable,str(INVESTIGATION / 'install-evaluation-policy.py'),case,str(out / 'policy-revision')],out,'policy')
    assert policy_exit == 0, 'policy installation failed; Atlas not called'
    assert stamp(ROOT / '.atlas/evaluation-store.json')['sha256'] == MARKER_SHA
    assert stamp(ROOT / '.atlas/policy.json')['sha256'] == GOVERNANCE_SHA
    assert (ROOT / '.atlas/evaluation-policy.json').read_bytes() == intended_policy
    command = out / 'command.json'
    runtime = out / 'runtime'
    argv = [sys.executable,str(INVESTIGATION / 'operation-config.py'),request['operation'],
            '--operation-id',args.operation_id,'--command-file',str(command),'--result-dir',str(runtime),
            '--query',str(query_path),'--query-sha256',sha(query_path.read_bytes()),
            '--consumer-case',case,'--consumer-agent',agent,
            '--input',str(ROOT / '.atlas/evaluation-store.json'),MARKER_SHA,
            '--input',str(ROOT / '.atlas/policy.json'),GOVERNANCE_SHA,
            '--input',str(ROOT / '.atlas/evaluation-policy.json'),sha(intended_policy)]
    for path in [dispatch_path,request_path,packet,admission_path,admission_stdout,admission_capture,
                 Path(__file__).absolute(),out / 'bridge-start.json']:
        argv += ['--input',str(path),stamp(path)['sha256']]
    config_exit = capture(argv,out,'configuration')
    assert config_exit == 0, 'configuration failed; Atlas not called'
    wrapper_exit = capture([sys.executable,str(INVESTIGATION / 'capture-state-operation.py'),str(command),str(runtime)],out,'capture')
    receipt = json.loads((runtime / 'receipt.json').read_bytes())
    stdout = (runtime / 'stdout.json').read_bytes()
    stderr = (runtime / 'stderr.txt').read_bytes()
    for name, data in [('stdout',stdout),('stderr',stderr)]:
        assert len(data) == receipt['streams'][name]['byte_length']
        assert sha(data) == receipt['streams'][name]['sha256']
    state_capture_path = regular(runtime / 'state-capture.json')
    state_capture = json.loads(state_capture_path.read_bytes())
    invalid = state_capture_problems(receipt, state_capture, wrapper_exit)
    if receipt.get('operation_id') != args.operation_id or receipt.get('operation') != 'evaluation-' + request['operation']:
        invalid.append('runtime-receipt-operation')
    if receipt['named_input_bytes_unchanged'] is not True or receipt['external_byte_guard']['matched'] is not True:
        invalid.append('external-byte-guard')
    if invalid:
        write_new(out / 'bridge-refusal.json', encode({
            'state':'ORIGINAL_OPERATION_CAPTURED_RESPONSE_NOT_FORWARDED',
            'reason':'Operation guard or state capture invalidates this attempt as consumer evidence.',
            'problems':invalid,'wrapper_exit_code':wrapper_exit,
            'runtime_receipt':stamp(runtime / 'receipt.json'),
            'state_capture':stamp(state_capture_path),
            'effects_or_budget_undone':False,'automatic_retry':False}))
        raise RuntimeError('operation guard or state capture mismatch; original streams retained, no response forwarded')
    # Return exactly the actual original streams, including refusals. No retry.
    response = (f'Original Atlas CLI response for {case}; operation {request["operation"]}; exit_code={receipt["exit_code"]}.\n'
                f'BEGIN STDOUT UTF8 bytes={len(stdout)} SHA256={sha(stdout)}\n').encode() + stdout
    response += (f'\nEND STDOUT\nBEGIN STDERR UTF8 bytes={len(stderr)} SHA256={sha(stderr)}\n').encode() + stderr
    response += b'\nEND STDERR\n'
    stdout.decode('utf-8', errors='strict'); stderr.decode('utf-8', errors='strict')
    write_new(out / 'reader-response.txt', response)
    finish = {'schema':'genesis-s2-reader-bridge-completion/v1','ended_at':now(),
              'case_id':case,'native_agent_id':agent,'operation_id':args.operation_id,
              'wrapper_exit_code':wrapper_exit,'original_runtime_exit_code':receipt['exit_code'],
              'runtime_receipt':stamp(runtime / 'receipt.json'),'response':stamp(out / 'reader-response.txt'),
              'state_capture':stamp(state_capture_path),'state_capture_consistent':True,
              'original_stdout':stamp(runtime / 'stdout.json'),'original_stderr':stamp(runtime / 'stderr.txt'),
              'named_input_bytes_unchanged':receipt['named_input_bytes_unchanged'],
              'byte_guard_matched':receipt['external_byte_guard']['matched'],
              'consumer_answer_created':False,'automatic_retry':False,'budget_reset':False}
    write_new(out / 'bridge-completion.json', encode(finish))
    print(json.dumps(finish,ensure_ascii=False))


if __name__ == '__main__':
    main()
