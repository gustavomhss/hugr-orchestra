"""Record a real successful activation of two already queued literal messages."""
from pathlib import Path
import json, hashlib, sys, datetime
D=Path(__file__).resolve().parent
a,b=map(int,sys.argv[1:3]); assert b==a+1
judge=sys.argv[3] if len(sys.argv)>3 else 's2_j1';assert judge in ['s2_j1','s2_j2']
p=D/'activation-triggers'/f'{a:03d}-{b:03d}-{judge}.txt'
body=p.read_bytes()
L=D/'transport-ledger.jsonl'; rows=[json.loads(x) for x in L.read_text().splitlines()]
for n in [a,b]:
 assert any(r.get('target')=='/root/'+judge and r.get('wave')==n and r.get('event')=='ACTUAL_SEND_MESSAGE_QUEUED' for r in rows)
row={'event':'ACTUAL_FOLLOWUP_ACTIVATION_SENT','target':'/root/'+judge,'waves':[a,b],'request_path':str(p),'request_utf8_bytes':len(body),'request_sha256':hashlib.sha256(body).hexdigest(),'observed_tool_result':'empty successful collaboration.followup_task return; no error','host_message_id':None,'host_timestamp':None,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limit':'One actual activation after two separately queued literal blocks. Trigger is concatenated once, after the second block. Host serialized bytes and delivery identifiers are not exposed.'}
if not any(r.get('event')==row['event'] and r.get('target')==row['target'] and r.get('waves')==[a,b] for r in rows):
 with L.open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
p=D/'dispatch-state.json'; state=json.loads(p.read_bytes());state.setdefault('last_actual_wave_by_judge',{})[judge]=b;state.setdefault('pending_queued_wave_by_judge',{}).pop(judge,None);p.write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(row,ensure_ascii=False))
