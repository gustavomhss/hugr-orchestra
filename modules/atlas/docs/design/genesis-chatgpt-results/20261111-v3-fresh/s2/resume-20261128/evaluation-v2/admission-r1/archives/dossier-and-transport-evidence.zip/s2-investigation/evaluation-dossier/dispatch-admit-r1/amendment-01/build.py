#!/usr/bin/env python3
"""Read-only evidence projection/transport builder. Never invokes Atlas or a judge."""
from pathlib import Path
import copy, hashlib, json, collections, subprocess

ROOT=Path('/workspace/scratch/5cfbb6c803f1')
DOS=ROOT/'s2-investigation/evaluation-dossier'
OUT=Path(__file__).parent
DIS=OUT.parent
BASE='modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2/'
P2=ROOT/'s2-execution/evaluation-prepare-02'
P3=ROOT/'s2-execution/evaluation-prepare-03'
AUD=ROOT/'s2-investigation/evaluation-audit'
C=json.loads((P2/'prepared.json').read_bytes())
PKG=json.loads((ROOT/'s2-corpus'/BASE/'native-package.json').read_bytes())
OLD=json.loads((DOS/'review-core/manifest.json').read_bytes())
SOURCES=json.loads((OUT/'source-extraction-manifest.json').read_bytes())
CHECKS=[];ASSETS=[];OMISSIONS=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n').encode()
def read(p):return json.loads(p.read_bytes())
def eq(label,a,b):
    if a!=b:raise AssertionError(label)
    CHECKS.append(label)
def identity(p):
    b=p.read_bytes();return {'path':str(p),'utf8_bytes':len(b),'sha256':sha(b)}
def put(name,data):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return p
def add(p,group,representation,**meta):
    b=p.read_bytes();b.decode('utf-8')
    row={'id':f'A{len(ASSETS):03d}','file':str(p),'utf8_bytes':len(b),'sha256':sha(b),'group':group,'representation':representation,**meta}
    ASSETS.append(row);return row
def generated(name,obj,group,**meta):return add(put(name,enc(obj)),group,'explicit projection',**meta)
def literal(p,group,**meta):
    dest=put('literal/'+str(p.relative_to(ROOT)),p.read_bytes())
    return add(dest,group,'literal bytes',source=identity(p),**meta)
def archived(p,role,retained,omitted,verifier,limits,count=None,schema=None):
    row={**identity(p),'role':role,'presented_fields':retained,'omitted_fields':omitted,'verifier':verifier,'limits':limits}
    if count is not None:row['records']=count
    if schema is not None:row['schema']=schema
    OMISSIONS.append(row);return row

eq('fixed original selection',sha((DOS/'review-core/manifest.json').read_bytes()),'c9ee2edf05f8c07fef7ca0e86cb5abf52872f63abcc141efbcecdbc5f8589be9')
eq('02 prepared fixed',sha((P2/'prepared.json').read_bytes()),'bb3ee09693ef1ddfb89e548f3f5e0d38c4abaee5e6d253f129c7c6c1a9dbda0e')
eq('03 exact prepared bytes', (P2/'prepared.json').read_bytes(),(P3/'prepared.json').read_bytes())
eq('03 exact stdout bytes',(P2/'stdout.json').read_bytes(),(P3/'stdout.json').read_bytes())
eq('package fixed',sha((ROOT/'s2-corpus'/BASE/'native-package.json').read_bytes()),'9356cefcb4a1db413e67869a855fd082536476fb18ff7784dde39f051e9b407b')

# Stable scope originals are not cross-shared with the judges.
scope=DIS/'materials-scope'
scope_capture={'schema':'s2-materials-scope-capture/v1','query':identity(scope/'root-query.txt'),'responses':{x:identity(scope/f'{x}-response.{ext}') for x,ext in [('j1','md'),('j2','json')]},'host_message_ids':None,'host_timestamps':None,'method':'Query and J1 literal supplied by parent capture; J2 literal captured from list_agents completed response. No terminal newline appended. Opinions never sent to the other judge.'}
put('scope-capture.json',enc(scope_capture))

# Historical decisions: every byte, including fenced Markdown and FIX-FIRST scopes.
for row in OLD['assets']:
    if row['group']=='02-historical-complete-decisions':
        p=DOS/row['file'];eq('historical original '+row['id'],sha(p.read_bytes()),row['sha256']);add(p,'01-history','literal bytes',original_asset=row['id'])
eq('historical decision bytes',sum(a['utf8_bytes'] for a in ASSETS),108942)

# Original AC definitions, original/native and ADMIT contracts; no redefinition.
owner=ROOT/'s2-corpus/modules/atlas/docs/design/genesis-ownership-plan.md'
raw=owner.read_bytes(); lines=raw.splitlines(keepends=True)
add(put('original-AC-01-10.txt',b''.join(lines[129:154])),'02-plan-contracts','literal source excerpt',source=identity(owner),line_start=130,line_end=154)
for row in OLD['assets']:
    if row['id'] in ['R039','R040','R041','R042']:
        p=DOS/row['file'];eq('fixed plan/contract '+row['id'],sha(p.read_bytes()),row['sha256']);add(p,'02-plan-contracts','literal bytes',original_asset=row['id'])

# Exact candidate envelope and all non-input entry fields. Uniform versions/hashes omitted explicitly.
c=C['candidate'];obs=c['observations']; keys=[o['key'] for o in obs]
eq('690 observation unique keys',len(set(keys)),690)
idx={k:i for i,k in enumerate(keys)}
definition=read(DOS/'core-proposal/candidate-definition.json')
rows=[json.loads(x) for x in (DOS/'core-proposal/690-observations.jsonl').read_text().splitlines()]
prefixes=definition['observation_prefixes']
eq('prefix dictionary reconstruction',[prefixes[r[0]]+r[1] for r in rows],keys)
observation_project={'schema':'s2-observation-key-universe/v1','candidate_id':C['candidate_id'],'original':identity(P2/'prepared.json'),'array_path':'candidate.observations','row_schema':['prefix_index','suffix'],'index_rule':'Zero-based row position is the observation index; key=prefixes[prefix_index]+suffix. Original insertion order preserved. No sorting.','prefixes':prefixes,'rows':[[r[0],r[1]] for r in rows],'omitted':'All 690 version values and the 626 sha256 fields remain archived in prepared.json and audit observations.json; this key projection alone cannot reconstruct the original candidate or input identities.','observed_shapes':[{'range_inclusive':[0,625],'keys':['key','version','sha256']},{'range_inclusive':[626,689],'keys':['key','version']} ]}
generated('690-key-universe.json',observation_project,'03-candidate-universe')
entries=[]
for e in c['entries']:
    row={k:v for k,v in e.items() if k!='inputs'}
    indexes=[idx[x['key']] for x in e['inputs']]
    eq('ordered input mapping '+e['key'],[{'key':obs[i]['key'],'version':obs[i]['version']} for i in indexes],e['inputs'])
    row['inputs_projection']={'observation_indexes':indexes,'rule':'Map each index to original observation {key,version}, in this exact order. Versions are referenced, not presented in 690-key-universe.json.'}
    row['original_entry_key_order']=list(e)
    entries.append(row)
eq('818 ordered bindings',sum(len(e['inputs']) for e in c['entries']),818)
eq('32 dependency edges',sum(len(e['dependencies']) for e in c['entries']),32)
eq('30 navigation links',sum(len(e['artifact']['navigation']) for e in c['entries']),30)
envelope={k:v for k,v in c.items() if k not in ['entries','observations','runtime_identity']}
generated('candidate-envelope-and-13-entries.json',{'schema':C['schema'],'candidate_id':C['candidate_id'],'candidate_fields':envelope,'entries':entries,'original_candidate_key_order':list(c),'omitted_top_level':['observations: key universe presented separately, versions/hash rows archived','runtime_identity: package tree/rules/engine/gaps presented separately; 925 uniform identity rows archived']},'03-candidate-universe')
add(DOS/'core-proposal/13-result-objects.jsonl','03-candidate-universe','complete JSON value projection',description='All 13 actual CAS result objects with every field, CAS byte size and SHA; body text remains opaque.')

# Per-artifact recipe/reference roles and exact source membership, not just totals.
source_pins=[];source_rows=[]
reference_use=[]
ref_index={json.dumps(x['reference'],sort_keys=True,separators=(',',':')):i for i,x in enumerate(c['references'])}
for a in PKG['artifacts']:
    membership=[]
    for r in a['source_refs']:
        if r['commit'] not in source_pins:source_pins.append(r['commit'])
        membership.append([idx['file:'+r['path']],source_pins.index(r['commit'])])
    refs={}
    for key in ['recipe_ref','producer_request_ref','producer_response_ref','semantic_review_refs']:
        values=a[key] if isinstance(a[key],list) else [a[key]]
        refs[key]=[ref_index[json.dumps(v,sort_keys=True,separators=(',',':'))] for v in values]
    source_rows.append({'key':a['key'],'source_refs_observation_index_and_commit_index':membership,'explicit_input_key_observation_indexes':[idx[k] for k in a['input_keys']],'reference_indexes':refs,'runtime_receipt_refs':a['runtime_receipt_refs'],'body':a['body']})
generated('per-artifact-source-membership-and-reference-roles.json',{'schema':'s2-source-membership-projection/v1','source':identity(ROOT/'s2-corpus'/BASE/'native-package.json'),'source_ref_columns':['observation_index','source_commit_index'],'source_commits':source_pins,'reference_index_rule':'Zero-based index in candidate_fields.references; full 40 reference objects already presented in candidate envelope. All role uses retain order.','global_reference_roles':{'protocol_ref':ref_index[json.dumps(PKG['protocol_ref'],sort_keys=True,separators=(',',':'))],'oracle_ref':ref_index[json.dumps(PKG['contract']['oracle_ref'],sort_keys=True,separators=(',',':'))]},'artifacts':source_rows,'omitted':'Individual source_ref git_blob_sha and sha256 columns; exact uniform comparison rows archived in source-preflight.json and native-package.json. Commit and membership universes retained. No new body semantics extracted.'},'03-candidate-universe')

# Complete transformed source functions. AST removes only clearly identified non-runtime content.
for s in SOURCES['files']:
    group='04-transformation-code' if s['group'] in ['transformation','other'] else '05-isolation-ports-code'
    add(OUT/s['projection_file'],group,'exact AST statement spans',source_path=s['path'],source_bytes=s['source_bytes'],source_sha256=s['source_sha256'],git_commit=s['git_commit'],omission=s['method'])

# Finite concrete authority remains uninstalled, independently of prepare03.
AUTH=ROOT/'s2-investigation/evaluation-authority'
for p in sorted(AUTH.iterdir()):
    if p.is_file() and p.name not in ['runtime-byte-lock.json']:
        literal(p,'06-authority-and-guards',status_note='Draft/proposal unless an explicit execution receipt below demonstrates that exact mechanism; policies remain NOT_INSTALLED.')
for rel in ['s2-execution/evaluation-prepare-02/recorder-used.py','s2-investigation/record-operation.py','s2-investigation/capture-state-operation.py','s2-investigation/install-evaluation-policy.py']:
    literal(ROOT/rel,'06-authority-and-guards')

# Runtime coverage: full package resolution tree and every exclusion, no uniform SHA tables.
runtime=read(AUD/'runtime-identity.json'); rt=copy.deepcopy(runtime)
rt.pop('files');rt.pop('identity')
imports=rt.pop('literal_runtime_imports')
rt['literal_import_scan_projection']={'total':len(imports),'omitted_uniform_in_closure_rows':sum(1 for x in imports if x.get('in_declared_identity_closure') and not x.get('error')),'all_nonuniform_rows':[x for x in imports if not x.get('in_declared_identity_closure') or x.get('error')],'original':identity(AUD/'runtime-identity.json')}
for n in rt['omitted_resolved_packages']:
    files=n.pop('files');comp=n['locked_tarball']['installed_comparison'];cf=comp.pop('files')
    eq('all 247 noble tarball results',len(cf),247);eq('247 noble inventory',len(files),247)
    eq('all noble files equal',[x['exact_bytes_equal'] for x in cf],[True]*247)
    n['installed_inventory_projection']={'records':247,'sum_byte_lengths':sum(x['byte_length'] for x in files),'uniform_rows_omitted':['path','relative_path','sha256','byte_length'],'full_manifest':identity(AUD/'runtime-identity.json'),'full_table_json_pointer':'/omitted_resolved_packages/0/files','all_exceptions':[]}
    comp['all_nonuniform_rows']=[x for x in cf if not x['exact_bytes_equal'] or not x['installed_present']]
    comp['uniform_rows_omitted']=247
generated('runtime-universe-resolution-and-noble.json',rt,'07-runtime-and-execution',original=identity(AUD/'runtime-identity.json'))
lock=read(AUTH/'runtime-byte-lock.json')
intr={x['path']:(x['byte_length'],x['sha256']) for x in runtime['files']}
noble={x['path']:(x['byte_length'],x['sha256']) for x in runtime['omitted_resolved_packages'][0]['files']}
bunpath=runtime['engine']['argv'][0];bunbytes=Path(bunpath).read_bytes()
expected={**intr,**noble,bunpath:(len(bunbytes),sha(bunbytes))}
actual={x['path']:(x['byte_length'],x['sha256']) for x in lock['files']}
eq('922 intrinsic physical',len(intr),922);eq('no intrinsic noble overlap',sorted(set(intr)&set(noble)),[]);eq('bun outside intrinsic and noble',bunpath not in intr and bunpath not in noble,True)
eq('1170 exact lock derivation',actual,expected)
lock_projection={k:v for k,v in lock.items() if k!='files'}
lock_projection['files_projection']={'intrinsic_physical':922,'noble':247,'bun':{'path':bunpath,'byte_length':len(bunbytes),'sha256':sha(bunbytes)},'count':1170,'overlaps':[],'missing':[],'extra':[],'hash_or_size_differences':[],'method':'Exact dictionary equality by absolute path, byte_length, sha256; intrinsic 922 + all noble247 + exact Bun executable. No duplicate paths in original lock.','original':identity(AUTH/'runtime-byte-lock.json'),'uniform_rows_not_transported':True}
eq('no duplicate lock paths',len(actual),len(lock['files']))
generated('runtime-lock-derivation.json',lock_projection,'07-runtime-and-execution')

# Honest receipt projections: omitted file rows require the archived original, never called integral.
rec2=read(P2/'receipt.json');rec3=read(P3/'receipt.json')
for name,p,receipt in [('02',P2,rec2),('03',P3,rec3)]:
    skip=['input_files_before','input_files_after','cas_before','cas_after']
    projected={k:v for k,v in receipt.items() if k not in skip}
    for field in skip:
        rows=receipt[field]
        projected[field+'_projection']={'records':len(rows),'schema_keys':sorted({k for row in rows for k in row}),'uniform_rows_omitted':True,'original':identity(p/'receipt.json'),'json_pointer':'/'+field}
    projected['projection_note']='All scalar/header/control/limit fields preserved. Named file/CAS row tables are referenced, not fully delivered; this is not an integral receipt and cannot reconstruct them without archived originals.'
    generated(f'prepare-{name}-receipt-projection.json',projected,'07-runtime-and-execution')
    command=read(p/'command.json');keep={k:v for k,v in command.items() if k not in ['input_files','expected_input_files']}
    for field in ['input_files','expected_input_files']:
        if field in command:keep[field+'_projection']={'records':len(command[field]),'original':identity(p/'command.json'),'json_pointer':'/'+field}
    generated(f'prepare-{name}-command-projection.json',keep,'07-runtime-and-execution')
for name in ['precondition.json','state-capture.json']:
    literal(P3/name,'07-runtime-and-execution')
before={x['path']:(x.get('byte_length'),x.get('sha256')) for x in rec3['input_files_before']};after={x['path']:(x.get('byte_length'),x.get('sha256')) for x in rec3['input_files_after']}
eq('1890 observed files exact before after',before,after)
source716={x['path']:(x['byte_length'],x['sha256']) for x in rec2['input_files_after']}
eq('source716',len(source716),716)
eq('03 source716 exactly preserved',{k:v for k,v in before.items() if k in source716},source716)
eq('03 runtime1170 exactly locked',{k:v for k,v in before.items() if k in actual},actual)
control={k:v for k,v in before.items() if k not in source716 and k not in actual}
eq('four extra controls',len(control),4)
eq('source runtime no overlap',sorted(set(source716)&set(actual)),[])
eq('03 same CAS before after',rec3['cas_before'],rec3['cas_after'])
eq('02 after equals03 before CAS',rec2['cas_after'],rec3['cas_before'])
relative_source=[str(Path(k).relative_to(ROOT/'s2-evaluation')) for k in source716]
extras=[x for x in relative_source if 'file:'+x not in idx]
eq('716 minus690 =26 paths',len(extras),26)
generated('execution-03-comparison-and-coverage.json',{'schema':'s2-prepare03-exact-comparison/v1','candidate':C['candidate_id'],'prepared02':identity(P2/'prepared.json'),'prepared03':identity(P3/'prepared.json'),'prepared_exact_bytes_equal':True,'stdout02':identity(P2/'stdout.json'),'stdout03':identity(P3/'stdout.json'),'stdout_exact_bytes_equal':True,'reuse_limit':'The existing 22752 static comparisons concern exactly identical prepared bytes. This comparison does not rerun that auditor or create a judge decision.','source716_universe':{'root':str(ROOT/'s2-evaluation'),'first_class':'All 690 keys in 690-key-universe.json with leading file: removed; plus exact 26 relative paths below. Receipt order retained only in archived original. Membership is fully enumerated here.','additional26_paths':extras,'all_690_present':all('file:'+x in idx for x in relative_source if x not in extras)},'runtime1170_universe':'runtime-lock-derivation.json; package enumeration source and complete external lock preserved','controls4':[{'path':k,'byte_length':v[0],'sha256':v[1]} for k,v in control.items()],'observed1890':{'before_after_exact_equal':before==after,'source_runtime_overlap':[],'missing':[],'extra':[],'mismatches':[]},'cas92_before_after_exact_equal':True,'cas02after_equals03before':True,'state_files_before':rec3['state_files_before'],'state_files_after':rec3['state_files_after'],'temporal_limits':['prepare02 did not capture the omitted noble package before/after; no retroactive coverage is claimed.','prepare03 is a new original CLI execution; its own recorder observed the external byte guard before invocation and named files afterward.','The guard is operator-invoked. Atlas CLI/modules do not require this wrapper; supported callers may bypass it.','The precheck blocks this invocation when mismatches are found. Post-execution drift only invalidates a clean proof claim and cannot undo or prevent effects already executed.','Between-snapshot races, malicious host interference, OS isolation and unobserved external dependencies are not excluded by these receipts.','Policies are not installed; no admission, index/read, consumer or maintenance has run.']},'07-runtime-and-execution')

# Prior source check: complete algorithm and all header/exception fields; hash rows referenced.
pre=read(ROOT/'s2-investigation/byte-audit/source-preflight.json')
generated('preflight-all-header-and-exceptions.json',{k:v for k,v in pre.items() if k!='files'},'08-audits-and-limits',omitted='667 uniform file comparison rows only; full original referenced in omission inventory.')
literal(ROOT/'s2-investigation/byte-audit/source_preflight.py','08-audits-and-limits')
literal(AUD/'verify-evaluation.mjs','08-audits-and-limits')
add(DOS/'review-core/independent-v2-report-projection.json','08-audits-and-limits','explicit projection',source=identity(AUD/'report.json'),note='Only repeated runtime_identity key list omitted from field_delta_summary; all other original report fields, counts, divergences, material gaps and limits are preserved. Original full report remains archived. No judge opinion.')
add(DOS/'review-core/prior-verifier-results-selection.json','08-audits-and-limits','explicit projection')
literal(AUD/'manifest.json','08-audits-and-limits')
for rel in ['compatibility-assessment.json','source-manifest.json']:
    literal(ROOT/'s2-investigation/runtime/latest-release'/rel,'09-S4-compatibility')

# Explicit archive-only omissions include schemas, identity, role and the covering verifier.
archived(P2/'prepared.json','Exact candidate reviewed; identical to prepare03','All header fields,13entry fields except input version repetitions,40refs,13resultobjects,690key universe,818orderedindexes','690versions/626SHA;925runtime hashes',identity(AUD/'verify-evaluation.mjs'),'Judges cannot recompute hashes or claim to have read omitted rows. Entry inputs reconstruct only with archived original observations.',690,C['schema'])
archived(AUD/'observations.json','Independent full observation/source binding comparisons','Coverage universe, count and original report comparison buckets','Uniform 690 detailed comparison rows',identity(AUD/'verify-evaluation.mjs'),'Complete table referenced, not read by judges.',690,read(AUD/'observations.json').get('schema'))
archived(AUD/'runtime-identity.json','Intrinsic implementation closure and external noble reconciliation','Complete package tree/rules/engines/absences/conflicts/gaps;7file12edge noble closure; all nonuniform import rows and reconciliation exceptions','922file identities,925identity values;247noble row hashes and duplicate tar comparison columns;uniform in-closure import rows',identity(AUD/'verify-evaluation.mjs'),'Original audit time after prepare02; prepare03 receipt independently supplies before/after coverage of the explicit external lock.',925,runtime['schema'])
archived(ROOT/'s2-investigation/byte-audit/source-preflight.json','Public custody and original source pins','All header/limits/exceptions;596source membership per artifact and source commit;complete key universe','667uniform SHA/blob/byte rows',identity(ROOT/'s2-investigation/byte-audit/source_preflight.py'),'No Atlas product runtime or new semantic approval was executed by preflight.',667,pre['schema'])
for p in [P2/'receipt.json',P2/'command.json',P3/'receipt.json',P3/'command.json',AUTH/'runtime-byte-lock.json']:
    archived(p,'Execution or external lock record','All control/header/temporal/status/limit fields; exact population derivation','Uniform named file and CAS rows as explicitly noted in its projection',identity(Path(__file__)),'Projection depends on archived table for exact SHA per row and original row order.')
archived(AUD/'report.json','Original independent report','Every field except duplicate 925 runtime_identity key list in field_delta_summary','Only that repeated key list',identity(AUD/'verify-evaluation.mjs'),'Full original report archived; presented projection explicitly marks the omission.')
for p in [AUD/'checks.jsonl',AUD/'entries.json',AUD/'references.json',AUD/'cas.json',AUD/'materialization.json',AUD/'field-deltas.json',ROOT/'s2-investigation/binding/independent-mapping-check.json',ROOT/'s2-execution/prepare-01/integrity.json']:
    archived(p,'Detailed verification table','Decisive aggregate/full exception results and covering verifier references','Detailed repeated comparison rows',identity(AUD/'verify-evaluation.mjs') if p.is_relative_to(AUD) else 'prior verifier identities in prior-verifier-results-selection.json','No new judgment; detailed tables are referenced, not all displayed.')
generated('omission-inventory.json',{'schema':'s2-dispatch-amendment-omissions/v1','items':OMISSIONS},'00-amendment')
generated('13-entry-final-id-table.json',{'candidate':C['candidate_id'],'entries':[{'key':e['key'],'contract':e['contract'],'result':e['artifact']['result'],'inputs':e['inputs_id']} for e in c['entries']]},'10-final-identities')

scope_text='''EMENDA EXPLÍCITA DE APRESENTAÇÃO 01 — isolated-evaluation-admission.
Esta emenda substitui somente a programação de transporte das antigas ondas003–035, que NÃO foram enviadas. As ondas001–002 já recebidas por ambos permanecem parte do pedido: protocolo/4ADMIT,4manifests de aceitação e matriz13→corpo→pareceres. Seleção anterior preservada: manifest SHA c9ee2edf05f8c07fef7ca0e86cb5abf52872f63abcc141efbcecdbc5f8589be9. Pedido literal efetivamente entregue atéonda2:37364bytes SHA dbeb3fece239d979533cd076af36232634cffb9cb1fa8c206bc75ccab090e568.
O candidato é d1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30. Nenhuma alteração de pacote, plano, contrato, perguntas, oracle ou critérios. O HOLD V1 continua integralmente preservado. Nenhum parecer do outro juiz faz parte deste material.
A consulta de escopo MATERIALS_SCOPE_ONLY foi aceita como possibilidade de revisão, sem garantir resultado. A emenda reduz tabelas uniformes; conserva listas que definem cobertura, todas exceções, código decisivo e decisões históricas integrais. Objetos não apresentados integralmente estão identificados em omission-inventory.json, com esquema/contagem/bytes/hash, campos retidos/omitidos, verificador e limites. Não é alegada leitura ou recomputação criptográfica dos arquivos apenas referenciados.
Houve uma NOVA execução prepare03 do CLI original, em saída exclusiva, após o problema temporal de@noble ser reconhecido. Seus prepared.json e stdout são exatamente iguais aos de02; tem recibo próprio e precheck externo observado de1890arquivos, incluindo os247noble,716fontes,922arquivos intrínsecos,Bun e4controles. Isto não muda a identidade intrínseca nem retroage o recibo02. Julgue a suficiência da evidência atual e os limites de maneira independente. O wrapper é controle do operador, não requisito da CLI; bypass direto permanece possível. Um check posterior não impede efeitos já ocorridos.
A finalidade permanece exclusivamente os quatro ADMIT exatos em TODAS13entries. AC-01..AC-10 e runtime-import-binding,14casos eS2-U1 permanecem pendentes; políticas de admissão/consumo são drafts não instalados. Prepare03 é CAS-only e não é admissão, consumidor, teste de domínio ou manutenção.
Código apresentado como spans literais de declarações AST mantém funções inteiras e todos os ramos. Somente comentários/espaços externos e interfaces/type aliases sem efeito runtime no grupo orchestration foram omitidos; offsets/hash do fonte db9 e extrator ficam preservados. O verificadorV2 e14pareceres históricos são bytes literais integrais. Fonte opaca dos13corpos não é reenviada para nova semântica.
Durante ondas parciais, responda apenas ACK_PARTIAL, lista de materiais recebidos, achados parciais e faltas exatas; final_binding=NOT_ISSUED. Não finalize até receber pedido explícito de fechamento depois de todo o material idêntico ser entregue a ambos. Não use ferramentas, não crie agentes, não contate consumidores. Se algum material essencial faltar, identifique exatamente a falta para HOLD; não adapte critérios para passar.
'''
add(put('00-amendment.txt',scope_text.encode()),'00-amendment','transport instruction; not evidence judgment')

# Subject groups, maximum ~45KB per wave; chunk boundary on whole UTF8 lines, offsets preserved.
ASSETS.sort(key=lambda x:(x['group'],x['id']))
manifest={'schema':'s2-evaluation-dispatch-amendment/v1','candidate':C['candidate_id'],'reuse_actual_waves':[1,2],'superseded_unsent_old_waves':list(range(3,36)),'no_final_vote_prepopulated':True,'assets':ASSETS,'checks':CHECKS,'omissions':OMISSIONS,'source_extraction_manifest':identity(OUT/'source-extraction-manifest.json')}
put('manifest.json',enc(manifest))
groups=collections.defaultdict(list)
for asset in ASSETS:groups[asset['group']].append(asset)
chunks=[]
for group,assets in groups.items():
    fragments=[]
    for asset in assets:
        data=Path(asset['file']).read_bytes(); lines=data.splitlines(keepends=True);piece=b'';start=0
        for line in lines:
            # Compact JSON may be a large line; split safely at unicode boundary only if needed.
            while len(line)>23000:
                n=23000
                while True:
                    try:line[:n].decode('utf-8');break
                    except UnicodeDecodeError:n-=1
                part=line[:n];line=line[n:]
                if piece:fragments.append((asset,start,piece));start+=len(piece);piece=b''
                fragments.append((asset,start,part));start+=len(part)
            if len(piece)+len(line)>23000 and piece:fragments.append((asset,start,piece));start+=len(piece);piece=b''
            piece+=line
        if piece:fragments.append((asset,start,piece))
    payload=b'';included=[]
    def flush():
        global payload,included
        if not payload:return
        num=len(chunks)+1;p=put(f'chunks/{num:03d}-{group}.txt',payload)
        chunks.append({'number':num,'group':group,**identity(p),'fragments':included});payload=b'';included=[]
    for asset,start,fragment in fragments:
        meta={'asset':asset['id'],'path':asset['file'],'representation':asset['representation'],'source':asset.get('source',None),'git_commit':asset.get('git_commit'), 'source_path':asset.get('source_path'),'source_sha256':asset.get('source_sha256'),'source_bytes':asset.get('source_bytes'),'whole_utf8_bytes':asset['utf8_bytes'],'whole_sha256':asset['sha256'],'byte_start':start,'byte_end_exclusive':start+len(fragment),'omission':asset.get('omission',None),'note':asset.get('note',None)}
        header=('\nBEGIN_LITERAL_FRAGMENT '+json.dumps(meta,ensure_ascii=False,separators=(',',':'))+'\n').encode();part=header+fragment+b'\nEND_LITERAL_FRAGMENT\n'
        if len(payload)+len(part)>47000 and payload:flush()
        payload+=part;included.append({'asset':asset['id'],'start':start,'end':start+len(fragment),'sha256':sha(fragment)})
    flush()
for asset in ASSETS:
    spans=[f for chunk in chunks for f in chunk['fragments'] if f['asset']==asset['id']]
    pos=0
    for s in spans:eq('span continuity '+asset['id']+' '+str(pos),s['start'],pos);pos=s['end']
    eq('all asset bytes selected '+asset['id'],pos,asset['utf8_bytes'])
put('chunk-manifest.json',enc({'manifest':identity(OUT/'manifest.json'),'chunks':chunks,'checks':CHECKS,'total_payload_bytes':sum(x['utf8_bytes'] for x in ASSETS),'total_transport_bytes':sum(x['utf8_bytes'] for x in chunks),'group_payload_bytes':{g:sum(x['utf8_bytes'] for x in a) for g,a in groups.items()}}))
print(json.dumps({'assets':len(ASSETS),'chunks':len(chunks),'payload':sum(x['utf8_bytes'] for x in ASSETS),'transport':sum(x['utf8_bytes'] for x in chunks),'groups':{g:sum(x['utf8_bytes'] for x in a) for g,a in groups.items()},'manifest':identity(OUT/'manifest.json')},indent=2))
