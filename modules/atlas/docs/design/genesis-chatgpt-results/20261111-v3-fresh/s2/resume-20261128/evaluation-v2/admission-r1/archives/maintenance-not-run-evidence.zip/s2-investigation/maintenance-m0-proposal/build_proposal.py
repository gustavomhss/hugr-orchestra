#!/usr/bin/env python3
"""Write an external M0/U1 proposal only. Never execute/import Atlas or U1 helpers.

Only this directory is written. All roots, candidates, policies and commands below
are prospective data. Unknown runtime-produced identities stay explicit tokens.
"""
from pathlib import Path
import copy
import datetime
import hashlib
import json
import re

BASE = Path('/workspace/scratch/5cfbb6c803f1')
OUT = Path(__file__).parent
AREA = BASE / 's2-investigation/maintenance-plan'
EVAL = BASE / 's2-evaluation'
RUNTIME = BASE / 's2-runtime'
REV = 'db9b4235022c4df32fe3bfd4faeea8adcd69abb7'
EX = '846d4f9c-fb77-4e21-aff6-1fffccc3132b'
ACTOR = 'genesis-s2-resume-846d4f9c'
SCOPE = 'orchestra.interfaces'
PREFIX = 'modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2/resume-20261128/maintenance-v2'
PLAN_REL = PREFIX + '/evaluation-plan.json'
OPERATOR_REL = PREFIX + '/operator-plan.json'
ROOTS = {'M0': str(BASE / 's2-u1-baseline'), 'M1': str(BASE / 's2-u1-changed'), 'M2': str(BASE / 's2-u1-restored')}
EXEC = str(BASE / 's2-execution/u1')
BUN = str(BASE / 's2-tools/node_modules/@oven/bun-linux-x64-baseline/bin/bun')
HELPER_PINS = {
    'u1-evaluation-operation.mjs': 'd17aa2d06d68a817a0fc9abcb1e605340972ffefe6e95fdccd966988e314aad8',
    'build-native-request.mjs': 'd73b6136c2021566dbc8e6b395cbec9089469274c9a790d199676749e94c89f1',
    'build-operation-config.py': '62d4ae06a2ae89812fd29b408f8c1631730dc9028c249c1c61642986adcee217',
    'recipe-registry.json': 'f21d937f79ca5da480f995b7461862d6635a761c180bddb024498b3c424af459',
    'DRIVER-DRAFT.md': 'f522b7547036c951b83d4719eca2d2c19235c3174b8f7dce3fa2bc1e1ca263e5',
}
OBLIGATION_ID = '4c76c66cedd2f82c650e6aaee4d486cbd530091f98c90d137fbff11693900059'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stamp(path):
    data = path.read_bytes()
    return {'path': str(path), 'byte_length': len(data), 'sha256': sha(data),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def put(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    data = value if isinstance(value, bytes) else encode(value)
    with path.open('xb') as stream:
        stream.write(data)
    return stamp(path)


def token(name):
    return '{{' + name + '}}'


def ref(name):
    return {'path': token(name + '_PATH'), 'sha256': token(name + '_SHA256')}


assert not any(Path(root).exists() for root in ROOTS.values()), 'U1 roots must remain absent in this proposal task'
inventory_path = AREA / 'draft-helper-inventory.json'
inventory = json.loads(inventory_path.read_bytes())
for name, expected in HELPER_PINS.items():
    assert stamp(AREA / name)['sha256'] == expected
initial_path = BASE / 's2-investigation/evaluation-plan/evaluation-plan.json'
initial_bytes = initial_path.read_bytes()
assert sha(initial_bytes) == 'b49e58fad813cf5a6bbbc68a605cfbaf216eb8cc11575d0e3b8bf78b99870e63'
initial = json.loads(initial_bytes)
static_path = AREA / 'plan.json'
static = json.loads(static_path.read_bytes())
material_path = BASE / 's2-investigation/evaluation-plan/materialization-manifest.json'
material = json.loads(material_path.read_bytes())
assert len(material['files']) == 716
source_checks = []
for row in material['files']:
    src = EVAL / row['path']
    observed = stamp(src)
    assert observed['sha256'] == row['sha256'] and observed['byte_length'] == row['byte_length'], row['path']
    source_checks.append(observed)

# Operator-selected proposed generation names. These are not candidate IDs or receipts.
generations = {}
for name in ['M0', 'M0_REUSE_PROPOSAL', 'M1', 'M2', 'M2_REUSE_PROPOSAL']:
    label = 'genesis-s2-u1-proposed-generation/v1:' + EX + ':' + name
    generations[name] = {'label': label, 'value': sha(label.encode()), 'state': 'PROPOSED_NOT_INITIALIZED'}
assert len({row['value'] for row in generations.values()}) == 5
put('proposed-generations.json', {'schema': 'genesis-s2-u1-proposed-generations/v1',
    'state': 'PROPOSED_NOT_RUN', 'derivation': 'SHA-256 of explicit operator label, not Atlas candidate computation', 'generations': generations})

limits = {'routine': {'index_calls': 1, 'read_calls': 2, 'body_bytes_total': 16000},
          'deep': {'index_calls': 1, 'read_calls': 2, 'body_bytes_total': 64000}}
witnesses = [
    {'id': 'S2-U1-W0', 'root': 'M0', 'stage': 'baseline-admitted', 'mode': 'deep', 'kind': 'knowledge'},
    {'id': 'S2-U1-W1', 'root': 'M0', 'stage': 'M0-temporary-source-drift', 'mode': 'routine', 'kind': 'selection'},
    {'id': 'S2-U1-W2', 'root': 'M1', 'stage': 'changed-target-after-durable-stop-resume-and-admission', 'mode': 'deep', 'kind': 'knowledge'},
    {'id': 'S2-U1-W3', 'root': 'M1', 'stage': 'M1-temporary-source-drift-during-restoration-control', 'mode': 'routine', 'kind': 'selection'},
    {'id': 'S2-U1-W4', 'root': 'M2', 'stage': 'restored-target-after-final-exact-reuse-in-fresh-reader-process', 'mode': 'deep', 'kind': 'knowledge'},
]
knowledge_question = ('Use somente a porta Atlas atribuída. Descreva como a espera pela prontidão de um serviço filho termina, '
    'as condições relevantes e os limites da evidência retornada. Cite os trechos e identificadores obtidos. '
    'Quando a porta não servir conhecimento, registre integralmente a recusa e limite sua conclusão ao que foi observado.')
selection_question = ('Use somente a porta Atlas atribuída e realize a sequência de consultas fornecida. '
    'Registre o que cada seleção devolve, seus identificadores e limites. Se uma consulta for recusada, '
    'registre integralmente a recusa. Não substitua uma resposta ausente por memória ou por outra fonte.')
packet_refs = {}
for w in witnesses:
    max_bytes = 32000 if w['mode'] == 'deep' else 8000
    keys = ['s2.l1.desktop-web', 's2.l2.desktop-web'] if w['kind'] == 'knowledge' else ['s2.l1.desktop-web', 's2.l1.app-session']
    packet = {'schema': 'genesis-s2-u1-witness-packet/v1', 'witness_id': w['id'], 'mode': w['mode'],
        'reader_scope': SCOPE, 'limits': limits[w['mode']],
        'question': knowledge_question if w['kind'] == 'knowledge' else selection_question,
        'queries': [{'mode': 'index', 'query': {'scope': SCOPE, 'need': 'evidence'}}] + [
            {'mode': 'read', 'query': {'scope': SCOPE, 'key': key, 'maxBytes': max_bytes}} for key in keys],
        'access': 'Fresh independent context. Only the assigned bounded Atlas index/read port and its literal returned output. No source filesystem, producer contexts, memory, other agents, network or reserved material.',
        'response_fields': ['observations', 'returned_identities', 'citations', 'refusals', 'limits', 'actual_reader_operation_refs'],
        'identity_rule': 'This witness ID is a budget/case ID. The actual new host agent ID is recorded by the dispatcher after creation; no host identity is assigned here.'}
    packet_ref = put('witness-packets/' + w['id'] + '.json', packet)
    packet_refs[w['id']] = {'payload_path': PREFIX + '/witness-packets/' + w['id'] + '.json', 'sha256': packet_ref['sha256']}
    w['packet'] = packet_refs[w['id']]
    w['host_agent_id'] = None
    w['state'] = 'NOT_DISPATCHED'
    w['single_use_schedule'] = 'Exactly one fresh independent witness at the mapped root/stage. No replacement ID or budget reset is preauthorized.'

stages = [
    ('U1-P00', 'Prerequisites and freeze', 'No runtime operation',
     'Require documented completion of the first traversal and all original 14 cases in d1. Preserve their IDs, outcomes, deck and evidence. Freeze this distinct M0 plan, packets, generation proposals, helper bytes and operator sequence before materialization. No existing d1 approval is transferred.'),
    ('U1-P01', 'Materialize M0 sources', 'External file operation with receipt',
     'Create M0 as a new real non-Git directory from exactly the 716 named preserved source files plus the 12 additive files listed by materialization-proposal.json. No .atlas or .git is copied. Use fresh regular bytes, no symlinks/hardlinks. Capture a complete source inventory.'),
    ('U1-P02', 'Prepare M0', 'Original CLI prepare',
     'Run the guarded original CLI prepare once using the new plan path. Save complete prepared bytes, stdout/stderr, generated CAS and source/runtime guard evidence. M0 candidate and plan CAS IDs are learned from that result, not precomputed here.'),
    ('U1-P03', 'Initialize and provision M0 admission-only authority', 'Original CLI init-store; separate explicit policy installation',
     'Initialize M0 CAS-only with the proposed M0 generation. Install the exact resolved governance and admit-only policy with a new U1-specific operator installation record. Marker/policy are not approvals. The fixed d1 installer cannot install these roots.'),
    ('U1-P04', 'New exact M0 decisions and admission', 'Two independent decisions; original CLI admit',
     'Supply complete actual M0 material to the fixed independent admission pair and obtain two new exact decisions covering all13 entries and the four ADMIT criteria. Preserve literal requests/responses and construct a payload-only binding. Then admit M0 once and require a real emitted result. Record the returned admitted manifest, not a guessed CAS object.'),
    ('U1-P05', 'Baseline witness', 'Fresh W0 through index/read only',
     'Install the mapped W0 policy on M0; dispatch a fresh independent context with only its packet and reader port. Preserve literal queries, original CLI outputs, budgets and actual host agent ID. W0 is not one of the original14.'),
    ('U1-P06', 'Exact baseline reuse', 'Driver capture then prepare',
     'Install evaluation-maintenance only on M0. Capture unchanged M0 using its admitted manifest; prepare update against the same M0 root and distinct M0_REUSE_PROPOSAL generation with no native outputs or semantic reviews. Record the actual reuse/HOLD result, journal and counters. Do not initialize a root for the unused reuse generation.'),
    ('U1-P07', 'Materialize changed target source M1', 'External file operation with receipt',
     'Create M1 from the exact frozen M0 base-source inventory, excluding .atlas and later mutable binding/operation controls. Apply the unique owned-serve patch only in M1 and verify the fixed before/after sizes and SHA256. M0 remains coherent. M1 has no marker/policy/projection or CAS yet.'),
    ('U1-P08', 'Real invalidation control on old admitted M0', 'Source change, fresh W1 reader, exact restore',
     'Temporarily apply the same patch to M0 only after preserving its original file bytes and inventories. Install W1 policy and run the fixed neutral reader packet in a new independent context. Preserve actual refusal/selection outputs; then restore M0 from the exact saved original bytes, verify all base sources and record both mutations. Never patch d1 or s2-corpus. No further reader uses W1 after restoration.'),
    ('U1-P09', 'Capture and produce changed target', 'M0 authority, M1 source; real native production bridge',
     'Restore M0 maintenance-only policy. Capture from M1 against admitted M0 manifest using the corrected driver. The real planner determines affected order; compare it externally with the frozen oracle. Build each necessary native context using the capture, actual prior accepted result IDs and the pinned registry. Dispatch actual fresh producers separately; preserve literal requests/responses/bodies. For each changed result obtain two new result-specific semantic evidence records before that result is used as an accepted dependency. Count reachability, native calls and callback replays separately.'),
    ('U1-P10', 'Prepare complete M1 target', 'Driver prepare; M0 CAS store',
     'With source M1 stable, run prepareEvaluationUpdate once through the corrected driver using only actual sealed outputs and semantic records. Fix target generation M1 before this call. Save full prepare-result and target-prepared; inventory M0 CAS after prepare. The candidate is stored in M0 CAS but names root M1. No target admission or implicit reprepare occurs.'),
    ('U1-P11', 'New M1 decisions and private finalization', 'Two exact target decisions; driver finalize',
     'Obtain two new exact M1 ADMIT decisions over the complete target. Put their payload evidence and binding into the declared M1 binding namespace; capture those additional controls in its source inventory. Finalize using authority M0/store M0, source M1 and the full prepared update object. Save the actual private manifest/context and all output hashes. M0 must remain the authority root for this stage.'),
    ('U1-P12', 'Copy post-finalize CAS to fresh target', 'Verified external regular-file copy, not state clone',
     'Freeze/inventory M0 CAS after successful prepare and finalize, including new target and all ancestor/semantic/decision objects. Copy that exact complete CAS inventory into fresh M1/.atlas/cas using independent regular bytes; verify each path/size/hash and entire destination membership. Copy no projection, marker, policy, budget, staging or lock. Inventory M0 again to detect copy-time changes. A pre-update CAS snapshot is insufficient. M1 .atlas may contain only cas.'),
    ('U1-P13', 'Controlled stop and recovery', 'No Atlas invocation at the stop',
     'Stop after target/prepared, both decision streams, private finalization and the complete verified target CAS copy are durable, before M1 init/admission. Resume in a new host process; verify the frozen sources/runtime, prepared/update objects, decisions/binding, generations, CAS copy and absence of non-CAS target state. Continue without native production, recipe callbacks, reprepare or re-finalize. This demonstrates process restart, not power-loss durability.'),
    ('U1-P14', 'Initialize, admit and independently read M1', 'Original CLI init-store/admit-target; fresh W2',
     'Initialize fresh M1 from its target-prepared and exact target generation; install resolved admit-only policy separately; run admit-target once. Use its actual returned emitted manifest, which may differ from the private finalize manifest. Install W2 policy and give a new independent witness only its packet and port. W2 is also the post-recovery consumption observation, so no recovery-only witness is added.'),
    ('U1-P15', 'Restoration invalidation control on M1', 'Exact source restore, fresh W3 reader, restore changed bytes',
     'Save M1 changed source bytes. Temporarily write the exact original source bytes into admitted M1; install W3 and run its neutral reader packet in a fresh context. Capture actual current-selection results. Restore the saved changed bytes and verify M1 is coherent again before it serves as authority for M2. Never substitute M0/d1 responses for this M1 port.'),
    ('U1-P16', 'Materialize and produce restored M2', 'M1 authority, M2 original source',
     'Create M2 from the exact frozen M0 base sources; owned-serve therefore has the original exact bytes. No M0/M1 mutable state is copied. Install maintenance-only authority on coherent M1. Capture M2 against the actual admitted M1 manifest. Produce only callbacks justified by actual input/result changes, preserving new native and semantic records. Prepare M2 with its predeclared target generation in M1 CAS; obtain two new exact M2 decisions and finalize privately against M2.'),
    ('U1-P17', 'Copy final M1 CAS and admit M2', 'Verified CAS-only copy; original CLI init-store/admit-target',
     'After M2 prepare AND finalize, freeze the full M1 CAS inventory and copy it as regular independent files into fresh M2/.atlas/cas, with the same membership/byte verification and exclusions as P12. Initialize M2 only after this copy, install its resolved admit-only authority, and admit-target once. Record the returned admitted manifest.'),
    ('U1-P18', 'Final exact reuse and fresh restored witness', 'Driver capture/prepare on M2, then fresh W4',
     'Install M2 maintenance-only policy. Capture unchanged M2 and prepare against the same root with distinct M2_REUSE_PROPOSAL generation, empty outputs/reviews; preserve actual reuse and counters. Then start a fresh reader process, install W4 policy and dispatch a new independent witness. W4 covers restored current consumption after final reuse/restart; no additional witness or budget reset is added.'),
    ('U1-P19', 'Evidence closure and original controls', 'External comparison only until separately requested',
     'Reconcile actual source versions, direct/affected/outside mappings and callbacks with the unchanged graph oracle. Compare results/inputs/inputs_id/dependencies for outside entries, not v2 envelope IDs. Preserve original14 outcomes and all failed/held attempts. Carry compatible common control evidence only with its documented limits; any remaining domain control requires a separately frozen variant, new evidence and applicable decisions, not a silent registry mutation under M0. No final criterion or vote is inferred.'),
]
stage_rows = [{'id': x[0], 'name': x[1], 'mechanism': x[2], 'action': x[3], 'state': 'NOT_RUN'} for x in stages]
operator_plan = {'schema': 'genesis-s2-u1-operator-plan-proposal/v1', 'state': 'PROPOSED_NOT_RUN',
    'execution_id': EX, 'runtime_revision': REV, 'roots': ROOTS,
    'initial_d1_separation': {'root': str(EVAL), 'candidate': 'd1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30',
        'original_cases': initial['consumer_ids'], 'disposition': 'Preserved as distinct prerequisite work; none is renamed, rerun as U1, marked complete here or removed from its final obligations.'},
    'source_patch': static['source_patch'], 'frozen_oracle': static['frozen_oracle'], 'graph_for_operator_comparison_only': static['graph'],
    'proposed_generations': generations, 'witnesses': witnesses, 'read_limits': limits,
    'recovery_extra_witnesses': [], 'recovery_choice': 'W2 observes consumption after the deliberate durable stop; W4 observes restored consumption after exact reuse and a fresh reader process. No extra recovery ID is needed.',
    'stages': stage_rows,
    'old_root_rule': 'Each root has its own candidate/generation/source snapshot. M0 may coherently serve its original snapshot after M1 exists; that is not evidence about M1. A current-reader refusal requires changing a source in the very root selected by that port. Drift controls are temporary and fully restored before using that root as authority. No root/manifest fallback is permitted.',
    'cas_copy_rule': {'before_target_prepare': 'No target CAS/state is copied or needed by the source capture.',
        'after_prepare': 'Inventory authority CAS and preserve candidate/update/prepared evidence; target remains uninitialized.',
        'after_finalize': 'One full CAS-only copy of the frozen post-finalize authority inventory; includes all prepare/finalize additions and ancestor objects.',
        'source_to_target': [{'source': 'M0', 'target': 'M1'}, {'source': 'M1', 'target': 'M2'}],
        'copy_method': 'Read bytes from regular unaliased files and create exclusive destination files, not hardlinks/symlinks. Preserve per-file hashes/size and source/destination inventories. Do not copy any non-CAS .atlas file.',
        'recovery': 'Inspect partial destination and existing receipts before any continuation. Resume copying only verified missing files from the frozen snapshot with a new copy receipt; never overwrite divergent CAS bytes or repeat init/admit blindly.'},
    'control_reuse': {'map': stamp(AREA / 'common-controls-map.json'),
        'limit': 'The static map is not new S2 execution. Recipe/required-edge/metadata/blocked variants are not silently added to this primary source-only M0 lineage. If existing common evidence is inadequate, freeze a distinct variant before production.'},
    'policy_installation': {'existing_installer': str(BASE / 's2-investigation/install-evaluation-policy.py'),
        'existing_installer_applicable': False, 'reason': 'It pins the d1 prepared bytes, root and policies and admits only original case IDs. Do not modify/reuse it for M0.',
        'needed': 'A separately reviewed U1 installation implementation or explicit recorded operator file write must verify marker/candidate/root/generation, exact proposed policy bytes, existing policy transition, regular files and untouched budgets. The proposal does not create that installer.'},
    'uncertain_outcome': 'Do not retry Atlas operations or re-dispatch a witness after uncertain outcome. Inspect original streams, .atlas state and budgets; preserve the partial attempt. A new case/budget is not preauthorized. Change the frozen scope only through an explicit new proposal and applicable review.',
    'authority_limit': 'Actor strings and policy files are nominal local controls, not authentication or OS isolation. The witness-stage mapping is enforced by the frozen operator schedule and installed policy templates; the runtime plan copies the same finite ID list to each generation.'}
operator_ref = put('operator-plan.json', operator_plan)

plan = copy.deepcopy(initial)
plan['consumer_ids'] = [w['id'] for w in witnesses]
plan['consumer_modes'] = {w['id']: w['mode'] for w in witnesses}
plan['read_limits'] = limits
plan['isolation']['root'] = ROOTS['M0']
plan['maintenance'] = {
    'case': 'S2-U1', 'status': 'PROPOSED_NOT_RUN_DISTINCT_M0',
    'phase': 'Separate maintenance evaluation baseline M0. New preparation and two new exact admission decisions are required; no d1 authority or original-case result is transferred.',
    'operator_plan_ref': {'payload_path': OPERATOR_REL, 'sha256': operator_ref['sha256']},
    'frozen_case_ref': initial['maintenance']['frozen_case_ref'], 'frozen_graph_ref': initial['maintenance']['frozen_graph_ref'],
    'original_question_deck_ref': initial['maintenance']['question_deck_ref'],
    'original_cases_preserved': initial['consumer_ids'],
    'witness_packet_refs': [packet_refs[w['id']] for w in witnesses],
    'changed_input': initial['maintenance']['changed_input'],
    'controls': initial['maintenance']['controls'],
    'intended_operations_by_separate_policy': ['admit', 'index', 'read', 'evaluation-maintenance'],
    'policy_created': False,
    'prerequisites': ['First traversal and all original 14 cases have their own completed evidence before M0 work begins.',
        'New exact M0 plan/source/helper/runtime pins, private root, generation, admission decisions and governed publication.',
        'Actual native production and new result-specific semantics for changed results; new exact ADMIT for each complete target.',
        'Recorded CAS-only target transfer and recovery without source/root/manifest fallback.'],
    'secrecy': 'This plan contains reference identities and operational scope, not reserved answers. Witnesses receive only their separate neutral packet and the assigned reader port; never this plan/operator plan or oracle material.',
    'final_obligations': 'The original unchanged obligation set remains PENDING_FINAL_EVIDENCE. This proposal issues no ADMIT or final criterion verdict.'}
for name, digest in HELPER_PINS.items():
    plan['implementation'][PREFIX + '/helpers/' + name] = digest
for value in packet_refs.values():
    plan['implementation'][value['payload_path']] = value['sha256']
plan['implementation'][OPERATOR_REL] = operator_ref['sha256']
plan_ref = put('evaluation-plan.json', plan)

# The marker is runtime-produced and is deliberately not templated or fabricated.
governance_path = BASE / 's2-investigation/evaluation-authority/governance-policy.draft.json'
governance = json.loads(governance_path.read_bytes())
put('policies/governance-policy.template.json', governance)
policy_rows = []
for root_name, root_path in ROOTS.items():
    for purpose in ['admit', 'maintenance']:
        policy = {'schema': 'ownership-evaluation-policy/v1', 'root': root_path,
            'evaluationPlan': token(root_name + '_EVALUATION_PLAN_ID'), 'obligationSet': OBLIGATION_ID,
            'evaluationCandidate': token(root_name + '_CANDIDATE_ID'), 'generation': generations[root_name]['value'],
            'scope': SCOPE, 'actor': ACTOR, 'operations': ['admit'] if purpose == 'admit' else ['evaluation-maintenance'], 'consumer': None}
        path = 'policies/' + root_name.lower() + '-' + purpose + '.template.json'
        put(path, policy); policy_rows.append({'file': path, 'root': root_name, 'purpose': purpose})
for w in witnesses:
    policy = {'schema': 'ownership-evaluation-policy/v1', 'root': ROOTS[w['root']],
        'evaluationPlan': token(w['root'] + '_EVALUATION_PLAN_ID'), 'obligationSet': OBLIGATION_ID,
        'evaluationCandidate': token(w['root'] + '_CANDIDATE_ID'), 'generation': generations[w['root']]['value'],
        'scope': SCOPE, 'actor': ACTOR, 'operations': ['index', 'read'], 'consumer': {'id': w['id'], 'mode': w['mode']}}
    path = 'policies/' + w['id'] + '.template.json'; put(path, policy)
    policy_rows.append({'file': path, 'root': w['root'], 'purpose': 'witness', 'witness_id': w['id']})
put('policies/policy-transition-proposal.json', {'schema': 'genesis-s2-u1-policy-transition-proposal/v1', 'state': 'NOT_INSTALLED',
    'templates': policy_rows, 'governance_source': stamp(governance_path), 'not_a_marker': True,
    'nominal_actor': ACTOR, 'ratify_token': 'ALWAYS_UNSET',
    'install_requires': ['Runtime-created marker already exists and matches exact candidate, plan, obligationSet, root, scope and generation.',
        'Resolve placeholders from actual prepared/target results and verify the expected reused obligation ID.',
        'Write exact governance/evaluation policy bytes separately with before/after snapshots and a new installation receipt.',
        'Do not copy or edit budgets, projection, staging, locks or marker; no parallel consumer/policy switch in one root.',
        'Do not use or patch the fixed d1 policy installer.'],
    'unimplemented_install_action': 'U1-specific installation is an explicit remaining implementation/review item; no invented executable command is supplied.'})

driver_source = PREFIX + '/helpers/u1-evaluation-operation.mjs'
builder_source = PREFIX + '/helpers/build-native-request.mjs'
registry_source = PREFIX + '/helpers/recipe-registry.json'
registry_ref = {'path': str(AREA / 'recipe-registry.json'), 'sha256': HELPER_PINS['recipe-registry.json']}
prepared_paths = {'M0': EXEC + '/m0-prepare-01/prepared.json',
    'M1': EXEC + '/m1-prepare-update-01/driver/target-prepared.json',
    'M2': EXEC + '/m2-prepare-update-01/driver/target-prepared.json'}
templates = []


def command(mode, root, operation_id, **extra):
    value = {'schema': 'genesis-s2-u1-command-request/v1', 'mode': mode, 'authority_root': ROOTS[root],
        'operation_id': operation_id, 'output_dir': EXEC + '/' + operation_id,
        'candidate_id': None if mode == 'prepare' else token(root + '_CANDIDATE_ID'),
        'source_inventories': token(operation_id.upper().replace('-', '_') + '_EXACT_SOURCE_INVENTORY_REFS_ARRAY'),
        'controls': token(operation_id.upper().replace('-', '_') + '_EXPLICIT_CONTROL_REFS_ARRAY'), **extra}
    file = 'command-templates/' + operation_id + '.command-request.template.json'
    put(file, value)
    templates.append({'operation_id': operation_id, 'file': file, 'mode': mode, 'root': root,
        'future_config_builder_argv': ['python', str(AREA / 'build-operation-config.py'), '--request', EXEC + '/controls/' + operation_id + '.command-request.json',
            '--request-sha256', token('RESOLVED_COMMAND_REQUEST_SHA256'), '--command-file', EXEC + '/controls/' + operation_id + '.command.json'],
        'future_guarded_execution_argv': ['python', str(BASE / 's2-investigation/capture-state-operation.py'), EXEC + '/controls/' + operation_id + '.command.json', value['output_dir']],
        'state': 'TEMPLATE_NOT_EXECUTED'})
    return value


def operation(mode, authority, source, operation_id, **extra):
    value = {'schema': 'genesis-s2-u1-operation-request/v1', 'mode': mode, 'authority_root': ROOTS[authority],
        'source_root': ROOTS[source], 'output_dir': EXEC + '/' + operation_id + '/driver',
        'baseline': {'path': prepared_paths[authority], 'sha256': token(authority + '_PREPARED_SHA256')},
        'manifest': token(authority + '_ACTUALLY_ADMITTED_MANIFEST_ID'), 'driver_source_path': driver_source,
        'registry_source_path': registry_source, 'registry': registry_ref, **extra}
    put('operation-templates/' + operation_id + '.operation-request.template.json', value)
    command({'capture': 'capture', 'prepare': 'prepare-update', 'finalize': 'finalize-update'}[mode], authority, operation_id,
        operation_request=EXEC + '/controls/' + operation_id + '.operation-request.json')


command('prepare', 'M0', 'm0-prepare-01', plan_relative=PLAN_REL, prepared_output=prepared_paths['M0'])
for r in ROOTS:
    command('init-store', r, r.lower() + '-init-store-01', prepared=prepared_paths[r], generation=generations[r]['value'])
    command('admit' if r == 'M0' else 'admit-target', r, r.lower() + '-admit-01', prepared=prepared_paths[r],
        approval_relative=PREFIX + '/bindings/' + r.lower() + '/binding.json')
for authority in ['M0', 'M2']:
    op = authority.lower() + '-reuse-capture-01'
    operation('capture', authority, authority, op)
    operation('prepare', authority, authority, authority.lower() + '-reuse-prepare-01',
        capture={'path': EXEC + '/' + op + '/driver/capture.json', 'sha256': token(authority + '_REUSE_CAPTURE_SHA256')},
        target_root=ROOTS[authority], target_generation=generations[authority + '_REUSE_PROPOSAL']['value'], native_outputs=[], semantic_reviews=[])
for authority, target in [('M0', 'M1'), ('M1', 'M2')]:
    low = target.lower(); capture_op = low + '-capture-01'; prep_op = low + '-prepare-update-01'
    operation('capture', authority, target, capture_op)
    operation('prepare', authority, target, prep_op,
        capture={'path': EXEC + '/' + capture_op + '/driver/capture.json', 'sha256': token(target + '_CAPTURE_SHA256')},
        target_root=ROOTS[target], target_generation=generations[target]['value'],
        native_outputs=token(target + '_ACTUAL_SEALED_NATIVE_OUTPUT_REFS_ARRAY'), semantic_reviews=token(target + '_ACTUAL_NEW_SEMANTIC_REVIEW_REFS_ARRAY'))
    operation('finalize', authority, target, low + '-finalize-01',
        target={'path': EXEC + '/' + prep_op + '/driver/prepare-result.json', 'sha256': token(target + '_PREPARED_UPDATE_SHA256')},
        binding={'path': ROOTS[target] + '/' + PREFIX + '/bindings/' + low + '/binding.json', 'sha256': token(target + '_EXACT_BINDING_SHA256')})
    native_context = {'schema': 'genesis-s2-u1-native-context-request/v1', 'authority_root': ROOTS[authority],
        'baseline': {'path': prepared_paths[authority], 'sha256': token(authority + '_PREPARED_SHA256')},
        'capture': {'path': EXEC + '/' + capture_op + '/driver/capture.json', 'sha256': token(target + '_CAPTURE_SHA256')},
        'registry': registry_ref, 'registry_source_path': registry_source, 'builder_source_path': builder_source,
        'manifest': token(authority + '_ACTUALLY_ADMITTED_MANIFEST_ID'), 'admission_receipt': {'path': EXEC + '/' + authority.lower() + '-admit-01/receipt.json', 'sha256': token(authority + '_ACTUAL_ADMISSION_RECEIPT_SHA256')},
        'key': token('ACTUAL_NEXT_REQUIRED_NATIVE_KEY'), 'output_dir': EXEC + '/producers/' + low + '-' + token('EXCLUSIVE_NATIVE_CONTEXT_NAME'),
        'accepted_outputs': token(target + '_PRIOR_ACCEPTED_OUTPUT_REFS_ARRAY'),
        'semantic_reviews': token(target + '_PRIOR_NEW_SEMANTIC_REVIEW_REFS_ARRAY')}
    put('operation-templates/' + low + '-build-native-context.operation-request.template.json', native_context)
    command('build-native-context', authority, low + '-build-native-context-' + token('EXCLUSIVE_OPERATION_SUFFIX'),
        operation_request=EXEC + '/controls/' + low + '-build-native-context-' + token('EXCLUSIVE_OPERATION_SUFFIX') + '.operation-request.json')
for w in witnesses:
    for n, item in enumerate(json.loads((OUT / 'witness-packets' / (w['id'] + '.json')).read_bytes())['queries'], 1):
        query_file = 'reader-queries/' + w['id'] + '-' + str(n).zfill(2) + '.json'
        put(query_file, item['query'])
        command(item['mode'], w['root'], w['id'].lower() + '-' + str(n).zfill(2) + '-' + item['mode'],
            query=EXEC + '/reader-queries/' + w['id'] + '-' + str(n).zfill(2) + '.json', witness_id=w['id'])
put('command-templates/index.json', {'schema': 'genesis-s2-u1-command-template-index/v1', 'state': 'NOT_RUN',
    'cwd': str(RUNTIME / 'modules/atlas'), 'bun': BUN, 'templates': templates,
    'nominal_environment': {'ATLAS_ACTOR': ACTOR}, 'always_unset': ['ATLAS_RATIFY_TOKEN'],
    'unset_actor_modes': ['prepare', 'init-store', 'build-native-context'],
    'output_parents': 'Create only external execution/control parent directories as a separate recorded step when work is later authorized. Output directories themselves must remain exclusive/nonexistent before each recorder operation.',
    'typed_placeholders': 'Tokens ending _ARRAY must be replaced by actual JSON arrays, not strings. Empty arrays are valid only for proven exact reuse or where no prior records exist; do not predeclare nine native calls.',
    'controls_required': ['All non-state source inventories for authority and source roots, with intended hashes and no redefinition of frozen base rows.',
        'Fixed runtime-byte-lock 1170 rows plus corrected external helper bytes, recorder/wrapper and exact request/control files.',
        'Installed current marker/policies for authoritative modes; actual prepared files, captures and all captured file rows, native seals/requests/responses/bodies, semantic records and binding evidence used by that operation.',
        'All queries and execution requests remain outside evaluation source observations; decision payload references use the dedicated binding namespace.'],
    'not_supplied': ['No Atlas candidate, marker, original runtime receipt, producer response, semantic judgment or ADMIT decision is fabricated.',
        'No generic policy installer command is invented. See separate explicit policy-installation prerequisite.']})

# Exact future base-source schedule. This is a copy proposal, not a materialization receipt.
base_files = []
for row in material['files']:
    base_files.append({'path': row['path'], 'source_path': str(EVAL / row['path']), 'byte_length': row['byte_length'],
        'sha256': row['sha256'], 'git_blob_sha': row['git_blob_sha'], 'category': 'unchanged-preserved-base', 'provenance': row['provenance']})
for name in HELPER_PINS:
    s = stamp(AREA / name)
    base_files.append({'path': PREFIX + '/helpers/' + name, 'source_path': s['path'], 'byte_length': s['byte_length'], 'sha256': s['sha256'], 'git_blob_sha': s['git_blob'], 'category': 'new-maintenance-helper-or-doc'})
for w in witnesses:
    s = stamp(OUT / 'witness-packets' / (w['id'] + '.json'))
    base_files.append({'path': packet_refs[w['id']]['payload_path'], 'source_path': s['path'], 'byte_length': s['byte_length'], 'sha256': s['sha256'], 'git_blob_sha': s['git_blob'], 'category': 'new-neutral-witness-packet'})
for rel, filename in [(OPERATOR_REL, 'operator-plan.json'), (PLAN_REL, 'evaluation-plan.json')]:
    s = stamp(OUT / filename)
    base_files.append({'path': rel, 'source_path': s['path'], 'byte_length': s['byte_length'], 'sha256': s['sha256'], 'git_blob_sha': s['git_blob'], 'category': 'new-maintenance-plan'})
assert len(base_files) == 728 and len({x['path'] for x in base_files}) == 728
put('materialization-proposal.json', {'schema': 'genesis-s2-u1-materialization-proposal/v1', 'state': 'NOT_MATERIALIZED',
    'roots': ROOTS, 'original_root': str(BASE / 's2-corpus'), 'source_materialization_head': None,
    'base_source_count': len(base_files), 'unchanged_preserved_count': 716, 'additive_count': 12,
    'base_sources': base_files, 'preserved_source_manifest': stamp(material_path),
    'root_sources': {'M0': 'All728 exact base sources; no inherited .atlas or .git.',
        'M1': 'All728 base sources, with only owned-serve.ts changed to the fixed prospective bytes. Later actual M1 binding payloads are separate explicit additions.',
        'M2': 'All728 exact base sources (original owned-serve.ts bytes). Later actual M2 binding payloads are separate explicit additions.'},
    'mutable_control_namespace': PREFIX + '/bindings/',
    'rules': ['Create independent real directories; no symlinks/hardlinks or copied marker/policy/projection/budgets.',
        'Copy only explicitly listed source rows, not the live evaluation directory recursively.',
        'Before every operation preserve the complete actual non-state inventory, including explicit later binding files. Never silently rewrite a pinned base row.',
        'Keep operator controls, requests, native output/semantic records and query files external unless a specific payload binding requires the dedicated source namespace.',
        'Perform CAS-only target transfer only after target prepare/finalize according to operator-plan.json.']})

# Static shape comparison only: no runtime validator, kernel ID, helper or main is called.
expected_plan_keys = {'schema','package_path','original_prepared','obligations','entries','consumer_ids','consumer_modes','read_limits','maintenance','implementation','isolation'}
assert set(plan) == expected_plan_keys and plan['schema'] == 'genesis-evaluation-plan/v1'
assert plan['entries'] == initial['entries'] and plan['original_prepared'] == initial['original_prepared'] and plan['obligations'] == initial['obligations']
assert not set(plan['consumer_ids']) & set(initial['consumer_ids'])
assert len(plan['consumer_ids']) == 5 and len(set(plan['consumer_ids'])) == 5 and len(plan['implementation']) == 39
policy_keys = {'schema','root','evaluationPlan','obligationSet','evaluationCandidate','generation','scope','actor','operations','consumer'}
for row in policy_rows:
    value = json.loads((OUT / row['file']).read_bytes())
    assert set(value) == policy_keys and value['schema'] == 'ownership-evaluation-policy/v1'
    assert value['generation'] == generations[row['root']]['value'] and re.fullmatch(r'[0-9a-f]{64}', value['generation'])
    if row['purpose'] == 'witness':
        assert value['consumer']['mode'] == plan['consumer_modes'][value['consumer']['id']]
all_tokens = {}
for path in OUT.rglob('*.json'):
    for name in sorted(set(re.findall(r'\{\{([^{}]+)\}\}', path.read_text()))):
        all_tokens.setdefault(name, []).append(str(path.relative_to(OUT)))
put('placeholder-catalog.json', {'schema': 'genesis-s2-u1-placeholder-catalog/v1', 'state': 'UNRESOLVED_NOT_EXECUTABLE',
    'tokens': all_tokens, 'rules': ['Resolve candidate/plan/manifest IDs only from actual original operation outputs.',
        'Resolve file hashes only from exact preserved bytes; no synthetic receipt or approval.',
        'Preserve actual fresh host agent identity separately at dispatch, not by reusing a witness ID.',
        'Resolve every token and verify the intended files/installed policy/marker before passing a request to the config builder.',
        'Generation values are proposed independent operator selections, not observed initialization results.']})
put('static-schema-review.json', {'schema': 'genesis-s2-u1-proposal-static-schema-review/v1',
    'state': 'STATIC_SHAPE_ONLY_NOT_RUNTIME_VALIDATED', 'runtime_revision': REV,
    'checks': {'native_plan_top_level_keys_equal_db9_source': True, 'original13_entries_equal_initial_plan': True,
        'original_prepared_and_obligation_refs_equal': True, 'new_witness_ids_finite_and_disjoint_from_original14': True,
        'witness_policy_ids_modes_match_new_plan': True, 'policy_template_key_sets_equal_db9_source': True,
        'proposed_generations_are_distinct_64_hex': True, 'implementation_pins_count': 39,
        'preserved_source_rows_hash_verified': 716, 'future_base_source_rows': 728},
    'runtime_sources_read': [stamp(RUNTIME / rel) for rel in [
        'modules/atlas/docs/design/evaluation-admission.md',
        'modules/atlas/packages/adapter-io/src/genesis-evaluation.ts',
        'modules/atlas/packages/adapter-io/src/ownership-evaluation-policy.ts',
        'modules/atlas/packages/adapter-io/src/evaluation-read-budget.ts',
        'modules/atlas/packages/adapter-io/src/ownership-access.ts',
        'modules/atlas/packages/adapter-io/src/evaluation-manifest-binding.ts',
        'modules/atlas/packages/adapter-io/src/evaluation-rebuild.ts',
        'modules/atlas/scripts/genesis-evaluation.ts']],
    'template_limits': 'Policy IDs and command inputs still contain explicit typed placeholders, so these templates are intentionally not executable or fully runtime-valid. No native schema validator was invoked.',
    'runtime_or_helpers_executed': False, 'roots_created': [], 'policies_installed': [], 'candidates_computed': [], 'receipts_or_votes_created': []})
assert initial_path.read_bytes() == initial_bytes
assert not any(Path(root).exists() for root in ROOTS.values())
put('proposal-summary.json', {'schema': 'genesis-s2-u1-m0-proposal-summary/v1', 'state': 'PROPOSED_NOT_RUN',
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'evaluation_plan': plan_ref, 'operator_plan': operator_ref,
    'helper_inventory': stamp(inventory_path), 'original_audit': stamp(BASE / 's2-investigation/maintenance-mechanical-audit/report.json'),
    'mechanical_corrections': stamp(BASE / 's2-investigation/maintenance-mechanical-fix-01/report.json'),
    'witness_count': 5, 'additional_recovery_witnesses': 0, 'policies': len(policy_rows), 'command_templates': len(templates),
    'original14_case_ids_preserved': initial['consumer_ids'], 'native_calls_or_decisions': 'NOT_CREATED',
    'remaining_dependencies': ['Complete original first traversal and 14 cases before M0.',
        'Review/freeze this proposal and its exact bytes before materialization.',
        'Implement/review U1-specific exact policy installation or preserve equivalent explicit operator-write receipts; fixed d1 installer is inapplicable.',
        'Actual fresh native producers, independent witnesses and new semantic/admission decisions remain future work.',
        'Read-only bridge must bind each fresh witness to its mapped root/candidate/generation and budget; do not reuse a d1-only bridge without explicit U1 configuration.',
        'Validate transfer/recovery bytes with their actual future receipts; this proposal is not implementation qualification.']})
print(json.dumps({'evaluation_plan': plan_ref, 'operator_plan': operator_ref, 'witnesses': 5, 'base_sources_proposed': 728,
                  'command_templates': len(templates), 'u1_roots_created': False, 'atlas_or_helpers_executed': False}))
