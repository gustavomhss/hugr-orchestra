# Operação U1 — instalação e ponte propostas, NOT_RUN

Este diretório contém código futuro para a dependência operacional da proposta M0. Nenhum `main`, helper, Atlas, teste de produto, policy, consumidor ou juiz foi executado. Nenhuma raiz U1 foi criada. A proposta original em `maintenance-m0-proposal/` permanece intacta; `proposed-integration/` contém uma revisão separada para eventual freeze de M0.

## Instalador separado de d1

`install-u1-policy.py` aceita um pedido externo fixado por SHA-256. Só admite as raízes exatas M0/M1/M2 propostas e exige um marcador de inicialização já existente, regular, com root/device/inode atuais. Compara candidato, plano, obrigação, escopo e geração entre o marcador e os bytes do prepared original ou target.

As identidades são vinculadas aos outputs integrais dos recibos reais de prepare/prepare-update e init-store, incluindo guard de bytes, cobertura dos 1.170 arquivos de runtime, streams e captura de estado. Para manutenção ou witness, também exige admissão governada efetiva. O helper não implementa o kernel, recalcula IDs CAS ou fabrica marcadores/recibos: sua comprovação é a igualdade com a evidência original fornecida, cuja identidade do operador continua nominal.

O helper confere os próprios bytes, o módulo comum, o escopo e a referência E002 contra os pins e as cópias de fonte do novo plano M0, presentes no lock da operação que produziu o candidato. Esses arquivos precisam estar incluídos antes de preparar M0. Ele não exige fonte íntegra durante uma sonda deliberada de drift; essa avaliação continua sendo feita pelo leitor real.

A política é fornecida integralmente pelo operador, nunca sintetizada. As identidades precisam coincidir com o marcador. Os modos são estritos: `admit`, `evaluation-maintenance`, ou `index`+`read` para um dos cinco witnesses na raiz/modo fixados. A governança deve ter os bytes compartilhados já declarados. Não há ampliação silenciosa das operações nem cópia de autoridade de d1.

Antes de escrever, exige o hash exato da política anterior (ou `null` para ausência), preserva inventário do estado e cópias dos arquivos fora do CAS. Depois escreve somente `policy.json`/`evaluation-policy.json`, por substituição atômica de arquivos próprios, e captura novamente. Todos os outros arquivos/diretórios, incluindo CAS, marcador, projeção e budgets, devem permanecer idênticos. Locks/arquivos parciais de estado provocam recusa para inspeção. Falhas depois de alguma escrita recebem recibo de resultado incerto; não há retry, rollback ou reset automático.

Forma futura de invocação, **não executada**:

```text
python install-u1-policy.py --request <pedido-real-absoluto> --request-sha256 <sha256-dos-bytes>
```

O pedido deve seguir `templates/policy-install-request.template.json`. Para `maintenance` ou `witness`, a referência de admissão é obrigatória. O diretório de saída exclusivo deve ficar sob `s2-execution/u1/policy/`, com pai já criado. O instalador d1 e seus pins não foram alterados e não são chamados por este código.

## Ponte de witness

`run-u1-witness.py` exige a política do witness já instalada; instalação e transporte são ações separadas. Confere seu recibo, os mesmos IDs reais do prepared/init/admission e o pacote neutro congelado. Exige registro externo do despacho realmente ocorrido, `fork_turns: none`, ID real de agente, raiz/candidato/geração/caso correspondentes. O ID do witness não é convertido em ID de agente.

O pedido do consumidor deve ser preservado literalmente, com `kind`, `case_id`, `operation` e `query`, e corresponder a uma query permitida no pacote. O helper cria a configuração pelo `maintenance-plan/build-operation-config.py` corrigido, conserva controles explícitos e passa a chamada única ao `capture-state-operation.py` fixado. O próprio runtime aplica os budgets; a ponte não os recria ou zera.

A função `state_capture_problems` é cópia **literal** do gate E002 corrigido, cuja origem integral está em `reference/e002-run-reader-operation.py`: 13.779 bytes, SHA-256 `955031da137d2052e333d495096a660369246b9ed92707f1e72745d729a252e5`. A função extraída tem 1.578 bytes e SHA-256 `5a922a0be757bb0e29d1e071e6555d49507dcf08e3a52e5b5de38ad3d3746180`; `e002-reuse.json` registra a igualdade textual. Não se importou nem executou o bridge d1.

O gate é aplicado aos recibos históricos usados como pré-condição e à operação corrente, incluindo o exit real do wrapper nesta última. Uma recusa legítima da CLI com exit não zero pode ser transmitida quando toda a captura é consistente. Falha apenas do wrapper, divergência de estado/guard ou streams inválidos impede o encaminhamento. Os efeitos e o orçamento consumido são preservados, sem repetir a operação. O arquivo `reader-response.txt` contém somente os streams originais e seus identificadores; não cria resposta de domínio, voto ou julgamento.

Forma futura de invocação, **não executada**:

```text
python run-u1-witness.py --request <controle-real-absoluto> --request-sha256 <sha256-dos-bytes>
```

O controle segue `templates/witness-bridge-request.template.json`; o diretório de saída exclusivo fica sob `s2-execution/u1/witnesses/`. O registro de dispatch e o pedido do consumidor devem existir de fato. Os placeholders não são evidência e os templates não podem ser usados como se um agente já tivesse sido criado.

## Integração antes do freeze

A revisão proposta acrescenta sete arquivos fixados ao namespace `maintenance-v2/operator-helpers/`: os dois executáveis, `u1_operator_common.py`, `operator-scope.json`, esta documentação, a referência integral E002 e `integration-amendment.json`. O plano nativo revisado mantém os cinco witnesses, seus limites, os 13 entries, as refs semânticas e a obrigação original; muda somente a ligação desta implementação operacional adicional.

`proposed-integration/source-overlay.json` identifica as adições e a substituição prospectiva do arquivo de plano, sem modificar a proposta anterior ou materializar uma raiz. São 46 pins no plano revisado e 735 arquivos-base prospectivos. Qualquer edição posterior destes helpers exige hashes novos e outro plano fixado antes de M0; não pode ser sobreposta depois de preparado.

Os hashes dos helpers comuns já existentes permanecem: configurador U1 `62d4ae06…`, wrapper `b7022b32…` e recorder `0185ccf1…`, íntegros e completos no inventário. A revisão é estática/sintática, sem qualificação de comportamento, parecer ou decisão. Nenhum material desta proposta U1 foi enviado aos juízes atuais de d1.
