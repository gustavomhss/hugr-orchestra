from pathlib import Path
import json,hashlib,sys,datetime
O=Path(__file__).parent; D=O.parent; wave=int(sys.argv[1]);p=(O if wave<=30 else D/'delta-setup-01')/'messages'/f'{wave:03d}.txt';b=p.read_bytes()
row={'event':'ACTUAL_FOLLOWUP_TASK_SENT','amendment':1,'wave':wave,'target':'/root/s2_j1','request_path':str(p),'request_utf8_bytes':len(b),'request_sha256':hashlib.sha256(b).hexdigest(),'host_message_id':None,'host_timestamp':None,'observed_tool_result':'empty successful collaboration.followup_task return; no error','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limit':'Local timestamp records ledger write, not host delivery. Literal tool request supplied from this prepared message; host does not expose transport bytes or message ID.'}
L=D/'transport-ledger.jsonl';old=[json.loads(s) for s in L.read_text().splitlines()]
if not any(r.get('event')==row['event'] and r.get('target')==row['target'] and r.get('wave')==wave for r in old):
    with L.open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
state=json.loads((D/'dispatch-state.json').read_bytes());state.setdefault('last_actual_wave_by_judge',{})['s2_j1']=wave;(D/'dispatch-state.json').write_text(json.dumps(state,indent=2)+'\n')
print(wave,len(b),row['request_sha256'])
