const fs=require('fs'),path=require('path'),crypto=require('crypto'),cp=require('child_process');
const ROOT='/workspace/scratch/5cfbb6c803f1', runtime=ROOT+'/s2-runtime', OUT=__dirname, ts=require(runtime+'/modules/atlas/node_modules/typescript');
const sh=b=>crypto.createHash('sha256').update(b).digest('hex');
const base='modules/atlas/packages/adapter-io/src/';
const transformation=['genesis-evaluation.ts','genesis-evaluation-binding.ts','genesis-native.ts','genesis-native-format.ts','genesis-native-io.ts','genesis-native-binding.ts','ownership-input.ts','evaluation-runtime-identity.ts'];
const isolation=['ownership-evaluation-policy.ts','evaluation-read-budget.ts','evaluation-state-io.ts','evaluation-manifest-binding.ts','store-evaluation-identity.ts','ownership-access.ts','ownership-attachment.ts','read-access.ts','knowledge-log.ts','knowledge-replay.ts','own-export.ts','okf-store.ts','store.ts'];
const orchestration=['compose.ts','compose-runtime.ts','wire.ts','governed-emit.ts','governed-link.ts','memory-emit.ts','governed-promote.ts'];
const other=['modules/atlas/scripts/genesis-evaluation.ts','modules/atlas/packages/knowledge/src/ownership/evaluation.ts','modules/atlas/packages/knowledge/src/ownership/read.ts','modules/atlas/packages/knowledge/src/ownership/shape.ts','modules/atlas/packages/kernel/src/canonical.ts','modules/atlas/packages/kernel/src/encoder.ts'];
const files=[...transformation.map(p=>[base+p,'transformation']),...isolation.map(p=>[base+p,'isolation']),...orchestration.map(p=>[base+p,'orchestration']),...other.map(p=>[p,'other'])];
fs.mkdirSync(OUT+'/source',{recursive:true});let records=[];
for(const [rel,group] of files){
 const raw=fs.readFileSync(runtime+'/'+rel),text=raw.toString('utf8'),pin=cp.execFileSync('git',['-C',runtime,'show','db9b4235022c4df32fe3bfd4faeea8adcd69abb7:'+rel],{env:{...process.env,GIT_OPTIONAL_LOCKS:'0',GIT_NO_LAZY_FETCH:'1',GIT_TERMINAL_PROMPT:'0'},maxBuffer:2000000});
 if(!raw.equals(pin))throw Error('drift '+rel);
 const sf=ts.createSourceFile(rel,text,ts.ScriptTarget.Latest,true),parts=[],nodes=[];
 for(const node of sf.statements){if(group==='orchestration'&&(ts.isInterfaceDeclaration(node)||ts.isTypeAliasDeclaration(node)))continue;const start=node.getStart(sf),end=node.end;const slice=text.slice(start,end);parts.push(slice);nodes.push({kind:ts.SyntaxKind[node.kind],name:node.name?.text??null,source_start_utf8:Buffer.byteLength(text.slice(0,start)),source_end_utf8:Buffer.byteLength(text.slice(0,end)),sha256:sh(Buffer.from(slice))});}
 const output=Buffer.from(parts.join('\n')+'\n'),name=rel.replaceAll('/','__');fs.writeFileSync(OUT+'/source/'+name,output);records.push({path:rel,group,git_commit:'db9b4235022c4df32fe3bfd4faeea8adcd69abb7',source_bytes:raw.length,source_sha256:sh(raw),projection_file:'source/'+name,projection_bytes:output.length,projection_sha256:sh(output),method:'All top-level TypeScript AST statements, exact text spans getStart..end; only outer comments/whitespace omitted. All runtime declarations/function bodies/imports retained; type-only interface/type alias declarations omitted only in orchestration group. Internal comments retained. Not runtime execution.',nodes});
}
fs.writeFileSync(OUT+'/source-extraction-manifest.json',JSON.stringify({schema:'s2-literal-typescript-statement-projection/v1',typescript:ts.version,files:records},null,2)+'\n');
console.log(JSON.stringify(records.reduce((o,r)=>(o[r.group]=(o[r.group]||0)+r.projection_bytes,o),{})));