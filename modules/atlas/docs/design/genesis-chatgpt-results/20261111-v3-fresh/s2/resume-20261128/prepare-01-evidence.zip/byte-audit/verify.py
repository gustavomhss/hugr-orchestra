"""Hash and reconcile public S2 custody bytes. This does not execute Atlas."""
from pathlib import Path
import base64
import collections
import datetime
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
MATERIALIZED = ROOT / 'materialized'
PREFIX = 'modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2/'
PIN = 'bb2a931301d541692b11e5a7f1eab234cd9ed2fd'
SOURCE = '1cde2ff7a71bcf7aecb5d030917b577165135d38'
PACKAGE_HASH = '9356cefcb4a1db413e67869a855fd082536476fb18ff7784dde39f051e9b407b'

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    data = (MATERIALIZED / path).read_text(encoding='utf-8')
    if data.startswith('```json\n'):
        data = data[len('```json\n'):].rsplit('```', 1)[0].strip()
    return json.loads(data)

downloads = []
for path in sorted((ROOT / 'fetch').rglob('*.fetch.json')):
    response = json.loads(path.read_bytes())
    data = base64.b64decode(response['content'])
    relative = response['path'].removeprefix(PREFIX)
    if relative == response['path'] or '..' in Path(relative).parts:
        raise ValueError('Unexpected fetched path')
    destination = MATERIALIZED / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    downloads.append({
        'path': response['path'], 'relative_path': relative,
        'commit': response['ref'], 'byte_length': len(data),
        'sha256': sha256(data), 'git_blob_sha': blob,
        'returned_git_blob_sha': response['sha'],
        'git_blob_matches': blob == response['sha'],
    })

by_path = {r['relative_path']: r for r in downloads}
package = read_json('native-package.json')
accepted = [read_json(f'accepted/l{i}.json') for i in range(1, 5)]
accepted_by_key = {a['key']: a for m in accepted for a in m['artifacts']}
artifacts = []
for artifact in package['artifacts']:
    key = artifact['key']
    body = by_path[artifact['body']['path']]
    acceptance = accepted_by_key[key]
    reviews = []
    for reference in artifact['semantic_review_refs']:
        relative = reference['payload_path'].removeprefix(PREFIX)
        review_bytes = by_path[relative]
        review = read_json(relative)
        decision = next(d for d in review['artifacts'] if d['key'] == key)
        manifest_review = next(r for r in acceptance['reviews'] if r['response_path'] == relative)
        reviews.append({
            'path': reference['payload_path'],
            'sha256': review_bytes['sha256'],
            'sha256_matches_package_and_acceptance': review_bytes['sha256'] == reference['sha256'] == manifest_review['response_sha256'],
            'reviewer': review['reviewer'],
            'historical_verdict': decision['verdict'],
            'historical_body_sha256': decision['body_sha256'],
            'historical_body_matches': decision['body_sha256'] == body['sha256'],
        })
    artifacts.append({
        'key': key, 'layer': artifact['layer'], 'body': body,
        'body_sha256_matches_package_and_acceptance': body['sha256'] == artifact['body']['sha256'] == acceptance['body_sha256'],
        'body_bytes_match_package_and_acceptance': body['byte_length'] == artifact['body']['byte_length'] == acceptance['byte_length'],
        'body_path_matches_acceptance': artifact['body']['path'] == acceptance['body_path'],
        'historical_semantic_reviews': reviews,
    })

deck = read_json('requests/consumer-question-deck.json')
oracle = read_json('oracles/update-final-graph-expectation.json')
keys = {a['key'] for a in package['artifacts']}
build_edges = {(a['key'], d['key']) for a in package['artifacts'] for d in a['build_dependencies']}
navigation_edges = {(a['key'], d) for a in package['artifacts'] for d in a['navigation']}
direct = {a['key'] for a in package['artifacts'] if oracle['changed_input'] in a['input_keys']}
affected = set(direct)
while True:
    updated = affected | {c for c, d in build_edges if d in affected}
    if updated == affected:
        break
    affected = updated
source_refs = [r for a in package['artifacts'] for r in a['source_refs']]
source_versions = collections.defaultdict(set)
for ref in source_refs:
    source_versions[ref['path']].add((ref['commit'], ref['git_blob_sha'], ref['sha256']))
unique_inputs = {i for a in package['artifacts'] for i in a['input_keys']}
frozen_case_ids = ['S2-C1', 'S2-C2', 'S2-C3', 'S2-C4', 'S2-C5', 'S2-I1D', 'S2-I1A', 'S2-I1U', 'S2-I2D', 'S2-I2A', 'S2-I2U', 'S2-I3D', 'S2-I3A', 'S2-I3U']
checks = {
    'all_download_git_blobs_match': all(r['git_blob_matches'] for r in downloads),
    'package_hash_matches_pin': by_path['native-package.json']['sha256'] == PACKAGE_HASH,
    'package_byte_length_matches': by_path['native-package.json']['byte_length'] == 332594,
    'package_13_unique_keys': len(package['artifacts']) == len(keys) == 13,
    'required_key_set_matches': set(package['required_artifact_keys']) == keys,
    'missing_required_key_list_empty': package['missing_required_artifact_keys'] == [],
    'accepted_key_set_matches': set(accepted_by_key) == keys,
    'all_13_body_hashes_lengths_paths_match': all(a['body_sha256_matches_package_and_acceptance'] and a['body_bytes_match_package_and_acceptance'] and a['body_path_matches_acceptance'] for a in artifacts),
    'all_26_historical_reviews_match': all(len(a['historical_semantic_reviews']) == 2 and all(r['sha256_matches_package_and_acceptance'] and r['historical_body_matches'] and r['historical_verdict'] == 'PASS' for r in a['historical_semantic_reviews']) for a in artifacts),
    'all_source_reference_pins_match': all(r['commit'] == SOURCE for r in source_refs),
    'no_conflicting_source_reference_identity': all(len(v) == 1 for v in source_versions.values()),
    'deck_14_ids_match_frozen_order': [c['id'] for c in deck['cases']] == frozen_case_ids,
    'deck_target_keys_exist': all(c.get('target', next(iter(keys))) in keys for c in deck['cases']),
    'oracle_package_hash_matches': oracle['native_package_sha256'] == by_path['native-package.json']['sha256'],
    'oracle_direct_inputs_match_package': set(oracle['direct_input_artifacts']) == direct,
    'oracle_build_edges_match_package': set((r['consumer'],r['dependency']) for r in oracle['build_edges']) == build_edges,
    'oracle_navigation_edges_match_package': set((r['from'],r['to']) for r in oracle['navigation_edges']) == navigation_edges,
    'oracle_expected_closure_matches_package_graph': set(oracle['build_affected_closure']) == affected,
    'oracle_outside_closure_matches_package_graph': set(oracle['outside_build_closure']) == keys - affected,
}
report = {
    'schema': 'genesis-s2-public-byte-audit/v1',
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repository': 'gustavomhss/hugr-orchestra', 'inspected_revision': PIN,
    'operation': 'Decode GitHub MCP base64 file bytes; recompute Git blob SHA-1 and SHA-256; reconcile package, bodies, historical review pointers, frozen question deck and graph expectation.',
    'command': 'python3 verify.py',
    'work_directory': str(ROOT),
    'identity': 'Materialized read-only inspection files; not a Git checkout; no local HEAD asserted.',
    'status': 'PASS_BYTE_CUSTODY_ONLY' if all(checks.values()) else 'FAIL_BYTE_CUSTODY',
    'checks': checks,
    'package': by_path['native-package.json'],
    'artifact_count': len(artifacts),
    'layer_counts': dict(collections.Counter(str(a['layer']) for a in artifacts)),
    'historical_review_link_count': sum(len(a['historical_semantic_reviews']) for a in artifacts),
    'distinct_historical_review_files': len({r['path'] for a in artifacts for r in a['historical_semantic_reviews']}),
    'artifacts': artifacts,
    'source_references': {
        'reference_count': len(source_refs), 'unique_paths': len(source_versions),
        'unique_explicit_input_keys': len(unique_inputs),
        'input_prefix_counts': dict(collections.Counter(i.split(':',1)[0] for i in unique_inputs)),
        'pins': sorted({r['commit'] for r in source_refs}),
        'original_source_bytes_retrieved': False,
        'scope': 'Metadata consistency only; this does not prove current runtime observations, membership or source bytes.',
    },
    'consumer_deck': {**by_path['requests/consumer-question-deck.json'], 'ids': frozen_case_ids, 'read_limits': deck['read_limits'], 'state': 'NOT_RUN', 'case_matrix': [{**case, 'state': 'NOT_RUN', 'trace': None, 'judgment': None} for case in deck['cases']]},
    'maintenance_expectation': {**by_path['oracles/update-final-graph-expectation.json'], 'case': 'S2-U1', 'state': 'NOT_RUN', 'changed_input': oracle['changed_input'], 'direct_input_artifacts': sorted(direct), 'potential_affected_closure': sorted(affected), 'outside_build_closure': sorted(keys-affected), 'build_edge_count': len(build_edges), 'navigation_edge_count': len(navigation_edges), 'actual_interpretation_calls': 'NOT_OBSERVED'},
    'downloaded_inputs': downloads,
    'runtime_execution': False, 'new_semantic_judgment': False,
    'limits': [
        'No prepare, binding, publication, Atlas index/read, consumer, maintenance, product test, CI or guard was executed.',
        'Historical semantic PASS decisions were checked for exact body/hash references; they were not regenerated or promoted to runtime binding.',
        'Source-reference metadata consistency is checked; original source bytes and runtime observations were not fetched or executed.',
        'Expected graph reach is not an observed invalidation result or count of interpretation calls.',
    ],
}
(ROOT / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': report['status'], 'checks': checks, 'frozen_deck_sha256': report['consumer_deck']['sha256'], 'frozen_oracle_sha256': report['maintenance_expectation']['sha256'], 'downloaded_inputs': len(downloads), 'verification_sha256': sha256((ROOT/'verification.json').read_bytes())}, indent=2))
sys.exit(0 if all(checks.values()) else 1)
