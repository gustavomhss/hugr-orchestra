#!/usr/bin/env python3
"""DRAFT_NOT_RUN: bind a future U1 operation to explicit inventories and controls.

Writes only a new external command file. The fixed recorder/wrapper execute the
actual CLI/API driver later. No source mutation, policy, agent, vote or runtime
execution is created here.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re

BASE = Path('/workspace/scratch/5cfbb6c803f1')
INVESTIGATION = BASE / 's2-investigation'
AREA = INVESTIGATION / 'maintenance-plan'
RUNTIME = BASE / 's2-runtime'
CWD = RUNTIME / 'modules/atlas'
BUN = BASE / 's2-tools/node_modules/@oven/bun-linux-x64-baseline/bin/bun'
CLI = CWD / 'scripts/genesis-evaluation.ts'
DRIVER = AREA / 'u1-evaluation-operation.mjs'
CONTEXT = AREA / 'build-native-request.mjs'
RECORDER = INVESTIGATION / 'record-operation.py'
WRAPPER = INVESTIGATION / 'capture-state-operation.py'
LOCK = INVESTIGATION / 'evaluation-authority/runtime-byte-lock.json'
ROOTS = {BASE / name for name in ('s2-u1-baseline', 's2-u1-changed', 's2-u1-restored')}
ACTOR = 'genesis-s2-resume-846d4f9c'
SHA = re.compile(r'^[0-9a-f]{64}$')
FIXED = {
    RECORDER: '0185ccf143d7a5d1112b573fd0405da899b27d112cb4c7b431e1cbb1da629b30',
    WRAPPER: 'b7022b3205d04f02b6fceaee94d2f7912f15271be6ee4b2e4d7c62ba0013a441',
    LOCK: 'fe5e317cf140c805554910d20d7a7c8964f76df12217aeb6a5280483c6c12df8',
    CLI: '3f7477b37400c1ffeea550ca0d48b328b16dedcea4deb015ad190128ff63b94c',
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def regular(value):
    path = Path(value)
    require(path.is_absolute() and path.resolve(strict=True) == path and path.is_file()
            and not path.is_symlink() and path.stat().st_nlink == 1, 'regular unaliased path required: ' + str(path))
    return path


def stamp(value, expected=None):
    path = regular(value)
    raw = path.read_bytes()
    row = {'path': str(path), 'byte_length': len(raw), 'sha256': digest(raw)}
    if expected is not None:
        require(SHA.fullmatch(expected) and row['sha256'] == expected, 'intended bytes differ: ' + str(path))
    return row


def relative(value):
    require(isinstance(value, str) and value and not value.startswith('/') and
            all(x and x not in ('.', '..', '.atlas', '.git') for x in value.split('/')) and
            not re.search(r'[\\:*?"<>|\x00-\x1f\x7f]', value), 'invalid data path')
    return value


def external_new(value):
    path = Path(value)
    require(path.is_absolute() and path.parent.resolve(strict=True) == path.parent and not path.exists()
            and not path.is_symlink() and path.is_relative_to(BASE / 's2-execution/u1'), 'exclusive U1 output path required')
    return path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha256', required=True)
    parser.add_argument('--command-file', type=Path, required=True)
    args = parser.parse_args()
    request_row = stamp(args.request, args.request_sha256)
    config = json.loads(args.request.read_bytes())
    require(config['schema'] == 'genesis-s2-u1-command-request/v1', 'command request schema')
    mode = config['mode']
    require(mode in ('prepare', 'init-store', 'admit', 'admit-target', 'index', 'read',
                     'capture', 'prepare-update', 'finalize-update', 'build-native-context'), 'unplanned operation')
    root = Path(config['authority_root'])
    require(root in ROOTS and root.resolve(strict=True) == root, 'unplanned root')
    operation_id = config['operation_id']
    require(isinstance(operation_id, str) and re.fullmatch(r'[A-Za-z0-9_.-]+', operation_id), 'operation id')
    output = external_new(config['output_dir'])
    command_file = external_new(args.command_file)
    require(output != command_file, 'command path equals output directory')
    rows = {}

    def add(row):
        path = row['path']
        require(set(row) == {'path', 'byte_length', 'sha256'} and type(row['byte_length']) is int
                and row['byte_length'] >= 0 and SHA.fullmatch(row['sha256']), 'invalid inventory row')
        require(path not in rows or rows[path] == row, 'conflicting intended bytes: ' + path)
        rows[path] = row

    for path, pin in FIXED.items():
        add(stamp(path, pin))
    lock = json.loads(LOCK.read_bytes())
    require(len(lock['files']) == 1170, 'runtime lock coverage')
    for row in lock['files']:
        require(stamp(row['path'], row['sha256']) == row, 'runtime changed')
        add(row)
    add(stamp(Path(__file__).absolute()))
    add(request_row)
    inventory_roots = set()
    for ref in config['source_inventories']:
        add(stamp(ref['path'], ref['sha256']))
        inventory = json.loads(Path(ref['path']).read_bytes())
        require(inventory['schema'] == 'genesis-s2-u1-source-inventory/v1', 'source inventory schema')
        source_root = Path(inventory['root'])
        require(source_root in ROOTS and source_root not in inventory_roots and source_root.resolve(strict=True) == source_root, 'source inventory root')
        inventory_roots.add(source_root)
        require(inventory['files'] and inventory.get('all_non_state_regular_files') is True, 'complete source inventory required')
        actual_paths = {str(p.relative_to(source_root)) for p in source_root.rglob('*')
                        if p.is_file() and '.atlas' not in p.relative_to(source_root).parts}
        require(actual_paths == {row['path'] for row in inventory['files']}, 'source inventory coverage differs')
        for row in inventory['files']:
            path = source_root / relative(row['path'])
            intended = {'path': str(path), 'byte_length': row['byte_length'], 'sha256': row['sha256']}
            require(stamp(path, row['sha256']) == intended, 'source differs from intended inventory')
            add(intended)
    require(root in inventory_roots, 'authority root inventory missing')
    for ref in config['controls']:
        add(stamp(ref['path'], ref['sha256']))

    def controlled(path):
        path = regular(path)
        require(str(path) in rows, 'control lacks intended hash: ' + str(path))
        return path

    def load_control(path):
        return json.loads(controlled(path).read_bytes())

    def pin_reference(ref, parse_json=True):
        add(stamp(ref['path'], ref['sha256']))
        return load_control(ref['path']) if parse_json else None

    if mode in ('capture', 'prepare-update', 'finalize-update', 'build-native-context'):
        operation_request = load_control(config['operation_request'])
        for name in ('baseline', 'registry', 'target'):
            if name in operation_request:
                pin_reference(operation_request[name])
        if 'capture' in operation_request:
            captured = pin_reference(operation_request['capture'])
            for row in captured['inputs']:
                if row['observation']['kind'] == 'present':
                    path = Path(captured['files_root']) / relative(row['file'])
                    observed = stamp(path, row['sha256'])
                    require(observed['byte_length'] == row['byte_length'], 'capture byte length')
                    add(observed)
        for name in ('native_outputs', 'accepted_outputs'):
            for ref in operation_request.get(name, []):
                record = pin_reference(ref)
                pin_reference(record['request'])
                response = pin_reference(record['response'])
                pin_reference(response['body'], parse_json=False)
        for ref in operation_request.get('semantic_reviews', []):
            pin_reference(ref)
        if 'admission_receipt' in operation_request:
            ref = operation_request['admission_receipt']
            admission = pin_reference(ref)
            stream = admission['streams']['stdout']
            add(stamp(Path(ref['path']).parent / relative(stream['path']), stream['sha256']))
        if 'binding' in operation_request:
            binding = pin_reference(operation_request['binding'])
            for decision in binding['decisions']:
                for name in ('request_ref', 'response_ref'):
                    ref = decision[name]
                    add(stamp(Path(operation_request['source_root']) / relative(ref['payload_path']), ref['sha256']))

    def prepared(path):
        value = load_control(path)
        require(value['schema'] == 'genesis-native-prepared/v2' and value['candidate']['repo_root'] == str(root)
                and SHA.fullmatch(value['candidate_id']), 'prepared identity/root')
        return value

    if mode not in ('prepare', 'init-store', 'build-native-context'):
        for name in ('evaluation-store.json', 'evaluation-policy.json', 'policy.json'):
            controlled(root / '.atlas' / name)
        marker = load_control(root / '.atlas/evaluation-store.json')
        policy = load_control(root / '.atlas/evaluation-policy.json')
        require(marker['root'] == str(root) and policy['actor'] == ACTOR and
                all(marker[k] == policy[k] for k in ('root', 'evaluationPlan', 'obligationSet', 'evaluationCandidate', 'generation', 'scope')), 'policy/marker mismatch')
        expected_operation = 'evaluation-maintenance' if mode in ('capture', 'prepare-update', 'finalize-update') else ('admit' if mode == 'admit-target' else mode)
        require(policy['operations'] == [expected_operation] or (mode in ('index', 'read') and policy['operations'] == ['index', 'read']), 'policy operation scope')
    argv = [str(BUN)]
    output_files = []
    candidate_id = config.get('candidate_id')
    if mode in ('prepare', 'init-store', 'admit', 'admit-target', 'index', 'read'):
        argv += ['scripts/genesis-evaluation.ts', mode, str(root)]
        if mode == 'prepare':
            plan_path = relative(config['plan_relative'])
            controlled(root / plan_path)
            plan = load_control(root / plan_path)
            require(plan['isolation']['root'] == str(root) and plan['maintenance']['case'] == 'S2-U1', 'maintenance plan scope')
            destination = Path(config['prepared_output'])
            require(destination == output / 'prepared.json', 'prepare output must be inside recorder result')
            argv += [plan_path, str(destination)]; output_files.append(str(destination))
        elif mode in ('init-store', 'admit', 'admit-target'):
            value = prepared(config['prepared'])
            require(candidate_id == value['candidate_id'], 'candidate pin')
            argv.append(str(controlled(config['prepared'])))
            if mode == 'init-store':
                require(SHA.fullmatch(config['generation']), 'generation')
                argv.append(config['generation'])
            else:
                require(marker['evaluationCandidate'] == candidate_id, 'admit marker candidate')
                approval = relative(config['approval_relative'])
                binding = load_control(root / approval)
                require(binding['candidate_id'] == candidate_id and len(binding['decisions']) == 2, 'binding transport identity')
                for decision in binding['decisions']:
                    for field in ('request_ref', 'response_ref'):
                        ref = decision[field]
                        target = controlled(root / relative(ref['payload_path']))
                        require(rows[str(target)]['sha256'] == ref['sha256'], 'binding reference bytes')
                argv.append(approval)
        else:
            query = controlled(config['query'])
            require(policy['consumer']['id'] == config['witness_id'], 'reader witness policy')
            require(marker['evaluationCandidate'] == candidate_id, 'reader candidate')
            argv.append(str(query))
    else:
        driver = CONTEXT if mode == 'build-native-context' else DRIVER
        controlled(driver)
        request = controlled(config['operation_request'])
        value = load_control(request)
        require(value['authority_root'] == str(root), 'API request authority root')
        if mode != 'build-native-context':
            expected_mode = {'capture': 'capture', 'prepare-update': 'prepare', 'finalize-update': 'finalize'}[mode]
            require(value['mode'] == expected_mode and Path(value['source_root']) in inventory_roots, 'API operation/source scope')
            require(value['output_dir'] == str(output / 'driver'), 'driver output must be inside recorder result')
            require(marker['evaluationCandidate'] == candidate_id, 'driver candidate')
        argv += [str(driver), str(request)]
    nominal = {} if mode in ('prepare', 'init-store', 'build-native-context') else {'ATLAS_ACTOR': ACTOR}
    command = {
        'execution_id': '846d4f9c-fb77-4e21-aff6-1fffccc3132b', 'operation_id': operation_id,
        'operation': 'evaluation-' + mode if mode in ('prepare', 'init-store', 'admit', 'admit-target', 'index', 'read') else 'u1-' + mode,
        'code_root': str(RUNTIME), 'corpus_root': str(root), 'runtime_revision': 'db9b4235022c4df32fe3bfd4faeea8adcd69abb7',
        'corpus_revision': None, 'require_no_atlas_state': False, 'bun': str(BUN), 'cwd': str(CWD),
        'command_argv': argv, 'nominal_environment': nominal, 'unset_environment': ['ATLAS_ACTOR', 'ATLAS_RATIFY_TOKEN'],
        'candidate_id': candidate_id, 'original_candidate': '4a36e1210acf6a4bb460846b717d446e6c259f80a78fd73cfce8b5a6e445f522',
        'release_pin': {'runtime_revision': 'db9b4235022c4df32fe3bfd4faeea8adcd69abb7',
                        'release_revision': 'e171783482d0a44974d6056cd9e144a7e33406a7',
                        'limit': 'Existing common qualification; this U1 operation requires its own receipt and domain review.'},
        'input_files': sorted(rows), 'expected_input_files': [rows[k] for k in sorted(rows)], 'output_files': output_files,
        'configuration': {'schema': 'genesis-s2-u1-operation-configuration/v1', 'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                          'state': 'NOT_RUN_CONFIGURATION_ONLY', 'intended_output_dir': str(output),
                          'request': request_row, 'runtime_lock_rows': 1170, 'source_roots': sorted(map(str, inventory_roots)),
                          'limit': 'Explicit operator inventories and controls; no authenticated identity, intrinsic runtime coverage extension, execution or approval.'},
    }
    with command_file.open('xb') as stream:
        stream.write((json.dumps(command, ensure_ascii=False, indent=2) + '\n').encode())
        stream.flush(); os.fsync(stream.fileno())
    print(json.dumps({'command': stamp(command_file), 'output_dir': str(output), 'state': 'NOT_RUN_CONFIGURATION_ONLY'}))


if __name__ == '__main__':
    main()
