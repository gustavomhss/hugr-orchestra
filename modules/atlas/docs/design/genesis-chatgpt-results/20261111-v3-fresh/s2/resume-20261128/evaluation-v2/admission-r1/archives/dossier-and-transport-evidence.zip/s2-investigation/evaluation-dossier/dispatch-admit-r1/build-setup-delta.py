"""Static dossier snapshot only; never imports or invokes Atlas or any operation helper."""
from pathlib import Path
import json, hashlib, copy
B=Path('/workspace/scratch/5cfbb6c803f1')
D=B/'s2-investigation/evaluation-dossier/dispatch-admit-r1'
O=D/'delta-setup-01'; O.mkdir(exist_ok=True)
M=O/'messages'; M.mkdir(exist_ok=True)
assets=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'utf8_bytes':len(b),'sha256':sha(b)}
def put(name,b,representation='literal bytes',source=None):
 p=O/name
 if p.exists():assert p.read_bytes()==b, 'refuse to replace '+str(p)
 else:p.write_bytes(b)
 a={'id':f'B{len(assets):03d}','file':str(p),**{k:v for k,v in meta(p).items() if k!='path'},'representation':representation}
 if source:a['source']=meta(source)
 assets.append(a);return a
def literal(rel,name=None):
 p=B/rel;return put(name or p.name,p.read_bytes(),source=p)
def output(name,o):return put(name,(json.dumps(o,ensure_ascii=False,separators=(',',':'))+'\n').encode(),'explicit projection')
def read(rel):return json.loads((B/rel).read_bytes())
def projection(rel,fields):
 p=B/rel;o=read(rel);m=meta(p)
 for field in fields:
  xs=o.pop(field)
  o[field+'_projection']={'records':len(xs),'uniform_rows_omitted':True,'original':m,'json_pointer':'/'+field,'schema_keys':sorted(xs[0]) if xs and isinstance(xs[0],dict) else None}
 o['projection_note']='All other original fields are preserved. The declared uniform row tables are referenced, not delivered; this is not an integral receipt/configuration and cannot reconstruct those tables without the archived original.'
 return o
note='''DELTA FACTUAL DE SETUP — não é fechamento nem parecer.

As propostas anteriores de autoridade e as declarações de estado propostas nas ondas anteriores continuam preservadas como fatos daqueles instantes. Root executou um prepare03 separado, e depois inicialização de store e instalação explícita da política admit-only. O prepare03 e seus limites já integram A072–A077; a igualdade de prepared02/03 não retroage a cobertura externa para prepare02.

Este delta acrescenta a emenda de sequenciamento escrita antes do init, os recibos reais do init/policy e as fontes do builder e da ponte preparada para consumidores. O candidato d1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30, plano, obligation-set, quatro ADMIT e votos V1 não foram editados. A ordem antiga “init após ADMIT” era uma proposta operacional externa; a emenda explícita substitui somente essa ordem. Nenhum admit/publicação/consulta/consumidor/manutenção foi executado nesses passos.

O init original criou o marker e a instalação posterior escreveu exatamente duas políticas já propostas. A política já está instalada para admit, enquanto as políticas por caso e a ponte de consumidor continuam preparadas, sem uso. A identidade nominal do ator não é autenticação. A instalação é configuração explícita externa; seu recibo não é recibo de execução do CLI Atlas.

O guard é precondição do operador S2 através do recorder. Outros chamadores do CLI podem ignorá-lo. A comparação posterior detecta drift, não impede nem desfaz efeito já produzido. Os snapshots não demonstram ausência de corrida, isolamento de SO ou captura intrínseca de @noble/hashes. As limitações históricas do prepare02 permanecem; não se declara resolvida a suficiência normativa, que cabe aos dois juízes.

O helper run-reader-operation.py e os 14 pacotes de questões são preparação de transporte literal futura. Não geram identidade de agente, resposta, voto ou sucesso. Os agentes consumidores serão novos contextos sem herança; o operador entregará apenas questão e saídas literais autorizadas. O pacote S2-C1 é apresentado aqui para examinar a interface prevista, não como execução do caso.

As projeções de receipt/command omitem apenas as tabelas uniformes declaradas, preservam todos os demais campos e apresentam a derivação exata de seu universo. Não tratar arquivos externos arquivados como material lido. Se a apresentação não sustentar critério, registrar HOLD e o item exato faltante. Este delta não pede um voto predeterminado.
'''
put('00-temporal-scope.txt',note.encode())
literal('s2-investigation/evaluation-authority/sequencing-amendment-before-init.json')
ir=read('s2-execution/init-store-01/receipt.json');ic=read('s2-execution/init-store-01/command.json')
assert meta(B/'s2-execution/init-store-01/receipt.json')['sha256']=='03c2937cc78bfcaa31438eef332cea482d602a3c7e7a3820ac63d4a4224b49b4'
assert ir['exit_code']==0 and len(ir['input_files_before'])==1896
assert ir['input_files_before']==ir['input_files_after']==ic['expected_input_files']
assert ic['input_files']==[r['path'] for r in ir['input_files_before']]
assert ir['cas_before']==ir['cas_after'] and len(ir['cas_before'])==92
pr=read('s2-execution/evaluation-prepare-03/receipt.json')
assert pr['cas_after']==ir['cas_before']
old={r['path']:r for r in pr['input_files_after']};new={r['path']:r for r in ir['input_files_before']}
assert old.keys()<=new.keys() and all(new[p]==r for p,r in old.items())
extra=[r for r in ir['input_files_before'] if r['path'] not in old]
assert len(extra)==6
output('init-receipt-projection.json',projection('s2-execution/init-store-01/receipt.json',['input_files_before','input_files_after','cas_before','cas_after']))
cp=projection('s2-execution/init-store-01/command.json',['input_files','expected_input_files'])
sources=cp['configuration'].pop('input_sources')
assert set(sources)==set(new)
source_groups={}
for p,roles in sources.items():
 for role in roles:source_groups.setdefault(role,[]).append(p)
cp['configuration']['input_sources_projection']={'records':len(sources),'omitted':'path-to-source-role table only','original':meta(B/'s2-execution/init-store-01/command.json'),'json_pointer':'/configuration/input_sources','source_role_counts':{k:len(v) for k,v in source_groups.items()},'nonuniform_roles_full':{k:v for k,v in source_groups.items() if len(v)<20}}
output('init-command-projection.json',cp)
for rel in ['precondition.json','state-capture.json','stdout.json','operator-configuration-attempt-note.json']:
 literal('s2-execution/init-store-01/'+rel,'init-'+rel)
for rel in ['receipt.json','invocation.json','after-policy.json','after-evaluation-policy.json']:
 literal('s2-execution/install-policy-admit-01/'+rel,'policy-install-'+rel)
marker=B/'s2-evaluation/.atlas/evaluation-store.json'
assert meta(marker)['sha256']=='b191a34d21a16337044e5a30f41fba19338feb3123dd606bf3d9e945e7158497'
literal('s2-evaluation/.atlas/evaluation-store.json','installed-marker.json')
for target,record in [('policy.json','after-policy.json'),('evaluation-policy.json','after-evaluation-policy.json')]:
 assert (B/'s2-evaluation/.atlas'/target).read_bytes()==(B/'s2-execution/install-policy-admit-01'/record).read_bytes()
inv=read('s2-execution/install-policy-admit-01/invocation.json')
assert inv['exit_code']==0 and inv['cas_inventory_unchanged'] is True
assert sorted(p.name for p in (B/'s2-evaluation/.atlas').iterdir())==['cas','evaluation-policy.json','evaluation-store.json','policy.json']
current=[]
for p in sorted((B/'s2-evaluation/.atlas/cas').rglob('*')):
 if p.is_file():
  b=p.read_bytes();current.append({'path':str(p.relative_to(B/'s2-evaluation')),'byte_length':len(b),'sha256':sha(b)})
assert current==ir['cas_after']
output('setup-reconciliation.json',{'schema':'s2-setup-static-reconciliation/v1','method':'Read captured JSON and named current bytes; compare exact arrays and SHA-256; no Atlas invocation. Build script is included.','init_original_receipt':meta(B/'s2-execution/init-store-01/receipt.json'),'init_original_command':meta(B/'s2-execution/init-store-01/command.json'),'init_input_universe':{'base':'All 1890 prepare03 input_files_after records, same path/length/hash','base_archive':meta(B/'s2-execution/evaluation-prepare-03/receipt.json'),'additional_six_records':extra,'removed':[],'changed_base_records':[],'duplicate_paths':0,'order':'Literal command.input_files order equals expected_input_files, receipt.input_files_before and receipt.input_files_after order; tables remain archived.'},'init_guard_equality':{'before_after_expected_arrays_exact':True,'cas_prepare03_after_init_before_init_after_exact':True,'cas_count':92,'state_before':ir['state_files_before'],'state_after':ir['state_files_after']},'policy_install':{'invocation':meta(B/'s2-execution/install-policy-admit-01/invocation.json'),'receipt':meta(B/'s2-execution/install-policy-admit-01/receipt.json'),'current_policies_equal_captured_after_bytes':True,'marker_equal_init_captured_hash':True,'cas_inventory_at_dossier_snapshot_equal_init_after':True,'atlas_top_level_at_dossier_snapshot':['cas','evaluation-policy.json','evaluation-store.json','policy.json'],'temporal_limit':'Policy-install invocation records CAS count/equality; it does not contain both full inventory row tables. Current snapshot equality is a later read-only reconciliation, not a retroactive historical capture.'},'product_tests_run':False,'new_judge_decision':None,'limitations':['External guard is operator-invocation convention, not an intrinsic restriction on every CLI caller.','Post-execution drift detection cannot prevent or undo already executed effects.','No race-free or OS isolation claim.','Intrinsic @noble/hashes runtime identity gap remains.','No execution of admit, consumer, read, index, publication or maintenance is established by setup receipts.']})
builder=B/'s2-investigation/operation-config.py'
assert meta(builder)['sha256']=='4e7d3bd974b43df6310c46e1a1b70cfab34d509adeff1f06d72735c775f51e82'
literal('s2-investigation/operation-config.py')
for rel in ['README.md','build-packets.py','run-reader-operation.py','prepared/manifest.json','prepared/S2-C1.txt']:
 literal('s2-investigation/consumer-dispatch/'+rel,'consumer-'+Path(rel).name)
packets=read('s2-investigation/consumer-dispatch/prepared/manifest.json')
assert len(packets['cases'])==14
for row in packets['cases']:
 m=meta(row['path']);assert m['utf8_bytes']==row['byte_length'] and m['sha256']==row['sha256']
assert not packets['runtime_calls_executed'] and not packets['native_consumer_agents_created']
literal('s2-investigation/evaluation-dossier/dispatch-admit-r1/build-setup-delta.py','build-setup-delta.py')
manifest={'schema':'s2-setup-delta-assets/v1','original_amendment_unchanged':meta(D/'amendment-01/manifest.json'),'assets':assets,'closing_included':False,'verdict_issued':False}
mp=O/'manifest.json'; mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
if mp.exists():assert mp.read_bytes()==mb
else:mp.write_bytes(mb)
waves=[];parts=[];spans=[];n=31
def flush():
 global parts,spans,n
 if not parts:return
 head=f'DELTA SETUP01 — ONDA{n:02d}. Continuação literal do dossiê ADMIT; nenhum fechamento. O estado real de init/policy substitui somente a antiga proposta temporal. Candidato e critérios não foram alterados. Responda ACK_PARTIAL wave={n}, IDs/ranges recebidos, achados e faltas; final_binding=NOT_ISSUED.\n'.encode()
 b=head+b''.join(parts);p=M/f'{n:03d}.txt'
 if p.exists():assert p.read_bytes()==b
 else:p.write_bytes(b)
 waves.append({'wave':n,'request_path':str(p),'request_utf8_bytes':len(b),'request_sha256':sha(b),'fragments':spans});n+=1;parts=[];spans=[]
for a in assets:
 b=Path(a['file']).read_bytes();assert len(b)<44000
 h={k:a[k] for k in ['id','representation','utf8_bytes','sha256']};h['path']=a['file'];h['byte_range']=[0,len(b)]
 if 'source' in a:h['source']=a['source']
 f=('\nBEGIN '+json.dumps(h,ensure_ascii=False,separators=(',',':'))+'\n').encode()+b+b'\nEND '+a['id'].encode()+b'\n'
 if parts and sum(map(len,parts))+len(f)>47000:flush()
 parts.append(f);spans.append({'asset':a['id'],'byte_start':0,'byte_end':len(b),'fragment_sha256':sha(b)})
flush()
wm={'schema':'s2-setup-delta-fixed-messages/v1','assets_manifest':meta(mp),'closing_included':False,'waves':waves}
wp=O/'messages-manifest.json'; wb=(json.dumps(wm,ensure_ascii=False,indent=2)+'\n').encode()
if wp.exists():assert wp.read_bytes()==wb
else:wp.write_bytes(wb)
print(json.dumps({'asset_count':len(assets),'asset_bytes':sum(a['utf8_bytes'] for a in assets),'manifest':meta(mp),'messages_manifest':meta(wp),'waves':waves},ensure_ascii=False,indent=2))
