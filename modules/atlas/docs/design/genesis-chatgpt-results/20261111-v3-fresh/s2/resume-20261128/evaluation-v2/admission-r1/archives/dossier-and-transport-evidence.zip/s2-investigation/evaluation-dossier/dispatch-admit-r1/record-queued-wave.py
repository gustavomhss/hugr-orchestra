from pathlib import Path
import json,hashlib,sys,datetime
D=Path(__file__).resolve().parent;n=int(sys.argv[1]);mode=sys.argv[2]
assert mode in ['queued','activated']
if mode=='queued':
 p=D/('amendment-01' if n<=30 else 'delta-setup-01')/'messages'/f'{n:03d}.txt'
 event='ACTUAL_SEND_MESSAGE_QUEUED';observed='empty successful collaboration.send_message return; no error'
 T=D/'activation-triggers';T.mkdir(exist_ok=True)
 t=f'Ativação da onda{n:02d}: processe somente a mensagem literal ONDA{n:02d} já enfileirada nesta conversa. Responda ACK_PARTIAL conforme o cabeçalho, sem fechamento; final_binding=NOT_ISSUED.'
 q=T/f'{n:03d}-s2_j1.txt'
 if q.exists():assert q.read_bytes()==t.encode()
 else:q.write_bytes(t.encode())
else:
 p=D/'activation-triggers'/f'{n:03d}-s2_j1.txt';event='ACTUAL_FOLLOWUP_ACTIVATION_SENT';observed='empty successful collaboration.followup_task return; no error'
b=p.read_bytes();row={'event':event,'target':'/root/s2_j1','wave':n,'request_path':str(p),'request_utf8_bytes':len(b),'request_sha256':hashlib.sha256(b).hexdigest(),'observed_tool_result':observed,'host_message_id':None,'host_timestamp':None,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limit':'Literal queued wave and short activation trigger are two distinct requests. Both are preserved for concatenation. Host serialized request bytes/IDs/timestamps are not exposed.'}
L=D/'transport-ledger.jsonl';old=[json.loads(x) for x in L.read_text().splitlines()]
if not any(x.get('event')==event and x.get('target')==row['target'] and x.get('wave')==n for x in old):
 with L.open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
s=D/'dispatch-state.json';o=json.loads(s.read_bytes())
if mode=='activated':
 o.setdefault('last_actual_wave_by_judge',{})['s2_j1']=n
 o.setdefault('pending_queued_wave_by_judge',{}).pop('s2_j1',None)
else:o.setdefault('pending_queued_wave_by_judge',{})['s2_j1']=n
s.write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps(row,ensure_ascii=False))
