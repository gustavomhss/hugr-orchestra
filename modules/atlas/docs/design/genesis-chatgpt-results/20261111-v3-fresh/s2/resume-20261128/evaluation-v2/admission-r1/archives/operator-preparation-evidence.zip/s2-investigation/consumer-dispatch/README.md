# Ponte dos consumidores S2 — preparada, não executada

Estado desta preparação: nenhum consumidor criado e nenhuma chamada Atlas feita por estes helpers. A execução depende da admissão governada real do candidato `d1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30`, após os dois votos exatos. Os helpers externos não alteram o runtime, o plano, os corpos, o deck ou o oracle.

`build-packets.py` leu exclusivamente o deck congelado SHA-256 `51dacb110d80dd3e3f0fcf6cb3aa87ebb8a4c8d47e18abf76891d8bef430b356`. Gerou 14 instruções contendo o caso literal, as regras, os limites e o formato das portas. `prepared/manifest.json` registra os bytes. Não leu respostas reservadas. O primeiro caso é C1; cada caso posterior exigirá outro agente nativo com `fork_turns=none`.

O operador deve conservar a mensagem realmente enviada e o retorno real do host ao criar cada agente. Só então pode escrever um registro `genesis-s2-actual-consumer-dispatch/v1` com `state=ACTUAL_SPAWN_RECORDED`, `case_id`, `native_agent_id`, `fork_turns=none`, candidato, geração e `request_packet` (path/SHA-256). Esse registro descreve uma observação do operador; não autentica a identidade do agente nem prova isolamento de sistema operacional. Os consumidores não podem usar ferramentas, fontes, contexto do produtor, oracles ou decisões dos juízes; solicitam somente index/read pela ponte.

`run-reader-operation.py` recebe o registro de despacho, a mensagem original do consumidor, o recibo original da admissão e seu SHA-256, além de um ID de operação e diretório novo. Ele exige emissão efetiva e inputs intactos no recibo de admissão; não considera init-store ou instalação de política uma admissão. A mensagem precisa ser um único objeto `atlas-query` para o caso registrado. O helper serializa apenas o objeto `query` escolhido pelo consumidor e registra sua igualdade semântica com a mensagem original.

Cada tentativa instala a política exata previamente declarada para aquele caso, preserva a revisão, gera a configuração com os bytes fixados e chama o wrapper original que invoca a CLI Atlas. São preservados comando, streams, tempos, recibo, estado e orçamento antes/depois. A ponte nunca reseta orçamento, nunca repete automaticamente e nunca corrige a consulta usando o oracle. Uma recusa real continua sendo recusa, com o código de saída e todos os bytes originais. Divergência no guard externo mantém os streams reais, mas impede encaminhá-los como evidência válida ao consumidor; efeitos e chamadas de orçamento não são desfeitos.

`reader-response.txt` envolve o stdout/stderr reais em delimitadores com tamanho e SHA-256. Os bytes internos são copiados integralmente, incluindo respostas HOLD. O operador encaminha esse texto literalmente ao mesmo consumidor e guarda o envio; não acrescenta títulos de seção, respostas ou sugestões de navegação vindas das fontes. O julgamento posterior usa a resposta final efetiva, a sequência de consultas, os recibos e o oracle reservado, sem expor esse oracle ao consumidor.

Validação até aqui: compilação Python em memória e leitura dos contratos das portas. `run-reader-operation.py` não foi chamado e nenhum teste de produto foi executado.
# State-capture consistency gate — additive revision

The original bridge was prepared but never executed. Its preserved bytes are in
`revisions/before-state-capture-gate/`. The current bridge additionally verifies
the fixed wrapper's state-capture schema, operation and helper identities, both
before/after inventory comparisons, the inventories themselves, and equality of
wrapper/recorder/runtime exit codes before writing `reader-response.txt`.

The admission receipt must also have a consistent original state capture, which
is pinned as an additional input to the later reader operation. A wrapper-only
capture failure, including exit 4 for state mismatch, preserves the actual CLI
streams and records a bridge refusal without forwarding consumer evidence. An
actual CLI refusal with a consistent capture remains a literal response, even
when its own exit code is nonzero. No budget or effect is undone and no automatic
retry is introduced. The recorder, wrapper, candidate, policy and frozen case
packets remain unchanged. This revision is preparation, not a completed reader
or consumer execution.

