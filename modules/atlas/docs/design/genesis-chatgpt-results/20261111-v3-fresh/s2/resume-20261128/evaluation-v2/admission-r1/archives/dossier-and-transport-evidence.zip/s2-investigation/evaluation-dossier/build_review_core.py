#!/usr/bin/env python3
"""Assemble a review core plus explicit supplements, without dispatch or runtime action."""
from pathlib import Path
import copy
import hashlib
import json

ROOT=Path('/workspace/scratch/5cfbb6c803f1');OUT=ROOT/'s2-investigation/evaluation-dossier';DEST=OUT/'review-core'
DEST.mkdir(exist_ok=True)
BASE=json.loads((OUT/'manifest.json').read_bytes())
C=json.loads((ROOT/'s2-execution/evaluation-prepare-02/prepared.json').read_bytes())
AUDIT=ROOT/'s2-investigation/evaluation-audit';LATEST=ROOT/'s2-investigation/runtime/latest-release'
ASSETS=[];CHECKS=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def j(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def compact(v):
    if not isinstance(v,dict):return (json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n').encode()
    return ('{\n'+',\n'.join('  '+json.dumps(k)+': '+json.dumps(value,ensure_ascii=False,separators=(',',':')) for k,value in v.items())+'\n}\n').encode()
def check(label,a,b):
    if a!=b:raise ValueError(label)
    CHECKS.append(label)
def save(rel,b):
    p=OUT/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return p
def item(path,group,tier='core',**meta):
    b=path.read_bytes();b.decode('utf-8')
    record=dict(id=f'R{len(ASSETS):03d}',file=str(path.relative_to(OUT)),utf8_bytes=len(b),sha256=sha(b),group=group,tier=tier,**meta)
    ASSETS.append(record);return record
def original(path,group,tier='core',**meta):
    rel='sources/local/'+str(path.relative_to(ROOT));return item(save(rel,path.read_bytes()),group,tier,origin=str(path),literal=True,**meta)
def generate(name,obj,group,tier='core',encoding='compact'):
    b=compact(obj) if encoding=='compact' else j(obj)
    return item(save('review-core/'+name,b),group,tier,literal=False)

# Archive every finalized independent audit artifact; none is turned into a verdict.
for path in sorted(AUDIT.iterdir()):
    if path.is_file():save('sources/local/'+str(path.relative_to(ROOT)),path.read_bytes())
check('audit report fixed hash',sha((AUDIT/'report.json').read_bytes()),'ba77fa8ecc3df1d34311e48c9afdc9ad81ad5a8d7c6283f3cb6a6167d6868371')
check('audit verifier fixed hash',sha((AUDIT/'verify-evaluation.mjs').read_bytes()),'5a1ea48e9a3cab879f64331a443d33228dd15cf2502026a3da4b56809f5ddef5')
check('original prepare recorder',sha((ROOT/'s2-execution/evaluation-prepare-02/recorder-used.py').read_bytes()),'3c284c29c6e627a2c90775a8f10617243781868407ea03bdf9e430cb2f3a20ba')
check('proposed recorder',sha((ROOT/'s2-investigation/record-operation.py').read_bytes()),'0185ccf143d7a5d1112b573fd0405da899b27d112cb4c7b431e1cbb1da629b30')
check('proposed byte lock',sha((ROOT/'s2-investigation/evaluation-authority/runtime-byte-lock.json').read_bytes()),'fe5e317cf140c805554910d20d7a7c8964f76df12217aeb6a5280483c6c12df8')

context='''# Review core: materials only, no dispatch or decision

Candidate under prospective isolated-evaluation admission: d1c8478b155b2085df1289ef91edfeaa4834e9300d651c0b953e6e2978aa5d30; actual prepared-file SHA-256 bb3ee09693ef1ddfb89e548f3f5e0d38c4abaee5e6d253f129c7c6c1a9dbda0e. Original native V1 candidate and HOLD remain intact. Four ADMIT criteria do not dispose of original AC-01..10/runtime-import-binding or the final14/S2-U1 obligations.

This selection removes repeated V1/package/CAS metadata from the presentation, not from the archive. It carries all14 historical decisions verbatim, including FIX-FIRST and acceptance limits, with their four original accepted manifests and exact13-entry mapping. Body/source texts are intentionally opaque; no re-semantic approval is inferred. No current judge opinion is included.

Candidate projection is exact and reversible:690 observations and818 per-entry input bindings retain order and versions; all13 entries,40references,32build edges,30navigation links,authority/validity/gaps/evidence and actual contracts are retained. The separate runtime925 supplement is required for full candidate reconstruction; the core does not pretend that supplement was already delivered.

The independent audit reports22,752 comparisons without structural divergences AND a material intrinsic identity coverage gap for @noble/hashes. Its complete limitations are carried. Current247-file locked-tarball reconciliation is after prepare. The original prepare receipt did not snapshot that package before/after. The proposed external1170-file guard is not a change to intrinsic runtime identity, not historical coverage, not an ADMIT verdict and has not yet been used for a runtime operation.

S4 compatibility evidence is separate from domain execution. S4 domain NOT_RUN is not reinterpreted as an invented capability veto; neither generic CI nor the release proves S2 admission/consumption. Policies/generation/14-context consumer plans remain proposals not installed. Original recorder-used.py and proposed enhanced recorder are distinguished explicitly.

No prepare, init-store, policy installation, admission, publication, reader, index, producer, consumer, maintenance or product test is invoked by this dossier assembly. No requests have been sent. The parent must review selection, supplements and completeness before any original judge request is formed. Counts are transport checks, not votes.
'''
item(save('review-core/00-scope.txt',context.encode()),'01-scope-and-protocol')
for a in BASE['assets']:
    path=a['file']
    if path.endswith('/evaluation-admission.md') or path.endswith('/evaluation-admission-criteria-v1.json'):
        item(OUT/path,'01-scope-and-protocol',git_commit=a.get('git_commit'),git_path=a.get('git_path'))
    if '/s2/judgments/' in path:
        item(OUT/path,'02-historical-complete-decisions',git_commit=a.get('git_commit'),git_path=a.get('git_path'))
    if '/s2/accepted/' in path:
        item(OUT/path,'03-accepted-manifests-and-lineage',git_commit=a.get('git_commit'),git_path=a.get('git_path'))

lineage=json.loads((OUT/'projections/historical-lineage.json').read_bytes())['entries'];candidate_by_key={e['key']:e for e in C['candidate']['entries']}
lineage_rows=[]
for e in lineage:
    lineage_rows.append([e['key'],candidate_by_key[e['key']]['artifact']['result'],e['body']['repo_path'],e['body']['byte_length'],e['body']['sha256'],e['accepted_manifest']['git_path'],[(r['judge'],r['response_path'],r['response_sha256']) for r in e['accepted_record']['reviews']]])
generate('lineage.json',dict(columns=['entry_key','actual_v2_result_id','body_repo_path','body_utf8_bytes','body_sha256','accepted_manifest_repo_path','original_pairs_judge_response_path_sha256'],review_path_prefix='modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2/',rows=lineage_rows),'03-accepted-manifests-and-lineage')

source_names=[
 'packages/adapter-io/src/genesis-evaluation.ts','packages/adapter-io/src/genesis-evaluation-binding.ts','scripts/genesis-evaluation.ts','packages/knowledge/src/ownership/evaluation.ts',
 'packages/adapter-io/src/ownership-evaluation-policy.ts','packages/adapter-io/src/evaluation-read-budget.ts','packages/adapter-io/src/evaluation-state-io.ts','packages/adapter-io/src/evaluation-manifest-binding.ts','packages/adapter-io/src/store-evaluation-identity.ts','packages/adapter-io/src/evaluation-runtime-identity.ts',
 'packages/adapter-io/src/genesis-native.ts','packages/adapter-io/src/genesis-native-format.ts','packages/adapter-io/src/genesis-native-io.ts','packages/adapter-io/src/ownership-input.ts']
for suffix in source_names:
    a=next(a for a in BASE['assets'] if a['file']=='sources/s2-runtime/modules/atlas/'+suffix)
    item(OUT/a['file'],'04-complete-transformation-policy-and-identity-functions',git_commit=a['git_commit'],git_path=a['git_path'])

for filename in ['candidate-definition.json','690-observations.jsonl','13-result-objects.jsonl']:
    item(OUT/'core-proposal'/filename,'05-exact-candidate-result-and-observation-projection')
for a in BASE['assets']:
    if a['file'].startswith('sources/local/v2-cas/contract-'):
        item(OUT/a['file'],'05-exact-candidate-result-and-observation-projection',cas_address=a['cas_address'])
item(OUT/'sources/local/native-v1-contract.json','05-exact-candidate-result-and-observation-projection')
for a in BASE['assets']:
    if a['file'].startswith('sources/local/s2-evaluation/') and (a['file'].endswith('/evaluation-plan.json') or a['file'].endswith('/obligation-set.json')):
        item(OUT/a['file'],'06-literal-plan-and-original-obligations')

authority=ROOT/'s2-investigation/evaluation-authority'
for p in sorted(authority.glob('*.json')):
    original(p,'07-proposed-authority-and-external-guard','archive' if p.name=='runtime-byte-lock.json' else 'core',state='PROPOSED_NOT_INSTALLED_OR_NOT_YET_USED')
original(ROOT/'s2-execution/evaluation-prepare-02/recorder-used.py','08-execution-receipts-and-recorders')
original(ROOT/'s2-investigation/record-operation.py','07-proposed-authority-and-external-guard',state='PROPOSED_FUTURE_WRAPPER_NOT_INTRINSIC_RUNTIME_FIX')
original(ROOT/'s2-execution/prepare-01/receipt.json','08-execution-receipts-and-recorders')
# Make receipt inputs self-contained with the core's690 observations, without the667-file supplement.
receipt_path=ROOT/'s2-execution/evaluation-prepare-02/receipt.json';receipt=json.loads(receipt_path.read_bytes())
obs=C['candidate']['observations'];obs_by_path={x['key'][5:]:i for i,x in enumerate(obs)}
input_rows=[];input_definition=['observation_index or literal relative path','byte_length','sha256 only if not present in the selected observation']
rebuilt_inputs=[]
for f in receipt['input_files_before']:
    rel=str(Path(f['path']).relative_to(Path(C['candidate']['repo_root'])))
    selector=obs_by_path.get(rel,rel);row=[selector,f['byte_length']]
    if not isinstance(selector,int) or 'sha256' not in obs[selector]:row.append(f['sha256'])
    else:check('receipt observation SHA:'+rel,f['sha256'],obs[selector]['sha256'])
    input_rows.append(row)
    path=obs[selector]['key'][5:] if isinstance(selector,int) else selector
    digest=row[2] if len(row)==3 else obs[selector]['sha256']
    rebuilt_inputs.append(dict(path=C['candidate']['repo_root']+'/'+path,byte_length=row[1],sha256=digest))
check('core receipt input reconstruction',rebuilt_inputs,receipt['input_files_before'])
check('core receipt before-after identical',rebuilt_inputs,receipt['input_files_after'])
receipt_core=dict(schema='s2-review-core-receipt-projection/v1',original_path=str(receipt_path),original_sha256=sha(receipt_path.read_bytes()),original_utf8_bytes=receipt_path.stat().st_size,original_key_order=list(receipt),unchanged_fields={k:v for k,v in receipt.items() if k not in ['input_files_before','input_files_after']},input_columns=input_definition,input_rows=input_rows,reconstruction='Observation index refers to the core690-observation list, not a source-preflight index. Absolute path=corpus_root + / + observation key without file:; literal string selector is a relative path. Byte length is explicit; SHA-256 is the third column, or the selected observation.sha256 where the third column is absent. Expand both original input arrays identically; preserve original key order. UTF-8 indent2 trailing LF reproduces original receipt bytes. All CAS rows and original null/status/release fields are unchanged.')
rebuilt={k:rebuilt_inputs if k in ['input_files_before','input_files_after'] else receipt_core['unchanged_fields'][k] for k in receipt_core['original_key_order']}
check('core receipt complete original bytes',j(rebuilt),receipt_path.read_bytes())
generate('evaluation-prepare-02-receipt.json',receipt_core,'08-execution-receipts-and-recorders')
command_obj=json.loads((OUT/'projections/evaluation-prepare-02-command.json').read_bytes())
generate('evaluation-prepare-02-command.json',command_obj,'08-execution-receipts-and-recorders')

report=json.loads((AUDIT/'report.json').read_bytes());projected=copy.deepcopy(report)
delta=next(x for x in projected['field_delta_summary'] if x['field']=='runtime_identity')
check('runtime delta ordered key duplication',delta['evaluation']['keys'],list(C['candidate']['runtime_identity']))
delta['evaluation']['keys']={'reconstruction':'Ordered keys from complete v2-runtime-identity-definition/rows supplement; all925 retained there.'}
rebuild=copy.deepcopy(projected);next(x for x in rebuild['field_delta_summary'] if x['field']=='runtime_identity')['evaluation']['keys']=list(C['candidate']['runtime_identity'])
check('full report exact original bytes reconstruction',j(rebuild),(AUDIT/'report.json').read_bytes())
generate('independent-v2-report-projection.json',dict(original_path=str(AUDIT/'report.json'),original_sha256=sha((AUDIT/'report.json').read_bytes()),original_utf8_bytes=(AUDIT/'report.json').stat().st_size,original_json_encoding='UTF-8 indent2 trailing LF; reconstruction verified byte-for-byte',projection=projected,omissions='Only repeated925 key list replaced by exact ordered-key reference; no criterion, status, limitation, count or finding omitted.'),'09-independent-audit-and-all-limitations')
original(AUDIT/'verify-evaluation.mjs','s06-complete-independent-audit-verifier','supplement')
original(AUDIT/'manifest.json','09-independent-audit-and-all-limitations')
original(AUDIT/'README.md','09-independent-audit-and-all-limitations','supplement')
old=[]
for p,excluded in [(ROOT/'s2-execution/prepare-01/integrity.json',['artifacts']), (ROOT/'s2-investigation/binding/independent-mapping-check.json',['entry_records','references','cas_reads'])]:
    obj=json.loads(p.read_bytes());old.append(dict(original_path=str(p),sha256=sha(p.read_bytes()),utf8_bytes=p.stat().st_size,complete_fields_retained={k:v for k,v in obj.items() if k not in excluded},fields_not_repeated_in_core=excluded,scope='Original detailed arrays remain intact in archive and V1 full dossier; candidate V2 exact mapping is independently fully audited. This selection is explicit, not a claim to transport those arrays here.'))
generate('prior-verifier-results-selection.json',dict(reports=old,scope='780 and4752 original deterministic reports retained; no judge verdict. Original verifier sources supplied as separately listed supplement.'),'09-independent-audit-and-all-limitations')
for p in [ROOT/'s2-investigation/verify-prepared.mjs',ROOT/'s2-investigation/binding/independent-mapping-check.mjs',ROOT/'s2-investigation/byte-audit/source_preflight.py']:
    original(p,'s05-prior-verifier-complete-source','supplement')

for filename in ['compatibility-assessment.json','source-manifest.json']:
    original(LATEST/filename,'10-S4-fixed-release-compatibility')
for filename in ['COMPATIBILITY.md','runtime-release.json','handoff.json']:
    original(LATEST/filename,'s03-S4-complete-primary-material','supplement')

# Complete recorded runtime identity, transported once as a dedicated mandatory wave.
for name in ['v2-runtime-identity-definition.json','v2-runtime-identity-rows.jsonl']:
    item(OUT/'projections'/name,'s01-recorded-runtime925-complete','supplement')

# The omitted package is also complete, with duplicate path/hash equality reconstructed.
rt=json.loads((AUDIT/'runtime-identity.json').read_bytes());noble=rt['omitted_resolved_packages'][0];np=copy.deepcopy(noble)
file_rows=[[f['relative_path'],f['byte_length'],f['sha256']] for f in noble['files']]
prefix=str(Path(noble['manifest']).parent)+'/'
check('noble files exact reconstruction',[dict(path=prefix+row[0],relative_path=row[0],sha256=row[2],byte_length=row[1]) for row in file_rows],noble['files'])
comparison=noble['locked_tarball']['installed_comparison'];comparison_order=[]
index={row[0]:i for i,row in enumerate(file_rows)}
for f in comparison['files']:
    i=index[f['path']];row=file_rows[i];expected=dict(path=row[0],tar_byte_length=row[1],tar_sha256=row[2],installed_present=True,installed_byte_length=row[1],installed_sha256=row[2],exact_bytes_equal=True)
    check('noble tarball exact row:'+str(i),f,expected);comparison_order.append(i)
np['files']={'rows_file':'noble247-rows.jsonl','columns':['relative_path','byte_length','sha256'],'absolute_path_prefix':prefix,'reconstruction':'path=prefix+relative_path; original field order path,relative_path,sha256,byte_length.'}
np['locked_tarball']['installed_comparison']['files']={'indexes_in_rows_file':comparison_order,'reconstruction':'Each row expands path=relative_path,tar_byte_length=byte_length,tar_sha256=sha256,installed_present=true,installed_byte_length=byte_length,installed_sha256=sha256,exact_bytes_equal=true, in that original field order. All247 actual rows were checked; statuses are original comparison facts, not new approval.'}
generate('noble247-definition.json',dict(original_runtime_audit_sha256=sha((AUDIT/'runtime-identity.json').read_bytes()),original_runtime_audit_path=str(AUDIT/'runtime-identity.json'),scope='Complete omitted_resolved_packages[0] object, with redundant247-row installed/tarball hashes stored once; all other fields literal.',object=np),'s02-noble247-complete-observation','supplement')
item(save('review-core/noble247-rows.jsonl',''.join(json.dumps(row,separators=(',',':'))+'\n' for row in file_rows).encode()),'s02-noble247-complete-observation','supplement')

# Keep detailed667-path pin evidence eligible as a separately labeled supplement.
for name in ['source-preflight-header.json','source-preflight-rows.jsonl']:
    item(OUT/'projections'/name,'s04-original667-file-pin-evidence','supplement')

manifest=dict(schema='s2-evaluation-review-core-selection/v1',status='PREPARED_FOR_PARENT_REVIEW_NOT_DISPATCHED',candidate=C['candidate_id'],assets=ASSETS,core_payload_bytes=sum(a['utf8_bytes'] for a in ASSETS if a['tier']=='core'),supplement_payload_bytes=sum(a['utf8_bytes'] for a in ASSETS if a['tier']=='supplement'),scope='Core plus mandatory runtime925/noble247/full-verifier waves forms the proposed judge-visible selection. Other supplements explicitly eligible on request. No source can be claimed delivered until actual transport is recorded.',mandatory_supplement_groups=['s01-recorded-runtime925-complete','s02-noble247-complete-observation','s06-complete-independent-audit-verifier'],archive_only=['1170-file runtime-byte-lock complete original','V1 original package/prepared and source preflight full data','All detailed independent audit tables and checks.jsonl','Previous full868KB stable+V2 dossier'],omissions=['Raw667-file source corpus and13body texts: deliberately opaque semantic reuse with full historical decisions','Repeated original V1/package/candidate metadata: preserved in full archive, replaced by one exact candidate V2 projection','Complete S4 primary release/handoff+readable summary: separately listed supplement, exact provenance in core assessment and source manifest','925 runtime key list duplication in audit report: reconstruct from separately transported925 table','247noble installed/tarball duplicate hashes: reconstruct by explicitly checked equality rules','1170-file external lock repeated rows: complete original preserved; no claim that its guard has been used','Prior780/4752 detailed arrays omitted in core selection only; originals and full verifiers eligible supplements, with explicit field list'],checks=CHECKS,no_judge_verdict=True,no_dispatch=True)
chunks=[];number=0
for tier in ['core','supplement']:
  for group in dict.fromkeys(a['group'] for a in ASSETS if a['tier']==tier):
    buf=bytearray();segments=[]
    def flush():
      global number,buf,segments
      if not buf:return
      number+=1;name=f'review-core/chunks/{number:03d}-{group}.txt';raw=bytes(buf);assert len(raw)<=30000;save(name,raw)
      chunks.append(dict(order=number,file=name,tier=tier,group=group,utf8_bytes=len(raw),sha256=sha(raw),segments=segments));buf=bytearray();segments=[]
    for a in [a for a in ASSETS if a['tier']==tier and a['group']==group]:
      raw=(OUT/a['file']).read_bytes();start=0
      while start<len(raw):
        end=min(start+26000,len(raw))
        if end<len(raw):
          line=raw.rfind(b'\n',start,end)
          if line<start:raise ValueError('overlong line:'+a['file'])
          end=line+1
        payload=raw[start:end];payload.decode('utf-8')
        framing=(f'===== LITERAL PAYLOAD {a["id"]} =====\nfile: {a["file"]}\nwhole_bytes: {len(raw)}\nwhole_sha256: {a["sha256"]}\nbyte_range: [{start},{end})\nsegment_bytes: {len(payload)}\nsegment_sha256: {sha(payload)}\nPAYLOAD_START\n').encode();trailer=f'\nPAYLOAD_END {a["id"]}\n\n'.encode()
        if buf and len(buf)+len(framing)+len(payload)+len(trailer)>30000:flush()
        cs=len(buf)+len(framing);buf.extend(framing);buf.extend(payload);buf.extend(trailer);segments.append(dict(asset=a['id'],source_start=start,source_end=end,chunk_start=cs,chunk_end=cs+len(payload)));start=end
    flush()
for a in ASSETS:
    parts=[]
    for chunk in chunks:
        raw=(OUT/chunk['file']).read_bytes()
        for s in chunk['segments']:
            if s['asset']==a['id']:parts.append((s['source_start'],raw[s['chunk_start']:s['chunk_end']]))
    if parts:check('chunk reconstruction:'+a['id'],b''.join(x[1] for x in sorted(parts)),(OUT/a['file']).read_bytes())
manifest['chunks']=chunks
manifest['groups']=[dict(group=g,tier=t,payload_bytes=sum(a['utf8_bytes'] for a in ASSETS if a['group']==g and a['tier']==t),transport_bytes=sum(c['utf8_bytes'] for c in chunks if c['group']==g and c['tier']==t),chunks=sum(c['group']==g and c['tier']==t for c in chunks)) for g,t in dict.fromkeys((a['group'],a['tier']) for a in ASSETS)]
manifest['core_transport_bytes']=sum(c['utf8_bytes'] for c in chunks if c['tier']=='core')
manifest['mandatory_supplement_transport_bytes']=sum(c['utf8_bytes'] for c in chunks if c['group'] in manifest['mandatory_supplement_groups'])
manifest['checks_total']=len(CHECKS);manifest['checks']=CHECKS
save('review-core/manifest.json',j(manifest));save('review-core/manifest.sha256',(sha(j(manifest))+'  manifest.json\n').encode())
selected_chunks={c['file'] for c in chunks}
for path in (DEST/'chunks').glob('*.txt'):
    if str(path.relative_to(OUT)) not in selected_chunks:path.unlink()
inventory=[dict(file=str(p.relative_to(OUT)),utf8_bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['final-inventory.json','final-inventory.sha256']]
seal=dict(schema='s2-dossier-final-file-inventory/v1',status='NOT_DISPATCHED',files=inventory,review_core_manifest_sha256=sha(j(manifest)),source_pins=dict(corpus=BASE['corpus_pin'],runtime=BASE['runtime_pin']),scope='Entire dossier snapshot; main manifest and review-core manifest are different presentation views, not two executed requests.')
save('final-inventory.json',j(seal));save('final-inventory.sha256',(sha(j(seal))+'  final-inventory.json\n').encode())
print(json.dumps(dict(manifest_sha256=sha(j(manifest)),core_bytes=manifest['core_transport_bytes'],mandatory_supplement_bytes=manifest['mandatory_supplement_transport_bytes'],core_chunks=sum(c['tier']=='core' for c in chunks),all_chunks=len(chunks),groups=manifest['groups'],inventory_sha256=sha(j(seal))),ensure_ascii=False))
