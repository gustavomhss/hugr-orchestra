from pathlib import Path
import json,hashlib,collections
OUT=Path(__file__).parent; M=OUT/'messages'
manifest=json.loads((OUT/'manifest.json').read_bytes())
assets=manifest['assets'];groups=collections.OrderedDict()
for a in assets:
    if a['group'] in ['00-amendment','01-history','10-final-identities']:continue
    groups.setdefault(a['group'],[]).append(a)
groups['11-explicit-omissions']=[a for a in assets if Path(a['file']).name=='omission-inventory.json']
groups['12-final-identities']=[a for a in assets if a['group']=='10-final-identities']
waves=[];n=6
def sha(b):return hashlib.sha256(b).hexdigest()
def fragment(a,start,b):
    info={k:a[k] for k in ['id','representation','utf8_bytes','sha256']}
    info['path']=a.get('source_path',a['file'])
    for k in ['source_bytes','source_sha256','git_commit','omission','note']:
        if k in a:info[k]=a[k]
    info['byte_range']=[start,start+len(b)]
    if 'source' in a:info['original_source']=a['source']
    return ('\nBEGIN '+json.dumps(info,ensure_ascii=False,separators=(',',':'))+'\n').encode()+b+b'\nEND '+a['id'].encode()+b'\n'
def flush(group,parts,spans):
    global n
    if not parts:return
    header=(f'EMENDA01 — ONDA{n:02d} — {group}. Continuação literal; nenhum fechamento. Ranges são [início,fim) em bytes UTF-8 do arquivo apresentado, sem incluir delimitadores. Se a fonte está projetada, a omissão está declarada; não considere tabelas externas como lidas. Responda ACK_PARTIAL wave={n}, IDs/ranges recebidos, achados e faltas; final_binding=NOT_ISSUED.\n').encode()
    b=header+b''.join(parts);p=M/f'{n:03d}.txt'
    if p.exists() and p.read_bytes()!=b:raise RuntimeError('refuse to replace existing request '+str(p))
    p.write_bytes(b);waves.append({'wave':n,'group':group,'request_path':str(p),'request_utf8_bytes':len(b),'request_sha256':sha(b),'fragments':spans});n+=1
for group,aa in groups.items():
    parts=[];spans=[]
    for a in aa:
        raw=Path(a['file']).read_bytes();assert len(raw)==a['utf8_bytes'] and sha(raw)==a['sha256']
        slices=[]
        if len(raw)<=44000:slices=[raw]
        else:
            rest=raw
            while rest:
                end=min(42000,len(rest))
                if end<len(rest):
                    newline=rest.rfind(b'\n',0,end)
                    if newline>20000:end=newline+1
                    else:
                        while True:
                            try:rest[:end].decode();break
                            except UnicodeDecodeError:end-=1
                slices.append(rest[:end]);rest=rest[end:]
        at=0
        for b in slices:
            part=fragment(a,at,b)
            if sum(map(len,parts))+len(part)>47000 and parts:flush(group,parts,spans);parts=[];spans=[]
            parts.append(part);spans.append({'asset':a['id'],'byte_start':at,'byte_end':at+len(b),'fragment_sha256':sha(b)});at+=len(b)
        assert at==len(raw)
    flush(group,parts,spans)
out={'schema':'s2-amendment-01-remaining-fixed-messages/v1','selection_manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'first_wave':6,'last_wave':n-1,'closing_included':False,'later_execution_delta_required':True,'waves':waves}
(OUT/'remaining-messages.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'waves':[(w['wave'],w['group'],w['request_utf8_bytes'],w['request_sha256']) for w in waves],'manifest_sha256':sha((OUT/'remaining-messages.json').read_bytes())},indent=2))
