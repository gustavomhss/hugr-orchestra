import type { Hash } from "@atlas/contracts"
import type { CasObject } from "./types.js"
import { defaultEncoder } from "./encoder.js"
export interface CanonicalApi {
  /** The RFC-8785/JCS-subset canonical preimage bytes (sorted keys, NFC, no floats). The bytes handed
   *  to the encoder seam; MUST exclude mutable side-indexes (KERNEL-8). (atlas-kernel:39-41) */
  canonicalForm(obj: CasObject): Uint8Array
  /** `Encoder.hash(canonicalForm(obj))` — content-addressed identity; MUST NOT be hand-rolled
   *  (KERNEL-1). (atlas-kernel:39-41, 98) */
  id(obj: CasObject): Hash
}
const SIDE_INDEX: ReadonlySet<string> = new Set(["grounding", "status", "freshness"])
const UTF8 = new TextEncoder()
function serialize(v: unknown): string {
  if (v === null || v === undefined) return "null"
  switch (typeof v) {
    case "boolean":
      return v ? "true" : "false"
    case "number":
      if (!Number.isFinite(v) || !Number.isInteger(v)) {
        throw new Error("canonical-form violation: floats forbidden (non-integer/non-finite number)")
      }
      return String(v)
    case "string":
      // NFC + one fixed escape policy (JSON string escaping).
      return JSON.stringify(v.normalize("NFC"))
    case "object": {
      if (Array.isArray(v)) return `[${v.map(serialize).join(",")}]`
      const o = v as Record<string, unknown>
      // Side-indexes (KERNEL-8) and `undefined`-valued keys are dropped FIRST: a key that never reaches the
      // preimage cannot collide in it, so the guard below prices only keys that are actually serialized.
      const present = Object.keys(o).filter((k) => !SIDE_INDEX.has(k) && o[k] !== undefined)
      // FAIL-CLOSED on an NFC key collision (KERNEL-1; functional-surface.md "a fact's canonical preimage
      // has a … key-order … divergence ⇒ fail-closed reject … never emit two CAS objects for one fact").
      //
      // Why this is a TOOTH and not defence-in-depth. `Object.keys` returns DISTINCT strings, but NFC is not
      // injective, so two distinct JS keys can normalize to one. Without this guard both survive into
      // `entries`, the sort comparator returns 0 for the pair, and V8's stable sort therefore preserves their
      // INSERTION order — emitting a duplicate-key preimage whose byte order depends on how the object was
      // built. MEASURED on the base commit: `{}` filled "café"(NFC)→1 then "café"(NFD)→2 hashed
      // bcee1c10…, and the same logical object filled in the other order hashed a065e84a… . Two digests for
      // one logical value is a canonicalizer that is not canonical, and it is the exact "two CAS objects for
      // one fact" fork KERNEL-1 forbids — reached from the opposite direction to the float/escape splits.
      //
      // Rejecting (rather than picking a winner) is the spec's mandated disposition and the only sound one:
      // the two keys are genuinely different data, so any tie-break would SILENTLY DISCARD one field.
      // Throwing makes the order-dependent preimage UNREACHABLE rather than merely unlikely.
      const seen = new Set<string>()
      const entries: (readonly [string, unknown])[] = []
      for (const k of present) {
        const nk = k.normalize("NFC")
        if (seen.has(nk)) {
          throw new Error(
            `canonical-form violation: NFC key collision on ${JSON.stringify(nk)} — two distinct keys ` +
              "normalize to one, so the preimage would depend on insertion order",
          )
        }
        seen.add(nk)
        entries.push([nk, o[k]] as const)
      }
      // Every key is now distinct, so the comparator never returns 0 and the order is total — the sorted
      // preimage is a function of the key SET alone, independent of `Object.keys` enumeration order.
      entries.sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0))
      return `{${entries.map(([k, val]) => `${JSON.stringify(k)}:${serialize(val)}`).join(",")}}`
    }
    default:
      // bigint / symbol / function are not JSON — a canonical-form violation.
      throw new Error(`canonical-form violation: unsupported value type ${typeof v}`)
  }
}
export function canonicalForm(obj: CasObject): Uint8Array {
  return UTF8.encode(serialize(obj))
}
export function id(obj: CasObject): Hash {
  return defaultEncoder.hash(canonicalForm(obj))
}
