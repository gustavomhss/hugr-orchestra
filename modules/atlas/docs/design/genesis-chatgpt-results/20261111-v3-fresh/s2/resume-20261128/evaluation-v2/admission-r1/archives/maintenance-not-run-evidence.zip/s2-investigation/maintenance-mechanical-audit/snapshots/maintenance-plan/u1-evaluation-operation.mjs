#!/usr/bin/env bun
// DRAFT_NOT_RUN. Host driver for existing evaluation-v2 APIs; no publication door.
// Real native production happens separately. Callbacks consume only exact sealed outputs.
import { basename, dirname, isAbsolute, join, resolve } from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { appendFileSync, closeSync, fsyncSync, mkdirSync, openSync, writeFileSync } from 'node:fs'
import { isDeepStrictEqual } from 'node:util'

const BASE = '/workspace/scratch/5cfbb6c803f1'
const RUNTIME = join(BASE, 's2-runtime/modules/atlas')
const EXECUTION = '846d4f9c-fb77-4e21-aff6-1fffccc3132b'
const report = { schema: 'genesis-s2-u1-operation/v1', execution_id: EXECUTION,
  stage: 'arguments', callback_entries: [], callback_returns: [], callback_failures: [],
  native_calls_created_by_driver: 0, publication_attempted: false, product_tests_executed: false }
let journal

function requireValue(condition, message) {
  if (!condition) throw new Error(message)
}

function event(value) {
  if (!journal) return
  const fd = openSync(journal, 'a')
  try { appendFileSync(fd, JSON.stringify({ at: new Date().toISOString(), ...value }) + '\n'); fsyncSync(fd) }
  finally { closeSync(fd) }
}

async function main() {
  requireValue(process.argv.length === 3, 'usage: bun u1-evaluation-operation.mjs <pinned-request.json>')
  const requireRuntime = createRequire(join(RUNTIME, 'packages/adapter-io/package.json'))
  const { id } = await import(pathToFileURL(requireRuntime.resolve('@atlas/kernel')).href)
  const { planOwnershipUpdate } = await import(pathToFileURL(requireRuntime.resolve('@atlas/knowledge')).href)
  const port = (name) => import(pathToFileURL(join(RUNTIME, 'packages/adapter-io/src', name)).href)
  const { nativeRoot, readNativeFile, decodeNativeUtf8, nativeSha256, nativeCasDirectory, nativePut } = await port('genesis-native-io.ts')
  const { nativePath, nativeDigest, nativeReferencePath } = await port('genesis-native-format.ts')
  const { createDiskStore } = await port('store.ts')
  const { loadEvaluationAccess } = await port('ownership-evaluation-policy.ts')
  const { observeOwnershipInput, ownershipInputMaxBytes } = await port('ownership-input.ts')
  const { prepareEvaluationUpdate, finalizeEvaluationUpdate } = await port('evaluation-rebuild.ts')
  const { effectiveInputs } = await port('ownership-rebuild.ts')
  const readControl = (path) => {
    requireValue(isAbsolute(path), 'control-path-must-be-absolute')
    return readNativeFile(nativeRoot(dirname(path)), nativePath(basename(path)))
  }
  const readPinned = (ref) => {
    requireValue(ref && typeof ref.path === 'string', 'missing-file-reference')
    nativeDigest(ref.sha256, 64, 'control.sha256')
    const bytes = readControl(ref.path)
    requireValue(nativeSha256(bytes) === ref.sha256, 'control-byte-drift: ' + ref.path)
    return bytes
  }
  const pinnedJson = (ref) => JSON.parse(decodeNativeUtf8(readPinned(ref)))
  const requestBytes = readControl(resolve(process.argv[2]))
  const request = JSON.parse(decodeNativeUtf8(requestBytes))
  requireValue(request.schema === 'genesis-s2-u1-operation-request/v1', 'request-schema')
  requireValue(['capture', 'prepare', 'finalize'].includes(request.mode), 'request-mode')
  const root = nativeRoot(request.authority_root), sourceRoot = nativeRoot(request.source_root)
  const allowedRoot = (path) => ['s2-u1-baseline', 's2-u1-changed', 's2-u1-restored'].some((name) => path === join(BASE, name))
  requireValue(allowedRoot(root) && allowedRoot(sourceRoot), 'unplanned-maintenance-root')
  const outputRoot = resolve(request.output_dir)
  requireValue(outputRoot.startsWith(join(BASE, 's2-execution/u1') + '/') && outputRoot !== root && outputRoot !== sourceRoot, 'output-root')
  nativeRoot(dirname(outputRoot)); mkdirSync(outputRoot)
  journal = join(outputRoot, 'callback-journal.jsonl')
  writeFileSync(journal, '', { flag: 'wx' })
  const save = (name, value) => writeFileSync(join(outputRoot, nativePath(name)), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
  writeFileSync(join(outputRoot, 'request-used.json'), requestBytes, { flag: 'wx' })
  const baseline = pinnedJson(request.baseline)
  requireValue(baseline.schema === 'genesis-native-prepared/v2' && id(baseline.candidate) === baseline.candidate_id, 'baseline-integrity')
  requireValue(baseline.candidate.repo_root === root, 'baseline-authority-root')
  const access = loadEvaluationAccess(root)
  access.assert('evaluation-maintenance')
  requireValue(access.context.evaluationCandidate === baseline.candidate_id, 'baseline-policy-candidate')
  const store = createDiskStore(nativeCasDirectory(root))
  nativeDigest(request.manifest, 64, 'manifest')
  const manifest = store.get(request.manifest)
  requireValue(manifest && id(manifest) === request.manifest && manifest.kind === 'ownership-manifest' && manifest.version === 2 &&
    manifest.evaluationCandidate === baseline.candidate_id && manifest.generation === access.context.generation, 'baseline-manifest')
  requireValue(manifest.entries.length === baseline.candidate.entries.length, 'baseline-entry-count')
  // prepareEvaluation binds plan.implementation through plan CAS plus source
  // observations; candidate.implementation contains native implementation roles.
  // Rebuild plans retain original_plan, so resolve the unchanged original pins.
  const seenPlans = new Set()
  let implementationPlanRef = baseline.candidate.evaluation.evaluationPlan
  let implementationPlan
  for (;;) {
    requireValue(!seenPlans.has(implementationPlanRef) && seenPlans.size < 16, 'implementation-plan-lineage')
    seenPlans.add(implementationPlanRef)
    const value = store.get(implementationPlanRef)
    requireValue(value && id(value) === implementationPlanRef, 'implementation-plan-integrity')
    if (value.schema === 'genesis-evaluation-plan/v1') { implementationPlan = value; break }
    requireValue(value.schema === 'genesis-evaluation-rebuild-plan/v1' && typeof value.original_plan === 'string', 'implementation-plan-schema')
    implementationPlanRef = value.original_plan
  }
  const ownPath = fileURLToPath(import.meta.url), ownBytes = readControl(ownPath), ownHash = nativeSha256(ownBytes)
  nativePath(request.driver_source_path)
  requireValue(implementationPlan.implementation[request.driver_source_path] === ownHash, 'driver-not-pinned-by-baseline-plan')
  requireValue(nativeSha256(readNativeFile(sourceRoot, request.driver_source_path)) === ownHash, 'captured-driver-differs-from-executed-driver')
  const registry = pinnedJson(request.registry)
  nativePath(request.registry_source_path)
  requireValue(implementationPlan.implementation[request.registry_source_path] === request.registry.sha256 &&
    nativeSha256(readNativeFile(sourceRoot, request.registry_source_path)) === request.registry.sha256, 'registry-not-pinned-by-baseline-plan')
  requireValue(registry.schema === 'genesis-s2-u1-recipe-registry/v1' && Array.isArray(registry.recipes), 'registry-schema')
  requireValue(registry.recipes.length === baseline.candidate.entries.length &&
    new Set(registry.recipes.map((x) => x.key)).size === registry.recipes.length, 'registry-coverage')
  const sourceID = (bytes) => String(id({ kind: 'ownership-source', version: 1, bytes: Array.from(bytes) }))
  const observe = (key) => observeOwnershipInput(sourceRoot, key)
  const current = (key) => { const value = observe(key); return value.kind === 'present' ? value.version : undefined }
  const same = (a, b) => isDeepStrictEqual(a, b)
  const load = (ref) => { const object = store.get(ref); requireValue(object && id(object) === ref, 'CAS-integrity: ' + ref); return object }
  const originals = new Map(baseline.candidate.entries.map((entry) => {
    const selected = manifest.entries.find((row) => row.key === entry.key)
    requireValue(selected, 'manifest-entry-missing: ' + entry.key)
    const artifact = load(selected.artifact), receipt = load(artifact.receipt), result = load(artifact.result)
    requireValue(artifact.result === entry.artifact.result && receipt.contract === entry.contract &&
      same(receipt.inputs, entry.inputs) && same(receipt.dependencies, entry.dependencies), 'baseline-entry-binding: ' + entry.key)
    return [entry.key, { entry, artifact, receipt, result }]
  }))
  Object.assign(report, { mode: request.mode, authority_root: root, source_root: sourceRoot,
    baseline_candidate: baseline.candidate_id, baseline_manifest: request.manifest,
    baseline_generation: access.context.generation, driver_sha256: ownHash,
    request_sha256: nativeSha256(requestBytes), output_dir: outputRoot })
  event({ event: 'operation-start', ...report })
  if (request.mode === 'finalize') {
    report.stage = 'finalize-private-target'
    const target = pinnedJson(request.target), binding = pinnedJson(request.binding)
    requireValue(target.kind === 'prepared-evaluation-update' && target.prepared.candidate.repo_root === sourceRoot, 'target-root')
    const result = finalizeEvaluationUpdate({ store, target, binding, current,
      readReference: (ref) => readNativeFile(sourceRoot, nativeReferencePath(ref)) })
    save('finalize-result.json', result)
    access.verify()
    report.result = result
    report.stage = 'private-finalization-complete'
    return report
  }
  const captures = new Map()
  if (request.mode === 'capture') {
    report.stage = 'capture-live-inputs'
    mkdirSync(join(outputRoot, 'captured'))
    for (const row of baseline.candidate.observations) {
      requireValue(row.key.startsWith('file:'), 'unplanned-membership-input: ' + row.key)
      const observation = observe(row.key)
      let bytes, file
      if (observation.kind === 'present') {
        bytes = readNativeFile(sourceRoot, row.key.slice(5), ownershipInputMaxBytes)
        requireValue(sourceID(bytes) === observation.version && same(observe(row.key), observation), 'capture-race: ' + row.key)
        file = 'captured/' + nativeSha256(new TextEncoder().encode(row.key)) + '.bin'
        writeFileSync(join(outputRoot, file), bytes, { flag: 'wx' })
      }
      captures.set(row.key, { key: row.key, observation, ...(bytes === undefined ? {} : { file, byte_length: bytes.length, sha256: nativeSha256(bytes) }) })
    }
    requireValue([...captures.values()].every((row) => same(observe(row.key), row.observation)), 'capture-final-drift')
    const plan = planOwnershipUpdate(store, request.manifest, baseline.candidate.scope,
      (key) => { const row = captures.get(key); requireValue(row, 'uncaptured-planner-input: ' + key); return row.observation }, access.context)
    const captured = { schema: 'genesis-s2-u1-capture/v1', baseline_candidate: baseline.candidate_id,
      source_root: sourceRoot, authority_root: root, baseline_manifest: request.manifest,
      files_root: outputRoot, plan, inputs: [...captures.values()] }
    save('capture.json', captured)
    access.verify()
    report.capture = { path: join(outputRoot, 'capture.json'), rows: captures.size, plan }
    report.stage = 'capture-complete'
    return report
  }
  report.stage = 'prepare-private-target'
  const captured = pinnedJson(request.capture)
  requireValue(captured.schema === 'genesis-s2-u1-capture/v1' && captured.baseline_candidate === baseline.candidate_id &&
    captured.source_root === sourceRoot && captured.baseline_manifest === request.manifest, 'capture-lineage')
  const capturedRoot = nativeRoot(captured.files_root), bytes = new Map(), observations = new Map()
  for (const row of captured.inputs) {
    requireValue(!observations.has(row.key), 'duplicate-capture')
    observations.set(row.key, row.observation)
    if (row.observation.kind === 'present') {
      const data = readNativeFile(capturedRoot, row.file, ownershipInputMaxBytes)
      requireValue(data.length === row.byte_length && nativeSha256(data) === row.sha256 && sourceID(data) === row.observation.version, 'captured-bytes-integrity')
      bytes.set(row.key, data)
    }
  }
  requireValue(observations.size === baseline.candidate.observations.length && baseline.candidate.observations.every((row) => observations.has(row.key)), 'capture-universe')
  const stable = () => [...observations].every(([key, value]) => same(observe(key), value)) && nativeSha256(readControl(ownPath)) === ownHash
  requireValue(stable(), 'source-changed-since-native-capture')
  const outputs = new Map()
  for (const ref of request.native_outputs ?? []) {
    const record = pinnedJson(ref)
    requireValue(record.schema === 'genesis-s2-u1-native-output/v1' && originals.has(record.key) && !outputs.has(record.key), 'native-output-key')
    requireValue(typeof record.native_agent_id === 'string' && record.native_agent_id.startsWith('/root/'), 'native-agent-record')
    const producerRequestBytes = readPinned(record.request), producerRequest = JSON.parse(decodeNativeUtf8(producerRequestBytes))
    const responseBytes = readPinned(record.response), response = JSON.parse(decodeNativeUtf8(responseBytes))
    requireValue(producerRequest.schema === 'genesis-s2-u1-native-request/v1' && producerRequest.key === record.key &&
      producerRequest.baseline_candidate === baseline.candidate_id && producerRequest.source_root === sourceRoot, 'native-request-lineage')
    requireValue(response.schema === 'genesis-s2-u1-native-response/v1' && response.key === record.key &&
      response.request_sha256 === record.request.sha256, 'native-response-binding')
    const bodyBytes = readPinned(response.body), body = decodeNativeUtf8(bodyBytes), prior = originals.get(record.key)
    requireValue(body.length > 0, 'empty-native-body')
    const metadata = response.result_metadata ?? {}
    requireValue(Object.keys(metadata).every((k) => ['authorityBasis','validity','gaps','evidence'].includes(k)), 'native-result-fields')
    const output = { body, authorityBasis: metadata.authorityBasis ?? prior.result.authority.basis,
      validity: metadata.validity ?? 'supported', gaps: metadata.gaps ?? [...prior.result.gaps], evidence: metadata.evidence ?? [...prior.result.evidence] }
    requireValue(typeof output.authorityBasis === 'string' && ['supported','blocked'].includes(output.validity) &&
      Array.isArray(output.gaps) && output.gaps.every((x) => typeof x === 'string') &&
      Array.isArray(output.evidence) && output.evidence.every((x) => typeof x === 'string'), 'native-result-metadata')
    const result = { kind: 'ownership-result', version: 1,
      body: id({ kind: 'ownership-body', version: 1, bytes: Array.from(bodyBytes) }),
      authority: { scope: baseline.candidate.scope, basis: output.authorityBasis },
      validity: 'supported', gaps: output.gaps, evidence: output.evidence }
    outputs.set(record.key, { record, request: producerRequest, output, result: id(result), body_sha256: nativeSha256(bodyBytes),
      producer_request: nativePut(store, { kind: 'ownership-body', version: 1, bytes: Array.from(producerRequestBytes) }),
      producer_response: nativePut(store, { kind: 'ownership-body', version: 1, bytes: Array.from(responseBytes) }) })
  }
  const semantic = (request.semantic_reviews ?? []).map((ref) => {
    const data = readPinned(ref), value = JSON.parse(decodeNativeUtf8(data))
    requireValue(value.schema === 'genesis-s2-u1-semantic-review/v1' && value.purpose === 'changed-result-semantic-evidence' &&
      ['/root/s2_j1','/root/s2_j2'].includes(value.reviewer) && Array.isArray(value.entries), 'semantic-review-shape')
    return { value, data }
  })
  const recipes = new Map(registry.recipes.map((spec) => [spec.key, { ...spec, run: (input) => {
    report.callback_entries.push(spec.key); event({ event: 'recipe-enter', key: spec.key })
    try {
      requireValue(input.lists.size === 0, 'unplanned-membership')
      const sealed = outputs.get(spec.key); requireValue(sealed, 'missing-real-native-output: ' + spec.key)
      const inputs = effectiveInputs(spec.key, originals.get(spec.key).receipt, spec, input.captured, input.lists)
      requireValue(Array.isArray(inputs) && same(inputs, sealed.request.inputs), 'native-output-input-binding')
      const dependencies = [...input.dependencies].map(([key, result]) => ({ key, result }))
      requireValue(same(dependencies, sealed.request.dependencies), 'native-output-dependency-binding')
      for (const row of inputs) requireValue(input.bytes.has(row.key) && sourceID(input.bytes.get(row.key)) === row.version, 'native-output-capture-bytes')
      requireValue(stable(), 'source-drift-before-output-materialization')
      report.callback_returns.push({ key: spec.key, native_agent_id: sealed.record.native_agent_id, result: sealed.result,
        producer_request: sealed.producer_request, producer_response: sealed.producer_response })
      event({ event: 'recipe-return', key: spec.key, result: sealed.result })
      return { ...sealed.output, gaps: [...sealed.output.gaps], evidence: [...sealed.output.evidence] }
    } catch (error) {
      report.callback_failures.push({ key: spec.key, error: String(error) }); event({ event: 'recipe-throw', key: spec.key, error: String(error) }); throw error
    }
  } }]))
  nativeDigest(request.target_generation, 64, 'target_generation')
  requireValue(allowedRoot(request.target_root) && request.target_root === sourceRoot, 'target-root')
  const result = prepareEvaluationUpdate({ store, baseline, manifest: request.manifest, context: access.context,
    targetGeneration: request.target_generation, targetRepoRoot: request.target_root, recipes, observe,
    readCapturedBytes: (key) => bytes.get(key), listMembers: (dir) => { throw new Error('unplanned-membership: ' + dir) },
    semanticEvidence: (key, targetResult) => {
      const sealed = outputs.get(key)
      if (!sealed || sealed.result !== targetResult) return undefined
      const matched = semantic.filter(({ value }) => {
        const rows = value.entries.filter((row) => row.key === key)
        return rows.length === 1 && rows[0].verdict === 'PASS' && rows[0].result === targetResult &&
          rows[0].body_sha256 === sealed.body_sha256 && rows[0].native_request_sha256 === sealed.record.request.sha256 &&
          rows[0].native_response_sha256 === sealed.record.response.sha256
      })
      return matched.length === 2 && new Set(matched.map(({ value }) => value.reviewer)).size === 2
        ? matched.map(({ data }) => nativePut(store, { kind: 'ownership-body', version: 1, bytes: Array.from(data) })) : undefined
    } })
  requireValue(stable(), 'source-drift-after-prepare')
  access.verify()
  save('prepare-result.json', result)
  if (result.kind === 'prepared-evaluation-update') save('target-prepared.json', result.prepared)
  report.result = result
  report.stage = 'private-preparation-complete'
  return report
}

try {
  const result = await main()
  event({ event: 'operation-return', stage: result.stage, result_kind: result.result?.kind ?? 'capture' })
  process.stdout.write(JSON.stringify(result, null, 2) + '\n')
  process.exitCode = result.result?.kind === 'hold' || result.capture?.plan?.kind === 'hold' ? 2 : 0
} catch (error) {
  event({ event: 'operation-throw', stage: report.stage, error: String(error) })
  process.stdout.write(JSON.stringify({ ...report, kind: 'operator-failure', error: error instanceof Error ? error.message : String(error) }, null, 2) + '\n')
  process.exitCode = 1
}
