import { atlasDir } from "./layout.js"
import { dirname } from "node:path"
import { assertOperationalStateDirectory } from "./store-evaluation-identity.js"
import {
  KindConflationError,
  UndeterminedKindError,
  UnownedWriteError,
  ScannerBlockedError,
  capGate,
  memoryKindOf,
  put,
  MEMBER_TOK_CAP,
  ORCH_TOK_CAP,
  LOGBOOK_AUTHOR,
  validate,
} from "@atlas/memory"
import type { MemberId, MemoryEntry, MemoryRecord, NamedScanner, ProjectMemoryEntry } from "@atlas/memory"
import type { DurableMemory } from "./memory-store.js"
import { NO_SCANNER_NAME } from "./scanner.js"
const reject = (refusal: MemoryRefusal, reason: string, extra: Partial<MemoryRejected> = {}): MemoryRejected => ({
  ok: false,
  refusal,
  reason,
  ...extra,
})
export function createMemoryEmit(deps: MemoryEmitDeps): MemoryEmit {
  function emit(entry: MemoryEntry): MemoryVerdict {
    try { assertOperationalStateDirectory(dirname(deps.store.path)); assertOperationalStateDirectory(deps.store.path) } catch (error) {
      return reject("evaluation-phase", error instanceof Error ? error.message : String(error))
    }
    // 1 — the kind is DERIVED. `memoryKindOf` throws on no match and on a TIE; both are the same refusal
    // to a caller, because both mean "this entry does not name exactly one template".
    let kind
    try {
      kind = memoryKindOf(entry)
    } catch (e) {
      if (!(e instanceof UndeterminedKindError)) throw e
      return reject("undetermined-kind", e.message)
    }

    // 2 — the template that the DERIVED kind selected, never one the payload asked for.
    const verdict = validate(kind, entry)
    if (!verdict.valid) {
      return reject("template-invalid", `MEM-5 template: ${verdict.reasons.join("; ")}`)
    }

    // 3 — partition + owner. `put` mints the record and is the only thing here that does.
    //
    // [MEASURED — `kind-conflation` is UNREACHABLE FROM THIS DOOR, and is deliberately not advertised.]
    // `partition()` answers `knowledge` only for an entry carrying `kind: 'advisory' | 'predicate'`. That
    // key is outside all four memory templates, so gate 1 refuses such an entry as `undetermined-kind`
    // before `put` is ever called, and this branch fires on nothing. Measured against the shipped binary,
    // both discriminants, in `harness/probes/m1-memory-ring.mjs` (axis M2) — not argued from the source.
    //
    // The catch STAYS: `put` really does throw it, and a template change could reopen the path, so removing
    // the branch would trade a live fail-closed floor for tidiness. What was removed instead is the CLAIM —
    // `handler.ts`'s `atlas-memory-emit` guidance used to enumerate `kind-conflation` among the outcomes a
    // user may receive, which was the same shape of defect as `template-invalid` (a refusal advertised to
    // users that no input could produce). The M2 assertions turn RED the moment it becomes reachable again,
    // which is what keeps the guidance and the code from drifting back apart.
    let record: MemoryRecord
    try {
      record = put("memory", entry, deps.actor)
    } catch (e) {
      if (e instanceof KindConflationError) return reject("kind-conflation", e.message)
      if (e instanceof UnownedWriteError) return reject("unowned", e.message)
      if (e instanceof UndeterminedKindError) return reject("undetermined-kind", e.message)
      throw e
    }

    const durable = deps.store.read()

    // MEM-8's author check judges the ACTOR, not the store, so it precedes the store-state gate.
    if (kind === "logbook" && deps.actor !== LOGBOOK_AUTHOR) {
      return reject(
        "logbook-unauthorized",
        `MEM-8 logbook: only '${LOGBOOK_AUTHOR}' may append; '${deps.actor}' may not`,
      )
    }

    // 3b — the store state, for the kinds whose next gate judges the durable set (see the header).
    if ((kind === "logbook" || kind === "project") && durable.rejected > 0) {
      return durable.unreadable === true
        ? reject(
            "store-unavailable",
            `the memory log at '${deps.store.path}' could not be read; a ${kind} write is judged against it, so it is refused rather than judged against nothing`,
          )
        : reject(
            "store-partial",
            `the memory log at '${deps.store.path}' has ${durable.rejected} rejected line(s); a ${kind} write is judged against the whole set, so it is refused rather than judged against part of it`,
          )
    }

    // 4 — MEM-8, logbook only. Read from the DURABLE log so the guard survives a restart.
    if (kind === "logbook") {
      const prId = (entry as { readonly prId: string }).prId
      const extant = durable.store.some(
        (r) => r.kind === "logbook" && (r.entry as { readonly prId?: string }).prId === prId,
      )
      if (extant) {
        return reject(
          "logbook-duplicate",
          `MEM-8 logbook: an entry for PR '${prId}' already exists; a correction appends a supersede ` +
            "pointer and never rewrites the extant entry",
        )
      }
    }

    // 5 — MEM-3, project only. Over the OWNER'S set plus the candidate: a per-member cap computed over the
    // candidate alone would never bind, and one computed over EVERY member's records would refuse a write
    // because somebody else is verbose.
    if (kind === "project") {
      const cap = deps.actor === LOGBOOK_AUTHOR ? ORCH_TOK_CAP : MEMBER_TOK_CAP
      const mine = durable.store
        .filter((r) => r.owner === deps.actor && r.kind === "project")
        .map((r) => r.entry as ProjectMemoryEntry)
      const gate = capGate([...mine, entry as ProjectMemoryEntry], cap)
      if (!gate.accepted) {
        return reject("over-cap", "MEM-3 cap: the injected project set would exceed its bound", {
          tokens: gate.tokens,
          cap: gate.cap,
        })
      }
    }

    // 6 — MEM-9. Absent scanner ⇒ refuse; see `MemoryEmitDeps.scanner`.
    //
    // `NO_SCANNER_NAME` IS AN ABSENCE, NOT A HIT, and this line exists because W4 and W5 were built in
    // parallel and were each correct alone while being WRONG TOGETHER. W5's adapter, finding no binary on
    // PATH, returns a `NamedScanner` named `no-scanner-on-path` whose `scan()` always answers `true` —
    // fail-closed, which is right. But this door reads `scan() === true` as `scanner-blocked`, so the pair
    // would have told a user "a secret was detected in your write" when the truth is "nothing looked". A
    // refusal that misnames its own reason is a worse failure than the one it reports, because the user
    // acts on the reason: they would go hunting a secret that is not there instead of installing gitleaks.
    if (deps.scanner === undefined || deps.scanner.name === "" || deps.scanner.name === NO_SCANNER_NAME) {
      return reject(
        "scanner-unavailable",
        "MEM-9 pre-write scan: no NAMED scanner is configured, so this write was not checked for secrets. " +
          '"Not checked" and "no secret" are refused as the same value — and so are "not checked" and ' +
          '"a secret was found".',
        { scanner: deps.scanner?.name ?? "" },
      )
    }
    try {
      if (deps.scanner.scan(record)) {
        return reject("scanner-blocked", new ScannerBlockedError(deps.scanner.name).message, {
          scanner: deps.scanner.name,
        })
      }
    } catch (e) {
      // A scanner that THREW did not return "clean". Fail-closed: an unavailable check is refused, never
      // treated as a pass, which is the same rule as an absent one.
      return reject(
        "scanner-unavailable",
        `MEM-9 pre-write scan: scanner '${deps.scanner.name}' could not complete ` +
          `(${e instanceof Error ? e.message : String(e)}) — refused, never passed`,
        { scanner: deps.scanner.name },
      )
    }

    // 7 — one append. Append-only, so a refusal above left nothing to unwind.
    try { assertOperationalStateDirectory(dirname(deps.store.path)); assertOperationalStateDirectory(deps.store.path) } catch (error) {
      return reject("evaluation-phase", error instanceof Error ? error.message : String(error))
    }
    deps.store.append(record)
    return { ok: true, record }
  }

  return { emit }
}
export function assertOperationalMemoryRoot(root: string): void {
  assertOperationalStateDirectory(atlasDir(root))
}
export function memoryPhaseRefusal(root: string): MemoryRejected | undefined {
  try { assertOperationalMemoryRoot(root); return undefined } catch (error) {
    return reject("evaluation-phase", error instanceof Error ? error.message : String(error))
  }
}
