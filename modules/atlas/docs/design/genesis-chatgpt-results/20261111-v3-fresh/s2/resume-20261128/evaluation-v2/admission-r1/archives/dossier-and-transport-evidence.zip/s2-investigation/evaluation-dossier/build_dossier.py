#!/usr/bin/env python3
"""Read-only source/evidence collection and lossless projections; no Atlas operation."""
from pathlib import Path
import collections
import copy
import hashlib
import json
import os
import subprocess

ROOT = Path('/workspace/scratch/5cfbb6c803f1')
OUT = ROOT / 's2-investigation/evaluation-dossier'
CORPUS = ROOT / 's2-corpus'
RUNTIME = ROOT / 's2-runtime'
CPIN = 'bb2a931301d541692b11e5a7f1eab234cd9ed2fd'
RPIN = 'db9b4235022c4df32fe3bfd4faeea8adcd69abb7'
PREFIX = 'modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2/'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')
ASSETS = []
CHECKS = []
GROUPS = collections.OrderedDict()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()

def read_json(path):
    return json.loads(path.read_bytes())

def check(name, actual, expected):
    if actual != expected:
        if isinstance(actual, bytes) and isinstance(expected, bytes):
            raise ValueError(f'{name}: lengths {len(actual)}/{len(expected)}, sha256 {sha(actual)}/{sha(expected)}')
        raise ValueError(f'{name}: values differ; no source content printed')
    CHECKS.append(name)

def put(relative, data):
    path = OUT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path

def register(relative, data, group=None, **metadata):
    data.decode('utf-8')
    put(relative, data)
    record = dict(id=f'A{len(ASSETS):03d}', file=relative, utf8_bytes=len(data), sha256=sha(data), **metadata)
    ASSETS.append(record)
    if group:
        GROUPS.setdefault(group, []).append(record)
    return record

def pinned(root, pin, path, group):
    data = (root / path).read_bytes()
    committed = subprocess.check_output(['git', '-C', str(root), 'show', f'{pin}:{path}'], env=ENV)
    check(f'pin:{pin}:{path}', data, committed)
    return register(f'sources/{root.name}/{path}', data, group, origin=str(root/path), git_commit=pin, git_path=path, git_blob_sha=blob(data), representation='complete literal source bytes')

def local(path, group=None):
    relative = str(path.relative_to(ROOT))
    return register('sources/local/' + relative, path.read_bytes(), group, origin=str(path), representation='complete literal evidence bytes')

for root, pin in [(CORPUS, CPIN), (RUNTIME, RPIN)]:
    check(f'HEAD:{root.name}', subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], env=ENV).decode().strip(), pin)

package_path = CORPUS / (PREFIX + 'native-package.json')
package_bytes = package_path.read_bytes()
package = json.loads(package_bytes)
check('package sha256', sha(package_bytes), '9356cefcb4a1db413e67869a855fd082536476fb18ff7784dde39f051e9b407b')
check('package byte length', len(package_bytes), 332594)
package_source = pinned(CORPUS, CPIN, PREFIX + 'native-package.json', None)
prepared_path = ROOT / 's2-execution/prepare-01/prepared.json'
prepared_bytes = prepared_path.read_bytes()
prepared = json.loads(prepared_bytes)
check('prepared sha256', sha(prepared_bytes), '476891f3bf1edf24f7d2c486a1218bab5b0cd5b2b36b8295c3892917724c2b4a')
check('native v1 candidate', prepared['candidate_id'], '4a36e1210acf6a4bb460846b717d446e6c259f80a78fd73cfce8b5a6e445f522')
prepared_source = local(prepared_path)

context = """# Stable material for future isolated evaluation admission V2

Status: PREPARED_FOR_PARENT_REVIEW; NOT_DISPATCHED. This dossier issues no judgment.
There is no prepared V2 candidate in this stable packet. Native V1 HOLD remains intact.
The candidate 4a36e1210acf6a4bb460846b717d446e6c259f80a78fd73cfce8b5a6e445f522 belongs only to the fresh native-V1 prepare-01, not the unavailable historical r4 execution.

This packet transports historical semantic evidence and the existing db9 V2 admission protocol/code. The four ADMIT criteria have their stated purpose. Original AC-01..10, runtime-import-binding, final campaign/consumer/maintenance obligations retain their original status and require their own actual evidence. User authorization of sequence is not approval of absent outcomes.

Historical reuse is opaque: all 14 complete original decision files are carried, including FIX-FIRST, corrected-unit boundaries, reviewer explanations, suggestions and acceptance limits. No label-only replacement is used. The four accepted manifests and the 13-entry lineage mapping identify the precise body bytes and original reviewer pairs. The thirteen body texts and the raw 667-file source corpus are not transported in this dossier. Their paths, sizes, SHA-256, Git blobs, source pins, input versions and bindings are retained.

This is not a re-semantic review request, a final binding request, a producer request or a consumer task. No new judgment from either current judge is included. No new approval, policy, publication, reader result, maintenance execution or CI outcome is asserted. Source collection and projection checks are file/structure calculations only.

Literal sources carry full-source byte lengths, SHA-256, Git blob identity and commit pin. Chunk framing lies outside payload byte ranges. A large generated projection or report may span chunks at UTF-8 newline boundaries; concatenate payload segments in offset order to recover that exact asset. Complete code functions are never abridged. Corpus metadata snapshots and original full reports are also archived locally; the chunks use the explicitly lossless projections where stated.

Native V1 context previously supplied to both persistent judges was scope-packet.txt, SHA-256 f711d3f2b2cd8615ff9143115d403e59723d25a728506ae659e207874c44b6b1. Its scope was admissibility under the original AC contract, not a final candidate vote. This dossier includes native prepare/format/io/binding and related source-input identity code again, so the V2 transformation dependency does not depend on a remembered paraphrase. It does not copy either judge's response.

Still pending, to be added only from actual execution: frozen evaluation plan and obligation set, exact V2 prepared candidate/entries/contracts/input and result identities, runtime-identity closure, original V2 execution receipt and independent mapping verification, generation/isolation/policy evidence, actual two independent admission decisions and their transport records. None may be inferred from prepare-01's 780/4752 checks. Release status must remain explicit. Publication/index/read/independent consumer traversal and final 14 cases plus S2-U1 are separate subsequent evidence.
"""
register('00-context.txt', context.encode(), '01-context-and-protocol', representation='operator context, no decision')
for path in ['modules/atlas/docs/design/evaluation-admission.md', 'modules/atlas/docs/design/evaluation-admission-criteria-v1.json']:
    pinned(RUNTIME, RPIN, path, '01-context-and-protocol')

code_groups = {
 '02-v2-prepare-admit-binding-cli': [
  'packages/adapter-io/src/genesis-evaluation.ts',
  'packages/adapter-io/src/genesis-evaluation-binding.ts',
  'scripts/genesis-evaluation.ts',
  'packages/knowledge/src/ownership/evaluation.ts'],
 '03-v2-policy-and-reader-boundaries': [
  'packages/adapter-io/src/ownership-evaluation-policy.ts',
  'packages/adapter-io/src/evaluation-read-budget.ts',
  'packages/adapter-io/src/evaluation-state-io.ts',
  'packages/adapter-io/src/evaluation-manifest-binding.ts',
  'packages/adapter-io/src/store-evaluation-identity.ts',
  'packages/adapter-io/src/ownership-access.ts',
  'packages/knowledge/src/ownership/types.ts'],
 '04-v2-identity-and-rebuild-code-only': [
  'packages/adapter-io/src/evaluation-runtime-identity.ts',
  'packages/adapter-io/src/evaluation-rebuild.ts'],
 '05-native-v1-transform-and-validator-dependency': [
  'packages/adapter-io/src/genesis-native.ts',
  'packages/adapter-io/src/genesis-native-binding.ts',
  'packages/adapter-io/src/genesis-native-format.ts',
  'packages/adapter-io/src/genesis-native-io.ts',
  'packages/adapter-io/src/ownership-input.ts',
  'scripts/genesis-native.ts',
  'packages/kernel/src/canonical.ts',
  'packages/kernel/src/encoder.ts'],
}
for group, paths in code_groups.items():
    for path in paths:
        pinned(RUNTIME, RPIN, 'modules/atlas/' + path, group)

manifests = {}
for layer in range(1,5):
    path = PREFIX + f'accepted/l{layer}.json'
    asset = pinned(CORPUS, CPIN, path, '06-historical-acceptance-manifests-and-lineage')
    manifests[layer] = (asset, read_json(CORPUS/path))

review_assets = {}
for artifact in package['artifacts']:
    for ref in artifact['semantic_review_refs']:
        path = ref['payload_path']
        if path in review_assets:
            continue
        stage = path.removeprefix(PREFIX).rsplit('/',1)[0].removeprefix('judgments/')
        if stage == 'resume-l1':
            stage += '-desktop-design' if 'desktop-design' in path else '-app-session'
        asset = pinned(CORPUS, CPIN, path, '07-historical-full-decisions-' + stage.replace('/','-'))
        check('review sha:' + path, asset['sha256'], ref['sha256'])
        review_assets[path] = asset
check('distinct historical decisions', len(review_assets), 14)
check('historical complete decision bytes', sum(x['utf8_bytes'] for x in review_assets.values()), 108942)

lineage = []
for index, artifact in enumerate(package['artifacts']):
    asset, manifest = manifests[artifact['layer']]
    accepted = next(x for x in manifest['artifacts'] if x['key'] == artifact['key'])
    check('accepted body path:' + artifact['key'], accepted['body_path'], artifact['body']['path'])
    check('accepted body sha:' + artifact['key'], accepted['body_sha256'], artifact['body']['sha256'])
    check('accepted body size:' + artifact['key'], accepted['byte_length'], artifact['body']['byte_length'])
    check('accepted pair:' + artifact['key'], [(PREFIX+x['response_path'],x['response_sha256']) for x in accepted['reviews']], [(x['payload_path'],x['sha256']) for x in artifact['semantic_review_refs']])
    body = (CORPUS/(PREFIX+artifact['body']['path'])).read_bytes()
    check('current body sha:' + artifact['key'], sha(body), artifact['body']['sha256'])
    check('current body size:' + artifact['key'], len(body), artifact['body']['byte_length'])
    lineage.append(dict(package_index=index, key=artifact['key'], body=dict(repo_path=PREFIX+artifact['body']['path'], **artifact['body']), accepted_manifest=dict(asset=asset['id'], git_path=asset['git_path'], sha256=asset['sha256']), accepted_record=accepted, semantic_review_refs=[dict(**ref, dossier_asset=review_assets[ref['payload_path']]['id']) for ref in artifact['semantic_review_refs']]))
register('projections/historical-lineage.json', json_bytes(dict(schema='s2-historical-lineage/v1', package_sha256=sha(package_bytes), scope='Exact existing selection; full historical files retain other unit/revision judgments and limits.', entries=lineage)), '06-historical-acceptance-manifests-and-lineage', representation='derived mapping; no semantic rejudgment')

preflight_path = ROOT/'s2-investigation/byte-audit/source-preflight.json'
preflight_bytes = preflight_path.read_bytes()
preflight = json.loads(preflight_bytes)
preflight_source = local(preflight_path)
check('preflight original sha256', sha(preflight_bytes), '51b91eecab81cc7a71607167a81eaf8aacccdb0ec1b2262e960e8b9ad26e3778')
check('preflight path count', len(preflight['files']), 667)
file_indexes = {f['path']: i for i,f in enumerate(preflight['files'])}
observations = prepared['candidate']['observations']
obs_versions = {}
for observation in observations:
    check('observation file key:' + observation['key'], observation['key'].startswith('file:'), True)
    path = observation['key'][5:]
    if path in obs_versions: raise ValueError('duplicate observation')
    obs_versions[path] = observation['version']
    check('observation in preflight:' + path, path in file_indexes, True)
    check('observation SHA binds preflight:' + path, observation['sha256'], preflight['files'][file_indexes[path]]['sha256'])
    check('observation key order:' + path, list(observation), ['key','version','sha256'])

meta_groups = []
rows = []
for i, f in enumerate(preflight['files']):
    check(f'head blob equality:{i}', f['head_blob_sha'], f['git_blob_sha'])
    check(f'empty issues:{i}', f['issues'], [])
    check(f'local byte-check status:{i}', f['status'], 'PASS')
    check(f'expected sha shape:{i}', f['expected_sha256'] in ([], [f['sha256']]), True)
    check(f'expected blob shape:{i}', f['expected_git_blob_sha'] in ([], [f['git_blob_sha']]), True)
    group = {k:f[k] for k in ['roles','artifact_keys','pinned_commits','input_limit']}
    group['expected_sha256'] = 'same-singleton' if f['expected_sha256'] else 'empty'
    group['expected_git_blob_sha'] = 'same-singleton' if f['expected_git_blob_sha'] else 'empty'
    if group not in meta_groups: meta_groups.append(group)
    rows.append([i, f['path'], f['byte_length'], f['sha256'], f['git_blob_sha'], meta_groups.index(group), obs_versions.get(f['path'])])

header = dict(schema='s2-source-preflight-lossless-projection/v1', original=dict(asset=preflight_source['id'], sha256=sha(preflight_bytes), utf8_bytes=len(preflight_bytes)), original_top_key_order=list(preflight), original_file_key_order=list(preflight['files'][0]), original_top_level_except_files={k:v for k,v in preflight.items() if k!='files'}, columns=['file_index','path','byte_length','sha256','git_blob_sha','metadata_group_index','prepare01_ownership_source_version_or_null'], groups=meta_groups, reconstruction=dict(head_blob_sha='Copy git_blob_sha', expected_sha256='[sha256] when group marker same-singleton; [] when empty', expected_git_blob_sha='[git_blob_sha] when group marker same-singleton; [] when empty', roles='Copy metadata group roles preserving order', artifact_keys='Copy metadata group artifact_keys preserving order', pinned_commits='Copy metadata group pinned_commits preserving order', input_limit='Copy metadata group input_limit', issues=[], status='PASS', note='PASS is the original deterministic file-check status, not a semantic or admission verdict. Added observation versions are from prepare-01, not synthesized by source-preflight. Null means this path was not a candidate observation.'), original_json_encoding='UTF-8, ensure_ascii=False, indent=2, trailing LF; verified byte-for-byte after reconstruction')
reconstructed_files = []
for i,path,length,digest,gitblob,gid,version in rows:
    g=meta_groups[gid]
    values = dict(path=path, roles=g['roles'], artifact_keys=g['artifact_keys'], byte_length=length, sha256=digest, git_blob_sha=gitblob, head_blob_sha=gitblob, pinned_commits=g['pinned_commits'], input_limit=g['input_limit'], expected_sha256=[digest] if g['expected_sha256']=='same-singleton' else [], expected_git_blob_sha=[gitblob] if g['expected_git_blob_sha']=='same-singleton' else [], issues=[], status='PASS')
    reconstructed_files.append({k:values[k] for k in header['original_file_key_order']})
reconstructed_preflight = {k: reconstructed_files if k=='files' else header['original_top_level_except_files'][k] for k in header['original_top_key_order']}
check('preflight exact JSON structure reconstruction', reconstructed_preflight, preflight)
check('preflight exact original byte reconstruction', json_bytes(reconstructed_preflight), preflight_bytes)
register('projections/source-preflight-header.json', json_bytes(header), '08-source-preflight-definition-and-rows', representation='complete header, dictionaries, reconstruction rules')
rows_bytes = ''.join(json.dumps(x, ensure_ascii=False, separators=(',',':'))+'\n' for x in rows).encode()
register('projections/source-preflight-rows.jsonl', rows_bytes, '08-source-preflight-definition-and-rows', representation='667 exact metadata rows; observation version column from prepare-01')

projected_artifacts = []
source_ref_key_orders = []
for artifact in package['artifacts']:
    new = {k:v for k,v in artifact.items() if k not in ['source_refs','input_keys']}
    source_indexes = []
    ref_key_orders = []
    for ref in artifact['source_refs']:
        i = file_indexes[ref['path']]; f = preflight['files'][i]
        check('source ref reconstruct:' + artifact['key'] + ':' + ref['path'], ref, dict(commit=f['pinned_commits'][0],path=f['path'],git_blob_sha=f['git_blob_sha'],sha256=f['sha256']))
        source_indexes.append(i)
        if list(ref) not in source_ref_key_orders: source_ref_key_orders.append(list(ref))
        ref_key_orders.append(source_ref_key_orders.index(list(ref)))
    input_indexes = []
    for key in artifact['input_keys']:
        check('package file input key', key.startswith('file:'), True)
        input_indexes.append(file_indexes[key[5:]])
    new['source_ref_file_indexes'] = source_indexes
    new['source_ref_key_order_indexes'] = ref_key_orders
    new['input_file_indexes'] = input_indexes
    new['original_key_order'] = list(artifact)
    projected_artifacts.append(new)
package_projection = dict(schema='s2-native-package-lossless-projection/v1', original=dict(asset=package_source['id'], sha256=sha(package_bytes), utf8_bytes=len(package_bytes)), source_rows='projections/source-preflight-rows.jsonl', source_groups='projections/source-preflight-header.json', source_ref_key_orders=source_ref_key_orders, original_top_key_order=list(package), original_top_level_except_artifacts={k:v for k,v in package.items() if k!='artifacts'}, artifacts=projected_artifacts, reconstruction='source_refs are reconstructed in listed order as {commit: sole pinned_commits value, path, git_blob_sha, sha256} from each indexed source row, with each reference key order selected by source_ref_key_order_indexes into source_ref_key_orders; input_keys are file: + row.path in listed order. All remaining fields and their original order are preserved. No body text appears in the original package or this projection.')
reconstructed_artifacts=[]
for a in projected_artifacts:
    refs=[]
    for i, oi in zip(a['source_ref_file_indexes'], a['source_ref_key_order_indexes']):
        f=preflight['files'][i]; values=dict(commit=f['pinned_commits'][0],path=f['path'],git_blob_sha=f['git_blob_sha'],sha256=f['sha256']); refs.append({k:values[k] for k in source_ref_key_orders[oi]})
    reconstructed_artifacts.append({k:refs if k=='source_refs' else ['file:'+rows[i][1] for i in a['input_file_indexes']] if k=='input_keys' else a[k] for k in a['original_key_order']})
reconstructed_package = {k:reconstructed_artifacts if k=='artifacts' else package_projection['original_top_level_except_artifacts'][k] for k in package_projection['original_top_key_order']}
check('native package exact structure reconstruction', reconstructed_package, package)
package_projection['original_json_encoding'] = 'UTF-8, ensure_ascii=True, indent=2, trailing LF; verified byte-for-byte after reconstruction'
check('native package exact bytes reconstruction', (json.dumps(reconstructed_package, ensure_ascii=True, indent=2)+'\n').encode(), package_bytes)
register('projections/native-package-metadata.json', json_bytes(package_projection), '09-package-and-native-v1-candidate-metadata', representation='lossless package projection; repeated source/input identities indexed once')

candidate = prepared['candidate']
entries=[]; result_objects=[]
for entry in candidate['entries']:
    projected={k:v for k,v in entry.items() if k!='inputs'}
    projected['input_file_indexes']=[]
    for inp in entry['inputs']:
        i=file_indexes[inp['key'][5:]]
        check('entry input version:' + entry['key'] + ':' + str(i), inp['version'], rows[i][6])
        projected['input_file_indexes'].append(i)
    projected['original_key_order']=list(entry)
    entries.append(projected)
    rid=entry['artifact']['result']; cas_path=CORPUS/'.atlas/cas'/rid[:2]/rid
    raw=cas_path.read_bytes(); result_objects.append(dict(entry_key=entry['key'],result_id=rid,cas_source=str(cas_path),cas_file_sha256=sha(raw),cas_file_utf8_bytes=len(raw),object=json.loads(raw)))
cp=dict(schema='s2-native-v1-prepared-lossless-projection/v1', original=dict(asset=prepared_source['id'],sha256=sha(prepared_bytes),utf8_bytes=len(prepared_bytes)), candidate_id=prepared['candidate_id'], prepared_schema=prepared['schema'], original_prepared_key_order=list(prepared), original_candidate_key_order=list(candidate), candidate_header={k:v for k,v in candidate.items() if k not in ['entries','observations']}, observation_file_indexes=[file_indexes[x['key'][5:]] for x in observations], entries=entries, source_rows='projections/source-preflight-rows.jsonl', reconstruction='Each input index resolves to {key: file: + row.path, version: row.prepare01_ownership_source_version_or_null}; each observation resolves to these two keys followed by sha256: row.sha256. Null version is forbidden in any used index. Preserve every listed order. Entries/header include complete references, dependencies/result IDs, navigation, roots and required key order. No candidate V2 is represented.')
rebuilt_entries=[]
for e in entries:
    inp=[dict(key='file:'+rows[i][1],version=rows[i][6]) for i in e['input_file_indexes']]
    rebuilt_entries.append({k:inp if k=='inputs' else e[k] for k in e['original_key_order']})
rebuilt_candidate={k:rebuilt_entries if k=='entries' else [dict(key='file:'+rows[i][1],version=rows[i][6],sha256=rows[i][3]) for i in cp['observation_file_indexes']] if k=='observations' else cp['candidate_header'][k] for k in cp['original_candidate_key_order']}
rebuilt_prepared={k:rebuilt_candidate if k=='candidate' else prepared[k] for k in cp['original_prepared_key_order']}
check('native prepared exact structure reconstruction', rebuilt_prepared, prepared)
check('native prepared exact original bytes reconstruction', json_bytes(rebuilt_prepared), prepared_bytes)
register('projections/native-v1-prepared-metadata.json', json_bytes(cp), '09-package-and-native-v1-candidate-metadata', representation='lossless prepared projection; every input/observation version retained in shared row table')
register('projections/native-v1-result-objects.json', json_bytes(result_objects), '09-package-and-native-v1-candidate-metadata', representation='complete 13 original CAS result objects including authority/validity/gaps/evidence; bodies remain opaque CAS refs')
contract_id=candidate['contract']; contract_path=CORPUS/'.atlas/cas'/contract_id[:2]/contract_id
register('sources/local/native-v1-contract.json', contract_path.read_bytes(), '09-package-and-native-v1-candidate-metadata', origin=str(contract_path), cas_address=contract_id, representation='literal original native-v1 contract; no changed criteria')

for path in ['s2-execution/prepare-01/receipt.json','s2-investigation/record-prepare.py','s2-execution/prepare-01/integrity.json','s2-investigation/verify-prepared.mjs']:
    local(ROOT/path, '10-prepare01-original-receipt-and-780-verifier')
for path in ['s2-investigation/binding/independent-mapping-check.mjs','s2-investigation/binding/independent-mapping-check.json']:
    local(ROOT/path, '11-native-v1-4752-verifier-and-result')
local(ROOT/'s2-investigation/byte-audit/source_preflight.py', '12-preflight-reproducible-method')
local(ROOT/'s2-execution/prepare-01/cas-manifest.json', '13-original-cas-manifest')

rules = dict(schema='s2-dossier-reduction-and-pending/v1', literal_history=dict(files=14,total_utf8_bytes=108942,semantic_reference_uses=26,accepted_manifest_files=4,entries=13,omitted_historical_fields=[]), reductions=[
 dict(asset='source-preflight.json',removed_fields=['files[*].head_blob_sha','files[*].expected_sha256','files[*].expected_git_blob_sha','files[*].issues','files[*].status'],replacement='Reconstructed from checked equality/defaults and explicit per-group markers; no value loss. Other repeated row fields stored once per metadata group. Exact original bytes reconstructed and compared.',added_fields=['prepare01 ownership-source version or null']),
 dict(asset='native-package.json',removed_fields=['artifacts[*].source_refs','artifacts[*].input_keys'],replacement='Ordered file-index lists resolve exact refs/keys from shared rows; every other field retained. Exact original bytes reconstructed and compared.'),
 dict(asset='prepare-01/prepared.json',removed_fields=['candidate.observations','candidate.entries[*].inputs'],replacement='Ordered file-index lists resolve exact keys and versions; other candidate fields complete. Exact original bytes reconstructed and compared.'),
 dict(asset='raw source corpus and 13 bodies',transported=False,replacement='Paths, lengths, SHA-256, Git blobs/pins, observed versions, existing accepted manifests, full historical decisions and complete result metadata. Bodies are intentionally opaque; raw source text is outside this stable packet.'),
 dict(asset='new judge opinions',transported=False,replacement='None. Neither current judge response is read into this dossier.')], pending=['Actual frozen V2 evaluation plan and original obligation set','Actual V2 prepare receipt, prepared candidate, all per-entry contracts and semanticEvidence CAS IDs','Actual V2 independent mapping and identity verification','Executed runtime dependency closure and full runtime identity from V2 candidate','Actual independent generation plus isolated store and explicit policy binding if created','Two new distinct exact admission decisions and their real request/response transport','Compatible S4 release evidence, isolated admission/publication, index/read and independent consumer traversal','Final original acceptance obligations, fourteen cases, S2-U1 maintenance evidence'], scope='No admission verdict, inherited approval, product test, consumer result or maintenance run is made by this construction.')
register('projection-rules-and-pending.json', json_bytes(rules), '14-reductions-pending-and-builder', representation='explicit omission/reconstruction ledger; no gate outcome')
builder=Path(__file__).read_bytes()
builder_asset=dict(id=f'A{len(ASSETS):03d}',file='build_dossier.py',utf8_bytes=len(builder),sha256=sha(builder),origin=str(Path(__file__)),representation='complete deterministic collector/projector source; no Atlas operation')
ASSETS.append(builder_asset); GROUPS.setdefault('14-reductions-pending-and-builder',[]).append(builder_asset)

verification=dict(schema='s2-stable-dossier-assembly-verification/v1',operation='Read-only hashing/pinned source comparison and exact reversible projection reconstruction; dossier writes only',status='ASSEMBLY_CONSISTENT_ONLY',judge_verdict=None,dispatch_performed=False,checks_total=len(CHECKS),failures=[],checks=CHECKS,original_history_bytes=108942,original_history_files=14,original_source_rows=667,original_observations=len(observations),native_candidate=prepared['candidate_id'],v2_candidate=None,source_heads=dict(corpus=CPIN,runtime=RPIN),limits=['No product tests, prepare, policy, admit, publish, reader, consumer, producer, maintenance, or CI invoked.','No new judge opinions included.','No original source, package, contract, decision or evidence file modified.'])
put('assembly-verification.json', json_bytes(verification))

chunks=[]
chunk_number=0
MAX_CHUNK=30000
MAX_PAYLOAD=26000
for group, assets in GROUPS.items():
    current=bytearray(); segments=[]
    def flush():
        global chunk_number,current,segments
        if not current: return
        chunk_number+=1
        path=f'chunks/{chunk_number:03d}-{group}.txt'
        data=bytes(current)
        if len(data)>MAX_CHUNK: raise ValueError('oversized chunk')
        put(path,data)
        chunks.append(dict(order=chunk_number,file=path,group=group,utf8_bytes=len(data),sha256=sha(data),segments=segments))
        current=bytearray();segments=[]
    for asset in assets:
        data=(OUT/asset['file']).read_bytes()
        offset=0
        while offset<len(data):
            end=min(offset+MAX_PAYLOAD,len(data))
            if end<len(data):
                newline=data.rfind(b'\n',offset,end)
                if newline<offset: raise ValueError('overlong unsplittable UTF-8 line')
                end=newline+1
            payload=data[offset:end];payload.decode('utf-8')
            framing=(f'===== EXACT PAYLOAD {asset["id"]} =====\nfile: {asset["file"]}\nsource: {asset.get("origin","generated projection/context")}\ncommit: {asset.get("git_commit","not a commit-pinned raw source")}\nwhole_utf8_bytes: {len(data)}\nwhole_sha256: {asset["sha256"]}\nsource_byte_range: [{offset},{end})\nsegment_utf8_bytes: {len(payload)}\nsegment_sha256: {sha(payload)}\nPAYLOAD_START\n').encode()
            trailer=f'\nPAYLOAD_END {asset["id"]} [{offset},{end})\n\n'.encode()
            if current and len(current)+len(framing)+len(payload)+len(trailer)>MAX_CHUNK: flush()
            start=len(current)+len(framing)
            current.extend(framing);current.extend(payload);current.extend(trailer)
            segments.append(dict(asset=asset['id'],source_byte_start=offset,source_byte_end=end,chunk_byte_start=start,chunk_byte_end=start+len(payload),utf8_bytes=len(payload),sha256=sha(payload)))
            offset=end
    flush()

for asset in ASSETS:
    segs=[]
    for chunk in chunks:
        raw=(OUT/chunk['file']).read_bytes()
        for seg in chunk['segments']:
            if seg['asset']==asset['id']:
                segs.append((seg['source_byte_start'],raw[seg['chunk_byte_start']:seg['chunk_byte_end']]))
    if segs:
        check('chunk exact reconstruction:' + asset['id'],b''.join(x[1] for x in sorted(segs)),(OUT/asset['file']).read_bytes())

inventory=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name not in ['manifest.json','manifest.sha256']:
        raw=path.read_bytes(); inventory.append(dict(file=str(path.relative_to(OUT)),utf8_bytes=len(raw),sha256=sha(raw)))
manifest=dict(schema='s2-stable-evaluation-dossier-manifest/v1',status='PREPARED_FOR_PARENT_REVIEW_NOT_DISPATCHED',corpus_pin=CPIN,runtime_pin=RPIN,prepared_native_v1_candidate=prepared['candidate_id'],prepared_v2_candidate=None,assets=ASSETS,chunks=chunks,chunk_max_utf8_bytes=MAX_CHUNK,chunk_total_utf8_bytes=sum(x['utf8_bytes'] for x in chunks),all_files_except_manifest_and_seal=inventory,scope='File transport preparation only, no gate judgment or runtime operation. Segment byte offsets exclude framing; concatenate by asset/source offset.',pending=rules['pending'])
raw=json_bytes(manifest);put('manifest.json',raw);put('manifest.sha256',(sha(raw)+'  manifest.json\n').encode())
print(json.dumps(dict(manifest_sha256=sha(raw),assets=len(ASSETS),chunks=len(chunks),chunk_bytes=sum(x['utf8_bytes'] for x in chunks),max_chunk_bytes=max(x['utf8_bytes'] for x in chunks),historical_decision_bytes=108942,preflight_projection_bytes=len(rows_bytes)+len(json_bytes(header)),checks=len(CHECKS),status=manifest['status']),ensure_ascii=False))
