import { assertOperationalDiskStore, assertOperationalStateDirectory } from "./store-evaluation-identity.js"
import { join } from "node:path"
import { genericOwnershipVisible } from "./ownership-evaluation-policy.js"
import { readFileSync } from "node:fs"
import type { Hash } from "@atlas/contracts"
import type { CasObject } from "@atlas/kernel"
import type { CurrentNode, GroundedFact, StoreProjection } from "@atlas/knowledge"
import { blobPath } from "./layout.js"
import { readKnowledge } from "./knowledge-log.js"
import type { KnowledgeEntry } from "./knowledge-log.js"
import { actorInScope } from "./policy.js"
import type { AtlasPolicy } from "./policy.js"
import type { CommitRefusal } from "./sidecar.js"
import type { DiskStore } from "./store.js"
import { rehydrateProjection } from "./store.js"
export interface KnowledgeReplay {
  readonly applied: number
  readonly staged: number
  readonly missing: number
  /** Log lines that did not verify (torn, edited, or under another seat's folder). */
  readonly rejected: number
  /** A knowledge folder or file could not be read, so some rows may not have been replayed. */
  readonly unreadable?: true
  readonly refusal?: CommitRefusal
}
export function replayKnowledge(
  repoPath: string,
  disk: DiskStore,
  policy: AtlasPolicy,
  reproven: (node: CurrentNode, fact: GroundedFact) => boolean,
): KnowledgeReplay {
  assertOperationalStateDirectory(join(repoPath, ".atlas"))
  assertOperationalDiskStore(disk)
  const read = readKnowledge(repoPath)
  const projection = rehydrateProjection(disk)
  const pending = [...read.rows.values()].filter(
    (e) => !sameRow(projection.current.get(e.row.nodeKey), e.row),
  )
  const resolved = pending.filter((e) => restoreBlob(repoPath, disk, e) && genericOwnershipVisible(disk.get(e.row.contentHash as Hash)))
  const proven = resolved.filter((e) => {
    const fact = disk.get(e.row.contentHash as Hash) as GroundedFact
    return fact.seal === "proven" && actorInScope(policy, e.seat, e.row.scope) && reproven(e.row, fact)
  })
  const candidates = resolved.filter((e) => !proven.includes(e))
  const applied = proven.length === 0 ? undefined : disk.commitProjection((p) => ({ out: proven.length, next: withRows(p, proven) }))
  const staged =
    candidates.length === 0
      ? undefined
      : disk.commitStaging((p) => {
          const fresh = candidates.filter((e) => p.current.get(e.row.nodeKey)?.contentHash !== e.row.contentHash)
          return fresh.length === 0 ? { out: 0 } : { out: fresh.length, next: withRows(p, fresh) }
        })
  const refusal = [applied, staged].flatMap((r) => (r !== undefined && !r.settled ? [r.refusal] : []))[0]
  const counts = {
    applied: applied?.settled === true ? applied.out : 0,
    staged: staged?.settled === true ? staged.out : 0,
    missing: pending.length - resolved.length,
    rejected: read.rejected,
    ...(read.unreadable === true ? { unreadable: true as const } : {}),
  }
  const result = refusal === undefined ? counts : { ...counts, refusal }
  // Stderr only, so a command's stdout stays its answer; silent when nothing happened.
  if (counts.applied + counts.staged + counts.missing + counts.rejected > 0 || read.unreadable === true || refusal !== undefined)
    console.error(`atlas: knowledge replay ${JSON.stringify(result)}`)
  return result
}
function restoreBlob(repoPath: string, disk: DiskStore, entry: KnowledgeEntry): boolean {
  const hash = entry.row.contentHash as Hash
  if (disk.get(hash) !== undefined) return true
  try {
    return disk.put(JSON.parse(readFileSync(blobPath(repoPath, hash), "utf8")) as CasObject) === hash
  } catch {
    return false
  }
}
function sameRow(held: CurrentNode | undefined, logged: CurrentNode): boolean {
  if (held === undefined) return false
  const { derivedAt: _held, ...heldRest } = held
  const { derivedAt: _logged, ...loggedRest } = logged
  return JSON.stringify(heldRest) === JSON.stringify(loggedRest)
}
const withRows = (p: StoreProjection, entries: readonly KnowledgeEntry[]): StoreProjection => ({
  ...p,
  current: new Map([...p.current, ...entries.map((e) => [e.row.nodeKey, e.row] as const)]),
  cas: new Set([...p.cas, ...entries.map((e) => e.row.contentHash)]),
})
export function assertNoOperationalEvaluationReplay(repoPath: string): void {
  const read = readKnowledge(repoPath)
  if (read.unreadable || read.rejected !== 0 || [...read.rows.values()].some((entry) =>
    entry.row.claims.length === 0 || entry.row.claims.some((claim) => !claim.startsWith("Evaluation-only ownership manifest for "))))
    throw new Error("evaluation-operational-replay-refused")
}
