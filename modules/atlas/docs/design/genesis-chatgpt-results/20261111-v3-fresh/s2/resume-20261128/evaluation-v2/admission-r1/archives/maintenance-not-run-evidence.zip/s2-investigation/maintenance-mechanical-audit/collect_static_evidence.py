#!/usr/bin/env python3
"""External static evidence capture. Never imports/executes the inspected drafts or Atlas."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

BASE = Path('/workspace/scratch/5cfbb6c803f1')
OUT = Path(__file__).parent
AREA = BASE / 's2-investigation/maintenance-plan'
RUNTIME = BASE / 's2-runtime'
REV = 'db9b4235022c4df32fe3bfd4faeea8adcd69abb7'
DRAFTS = [
    'u1-evaluation-operation.mjs', 'build-native-request.mjs',
    'build-operation-config.py', 'recipe-registry.json',
    'DRIVER-DRAFT.md', 'draft-helper-inventory.json',
]
SUPPORT = ['S2-U1-PLAN.md', 'plan.json', 'static-reconciliation.json']
RUNTIME_PATHS = [
    'modules/atlas/packages/adapter-io/src/evaluation-rebuild.ts',
    'modules/atlas/packages/adapter-io/src/ownership-rebuild.ts',
    'modules/atlas/packages/adapter-io/src/genesis-evaluation.ts',
    'modules/atlas/packages/adapter-io/src/genesis-evaluation-binding.ts',
    'modules/atlas/packages/adapter-io/src/genesis-native-format.ts',
    'modules/atlas/packages/adapter-io/src/genesis-native-io.ts',
    'modules/atlas/packages/adapter-io/src/ownership-evaluation-policy.ts',
    'modules/atlas/packages/knowledge/src/ownership/update-plan.ts',
    'modules/atlas/scripts/genesis-evaluation.ts',
]
PREPARED = BASE / 's2-execution/evaluation-prepare-03/prepared.json'
PREPARED_SHA = 'bb3ee09693ef1ddfb89e548f3f5e0d38c4abaee5e6d253f129c7c6c1a9dbda0e'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stamp(path, data=None):
    data = path.read_bytes() if data is None else data
    return {'path': str(path), 'byte_length': len(data), 'sha256': sha(data),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def save(name, data):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(data)
    return stamp(target, data)


def dump(name, value):
    return save(name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


def evidence(path, first, last):
    data = path.read_bytes()
    return {**stamp(path, data), 'first_line': first, 'last_line': last,
            'literal_lines': data.decode().splitlines()[first-1:last]}


captured = {}
sources = []
for name in DRAFTS + SUPPORT:
    path = AREA / name
    data = path.read_bytes()
    captured[path] = data
    sources.append({**stamp(path, data), 'role': 'draft' if name in DRAFTS else 'support',
                    'snapshot': save('snapshots/maintenance-plan/' + name, data)})
for rel in RUNTIME_PATHS:
    path = RUNTIME / rel
    data = path.read_bytes()
    captured[path] = data
    git_bytes = subprocess.check_output(['git', '-C', str(RUNTIME), 'show', REV + ':' + rel])
    sources.append({**stamp(path, data), 'role': 'runtime-source', 'revision': REV,
                    'equals_git_object_bytes': data == git_bytes,
                    'snapshot': save('snapshots/runtime/' + rel, data)})
    assert data == git_bytes, rel
for name in ['record-operation.py', 'capture-state-operation.py']:
    path = BASE / 's2-investigation' / name
    data = path.read_bytes()
    captured[path] = data
    sources.append({**stamp(path, data), 'role': 'fixed-helper',
                    'snapshot': save('snapshots/fixed-helpers/' + name, data)})
prepared_bytes = PREPARED.read_bytes()
assert sha(prepared_bytes) == PREPARED_SHA
captured[PREPARED] = prepared_bytes
sources.append({**stamp(PREPARED, prepared_bytes), 'role': 'existing-prepared-03-read-only'})
prepared = json.loads(prepared_bytes)
registry = json.loads(captured[AREA / 'recipe-registry.json'])
by_key = {x['key']: x for x in prepared['candidate']['entries']}
observations = {x['key']: x['version'] for x in prepared['candidate']['observations']}
recipe_rows = []
for spec in registry['recipes']:
    prior = by_key[spec['key']]
    recipe_rows.append({
        'key': spec['key'],
        'declared_equals_receipt_input_keys_in_order': spec['declaredInputs'] == [x['key'] for x in prior['inputs']],
        'mandatory_equals_declared': spec['mandatoryInputs'] == spec['declaredInputs'],
        'required_equals_receipt_dependencies_in_order': spec['required'] == [x['key'] for x in prior['dependencies']],
        'recipe_version_equals_observed_version': spec['recipeVersion'] == observations.get(spec['recipeInputKey']),
        'recipe_input_in_mandatory': spec['recipeInputKey'] in spec['mandatoryInputs'],
        'declared_count': len(spec['declaredInputs']), 'required_count': len(spec['required']),
        'all_inputs_are_file_keys': all(x.startswith('file:') for x in spec['declaredInputs']),
        'reserved_path_segment_matches': [x for x in spec['declaredInputs']
            if re.search(r'(^|/)(oracles?|judgments?|judge-packets?|packets)(/|$)', x[5:], re.I)],
    })
inventory = json.loads(captured[AREA / 'draft-helper-inventory.json'])
inventory_rows = []
for row in inventory['files']:
    observed = stamp(Path(row['path']))
    inventory_rows.append({'path': row['path'], 'byte_length_matches': row['byte_length'] == observed['byte_length'],
                           'sha256_matches': row['sha256'] == observed['sha256']})

draft = lambda name, a, b: evidence(AREA / name, a, b)
runtime = lambda name, a, b: evidence(RUNTIME / 'modules/atlas/packages/adapter-io/src' / name, a, b)
findings = [
    {
        'id': 'MECH-01', 'kind': 'path-validator-incompatibility',
        'title': 'relative() is weaker than the nativePath used by the actual CLI',
        'condition': 'A future plan/approval/binding-reference/captured-relative path uses a .ATLAS or .GIT segment, a segment ending in dot/space, whitespace-only text, or non-NFC Unicode.',
        'observed_code_difference': 'Python rejects only exact .atlas/.git and does not check trailing dot/space, nonblank nativeText or NFC. nativePath rejects all of those shapes.',
        'effect': 'The builder can generate a command for a path which the original CLI/API subsequently refuses. This is a preflight mismatch, not evidence that any current operation failed.',
        'counterexamples_reasoned_from_source_not_executed': ['docs/.ATLAS/binding.json', 'docs/.GIT/binding.json', 'docs./binding.json', 'docs /binding.json', 'e\u0301/binding.json'],
        'proposal': 'Make the host relative-path validator equivalent to nativeText/nativePath, including case-insensitive reserved segments, NFC and trailing-character checks. Keep every runtime gate unchanged.',
        'evidence': [draft('build-operation-config.py', 64, 68), runtime('genesis-native-format.ts', 34, 56)],
    },
    {
        'id': 'MECH-02', 'kind': 'sealed-producer-recipe-binding-gap',
        'title': 'Consumed producer requests are not checked against the effective recipe declaration',
        'condition': 'A supplied, hash-pinned producer request has correct key/baseline/source_root/inputs/dependencies but a different or absent recipe field.',
        'observed_code_difference': 'The builder emits recipe: chosen.recipe. Its accepted-output path and the driver callback later compare inputs/dependencies, but neither compares producerRequest.recipe to the registry declaration actually used by the runtime.',
        'effect': 'Those checks cannot establish that the recipe declaration in the preserved producer context is the declaration used during materialization. Runtime recipeVersion checks validate the registry and source observation, not this omitted comparison. The normal unchanged output of this builder carries the expected field; no mismatching production has been observed.',
        'proposal': 'Require exact equality of the preserved request.recipe and the applicable registry spec before accepting each sealed output, and repeat at the callback boundary. Bind the registry SHA and source path explicitly if the sealed-request schema is extended; freeze any change before M0.',
        'evidence': [draft('build-native-request.mjs', 108, 154), draft('build-native-request.mjs', 179, 188),
                     draft('u1-evaluation-operation.mjs', 182, 191), draft('u1-evaluation-operation.mjs', 215, 229),
                     runtime('evaluation-rebuild.ts', 111, 126), draft('S2-U1-PLAN.md', 68, 72)],
    },
    {
        'id': 'MECH-03', 'kind': 'native-reference-compatibility-limit',
        'title': 'The config builder assumes payload_path for all decision references',
        'condition': 'A future otherwise valid binding uses the supported NativeReference shape {commit, path, sha256}.',
        'observed_code_difference': "Config generation unconditionally reads ref['payload_path'] in finalize-update and admit/admit-target. db9's NativeReference/nativeReferencePath and both native binding consumers support either payload_path or commit+path.",
        'effect': 'That legal db9 reference shape causes config construction to fail with a missing key. There is no existing U1 binding in this audit, and a declared payload-only workflow avoids this branch.',
        'proposal': 'Resolve both supported shapes with strict key/digest/path validation, or explicitly freeze and document a payload-only subset and reject the other form with a clear configuration error. Do not change the CLI contract.',
        'evidence': [draft('build-operation-config.py', 174, 179), draft('build-operation-config.py', 217, 226),
                     runtime('genesis-native-format.ts', 59, 75), runtime('genesis-evaluation-binding.ts', 24, 32),
                     draft('u1-evaluation-operation.mjs', 124, 129)],
    },
    {
        'id': 'MECH-04', 'kind': 'generated-output-receipt-coverage-gap',
        'title': 'API-helper artifacts are saved but not individually bound by the fixed recorder output_files list',
        'condition': 'A future guarded capture/prepare-update/finalize-update/build-native-context is run using a config produced by this builder without a separate immediate output inventory.',
        'observed_code_difference': 'output_files starts empty and is appended only for the CLI prepare prepared.json. The driver saves capture.json/captured source files/request-used.json/journal and prepare/finalize files; the recorder hashes only explicitly listed output_files plus stdout/stderr and state/CAS. The wrapper captures only non-CAS .atlas state. Native-context stdout already hashes producer-request.json/task.txt; prepare/finalize stdout contains their full result objects, so not all outputs lack a stream binding.',
        'effect': 'In particular, the capture inventory and its exact saved bytes are not identified by a hash in the original capture operation receipt/stream. A later pinned read establishes later-used bytes but does not by itself prove those are the bytes saved at capture time. This is a provenance completeness gap, not an observed loss or mutation.',
        'proposal': 'Have each helper return an explicit generated-output manifest with byte lengths/SHA256 in its preserved stdout, or enumerate deterministically known generated files in output_files and capture that manifest immediately. Keep the fixed recorder/wrapper bytes unchanged. Record later packaging separately.',
        'evidence': [draft('build-operation-config.py', 196, 208), draft('build-operation-config.py', 233, 259),
                     draft('u1-evaluation-operation.mjs', 63, 67), draft('u1-evaluation-operation.mjs', 138, 160),
                     draft('u1-evaluation-operation.mjs', 251, 256),
                     evidence(BASE / 's2-investigation/record-operation.py', 143, 156),
                     evidence(BASE / 's2-investigation/capture-state-operation.py', 18, 27)],
    },
]

checks = [
    {
        'id': 'CHECK-ORIGINAL-PLAN', 'observation': 'Compatible with inspected db9 source; no implementation lookup bug found in current drafts.',
        'detail': 'prepareEvaluation places path->SHA pins in plan.implementation and observes each file. candidate.implementation is the native role map. Rebuild target plans copy consumers/limits/maintenance/isolation, omit implementation, and retain original_plan as the prior evaluation-plan CAS ID. Both helpers walk that chain with integrity checks and a finite/cycle guard until genesis-evaluation-plan/v1, then check implementation pins. M0/M1/M2 needs at most the proposed two rebuild links. A lineage of 16+ links is outside the explicit helper cap.',
        'evidence': [runtime('genesis-evaluation.ts', 69, 72), runtime('genesis-evaluation.ts', 94, 96),
                     runtime('evaluation-rebuild.ts', 198, 213), draft('u1-evaluation-operation.mjs', 80, 102),
                     draft('build-native-request.mjs', 50, 61)],
    },
    {
        'id': 'CHECK-API-SIGNATURES', 'observation': 'The current prepare/finalize/planner arguments and prepared-vs-update split match inspected APIs.',
        'detail': 'Driver calls prepareEvaluationUpdate with store,baseline,manifest,context,targetGeneration,targetRepoRoot,recipes,observe,readCapturedBytes,listMembers,semanticEvidence. finalizeEvaluationUpdate accepts store,target,binding,current,readReference. prepare-result.json retains the full update; target-prepared.json retains the v2 prepared object used by CLI init-store/admit-target. No nonexistent rebuild/finalize CLI mode is generated.',
        'evidence': [runtime('evaluation-rebuild.ts', 15, 44), runtime('evaluation-rebuild.ts', 232, 238),
                     draft('u1-evaluation-operation.mjs', 124, 134), draft('u1-evaluation-operation.mjs', 234, 255),
                     draft('build-operation-config.py', 199, 243)],
    },
    {
        'id': 'CHECK-RESULT-AND-REUSE', 'observation': 'No supported-result promotion of a blocked output is inferred from the driver result-hash preview.',
        'detail': 'Driver computes a supported result ID preview but returns output.validity unchanged. db9 refuses blocked validity before constructing/storing the supported result. Its reuse path does not run recipes when exact inputs/dependencies are unchanged. callback journal entries must remain distinct from runtime calls and native agent calls, as the draft states.',
        'evidence': [draft('u1-evaluation-operation.mjs', 194, 205), draft('u1-evaluation-operation.mjs', 215, 229),
                     runtime('evaluation-rebuild.ts', 164, 197)],
    },
    {
        'id': 'CHECK-REGISTRY', 'observation': 'All 13 recipe records match the existing prepared-03 declaration fields in the recorded comparisons.',
        'detail': 'Comparison is JSON/data-only against the existing prepared bytes, not execution of recipes, CAS id code or Atlas. All declared keys are file keys, each required list matches receipt order, recipeInputKey is mandatory and recipeVersion matches the stored observation. No reserved path segment matches the builder regex. No claim of semantic sufficiency follows.',
        'rows': recipe_rows,
    },
    {
        'id': 'CHECK-INVENTORY', 'observation': 'All five listed draft file sizes and SHA256 values match the current bytes.',
        'rows': inventory_rows,
        'limit': 'The historical syntax command metadata is preserved as operator-provided evidence; those commands were not rerun or independently reconstructed by this audit.',
    },
]

notes = [
    {'id': 'NOTE-STATIC-PLAN-TIME', 'observation': 'The earlier S2-U1-PLAN.md 117–129 and plan.json api_surface.driver_required_not_written/material_blockers still say no driver exists. DRIVER-DRAFT.md and the inventory describe the later unexecuted drafts. Preserve chronology with an additive dated status note; do not rewrite historical evidence as if the code had existed earlier.'},
    {'id': 'NOTE-UNFROZEN-SCOPE', 'observation': 'Maintenance witness IDs/budgets, concrete M0 plan and implementation paths, M0/M1/M2 candidate/manifest/generations, policies, native production bridge/dispatch provenance and new decisions remain future inputs. This audit fills none of them and does not make the initial d1 plan eligible for evaluation-maintenance.'},
    {'id': 'NOTE-CAS-HANDOFF', 'observation': 'Driver prepares/finalizes in the authority-root store. CLI init/admit-target consumes CAS in the target root. The plan already requires verified regular-file CAS copying. Its timing must include all newly created target objects and baseline lineage before target init/admission; copying only the pre-update CAS is insufficient. No CAS copy tool or root is created here.'},
]

unchanged = [{'path': str(path), 'bytes_unchanged': path.read_bytes() == data} for path, data in captured.items()]
assert all(x['bytes_unchanged'] for x in unchanged)
report = {
    'schema': 'genesis-s2-u1-static-mechanical-audit/v1',
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'role': 'external mechanical source inspection; not a judge, semantic review, vote, qualification or execution',
    'runtime_revision': REV,
    'scope': DRAFTS,
    'method': ['Read source text', 'Compare nine runtime files to exact db9 Git object bytes',
               'Compare registry declarations to existing prepared-03 JSON',
               'Verify recorded helper sizes/SHA256', 'Preserve literal source snapshots and cited excerpts'],
    'executed': {'atlas': False, 'draft_main_or_helpers': False, 'product_tests': False, 'judge_dispatch': False,
                 'u1_roots_created': False, 'policies_created': False, 'candidates_created': False, 'source_modifications': False},
    'new_scripts_executed': ['This independent Python standard-library evidence collector only; git show is read-only.'],
    'findings': findings, 'checked_compatibilities': checks, 'scope_notes': notes,
    'sources': sources, 'source_bytes_unchanged_at_end': unchanged,
    'limits': ['Static reasoning only; future malformed examples were not executed.',
               'This is not exhaustive proof of correctness, independent consumer evidence or admission permission.',
               'No opinions or votes of either judge were used or forwarded.'],
}
report_ref = dump('report.json', report)
print(json.dumps({'report': report_ref, 'findings': len(findings), 'source_files': len(sources),
                  'all_source_bytes_unchanged': True, 'atlas_or_drafts_executed': False}))
