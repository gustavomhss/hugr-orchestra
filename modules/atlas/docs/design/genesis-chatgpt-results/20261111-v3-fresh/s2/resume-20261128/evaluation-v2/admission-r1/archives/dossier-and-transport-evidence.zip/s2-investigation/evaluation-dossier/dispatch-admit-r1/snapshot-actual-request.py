"""Concatenate only successfully dispatched literal request files in known order."""
from pathlib import Path
import json,hashlib,sys
D=Path(__file__).resolve().parent;last=int(sys.argv[1]);judge=sys.argv[2]
assert judge in ['s2_j1','s2_j2']
L=[json.loads(s) for s in (D/'transport-ledger.jsonl').read_text().splitlines()]
paths=[]
extra=json.loads((D/'actual-request-additions.json').read_bytes()) if (D/'actual-request-additions.json').exists() else []
for n in range(1,last+1):
 for addition in extra:
  if addition['target']=='/root/'+judge and addition.get('before_wave')==n:
   for capture in addition['ordered_source_captures']:
    c=Path(capture);o=json.loads(c.read_bytes());ep=Path(o['request_path']);eb=ep.read_bytes()
    assert len(eb)==o['request_utf8_bytes'] and hashlib.sha256(eb).hexdigest()==o['request_sha256']
    assert any(x.get('event')==o['kind'] and x.get('target')==o['target'] and x.get('wave')==n for x in L)
    paths.append((f'wave-{n:02d}-{o["kind"]}',ep))
 rows=[x for x in L if x.get('target')=='/root/'+judge and x.get('wave')==n and (x.get('event') in ['ACTUAL_FOLLOWUP_TASK_SENT','ACTUAL_SEND_MESSAGE_QUEUED'] or (x.get('tool')=='collaboration.followup_task' and x.get('observed_tool_result')=='empty visible return; no error'))]
 assert rows,(judge,n,'not recorded delivered')
 row=rows[0];p=Path(row.get('request_path') or D/row['request_file']);b=p.read_bytes()
 assert len(b)==row['request_utf8_bytes'] and hashlib.sha256(b).hexdigest()==row['request_sha256']
 paths.append((f'wave-{n:02d}',p))
 if row.get('event')=='ACTUAL_SEND_MESSAGE_QUEUED':
  triggers=[x for x in L if x.get('target')=='/root/'+judge and (x.get('wave')==n or n in x.get('waves',[])) and x.get('event') in ['ACTUAL_FOLLOWUP_ACTIVATION_SENT','ACTUAL_FOLLOWUP_ACTIVATION']]
  assert len(triggers)==1,(judge,n,'requires one successful activation')
  trigger=triggers[0];tp=Path(trigger['request_path']);tb=tp.read_bytes()
  assert len(tb)==trigger['request_utf8_bytes'] and hashlib.sha256(tb).hexdigest()==trigger['request_sha256']
  if n==max(trigger.get('waves',[n])):paths.append((f'wave-{n:02d}-activation',tp))
  else:assert max(trigger['waves'])<=last, 'Do not snapshot only half an activated batch'
 for addition in extra:
  if addition['target']=='/root/'+judge and addition.get('after_wave')==n:
   for capture in addition['ordered_source_captures']:
    c=Path(capture);o=json.loads(c.read_bytes());ep=Path(o['request_path']);eb=ep.read_bytes()
    assert len(eb)==o['request_utf8_bytes'] and hashlib.sha256(eb).hexdigest()==o['request_sha256']
    assert any(x.get('event')==o['kind'] and x.get('target')==o['target'] and x.get('wave')==n for x in L)
    paths.append((f'wave-{n:02d}-{o["kind"]}',ep))
 if n==2:paths.append(('root-materials-scope-query',D/'materials-scope/root-query.txt'))
spans=[];parts=[];at=0
for label,p in paths:
 b=p.read_bytes();spans.append({'label':label,'path':str(p),'byte_start':at,'byte_end':at+len(b),'utf8_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});parts.append(b);at+=len(b)
b=b''.join(parts);O=D/'actual-requests';O.mkdir(exist_ok=True);p=O/f'{judge}-through-wave-{last:02d}.txt'
if p.exists():assert p.read_bytes()==b
else:p.write_bytes(b)
m={'schema':'s2-actual-request-concatenation/v1','target':'/root/'+judge,'scope':'Only successfully sent request files plus root materials-scope query, in observed sequence, including explicitly recorded withdrawn transcription and correction requests; no failed tool call, unsent original selection, ACK or other judge opinion included.','literal_concatenation':'No delimiter or newline added between message files; message boundaries separately mapped.','path':str(p),'utf8_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'message_spans':spans,'host_message_id':None,'host_timestamp':None,'limit':'Hashes attest external request texts and their concatenation. Host does not expose serialized delivered request bytes; source send records state literal copying or explicit reconstruction and successful return. See correction captures for withdrawn-transcription limitations.','closing_included':False}
(O/f'{judge}-through-wave-{last:02d}.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:m[k] for k in ['target','path','utf8_bytes','sha256','closing_included']}))
