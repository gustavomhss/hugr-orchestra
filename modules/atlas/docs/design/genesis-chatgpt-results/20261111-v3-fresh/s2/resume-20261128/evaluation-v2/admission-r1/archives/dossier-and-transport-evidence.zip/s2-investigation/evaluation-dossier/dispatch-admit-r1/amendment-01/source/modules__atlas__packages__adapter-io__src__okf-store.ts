import { existsSync, lstatSync, mkdirSync, readdirSync, realpathSync } from "node:fs"
import { dirname, join, resolve } from "node:path"
import type { Hash } from "@atlas/contracts"
import type { Cas, CasObject } from "@atlas/kernel"
import { createDiskStore } from "./store.js"
export function isEvaluationPayload(value: unknown): boolean {
  const pending: unknown[] = [value]
  const seen = new Set<object>()
  while (pending.length > 0) {
    const next = pending.pop()
    if (typeof next === "string") {
      if (next.startsWith("Evaluation-only ownership manifest for ")) return true
      continue
    }
    if (next === null || typeof next !== "object" || seen.has(next)) continue
    seen.add(next)
    if (Array.isArray(next)) { pending.push(...next); continue }
    const record = next as Record<string, unknown>
    if ("evaluation" in record || "evaluationCandidate" in record || record.phase === "evaluation" ||
      (typeof record.kind === "string" && record.kind.startsWith("genesis-evaluation-")) ||
      (typeof record.schema === "string" && (record.schema.startsWith("genesis-evaluation-") || record.schema.startsWith("ownership-evaluation-"))) ||
      (record.version === 2 && typeof record.kind === "string" && record.kind.startsWith("ownership-"))) return true
    pending.push(...Object.values(record))
  }
  return false
}
export function assertOperationalCas(casPath: string): void {
  const paths = [resolve(casPath)]
  if (existsSync(casPath)) paths.push(realpathSync(casPath))
  for (const path of paths) for (const name of ["evaluation-store.json", "evaluation-policy.json"]) {
    try { lstatSync(join(dirname(path), name)) } catch (error) {
      if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") continue
      throw error
    }
    throw new Error("evaluation-operational-cas-refused")
  }
}
export const CAS_REL = join(".atlas", "cas")
export function readCas(casPath: string): Cas {
  assertOperationalCas(casPath)
  const store = createDiskStore(casPath)
  const cas: Cas = new Map<Hash, CasObject>()
  let shards: string[]
  try {
    shards = readdirSync(casPath, { withFileTypes: true })
      .filter((e) => e.isDirectory())
      .map((e) => e.name)
  } catch {
    return cas
  }
  for (const shard of shards) {
    let files: string[]
    try {
      files = readdirSync(join(casPath, shard), { withFileTypes: true })
        .filter((e) => e.isFile())
        .map((e) => e.name)
    } catch {
      continue
    }
    for (const name of files) {
      const obj = store.get(name as Hash)
      if (isEvaluationPayload(obj)) throw new Error("evaluation-operational-export-refused")
      if (obj !== undefined) cas.set(name as Hash, obj)
    }
  }
  assertOperationalCas(casPath)
  return cas
}
export function writeCasObjects(cas: Cas, casPath: string): number {
  assertOperationalCas(casPath)
  // Complete preflight before creating directories or writing even the first object.
  for (const obj of cas.values()) if (isEvaluationPayload(obj)) throw new Error("evaluation-operational-import-refused")
  const store = createDiskStore(casPath)
  mkdirSync(casPath, { recursive: true })
  let n = 0
  for (const obj of cas.values()) {
    store.put(obj)
    n += 1
  }
  return n
}
export function okfBundlePath(outDir: string): string {
  return join(outDir, "atlas-okf.json")
}
export function targetHasStore(targetDir: string): boolean {
  return existsSync(join(targetDir, ".atlas"))
}
export function sameCas(a: Cas, b: Cas): boolean {
  if (a.size !== b.size) return false
  for (const [k, v] of a) {
    const w = b.get(k)
    if (w === undefined || JSON.stringify(v) !== JSON.stringify(w)) return false
  }
  return true
}
