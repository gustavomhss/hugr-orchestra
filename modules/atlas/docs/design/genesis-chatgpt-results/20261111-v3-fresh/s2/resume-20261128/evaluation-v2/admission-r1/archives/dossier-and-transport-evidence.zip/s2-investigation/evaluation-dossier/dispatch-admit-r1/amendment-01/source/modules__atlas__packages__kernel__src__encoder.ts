import { blake3 } from "@noble/hashes/blake3"
import { bytesToHex } from "@noble/hashes/utils"
import type { Encoder, Hash } from "@atlas/contracts"
import { asHash } from "./brand.js"
export type { Encoder }
export interface EncoderApi {
  /** The kernel's default encoder (BLAKE3). (atlas-kernel:16, KERNEL-2 lines 46-50) */
  readonly encoder: Encoder
}
export const defaultEncoder: Encoder = {
  hash(bytes: Uint8Array): Hash {
    return asHash(bytesToHex(blake3(bytes)))
  },
}
