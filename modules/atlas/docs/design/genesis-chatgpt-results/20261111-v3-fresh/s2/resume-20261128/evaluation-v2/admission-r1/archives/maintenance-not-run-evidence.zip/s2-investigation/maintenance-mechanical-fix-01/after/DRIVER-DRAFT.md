# Driver S2-U1 v2 — rascunho sem execução

`u1-evaluation-operation.mjs` prepara o uso das APIs existentes de avaliação v2, no runtime exato `db9b4235022c4df32fe3bfd4faeea8adcd69abb7`. Nenhum modo foi chamado. A única verificação executada foi `node --check`, sem carregar imports ou executar Atlas. Este rascunho não altera o candidato d1, o plano inicial, as perguntas, o oracle ou a raiz de consumo.

O driver depende de um futuro baseline M0 de manutenção, com seus próprios prepare, política e dois ADMIT. Seus bytes e o registro de receitas precisam ser adicionados aos pins de implementação desse plano **antes** do prepare. Ele exige que a cópia observada na fonte seja idêntica ao arquivo efetivamente executado. Também exige a capacidade real `evaluation-maintenance` emitida por `loadEvaluationAccess` para o baseline; não aceita apenas um objeto de contexto fornecido pelo chamador.

## Modos implementados no rascunho

- `capture`: captura bytes pelo observador tri-state real e por leitura limitada; reconcilia cada versão com o ID Atlas dos bytes, verifica estabilidade e chama `planOwnershipUpdate`. Preserva o universo completo em arquivos próprios e um inventário. O conjunto afetado vem do runtime, não de uma lista passada como resultado esperado.
- `prepare`: recebe essa captura, receitas declaradas e saídas nativas reais previamente seladas. Os callbacks sincronizados verificam inputs e dependências exatos e materializam somente a saída correspondente. `prepareEvaluationUpdate` continua responsável por planejamento, seleção de callbacks, identidade do target e recusa. O driver registra entrada, retorno e erro de cada callback em journal com fsync; o array `calls` do runtime é mantido separado.
- `finalize`: depois de duas decisões ADMIT novas e exatas, chama `finalizeEvaluationUpdate` e conserva o grafo privado. Não instala política, ativa projeção ou publica. Inicialização e `admit-target` permanecem operações separadas da CLI original.

O driver não cria agentes, não chama modelos, não fabrica reviews e não produz respostas. Os campos de identidade de agentes são registros externos do operador, sem autenticação implícita. Cada saída precisa conservar o despacho real, o pedido integral, a resposta original e os bytes produzidos. A conformidade sintática de um JSON não prova que uma produção nativa ocorreu.

## Trabalho ainda necessário antes de executar

1. Concluir a primeira travessia e os 14 casos do plano inicial.
2. Fixar o plano M0, registros e orçamentos finitos das sondas U1, gerações, políticas e protocolos de interrupção/retomada; preservar a obrigação original.
3. Revisar este driver e seu uso sob o guard de runtime. Fixar os seus bytes no plano de manutenção. Preparar comandos originais/recibos sem modificar a CLI S4.
4. Qualificar a ponte de produção nativa que exponha somente inputs declarados e dependências aceitas ao produtor. O rascunho `build-native-request.mjs` foi escrito e recebeu somente `node --check`; nenhum contexto foi materializado por ele. O snapshot global contém evidências de controle que não devem ser fornecidas como respostas/oracles ao produtor. O registro de receitas derivado das 13 entradas contém zero caminhos de oracle ou pacote de juiz.
5. Registrar cada produtor real e selar seu pedido/saída sem reescrever o corpo. Obter semântica nova, ligada ao resultado e aos hashes desses pedidos/respostas, antes de consumir resultados alterados como dependências aceitas.
6. Exercitar alteração, invalidação, rebuild, interrupção/retomada, restauração/rebind e reúso reais. Reutilizar controles comuns compatíveis conforme o briefing, identificando seu escopo e sem alegar execução S2 nova.

O rascunho suporta apenas os inputs `file:` efetivamente existentes neste baseline. Uma solicitação de membership não prevista recusa; não inventa uma lista vazia. Preserva snapshots e streams em diretórios novos. Não implementa retry automático nem rollback, e não chama o executor v1.

`recipe-registry.json` deriva somente as declarações dos recibos atuais: key, recipeInputKey, recipeVersion, declaredInputs, mandatoryInputs e required. O prompt de receita original não identifica por si só o novo driver; o pin separado é obrigatório. O registry ainda é DRAFT_NOT_RUN e não confere autoridade.

## Ponte de produção nativa em rascunho

`build-native-request.mjs` usa a captura real futura e `effectiveInputs` do runtime para preparar uma unidade na ordem do planner. Para uma dependência alterada, exige a saída nativa preservada e dois registros semânticos específicos do resultado. O pacote do produtor contém somente os inputs declarados daquela unidade, seu corpo anterior e os corpos das dependências selecionadas. Os textos dos pareceres não são copiados. O helper recusa caminhos reservados; não despacha agentes nem chama receitas, não escreve CAS e não produz prosa. Um recibo efetivo de admissão e sua emissão são necessários para descrever o baseline como admitido. Identidades de agentes continuam registros externos do operador, sem autenticação implícita.

Os dois executáveis localizam os pins na propriedade `implementation` do plano original guardado no CAS. Em alvos de rebuild, percorrem `original_plan` com checagem de integridade e ciclos. Isso corresponde ao código S4: os pins do plano geram observações, enquanto `candidate.implementation` guarda papéis de implementação nativa e não é o mapa de caminhos do plano. Essa correção está somente no rascunho futuro, sem alterar o runtime ou o candidato inicial.

## Configuração futura e inventários

`build-operation-config.py` também é rascunho sem execução; recebeu apenas compilação sintática Python em memória. Ele prepara comandos para as três raízes U1 declaradas, a CLI S4 original e os dois helpers acima. Exige inventários completos dos arquivos regulares fora de `.atlas`, hashes explícitos dos controles, os mesmos 1.170 arquivos do lock externo de runtime, e os bytes dos recibos nativos/capturas/reviews efetivamente usados. Política e marcador precisam estar instalados e coincidir antes das operações que exigem autoridade; o helper não os instala. O resultado é uma configuração marcada `NOT_RUN_CONFIGURATION_ONLY`, que só terá efeito mediante execução posterior pelo recorder/wrapper já fixados.

Nenhuma raiz U1, contexto de produtor, operação de manutenção ou resposta nativa foi criada durante esta preparação. Antes de congelar M0, esses rascunhos ainda precisam da conferência mecânica, do plano concreto e das decisões independentes aplicáveis.

## Emenda mecânica 01 — 2026-11-28, NOT_RUN

Esta seção é aditiva. O texto anterior registra o estado inicial dos rascunhos; `S2-U1-PLAN.md` e `plan.json` preservam a etapa ainda anterior em que o driver não existia. Agora há código em rascunho, sem execução ou qualificação. Nenhum desses registros históricos foi reescrito para antecipar a existência do código.

Antes da edição foram preservados os cinco arquivos materiais e o inventário integral em `history/20261128-mechanical-fix-01-before/`. O `snapshot-manifest.json` dessa versão tem SHA-256 `fa9e4bfcba0fa8a5911d909615d79ec06e0a47d7c528e2ac87a85d386fd8beee`. Todos os seis arquivos coincidiam com a conferência estática original em `../maintenance-mechanical-audit/report.json`, SHA-256 `497a1343eb591b4b6286adf88da0d86b56ecbd0c0c8a53f436ee957f8ea40d27`. Essa conferência continua intacta e descreve os bytes anteriores à correção.

As alterações tratam seus quatro itens mecânicos:

- **MECH-01:** `native_relative` no configurador aplica as regras de texto/caminho de db9: texto não branco segundo o conjunto de whitespace de `String.trim`, NFC, segmentos não vazios, recusa de `.`/`..`, `.atlas`/`.git` sem distinção de maiúsculas, segmentos terminados em ponto/espaço e os mesmos caracteres proibidos. Cada uso anterior de `relative` foi migrado. A CLI original continua validando os caminhos novamente.
- **MECH-02:** o builder exige que `producerRequest.recipe` seja exatamente a entrada aplicável do registro antes de aceitar uma saída anterior. O callback do driver repete essa comparação contra seu `spec` antes de materializar a saída. Inputs e dependências continuam verificados separadamente. O registro de receitas não foi alterado.
- **MECH-03:** este fluxo U1 escolhe explicitamente apenas `NativeReference` local com as chaves exatas `{payload_path, sha256}` para `request_ref`/`response_ref` das decisões de finalize/admit/admit-target. O configurador valida as chaves, o digest e o caminho e emite erro claro para `commit`/`path`, em vez de depender de uma chave inexistente. A compatibilidade mais ampla do runtime não foi modificada. Essa restrição não altera as referências históricas preservadas no pacote, nas obrigações ou no CAS.
- **MECH-04:** ambos os helpers acrescentam `generated_outputs` ao stdout final, com schema `genesis-s2-u1-generated-output-inventory/v1`. O inventário enumera recursivamente os arquivos regulares efetivamente presentes no diretório exclusivo do helper, com caminho absoluto/relativo, tamanho e SHA-256, usando leitura nativa limitada. No driver, ele é capturado depois do último evento do journal; inclui `request-used.json`, o journal, capturas e resultados salvos que existirem. No builder, inclui o pacote completo, pedido e task. O recibo fixado já conserva e identifica os bytes integrais desse stdout, portanto não precisa de alteração no recorder ou wrapper.

O inventário de outputs também acompanha o stdout de falhas, registra erros de leitura e não declara completo um inventário que falhou. Não enumera stdout/stderr externos, CAS/estado Atlas, diretórios vazios nem um corpo/resposta de produtor que ainda não foi criado. O diretório `output/` reservado pelo builder permanece vazio nessa etapa. Uma falha anterior à criação do diretório é representada por `root: null` e lista vazia. A captura é um registro de arquivos ao término do helper; não promete isolamento do sistema operacional, ausência de corrida ou durabilidade contra perda de energia.

Os novos hashes devem ser usados nos pins do futuro M0. Nenhum pin do plano inicial, candidato, runtime, recorder ou wrapper foi substituído. A inspeção de `original_plan` e `implementation` permanece igual e vinculada às interfaces db9. O novo inventário registra somente checks estáticos/sintáticos, sem chamar `main`, helpers ou Atlas. A execução e as decisões aplicáveis continuam pendentes.
