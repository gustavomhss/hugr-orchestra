"""Read-only file/ACK reconciliation. No ADMIT or semantic judgment."""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;R=D/'root-captures'
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def identity(p):
 b=p.read_bytes();return {'path':str(p),'utf8_bytes':len(b),'sha256':sha(b)}
def check(name,value):
 assert value,name
 checks.append({'condition':name,'observed_equal_or_present':bool(value)})
def ack(name):
 p=R/name;o=json.loads(p.read_bytes());check(name+' is partial receipt, not final decision',o['kind']=='ACK_PARTIAL' and o['final_binding']=='NOT_ISSUED');return o

correct16=R/'dispatcher-j2-wave-16-attempt-02-corrected.txt'
check('J2 corrected16 exact fixed message',correct16.read_bytes()==(D/'amendment-01/messages/016.txt').read_bytes())
a16=ack('dispatcher-j2-waves-15-16-ack.txt')
check('J2 ACK16 distinguishes corrected and withdrawn A044',bool(a16['withdrawn_material']) and 'corrigida' in a16['received_by_wave']['16'][0]['representation_status'])

bad33=R/'dispatcher-j2-wave-33-attempt-01-withdrawn.txt'
wrong=b'/workspace/scratch/5cfbb6c803f1/s2-investigation/evaluation-dossier/dispatch-admit1/build-setup-delta.py'
right=b'/workspace/scratch/5cfbb6c803f1/s2-investigation/evaluation-dossier/dispatch-admit-r1/build-setup-delta.py'
check('J2 source.path33 single occurrence',bad33.read_bytes().count(wrong)==1)
check('J2 metadata33 exact one-field correction yields fixed message',bad33.read_bytes().replace(wrong,right,1)==(D/'delta-setup-01/messages/033.txt').read_bytes())
a33=ack('j2-waves-33-34-ack.txt')
check('J2 ACK33 names exact withdrawn and operative path',a33['errata_recognized']['withdrawn']==wrong.decode() and a33['errata_recognized']['operative']==right.decode())

attempt36=D/'delta-release-01/036.txt';retry36=R/'dispatcher-j1-wave-36-retransmission-02.txt'
check('J1 retry36 exact original message bytes',attempt36.read_bytes()==retry36.read_bytes())
a36before=ack('j1-waves-35-36-ack.txt');a36after=ack('j1-waves-36-37-38-recovery-ack.txt')
check('J1 original36 explicitly unavailable',a36before['received_by_wave']['36']['state']=='LITERAL_MESSAGE_NOT_AVAILABLE')
check('J1 recovery36 explicitly received full D003',a36after['transport_recovery']['state']=='LITERAL_CONTENT_NOW_RECEIVED' and a36after['received_by_wave']['36']['ranges']['D003']==[0,34693])

fixed39=(D/'delta-reader-capture-01/039.txt').read_bytes();actual39=R/'j2-wave-39-attempt-01.txt'
line=b"     assert original_stream['path'] == admission_stdout.name\n"
check('J2 error39 exactly one omitted context line',fixed39.count(line)==1 and fixed39.replace(line,b'',1)==actual39.read_bytes())
diff=D/'delta-reader-capture-01/bridge-state-capture.diff';errata=R/'j2-wave-39-e003-errata.txt'
check('J2 errata39 carries full fixed E003 exactly once',errata.read_bytes().count(diff.read_bytes())==1)
a39=ack('j2-wave-39-e003-errata-ack.txt')
check('J2 ACK39 declares corrected full E003 operative',a39['correction']['operative_representation']=='CORRECTED_FULL_RETRANSMISSION_RECEIVED' and a39['correction']['byte_range']==[0,6521] and a39['correction']['declared_sha256']==sha(diff.read_bytes()))

report={'schema':'s2-transport-recoveries-reconciliation/v1','scope':'Deterministic checks of external request files and explicit fields in preserved ACKs; not a vote, product test or proof of host serialization.','checks':checks,'artifacts':[identity(p) for p in [correct16,bad33,attempt36,retry36,actual39,diff,errata]],'historical_negative_or_withdrawn_messages_preserved':True,'between_judge_opinions_transported':False,'judge_verdict':None,'limits':['Hashes identify external request artifacts, not cryptographically authenticated host message bytes.','The first36 literal remains unavailable in that activation and is never retrospectively attributed as read.','Corrections preserve the actual incorrect message and subsequent explicit withdrawal/replacement rather than substituting the planned hash.']}
p=D/'transport-recoveries-reconciliation.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'report':identity(p),'judge_verdict':None},ensure_ascii=False,indent=2))
