"""DRAFT_NOT_RUN: byte/provenance checks shared by the future U1 operator helpers.

No Atlas import or CAS-ID implementation. Runtime-produced IDs are checked against
the exact preserved original operation output and runtime-created marker.
"""
import hashlib
import json
import os
from pathlib import Path
import re

BASE = Path('/workspace/scratch/5cfbb6c803f1')
INVESTIGATION = BASE / 's2-investigation'
HERE = Path(__file__).resolve().parent
PREFIX = 'modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2/resume-20261128/maintenance-v2'
ROOTS = {'M0': BASE / 's2-u1-baseline', 'M1': BASE / 's2-u1-changed', 'M2': BASE / 's2-u1-restored'}
ACTOR = 'genesis-s2-resume-846d4f9c'
SCOPE = 'orchestra.interfaces'
RUNTIME_REVISION = 'db9b4235022c4df32fe3bfd4faeea8adcd69abb7'
SHA = re.compile(r'^[0-9a-f]{64}$')
GOVERNANCE_SHA = 'edc84d9c4809be52f1ccea1b72851aa54c11fa81777a890c988a05b00e97cf22'
PINS = {
    INVESTIGATION / 'capture-state-operation.py': 'b7022b3205d04f02b6fceaee94d2f7912f15271be6ee4b2e4d7c62ba0013a441',
    INVESTIGATION / 'record-operation.py': '0185ccf143d7a5d1112b573fd0405da899b27d112cb4c7b431e1cbb1da629b30',
    INVESTIGATION / 'maintenance-plan/build-operation-config.py': '62d4ae06a2ae89812fd29b408f8c1631730dc9028c249c1c61642986adcee217',
    INVESTIGATION / 'evaluation-authority/runtime-byte-lock.json': 'fe5e317cf140c805554910d20d7a7c8964f76df12217aeb6a5280483c6c12df8',
    HERE / 'reference/e002-run-reader-operation.py': '955031da137d2052e333d495096a660369246b9ed92707f1e72745d729a252e5',
}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def regular(value):
    path = Path(value)
    require(path.is_absolute() and path.resolve(strict=True) == path and path.is_file()
            and not path.is_symlink() and path.stat().st_nlink == 1, 'regular unaliased file required: ' + str(path))
    return path


def stamp(path):
    path = regular(path)
    data = path.read_bytes()
    return {'path': str(path), 'byte_length': len(data), 'sha256': sha(data)}


def read_ref(ref):
    require(isinstance(ref, dict) and isinstance(ref.get('sha256'), str) and SHA.fullmatch(ref['sha256']), 'pinned reference required')
    path = regular(ref['path'])
    data = path.read_bytes()
    require(sha(data) == ref['sha256'], 'pinned bytes changed: ' + str(path))
    if 'byte_length' in ref:
        require(len(data) == ref['byte_length'], 'pinned byte length changed: ' + str(path))
    return path, data


def json_ref(ref):
    path, data = read_ref(ref)
    return path, data, json.loads(data)


def write_new(path, data):
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def new_external_directory(value, namespace):
    path = Path(value)
    base = BASE / 's2-execution/u1' / namespace
    require(path.is_absolute() and path.is_relative_to(base) and path != base
            and not path.exists() and not path.is_symlink()
            and path.parent.resolve(strict=True) == path.parent, 'exclusive external output directory required')
    path.mkdir()
    return path


def state_capture_problems(receipt, state, wrapper_exit=None):
    """Check the fixed wrapper's evidence before forwarding any reader body.

    A real CLI refusal can have a nonzero exit and is still forwarded when its
    capture is consistent. A wrapper-only capture failure is not such a refusal.
    """
    problems = []
    if state.get('schema') != 'genesis-s2-runtime-state-capture/v1':
        problems.append('state-capture-schema')
    if state.get('operation_id') != receipt.get('operation_id'):
        problems.append('state-capture-operation')
    if state.get('wrapper_sha256') != PINS[INVESTIGATION / 'capture-state-operation.py']:
        problems.append('state-capture-wrapper-identity')
    if state.get('recorder_sha256') != PINS[INVESTIGATION / 'record-operation.py']:
        problems.append('state-capture-recorder-identity')
    if state.get('original_runtime_receipt_exists') is not True:
        problems.append('state-capture-missing-receipt')
    for side in ('before', 'after'):
        if state.get(side + '_matches_original_recorder_inventory') is not True:
            problems.append('state-capture-' + side + '-mismatch')
        if state.get('state_' + side) != receipt.get('state_files_' + side):
            problems.append('state-capture-' + side + '-inventory')
    if state.get('recorder_exit_code') != receipt.get('exit_code'):
        problems.append('state-capture-recorder-exit')
    if wrapper_exit is not None and wrapper_exit != receipt.get('exit_code'):
        problems.append('state-capture-wrapper-exit')
    return problems


def operation_evidence(ref):
    path, data, receipt = json_ref(ref)
    require(receipt.get('schema') == 'genesis-s2-runtime-operation-receipt/v1', 'original operation receipt schema')
    require(receipt.get('record_kind') == 'ORIGINAL_EXECUTION_RECEIPT' and receipt.get('runtime_revision') == RUNTIME_REVISION,
            'original db9 operation evidence required')
    require(receipt.get('recorder_identity') == stamp(INVESTIGATION / 'record-operation.py'), 'original recorder identity')
    capture_path = regular(path.parent / 'state-capture.json')
    capture = json.loads(capture_path.read_bytes())
    require(not state_capture_problems(receipt, capture), 'original operation state capture is inconsistent')
    require(receipt.get('named_input_bytes_unchanged') is True and receipt.get('external_byte_guard', {}).get('matched') is True,
            'original operation byte guard is not satisfied')
    require(receipt['input_files_before'] == receipt['input_files_after'], 'original named input lists differ')
    original_rows = {row['path']: row for row in receipt['input_files_before']}
    lock = json.loads((INVESTIGATION / 'evaluation-authority/runtime-byte-lock.json').read_bytes())
    require(len(lock['files']) == 1170 and all(original_rows.get(row['path']) == row for row in lock['files']),
            'original operation omitted pinned runtime coverage')
    streams = {}
    sources = [stamp(path), stamp(capture_path)]
    for name, filename in [('stdout', 'stdout.json'), ('stderr', 'stderr.txt')]:
        stream = receipt['streams'][name]
        require(stream['path'] == filename, 'original stream name')
        stream_path = regular(path.parent / filename)
        raw = stream_path.read_bytes()
        require(len(raw) == stream['byte_length'] and sha(raw) == stream['sha256'], 'original stream bytes')
        streams[name] = raw
        sources.append(stamp(stream_path))
    return receipt, json.loads(streams['stdout']), sources


def resolve_context(request, executable):
    """Compare current marker/control bytes with preserved actual prepare+init output.

    Does not recompute kernel IDs, manufacture a marker, assert source freshness or
    grant permissions. Intentional source drift remains for the real reader to assess.
    """
    for path, digest in PINS.items():
        require(stamp(path)['sha256'] == digest, 'fixed helper changed: ' + str(path))
    scope_path = HERE / 'operator-scope.json'
    scope_bytes = regular(scope_path).read_bytes()
    frozen = json.loads(scope_bytes)
    require(frozen['schema'] == 'genesis-s2-u1-operator-scope/v1', 'operator scope schema')
    root = Path(request['root'])
    require(root in ROOTS.values() and root.resolve(strict=True) == root and root.is_dir() and not root.is_symlink(), 'exact U1 root required')
    root_name = next(key for key, value in ROOTS.items() if value == root)
    state_dir = root / '.atlas'
    require(state_dir.is_dir() and not state_dir.is_symlink() and state_dir.resolve(strict=True) == state_dir, 'initialized U1 state required')
    marker_path, marker_bytes, marker = json_ref(request['marker'])
    require(marker_path == state_dir / 'evaluation-store.json', 'marker path')
    marker_keys = {'schema','root','device','inode','evaluationPlan','obligationSet','evaluationCandidate','generation','scope','original_root','initialized_cas_only'}
    require(set(marker) == marker_keys and marker['schema'] == 'ownership-evaluation-store/v1', 'marker schema')
    live = root.stat()
    require(marker['root'] == str(root) and marker['device'] == live.st_dev and marker['inode'] == live.st_ino
            and marker['initialized_cas_only'] is True and marker['original_root'] == str(BASE / 's2-corpus'), 'marker root identity')
    prepared_path, prepared_bytes, prepared = json_ref(request['prepared'])
    require(set(prepared) == {'schema','candidate_id','candidate'} and prepared['schema'] == 'genesis-native-prepared/v2', 'prepared schema')
    candidate = prepared['candidate']
    require(candidate['kind'] == 'genesis-evaluation-candidate' and candidate['version'] == 2 and candidate['phase'] == 'evaluation'
            and candidate['repo_root'] == str(root) and candidate['scope'] == SCOPE, 'prepared root/phase')
    require(candidate['original_candidate'] == frozen['original_candidate'] and candidate['original_contract'] == frozen['original_contract'], 'original obligation lineage')
    require(candidate['evaluation']['phase'] == 'evaluation' and candidate['evaluation']['obligationSet'] == frozen['obligation_set'], 'evaluation obligation identity')
    for value in [prepared['candidate_id'], candidate['evaluation']['evaluationPlan'], marker['generation']]:
        require(isinstance(value, str) and SHA.fullmatch(value), 'runtime identity must be a real resolved digest')
    require(marker['evaluationCandidate'] == prepared['candidate_id'] and marker['evaluationPlan'] == candidate['evaluation']['evaluationPlan']
            and marker['obligationSet'] == frozen['obligation_set'] and marker['scope'] == SCOPE
            and marker['generation'] == frozen['generations'][root_name], 'marker/prepared/frozen-generation binding')
    require(set(candidate['required_artifact_keys']) == set(frozen['required_artifact_keys'])
            and len(candidate['entries']) == len(frozen['required_artifact_keys'])
            and {x['key'] for x in candidate['entries']} == set(frozen['required_artifact_keys']), 'candidate entry coverage')
    origin, output, origin_sources = operation_evidence(request['origin_receipt'])
    require(origin['exit_code'] == 0, 'successful original candidate operation required')
    if root_name == 'M0':
        require(origin['operation'] == 'evaluation-prepare' and origin['corpus_root'] == str(root) and output == prepared
                and origin['returned_candidate_id'] == prepared['candidate_id'], 'actual M0 prepare output binding')
    else:
        target = output.get('result', {})
        prior_root = ROOTS['M0' if root_name == 'M1' else 'M1']
        require(origin['operation'] == 'u1-prepare-update' and origin['corpus_root'] == str(prior_root) and output.get('schema') == 'genesis-s2-u1-operation/v1'
                and output.get('authority_root') == str(prior_root) and output.get('source_root') == str(root)
                and target.get('kind') == 'prepared-evaluation-update' and target.get('prepared') == prepared
                and target.get('targetGeneration') == marker['generation'], 'actual target prepare output binding')
    original_plan_path = regular(root / frozen['m0_plan_relative_path'])
    original_plan_bytes = original_plan_path.read_bytes()
    original_plan = json.loads(original_plan_bytes)
    require(candidate['plan_path'] == frozen['m0_plan_relative_path'] and original_plan['schema'] == 'genesis-evaluation-plan/v1'
            and original_plan['isolation'] == {'root': str(ROOTS['M0']), 'original_root': str(BASE / 's2-corpus')}, 'original M0 plan source')
    locked = {x['path']: x for x in origin['input_files_before']}
    require(locked.get(str(original_plan_path)) == stamp(original_plan_path), 'original plan bytes absent from actual candidate-operation lock')
    require(original_plan['consumer_ids'] == list(frozen['witnesses']) and original_plan['read_limits'] == frozen['read_limits']
            and original_plan['consumer_modes'] == {key: value['mode'] for key, value in frozen['witnesses'].items()}, 'frozen witness plan')
    pinned_own = {}
    for relative, source in [
        (frozen['source_paths']['common'], Path(__file__).resolve()),
        (frozen['source_paths']['scope'], scope_path),
        (frozen['source_paths'][executable.name], executable),
        (frozen['source_paths']['gate_reference'], HERE / 'reference/e002-run-reader-operation.py'),
    ]:
        observed = stamp(source)
        require(original_plan['implementation'].get(relative) == observed['sha256'], 'operator helper not pinned by original M0 plan')
        copy_path = regular(root / relative)
        require(copy_path.read_bytes() == source.read_bytes() and locked.get(str(copy_path)) == stamp(copy_path), 'operator helper source/actual-lock mismatch')
        pinned_own[str(source)] = observed
    init, init_output, init_sources = operation_evidence(request['init_receipt'])
    require(init['operation'] == 'evaluation-init-store' and init['exit_code'] == 0
            and init_output.get('kind') == 'evaluation-store-initialized' and init['candidate_id'] == prepared['candidate_id'], 'actual init evidence')
    require(init['command_argv'] == [frozen['bun'], 'scripts/genesis-evaluation.ts', 'init-store', str(root), str(prepared_path), marker['generation']], 'init argv identity')
    require({'path': '.atlas/evaluation-store.json', 'byte_length': len(marker_bytes), 'sha256': sha(marker_bytes)} in init['state_files_after'], 'marker differs from actual init output')
    require(stamp(prepared_path) in init['input_files_before'], 'prepared bytes not bound by init receipt')
    return {'root': root, 'root_name': root_name, 'marker': marker, 'marker_bytes': marker_bytes, 'original_plan': original_plan,
        'candidate_id': prepared['candidate_id'], 'prepared': prepared, 'scope': frozen,
        'sources': [stamp(scope_path), stamp(marker_path), stamp(prepared_path), stamp(original_plan_path)] + origin_sources + init_sources
            + list(pinned_own.values()) + [stamp(path) for path in PINS]}


def validate_policy(policy, context, purpose, witness_id=None):
    keys = {'schema','root','evaluationPlan','obligationSet','evaluationCandidate','generation','scope','actor','operations','consumer'}
    require(set(policy) == keys and policy['schema'] == 'ownership-evaluation-policy/v1', 'policy schema')
    require(policy['actor'] == ACTOR and all(policy[k] == context['marker'][k] for k in
            ['root','evaluationPlan','obligationSet','evaluationCandidate','generation','scope']), 'policy exact identity')
    if purpose in ['admit', 'maintenance']:
        require(policy['operations'] == (['admit'] if purpose == 'admit' else ['evaluation-maintenance']) and policy['consumer'] is None, 'policy operation scope')
    else:
        require(purpose == 'witness' and witness_id in context['scope']['witnesses'], 'declared witness required')
        witness = context['scope']['witnesses'][witness_id]
        require(witness['root'] == context['root_name'] and policy['operations'] == ['index','read']
                and policy['consumer'] == {'id': witness_id, 'mode': witness['mode']}, 'witness root/mode policy')


def admission_evidence(ref, context):
    receipt, output, sources = operation_evidence(ref)
    expected = 'evaluation-admit' if context['root_name'] == 'M0' else 'evaluation-admit-target'
    require(receipt['operation'] == expected and receipt['exit_code'] == 0 and receipt['corpus_root'] == str(context['root'])
            and receipt['candidate_id'] == context['candidate_id'] and receipt['returned_candidate_id'] == context['candidate_id']
            and output.get('kind') == 'evaluation-admission-attempt' and output.get('candidate_id') == context['candidate_id']
            and output.get('generation') == context['marker']['generation']
            and output.get('emission', {}).get('ok') is True and output['emission'].get('data', {}).get('emitted') is True, 'actual governed admission required')
    return sources


def state_inventory(root):
    directory = root / '.atlas'
    rows, snapshots = [], {}
    for path in sorted(directory.rglob('*')):
        relative = str(path.relative_to(directory))
        require(not path.is_symlink() and path.resolve(strict=True) == path, 'state alias')
        require(not path.name.endswith(('.lock','.next')), 'unresolved state lock/partial file; inspect before policy change')
        if path.is_dir():
            rows.append({'path': relative, 'kind': 'directory'})
        else:
            data = regular(path).read_bytes()
            rows.append({'path': relative, 'kind': 'file', 'byte_length': len(data), 'sha256': sha(data)})
            if not relative.startswith('cas/'):
                snapshots[relative] = data
    return rows, snapshots


def snapshot_state(output, label, rows, snapshots):
    write_new(output / (label + '-inventory.json'), encode(rows))
    for relative, data in snapshots.items():
        target = output / label / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        write_new(target, data)
