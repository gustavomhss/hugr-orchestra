## MATERIALS_SCOPE_ONLY

**A combinação proposta pode ser suficiente para julgar os quatro ADMIT, sem transportar linha a linha todas as tabelas de hashes. Isso não antecipa PASS:** permite avaliar a evidência, suas limitações e eventuais razões para HOLD.

Recebi somente as ondas 1 e 2 da seleção anterior. A subseleção deve ser uma emenda explícita, preservando o pedido anterior, os dois ACKs e a distinção entre material apresentado e material apenas identificado no arquivo.

Não exijo centenas de hashes opacos como substituto de uma verificação que não posso executar. Exijo, porém, **o conteúdo que determina o alcance da verificação**, os resultados originais pertinentes e as exceções capazes de mudar a decisão.

### 1. Material que precisa continuar literal e completo

**Autoridade e escopo:**

- Os protocolos e os quatro critérios ADMIT, já apresentados, mais os planos, obrigações e contratos efetivamente associados ao candidato.
- As 14 decisões históricas completas, incluindo FIX-FIRST, revisões posteriores e limites.
- A correspondência completa das decisões históricas com as 13 entries, preservando a distinção entre evidência semântica e nova decisão de admissão.
- As regras que mantêm AC-01..AC-10, runtime-import-binding, os 14 casos e S2-U1 pendentes e separados.

**Candidato e transformação:**

- Envelope do candidato: raiz, HEAD observado, implementação, versões de engines e referências exatas a plano, obrigações e contratos.
- As 13 entries e os 13 result objects completos, com autoridade, validade, gaps, evidência, metadata, contratos, `result_id`, `inputs_id` e identidades dos corpos.
- Todas as 32 arestas de build, os 30 vínculos de navegação, as roots e as 40 referências.
- Para cada entry, a estrutura dos inputs e dependências, identidade da receita, contagens por tipo e identidade da sequência ordenada efetivamente vinculada. **`inputs_id` isolado não explica a cobertura.**

Não exijo releitura dos corpos opacos preservados apenas para repetir a aceitação semântica anterior. Se algum campo novo resultar de interpretação do corpo, será necessário o trecho relevante e o contexto que sustenta essa transformação.

### 2. Código decisivo que precisa ser apresentado

Preciso das funções completas, com helpers relevantes, que determinam:

- transformação de pacote, resultados, metadata, relações e contratos;
- derivação de inputs, observações, versões e identidades;
- seleção e captura da implementação e de suas dependências;
- validação e persistência de decisões ADMIT;
- igualdade exigida entre candidato julgado e operação subsequente;
- isolamento, política, geração e verificação de estado atual;
- recusa nos caminhos suportados de reader, writer, replay e export;
- aplicação do guard externo, inclusive comportamento em falha e seus limites.

Também preciso do **verificador independente V2 integral**, do relatório original completo e da distinção entre o recorder efetivamente utilizado e o recorder apenas proposto.

Não é necessário transportar arquivos sem influência nessas propriedades. Entretanto, nomes de funções ou resumos não substituem condições, filtros, exceções ou chamadas delegadas que determinem a cobertura.

### 3. Tratamento das quatro tabelas extensas

| Tabela | Linhas repetitivas que podem ser omitidas da apresentação | Conteúdo que permanece necessário |
|---|---|---|
| **690 observações** | Registros uniformes de path/hash/version, quando integralmente percorridos pelo verificador apresentado. | Identidade e tamanho do objeto completo; esquema; contagem; regra de ordenação; origem dos membros; cobertura por entry; código que compara membership e versões com fontes reais; resultados completos e todas as exceções. |
| **925 hashes de runtime** | Hashes individuais uniformes dos arquivos inventariados. | Árvore de resolução por pacote, com nomes, versões, raízes resolvidas e contagens; regras de inclusão/exclusão; tratamento de dependências obrigatórias, opcionais e peers; engines; todos os conflitos, ausências e lacunas. O caminho de dependência que envolve `@noble/hashes` precisa ser literal. |
| **247 arquivos de `@noble/hashes`** | As 247 linhas uniformes de hashes, se a reconciliação integral estiver demonstrada pelo script e pelo resultado original. | Metadados do pacote e lock pertinentes; origem e integridade do tarball; localização instalada; procedimento e resultado da comparação completa; instantes das capturas; arquivos efetivamente usados pelo mecanismo relevante e sua resolução; declaração explícita da ausência de snapshot anterior/posterior no prepare original. |
| **667 proveniências** | Linhas uniformes de comparação de arquivos, hashes, blobs e comprimentos. | Mapa dos pins e das classes de origem; forma de materialização; algoritmo completo de conferência; cobertura de cada classe; estados antes/depois; todas as divergências, arquivos indisponíveis, exclusões e caminhos especiais. |

**Condição importante:** listas que definem o universo obrigatório, permissões, exclusões ou exceções não são simples tabelas repetitivas de resultado. Se uma dessas listas determina o que o verificador deixa de examinar, seu conteúdo decisivo precisa estar apresentado. Não basta demonstrar que ele verificou tudo dentro de uma seleção cujo alcance permaneça oculto.

### 4. Recibos e relatório de execução

As projeções de recibos devem preservar literalmente os campos decisivos:

- argv, cwd, raiz, HEAD, implementação e versões;
- início, término e ordem temporal das capturas;
- arquivo efetivamente executado e sua identidade;
- resultados, códigos de saída e identidades das saídas;
- cobertura, skips, avisos, falhas e limitações;
- estado de fontes e runtime antes/depois, quando realmente observado.

Uma projeção que depende do arquivo externo para restaurar campos omitidos deve ser descrita assim. Não deve ser chamada de recibo integral apresentado.

O relatório das **22.752 comparações** precisa permitir relacionar as verificações aos quatro critérios e às 13 entries. Preciso distinguir verificações de igualdade, verificações de membership, verificações de fonte externa e afirmações que continuam sem evidência. “Zero divergências” não pode absorver a lacuna de cobertura já declarada.

### 5. Material especialmente decisivo para `@noble/hashes`

A quantidade de linhas de hashes não resolve a questão temporal. Para julgá-la, preciso ver:

1. Onde a identidade intrínseca deixa de cobrir essa dependência e por que isso ocorre.
2. Qual implementação instalada foi observada em cada instante documentado.
3. O que a reconciliação posterior comprova e o que ela não comprova sobre o prepare já ocorrido.
4. Quais operações futuras o guard proposto protege, por qual ponto de entrada e com quais verificações antes/depois.
5. Como uma mudança detectada impede a operação ou invalida a prova.
6. Se existem caminhos suportados que contornam esse guard.
7. Se a evidência do guard é implementação, execução observada ou somente proposta.

Não trato um guard externo como alteração da identidade intrínseca, nem uma reconciliação posterior como cobertura histórica. Também não declaro antecipadamente que a lacuna necessariamente pode ou não ser compensada para o propósito limitado desta admissão: isso depende do material acima e dos critérios aplicáveis.

### 6. Forma mínima da emenda de seleção

A emenda deve listar, para cada objeto não apresentado integralmente:

- caminho ou identificador;
- tamanho e hash declarados;
- função na revisão;
- campos apresentados e campos omitidos;
- verificador e resultado que o cobrem;
- limitações remanescentes.

Assim, poderei fundamentar a decisão no **código apresentado e na execução registrada**, sem afirmar que li as tabelas omitidas ou recalculei suas identidades.

**Estado: requisitos de material definidos; nenhuma decisão ADMIT, nenhum PASS de AC e nenhum binding emitidos.**