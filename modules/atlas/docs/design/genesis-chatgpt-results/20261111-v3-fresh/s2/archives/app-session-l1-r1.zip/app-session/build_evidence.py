from pathlib import Path
import json, hashlib

B=Path('/workspace/scratch/992c54067adf/genesis-s2/producers/app-session')
A='packages/app-shell/'; S='packages/session-ui/'
def a(x):return A+x
def s(x):return S+x
# Each selection supports a bounded claim. Omitted intervals are separate blocks,
# never silently joined into a fabricated continuous excerpt.
EXCERPTS=[
('Executable UI boundary policy','UI allows explicit browserSafe platform exports; this is narrower than an unrestricted Core import.', 'script/module-architecture.json',[(15,17),(194,201)]),
('Server context credential lifetime','A stable server key does not keep a context alive after credential identity changes.',a('src/context/global.tsx'),[(68,107)]),
('Workspace identity and providers','Server/directory workspace identity is separate from the currently viewed session.',a('src/pages/session.tsx'),[(229,239),(264,272)]),
('Permanent asynchronous owner departure','Generation captures do not revive after an A→B→A value change.',a('src/components/prompt-input/submission-policy.ts'),[(23,43)]),
('Adjacent delta coalescing','Only adjacent events with equal directory and delta identity combine.',a('src/context/server-sdk.tsx'),[(86,119)]),
('SSE subscription and heartbeat','Bounded subscription precedes connected; heartbeat is a comment frame. This does not prove durable replay.','packages/server/src/handlers/event.ts',[(13,20),(26,43)]),
('Recovery read fencing','Superseded generation rejects; an intervening policy change repeats the read; local receipt differs from durable revision.',a('src/context/session-recovery.ts'),[(39,64)]),
('Admission is not transcript promotion','Admitted input is pending; promotion materializes a message and missing context is explicit.',a('src/context/server-session-v2-reducer.ts'),[(16,47)]),
('Policy barrier','Canonical read must span a stable serialized-write generation.',a('src/components/prompt-input/submission-policy.ts'),[(118,151)]),
('Ambiguous first-send cleanup','Dispatched attempts retain session/message identity; only confirmed empty, never-dispatched session can be deleted.',a('src/components/prompt-input/submit.ts'),[(455,476)]),
('Admission and draft handoff','Final dispatch checks ownership/policy; promotion requires admitted state and preserves edits made in flight.',a('src/components/prompt-input/submit.ts'),[(530,540),(545,575)]),
('Wire admission receipt','Schema explicitly distinguishes admitted and optional promoted sequence.','packages/schema/src/session-input.ts',[(15,25)]),
('Protocol prompt endpoint','Protocol declares receipt result and separately describes scheduling execution.','packages/protocol/src/groups/session.ts',[(333,351)]),
('Server admission delegation','Prompt handler forwards supplied ID, prompt, delivery and resume to its admission helper.','packages/server/src/handlers/session.ts',[(246,258)]),
('Core admission and retry equivalence','Existing ID requires equivalent session/prompt/delivery; admitted result requires durable event and projected record. Projection comparison has additional context/time fields.','packages/core/src/session/input.ts',[(48,94),(291,316)]),
('Remount-stable submission state','Admission source is a WeakMap-backed store; draft-to-session handoff shares busy state but resets selection map.',a('src/components/prompt-input/submission-admission.ts'),[(21,45)]),
('Permission lineage rule','The complete small helper is a bounded policy mechanism, not proof of backend enforcement.',a('src/context/permission-auto-respond.ts'),[(1,69)]),
('PTY cursor contract','Validated control frames set cursor; text advances it by JavaScript string length.',a('src/components/terminal.tsx'),[(531,554)]),
('Live start consent','Start requests open consent every time; start rejects duplicate in-flight requests.',a('src/orchestra/chapters/flight-engineer/run.ts'),[(81,104)]),
('WSL capability lifecycle','No platform API means disabled query; subscription updates cache and cleans up.',a('src/wsl/context.tsx'),[(9,36)]),
('Janitor source and notification ownership','Foreign report/late notification cannot open the current report through these checks.',a('src/context/janitor.tsx'),[(29,51)]),
('Janitor pocket session ownership','Stored-session reuse checks current owner/directory; created-session adoption is checked after async sync.',a('src/components/janitor-pocket.tsx'),[(99,124),(135,159)]),
('Renderer recovery record','Optional native failure recording is memoized per ErrorPage mount.',a('src/pages/error.tsx'),[(222,247)]),
('Reusable view model boundary','The model states its UI role; this declaration is not the wire protocol.',s('src/transcript-model.ts'),[(1,28)]),
('Markdown sanitation and cache boundary','Sanitation fails closed when unsupported, adds safe blank-link rel attributes and bounds cached entries.',s('src/components/markdown-cache.tsx'),[(11,53)]),
('Last observed process state','Process state is derived from completed transcript tool results, not polled live state.',a('src/pages/session/process-control-data.ts'),[(5,19),(24,48)]),
('Registered chapter reachability','Full registration object shows cicd maps to Actions and no Guardrails registration; this does not enumerate every possible consumer.',a('src/orchestra/chapter-route.tsx'),[(17,44)]),
('Actions request gate','Unknown outcome and stale/nonready binding disable another request.',a('src/orchestra/actions/request-policy.ts'),[(1,19)]),
('Secret reveal control','Presentation masking and explicit reveal are visible; credential storage is outside this component.',a('src/components/secret-input-v2.tsx'),[(1,25)]),
('External-link defaults','Defaults are caller-overridable; the component is not a URL sanitizer.',a('src/components/external-link.tsx'),[(3,21)]),
('Path normalization helper','Separator/root normalization does not claim filesystem canonicalization or case folding.',a('src/utils/path-key.ts'),[(1,24)]),
('Search input preconditions','Composition, existing handling and editable-target guards precede document-level forwarding.',a('src/utils/search-keydown.ts'),[(1,20)]),
('Download lifecycle','Object URL and temporary anchor are cleaned up after initiating download; no download was performed in this review.',a('src/utils/download.ts'),[(1,11)]),
('Serialize addon public lifecycle','Activation, buffer availability and options constrain terminal serialization; internal conversion is not fully audited.',a('src/addons/serialize.ts'),[(512,555)]),
('Palette generator entry','Generator explicitly reads source inputs, rejects failed contrast checks and writes named outputs; it was not run.',a('script/orchestra-palettes.ts'),[(1,27)]),
('Draft regression assertions','These are inspected Playwright assertions using mock transport, not a test result from this work.',a('e2e/regression/draft-admission-handoff.spec.ts'),[(60,102)]),
('ABA ownership assertion','This browser-provider test states that returning to A does not revive the original held operation; not executed.',a('test-browser/prompt-admission-owner.suite.ts'),[(341,377)]),
('Performance evidence limits','Benchmark documentation distinguishes diagnostics from machine-budget or compositor claims.',a('e2e/performance/README.md'),[(1,30)]),
('Fixture provenance distinction','Fixture documentation, not evidence of a current product test run.',a('src/pages/session/orchestra-evidence-fixtures/README.md'),[(1,27)]),
]
source_index={r['path']:r for r in json.loads((B/'sources.json').read_text())['records']}
index=[]
parts=['# Decisive evidence — app-session L1\n',
'Source pin: `1cde2ff7a71bcf7aecb5d030917b577165135d38`. Protocol pin: `ee2521a5b966bd505cc95bd1c733e09e12f33531`. These are exact captured source lines with a line-number prefix added. Discontinuous intervals use separate blocks. Code, comments and test assertions retain their original evidentiary status; no tests or product code were executed. `sources.json` gives complete SHA-256, byte lengths and original connector-response locations.\n',
'This packet concentrates on decisive lifecycle and boundary claims. Family breadth, limits and all 1,887 entry dispositions are in `l1.md` and `coverage.json`; an excerpt is not a whole-file audit.\n']
total=0
for number,(title,purpose,path,ranges) in enumerate(EXCERPTS,1):
    identity=f'E{number:02}'
    source=source_index[path]
    lines=(B/source['local_capture_file']).read_text().splitlines()
    chunks=[]
    parts += [f'## {identity} — {title}\n',purpose+'\n',f'Source: `{path}`. Git blob: `{source["git_blob_sha"]}`.\n']
    for start,end in ranges:
        assert 1<=start<=end<=len(lines),(path,start,end,len(lines))
        exact='\n'.join(lines[start-1:end])+'\n'
        chunks.append({'start_line':start,'end_line':end,'excerpt_sha256':hashlib.sha256(exact.encode()).hexdigest()})
        parts += [f'Lines {start}–{end}:\n','```text\n'+'\n'.join(f'{n:4} | {lines[n-1]}' for n in range(start,end+1))+'\n```\n']
        total+=end-start+1
    index.append({'id':identity,'title':title,'purpose':purpose,'path':path,'ranges':chunks})
parts += ['## Structural asset sample evidence\n',
'These are local structural inspections of pinned binary bytes, not text excerpts or visual/authorship conclusions. The exact inspection record is `binary-inspection.json`; source SHA-256 and Git identities are in `sources.json`.\n',
'| Captured asset | Decoded sample | Byte length |\n|---|---|---:|\n| `packages/app-shell/src/orchestra/avatars/seat-backend.webp` | WebP, 256×256, RGBA | 12,028 |\n| `packages/app-shell/public/orchestra/mtn-src.jpg` | JPEG, 900×601, RGB | 135,002 |\n| `packages/app-shell/src/pages/session/zen-assets/grain-bg.png` | PNG, 220×220, P | 29,501 |\n']
(B/'decisive-evidence.md').write_text('\n'.join(parts))
(B/'evidence-index.json').write_text(json.dumps({'source_commit':'1cde2ff7a71bcf7aecb5d030917b577165135d38','excerpt_count':len(index),'source_line_count':total,'excerpts':index},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'excerpts':len(index),'source_lines':total,'bytes':(B/'decisive-evidence.md').stat().st_size}))
