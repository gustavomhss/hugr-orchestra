import type {
  WslDistroProbe,
  WslInstalledDistro,
  WslJob,
  WslOnlineDistro,
  WslOrchestraCheck,
  WslRuntimeCheck,
  WslServerConfig,
  WslServerItem,
  WslServerRuntime,
  WslServersEvent,
  WslServersState,
} from "../../preload/types"
import { WSL_SERVERS_KEY } from "../store-keys"
import { getStore } from "../store"
import { pendingRestartAfterWslInstall, wslServerIdsToStartOnInitialize } from "./startup"
import { clearWslDistroState } from "./policy"
import { nativeT } from "../native-translations"
import { installWslArtifact, WslArtifactError } from "./artifact"
import {
  installWslDistro,
  installWslRuntimeElevated,
  listInstalledWslDistros,
  listOnlineWslDistros,
  openWslTerminal,
  probeWslDistro,
  probeWslRuntime,
  readWslCommandVersion,
  resolveWslOrchestra,
  summarize,
} from "./runtime"

type RunningSidecar = {
  listener: { stop: () => void; onExit: (cb: (code: number | null, signal: NodeJS.Signals | null) => void) => void }
  url: string
  username: string | null
  password: string
}

type SpawnSidecar = (distro: string) => Promise<RunningSidecar>

type ControllerLogger = {
  log: (message: string, meta?: unknown) => void
  error: (message: string, meta?: unknown) => void
}

type WslServersControllerOptions = {
  logger?: ControllerLogger
  readServers?: () => WslServerConfig[]
  writeServers?: (servers: WslServerConfig[]) => void
  probeDistro?: typeof probeWslDistro
  resolveOrchestra?: typeof resolveWslOrchestra
  readCommandVersion?: typeof readWslCommandVersion
  installArtifact?: (distro: string, opts: { signal?: AbortSignal }) => Promise<void>
}

export type WslServersController = ReturnType<typeof createWslServersController>

export function wslServerIdForDistro(distro: string) {
  return `wsl:${distro}`
}

export function createWslServersController(
  expectedVersion: string, // The caller supplies CliArtifactManifest.version.
  spawnSidecar: SpawnSidecar,
  options?: WslServersControllerOptions,
) {
  let state: WslServersState = initialState()
  const listeners = new Set<(event: WslServersEvent) => void>()
  const sidecars = new Map<string, RunningSidecar>()
  const startAttempts = new Map<string, number>()
  let jobAbort: AbortController | undefined
  const logger = options?.logger
  const readServers = options?.readServers ?? readPersistedServers
  const writeServers = options?.writeServers ?? writePersistedServers
  const probeDistro = options?.probeDistro ?? probeWslDistro

  const emit = () => {
    for (const listener of listeners) listener({ type: "state", state })
  }

  const setState = (next: Partial<WslServersState>) => {
    state = { ...state, ...next }
    emit()
  }

  const persistServers = (servers: WslServerConfig[]) => {
    writeServers(servers)
  }

  const updateServer = (id: string, update: (item: WslServerItem) => WslServerItem) => {
    const next = state.servers.map((item) => (item.config.id === id ? update(item) : item))
    setState({ servers: next })
  }

  const beginJob = (job: WslJob): AbortController => {
    jobAbort?.abort()
    const abort = new AbortController()
    jobAbort = abort
    setState({ job })
    return abort
  }

  const endJob = (abort: AbortController) => {
    if (jobAbort !== abort) return
    jobAbort = undefined
    setState({ job: null })
  }

  const refreshFromStore = () => {
    const persisted = readServers()
    const items: WslServerItem[] = persisted.map((config) => {
      const existing = state.servers.find((item) => item.config.id === config.id)
      return {
        config,
        runtime: existing?.runtime ?? { kind: "stopped" },
      }
    })
    setState({ servers: items })
  }

  const setRuntime = (id: string, runtime: WslServerRuntime) => {
    updateServer(id, (item) => ({ ...item, runtime }))
  }

  const setOrchestraCheck = (distro: string, check: WslOrchestraCheck) => {
    setState({
      orchestraChecks: {
        ...state.orchestraChecks,
        [distro]: check,
      },
    })
  }

  // Each check of a distro takes a generation, and a result from an older one is dropped: a slow background check
  // cannot overwrite what a later probe or install found.
  const checkGenerations = new Map<string, number>()
  const beginCheck = (distro: string) => {
    const generation = (checkGenerations.get(distro) ?? 0) + 1
    checkGenerations.set(distro, generation)
    return generation
  }
  const currentCheck = (generation: number, check: WslOrchestraCheck) => checkGenerations.get(check.distro) === generation
  const storeCheck = (generation: number, check: WslOrchestraCheck) => {
    if (currentCheck(generation, check)) setOrchestraCheck(check.distro, check)
  }

  // Reading the version admits the installed guest CLI against this desktop's bundle; admissionCheck says what a refusal
  // means. A guest command that failed for any other reason (exit 124 from its timeout, a WSL error) proves nothing about
  // the install, so it stays an error for the caller.
  const checkOrchestra = async (distro: string, opts?: { signal?: AbortSignal }) => {
    const resolved = await (options?.resolveOrchestra ?? resolveWslOrchestra)(distro, opts)
    if (!resolved) return orchestraCheck(distro, null, null, expectedVersion)
    return (options?.readCommandVersion ?? readWslCommandVersion)(resolved, distro, opts).then(
      (version) => orchestraCheck(distro, resolved, version, expectedVersion),
      (error: unknown) => {
        if (!(error instanceof WslArtifactError) || error.reason === "command") throw error
        return admissionCheck(distro, resolved, expectedVersion, error)
      },
    )
  }

  const probeAddableDistros = async (distros: string[], opts?: { signal?: AbortSignal }) => {
    const unique = [...new Set(distros)]
    const distroProbes = await Promise.all(
      unique
        .filter((distro) => !state.distroProbes[distro])
        .map(async (distro) => [distro, await probeDistro(distro, opts)] as const),
    )
    if (distroProbes.length) {
      setState({ distroProbes: { ...state.distroProbes, ...Object.fromEntries(distroProbes) } })
    }

    // Each distro settles on its own. One whose check failed (a WSL command error or timeout) is stored as a check to
    // retry, with its error: the user sees which distro failed, the others keep their checks, and the next probe
    // repeats it. An aborted probe stores nothing.
    const checking = unique
      .filter((distro) => distroProbeReady(state.distroProbes[distro]))
      .filter((distro) => !state.orchestraChecks[distro] || state.orchestraChecks[distro].problem === "retry")
    const generations = checking.map(beginCheck)
    const settled = await Promise.allSettled(checking.map((distro) => checkOrchestra(distro, opts)))
    opts?.signal?.throwIfAborted()
    const checks = settled
      .map((result, index) => {
        if (result.status === "fulfilled") return result.value
        const message = result.reason instanceof Error ? result.reason.message : String(result.reason)
        logger?.error("wsl orchestra check failed", { distro: checking[index], message })
        return retryCheck(checking[index]!, expectedVersion, message)
      })
      .filter((check, index) => currentCheck(generations[index]!, check))
    if (checks.length) {
      setState({ orchestraChecks: { ...state.orchestraChecks, ...Object.fromEntries(checks.map((check) => [check.distro, check])) } })
    }
  }

  const hasServer = (id: string, distro: string) => {
    return state.servers.some((item) => item.config.id === id && item.config.distro === distro)
  }

  const refreshOrchestraCheckBackground = (id: string, distro: string) => {
    const generation = beginCheck(distro)
    void checkOrchestra(distro)
      .then((check) => {
        if (!hasServer(id, distro)) return
        storeCheck(generation, check)
      })
      .catch((error) => {
        const message = error instanceof Error ? error.message : String(error)
        logger?.error("wsl orchestra check failed", { id, distro, message })
      })
  }

  const refreshOrchestraChecks = async () => {
    await Promise.all(
      state.servers.map((item) => {
        const generation = beginCheck(item.config.distro)
        return checkOrchestra(item.config.distro)
          .then((check) => {
            if (!hasServer(item.config.id, item.config.distro)) return
            storeCheck(generation, check)
          })
          .catch((error) => {
            const message = error instanceof Error ? error.message : String(error)
            logger?.error("wsl orchestra check failed", {
              id: item.config.id,
              distro: item.config.distro,
              message,
            })
          })
      }),
    )
  }

  const refreshDistroLists = async (opts: { signal?: AbortSignal }) => {
    const [installed, online] = await Promise.all([listInstalledWslDistros(opts), listOnlineWslDistros(opts)])
    return { installed, online }
  }

  const nextStartAttempt = (id: string) => {
    const next = (startAttempts.get(id) ?? 0) + 1
    startAttempts.set(id, next)
    return next
  }

  const invalidateStartAttempt = (id: string) => {
    startAttempts.set(id, (startAttempts.get(id) ?? 0) + 1)
  }

  const isCurrentStartAttempt = (id: string, attempt: number) => {
    return startAttempts.get(id) === attempt && state.servers.some((item) => item.config.id === id)
  }

  const startServer = async (id: string) => {
    const item = state.servers.find((x) => x.config.id === id)
    if (!item) return
    const attempt = nextStartAttempt(id)
    await stopServerInternal(id)
    if (!isCurrentStartAttempt(id, attempt)) return
    setRuntime(id, { kind: "starting" })
    logger?.log("wsl sidecar starting", { id, distro: item.config.distro })
    try {
      const sidecar = await spawnSidecar(item.config.distro)
      if (!isCurrentStartAttempt(id, attempt)) {
        try {
          sidecar.listener.stop()
        } catch {
          // ignore stop errors for stale sidecars
        }
        return
      }
      sidecars.set(id, sidecar)
      setRuntime(id, {
        kind: "ready",
        url: sidecar.url,
        username: sidecar.username,
        password: sidecar.password,
      })
      sidecar.listener.onExit((code, signal) => {
        if (sidecars.get(id) !== sidecar) return
        sidecars.delete(id)
        const message = startupFailure(code, signal)
        setRuntime(id, { kind: "failed", message })
        logger?.error("wsl sidecar exited", { id, distro: item.config.distro, code, signal })
      })
      refreshOrchestraCheckBackground(id, item.config.distro)
      logger?.log("wsl sidecar ready", { id, distro: item.config.distro, url: sidecar.url })
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      if (!isCurrentStartAttempt(id, attempt)) return
      setRuntime(id, { kind: "failed", message })
      // Without this, an Ubuntu-style silent failure leaves no trace in
      // main.log — the controller captures the message in its state but
      // nothing surfaces unless the user opens the WSL servers dialog.
      logger?.error("wsl sidecar failed to start", { id, distro: item.config.distro, message })
    }
  }

  const stopServerInternal = async (id: string) => {
    const existing = sidecars.get(id)
    if (!existing) return
    sidecars.delete(id)
    try {
      existing.listener.stop()
    } catch {
      // ignore stop errors
    }
  }

  const runJob = async <T>(job: WslJob, runner: (abort: AbortController) => Promise<T>) => {
    const abort = beginJob(job)
    try {
      const value = await runner(abort)
      endJob(abort)
      return value
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        endJob(abort)
        return undefined
      }
      const err = error instanceof Error ? error : new Error(String(error))
      endJob(abort)
      throw err
    }
  }

  return {
    getState() {
      return state
    },
    subscribe(listener: (event: WslServersEvent) => void) {
      listeners.add(listener)
      return () => listeners.delete(listener)
    },

    async initialize() {
      refreshFromStore()
      void refreshOrchestraChecks()
      for (const id of wslServerIdsToStartOnInitialize(state.servers.map((item) => item.config))) void startServer(id)
    },

    async probeRuntime() {
      await runJob({ kind: "runtime", startedAt: Date.now() }, async (abort) => {
        const runtime = await probeWslRuntime({ signal: abort.signal })
        setState({
          runtime,
          pendingRestart: state.pendingRestart && !runtime.available ? state.pendingRestart : false,
        })
      })
    },

    async refreshDistros() {
      await runJob({ kind: "distros", startedAt: Date.now() }, async (abort) => {
        // "Check again" lands here: checks that failed transiently are dropped, so the next probe repeats them.
        setState({
          ...(await refreshDistroLists({ signal: abort.signal })),
          orchestraChecks: Object.fromEntries(
            Object.entries(state.orchestraChecks).filter(([, check]) => check.problem !== "retry"),
          ),
        })
      })
    },

    async installWsl() {
      await runJob({ kind: "install-wsl", startedAt: Date.now() }, async (abort) => {
        const result = await installWslRuntimeElevated({ signal: abort.signal })
        if (result.code !== 0) {
          const message = summarize(result.stderr || result.stdout) || nativeT("desktop.wsl.error.installWsl")
          throw new Error(message)
        }
        const runtime = await probeWslRuntime({ signal: abort.signal })
        setState({ runtime, pendingRestart: pendingRestartAfterWslInstall(runtime) })
      })
    },

    async installDistro(name: string) {
      await runJob({ kind: "install-distro", distro: name, startedAt: Date.now() }, async (abort) => {
        const result = await installWslDistro(name, { signal: abort.signal })
        if (result.code !== 0) {
          const message =
            summarize(result.stderr || result.stdout) || nativeT("desktop.wsl.error.installDistro", { distro: name })
          throw new Error(message)
        }
        const distros = await refreshDistroLists({ signal: abort.signal })
        const probe = await probeDistro(name, { signal: abort.signal })
        setState({
          ...distros,
          distroProbes: { ...state.distroProbes, [name]: probe },
        })
      })
    },

    async probeAddable(distros: string[]) {
      if (!distros.length) return
      await runJob({ kind: "probe-addable", distros, startedAt: Date.now() }, async (abort) => {
        await probeAddableDistros(distros, { signal: abort.signal })
      })
    },

    async installServer(name: string) {
      await runJob({ kind: "install-server", distro: name, startedAt: Date.now() }, async (abort) => {
        const opts = { signal: abort.signal }
        const generation = beginCheck(name)
        await (options?.installArtifact ?? ((distro, opts) => installWslArtifact(distro, expectedVersion, opts)))(name, opts)
        abort.signal.throwIfAborted()
        const check = await checkOrchestra(name, opts)
        abort.signal.throwIfAborted()
        storeCheck(generation, check)
      })
    },

    async openTerminal(name: string) {
      await openWslTerminal(name)
    },

    async addServer(distro: string): Promise<WslServerConfig> {
      const id = wslServerIdForDistro(distro)
      if (state.servers.some((item) => item.config.id === id)) {
        throw new Error(nativeT("desktop.wsl.error.alreadyAdded", { distro }))
      }
      const config: WslServerConfig = {
        id,
        distro,
      }
      persistServers([...readServers(), config])
      setState({
        servers: [...state.servers, { config, runtime: { kind: "starting" } }],
      })
      void startServer(id)
      return config
    },

    async removeServer(id: string) {
      const distro = state.servers.find((item) => item.config.id === id)?.config.distro
      if (distro) beginCheck(distro)
      invalidateStartAttempt(id)
      await stopServerInternal(id)
      const remaining = readServers().filter((item) => item.id !== id)
      persistServers(remaining)
      setState({
        servers: state.servers.filter((item) => item.config.id !== id),
        ...(distro ? clearWslDistroState(state.distroProbes, state.orchestraChecks, distro) : {}),
      })
    },

    startServer,

    stopAll() {
      for (const item of state.servers) invalidateStartAttempt(item.config.id)
      for (const existing of sidecars.values()) {
        try {
          existing.listener.stop()
        } catch {
          // ignore
        }
      }
      sidecars.clear()
    },
  }
}

function initialState(): WslServersState {
  return {
    runtime: null,
    installed: [],
    online: [],
    distroProbes: {},
    orchestraChecks: {},
    pendingRestart: false,
    servers: [],
    job: null,
  }
}

function readPersistedServers(): WslServerConfig[] {
  const store = getStore()
  const existing = store.get(WSL_SERVERS_KEY)
  if (existing && typeof existing === "object") {
    const record = existing as { servers?: unknown }
    const list = Array.isArray(record.servers) ? record.servers : []
    return list.flatMap(normalizePersistedServer)
  }
  return []
}

function writePersistedServers(servers: WslServerConfig[]) {
  getStore().set(WSL_SERVERS_KEY, { servers })
}

function normalizePersistedServer(value: unknown): WslServerConfig[] {
  if (!value || typeof value !== "object") return []
  const record = value as Record<string, unknown>
  const distro = typeof record.distro === "string" && record.distro.length > 0 ? record.distro : null
  if (!distro) return []
  const id = typeof record.id === "string" && record.id.length > 0 ? record.id : wslServerIdForDistro(distro)
  return [
    {
      id,
      distro,
    },
  ]
}

// What a refused admission of an installed guest CLI means. The guest refusing its bytes (exit 84) or version (82) is an
// install from another desktop build, which every desktop update leaves behind: a server to update. Anything else (the
// guest's ABI or architecture, its install path, or this desktop's own bundle failing a host-side check) is not fixed
// by reinstalling, so the check carries that error's message and offers no install.
function admissionCheck(
  distro: string,
  resolvedPath: string,
  expectedVersion: string,
  error: WslArtifactError,
): WslOrchestraCheck {
  if (error.guestExit === 82 || error.guestExit === 84) {
    return { distro, resolvedPath, version: null, expectedVersion, matchesDesktop: false, error: null }
  }
  return { distro, resolvedPath, version: null, expectedVersion, matchesDesktop: null, error: error.message, problem: "unfixable" }
}

function retryCheck(distro: string, expectedVersion: string, error: string): WslOrchestraCheck {
  return { distro, resolvedPath: null, version: null, expectedVersion, matchesDesktop: null, error, problem: "retry" }
}

function orchestraCheck(
  distro: string,
  resolvedPath: string | null,
  version: string | null,
  expectedVersion: string,
): WslOrchestraCheck {
  if (!resolvedPath) {
    return {
      distro,
      resolvedPath: null,
      version: null,
      expectedVersion,
      matchesDesktop: null,
      error: nativeT("desktop.wsl.error.serverMissing"),
    }
  }
  if (!version) {
    return {
      distro,
      resolvedPath,
      version: null,
      expectedVersion,
      matchesDesktop: null,
      error: nativeT("desktop.wsl.error.serverCannotRun"),
    }
  }
  return {
    distro,
    resolvedPath,
    version,
    expectedVersion,
    matchesDesktop: version === expectedVersion,
    error: null,
  }
}

function distroProbeReady(probe: WslDistroProbe | undefined) {
  return !!probe?.canExecute && probe.hasBash
}

function startupFailure(code: number | null, signal: NodeJS.Signals | null) {
  return nativeT("desktop.wsl.error.serverExited", { code: code ?? "null", signal: signal ?? "null" })
}

// Re-export types used by callers
export type {
  WslInstalledDistro,
  WslOnlineDistro,
  WslRuntimeCheck,
  WslDistroProbe,
  WslOrchestraCheck,
  WslServerConfig,
  WslServerItem,
  WslServerRuntime,
  WslServersEvent,
  WslServersState,
}
