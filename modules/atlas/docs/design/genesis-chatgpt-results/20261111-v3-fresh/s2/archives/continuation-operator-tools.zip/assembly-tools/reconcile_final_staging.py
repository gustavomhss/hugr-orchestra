"""Resume the observed failed S2 staging copy without altering its retained attempt."""
import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PACKAGE_SHA = "9356cefcb4a1db413e67869a855fd082536476fb18ff7784dde39f051e9b407b"
PREFIX = "modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2"
OPERATION = ROOT / "runtime-work/final-staging" / PACKAGE_SHA
TEMPORARY = OPERATION / "payload-kml4b26g"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()

def write_new(path, raw):
    assert not path.exists()
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())

plan_raw = (OPERATION / "stage-plan.json").read_bytes()
plan = json.loads(plan_raw)
assert plan_raw == encoded(plan)
assert plan["package_sha256"] == PACKAGE_SHA
assert plan["artifact_count"] == plan["supported_count"] == plan["required_count"] == 13
assert plan["final_conditions"] == [] and plan["reference_errors"] == []
assert plan["roots_observed"] == {"entry": "s2.l4.entry"}
assert plan["payload_prefix"] == PREFIX
source = Path(plan["source_root"])
assert source == ROOT / "runtime-work/source-root"
assert not (source / ".atlas").exists()
assert sha((ROOT / "deliverable/native-package.json").read_bytes()) == PACKAGE_SHA
target = source / PREFIX
assert not target.exists()
assert not (OPERATION / "sealed.json").exists()
assert TEMPORARY.is_dir() and not TEMPORARY.is_symlink()
assert not (OPERATION / "prepared.json").exists()
assert not (OPERATION / "prepare-attempt-marker.json").exists()
for node in plan["files"]:
    path = node["path"]
    actual = TEMPORARY / path[len(PREFIX) + 1:] if path.startswith(PREFIX + "/") else source / path
    raw = actual.read_bytes()
    assert not actual.is_symlink()
    assert len(raw) == node["byte_length"] and sha(raw) == node["sha256"], path
expected_temporary_files = {n["path"][len(PREFIX) + 1:] for n in plan["files"] if n["path"].startswith(PREFIX + "/")}
observed_temporary_files = {p.relative_to(TEMPORARY).as_posix() for p in TEMPORARY.rglob("*") if p.is_file()}
assert expected_temporary_files == observed_temporary_files
assert not any(p.is_symlink() for p in TEMPORARY.rglob("*"))
for old in plan["materialized_originals_to_preserve"]:
    raw = (source / old["path"]).read_bytes()
    assert sha(raw) == old["sha256"] and len(raw) == old["byte_length"], old["path"]
# Copy, rather than alter or remove, the complete failed temporary payload.
# copytree refuses an existing target; copy2 preserves the read-only modes.
shutil.copytree(TEMPORARY, target, copy_function=shutil.copy2)
assert {p.relative_to(target).as_posix() for p in target.rglob("*") if p.is_file()} == expected_temporary_files
for node in plan["files"]:
    raw = (source / node["path"]).read_bytes()
    assert len(raw) == node["byte_length"] and sha(raw) == node["sha256"], node["path"]
for old in plan["materialized_originals_to_preserve"]:
    assert sha((source / old["path"]).read_bytes()) == old["sha256"], old["path"]
for relative in expected_temporary_files:
    assert (target / relative).read_bytes() == (TEMPORARY / relative).read_bytes()
assert all((p.stat().st_mode & 0o222) == 0 for p in [target, *target.rglob("*")])
assert not (source / ".atlas").exists()
assert (OPERATION / "stage-plan.json").read_bytes() == plan_raw
seal = {
    "schema": "genesis-s2-final-staging-seal/v1",
    "package_sha256": PACKAGE_SHA,
    "stage_plan_sha256": sha(plan_raw),
    "source_root": str(source),
    "payload_prefix": PREFIX,
    "file_count": len(plan["files"]),
    "original_count_preserved": len(plan["materialized_originals_to_preserve"]),
    "payload_read_only_permissions": True,
    "runtime_compatibility": plan["runtime_compatibility"],
    "prepare_executed": False,
    "runtime_cas_created": False,
}
receipt = {
    "schema": "genesis-s2-staging-failure-reconciliation/v1",
    "recorded_at": datetime.now(timezone.utc).isoformat(),
    "native_package_sha256": PACKAGE_SHA,
    "stage_plan_sha256": sha(plan_raw),
    "failure_receipt": "evidence/final-staging-first-attempt-failure.json",
    "failure_receipt_sha256": sha((ROOT / "deliverable/evidence/final-staging-first-attempt-failure.json").read_bytes()),
    "utility_sha256": sha(Path(__file__).read_bytes()),
    "action": "Copied the exact retained temporary payload into the exclusive final destination and reverified every planned file and materialized original.",
    "temporary_payload_preserved": str(TEMPORARY),
    "retained_temporary_file_count": len(expected_temporary_files),
    "resolved_file_count": len(plan["files"]),
    "originals_preserved": len(plan["materialized_originals_to_preserve"]),
    "all_final_and_retained_temporary_payload_bytes_equal": True,
    "all_planned_file_hashes_match": True,
    "runtime_or_product_tests_executed": False,
    "cas_exists": False,
    "runtime_compatibility": plan["runtime_compatibility"],
}
write_new(OPERATION / "staging-reconciliation.json", encoded(receipt))
write_new(OPERATION / "sealed.json", encoded(seal))
os.chmod(OPERATION / "stage-plan.json", 0o444)
os.chmod(OPERATION / "sealed.json", 0o444)
write_new(ROOT / "deliverable/evidence/final-staging-reconciliation.json", encoded(receipt))
print(json.dumps({"status": "STAGED_SEALED", "files": len(plan["files"]), "originals_preserved": len(plan["materialized_originals_to_preserve"]), "retained_failed_payload_files": len(expected_temporary_files), "package_sha256": PACKAGE_SHA, "prepare_executed": False}, indent=2))
