from pathlib import Path
import json, hashlib, collections

B=Path('/workspace/scratch/992c54067adf/genesis-s2/producers/app-session')
PIN='1cde2ff7a71bcf7aecb5d030917b577165135d38'
TREE=Path('/workspace/scratch/992c54067adf/genesis-s2/deliverable/inputs/app-session-tree.json')
assigned={x['path']:x for x in json.loads(TREE.read_text())}
current=json.loads((B/'sources.json').read_text())
if (B/'capture-attempts.json').exists():
    original=json.loads((B/'capture-attempts.json').read_text())
else:
    original=current
    (B/'capture-attempts.json').write_text(json.dumps(original,ensure_ascii=False,indent=2)+'\n')
witnesses=json.loads((B/'read-witnesses.json').read_text())
replacement={
 'packages/app-shell/src/orchestra/live/provider.tsx':['packages/app-shell/src/orchestra/live/commands.tsx','packages/app-shell/src/orchestra/chapters/flight-engineer/run.ts'],
 'packages/app-shell/src/components/settings-v2/appearance.tsx':['packages/app-shell/src/components/settings-v2/general-controllers.ts'],
 'packages/app-shell/src/i18n/orchestra-chapters/en.ts':['packages/app-shell/src/i18n/orchestra-chapters/agents.ts'],
 'packages/server/src/handlers/sessions.ts':['packages/server/src/handlers/session.ts'],
 'packages/app-shell/src/components/prompt-input.tsx':['packages/app-shell/src/components/prompt-input-v2.tsx'],
 'packages/app-shell/src/pages/session/v2/composer-prompt.tsx':['packages/app-shell/src/components/prompt-input-v2.tsx','packages/app-shell/src/components/prompt-input/submit.ts'],
 'packages/app-shell/src/orchestra/chapters/rag-studio/transport.ts':['packages/app-shell/src/orchestra/chapters/rag-studio/files.tsx','packages/app-shell/src/orchestra/chapters/rag-studio/question.tsx','packages/app-shell/src/orchestra/chapters/rag-studio/maintain.tsx'],
}
records=[];failures=[]
for raw in original['records']:
    r=dict(raw);p=r['path']
    if r.get('status')!='captured':
        response_path=r.get('capture_file')
        batch=json.loads((B/response_path).read_text())
        index,item=next((i,x) for i,x in enumerate(batch) if x['path']==p)
        r['original_connector_response_pointer']={'file':response_path,'array_index':index}
        r['original_error_response']=item.get('value',item.get('reason'))
        r['commit']=PIN
        r['assigned_tree_contains_path']=p in assigned
        if p.startswith('packages/app-shell/'):
            assert p not in assigned
            r['availability_assessment']='Confirmed absent guessed path in the complete assigned app-shell tree at the pin; this is not an unavailable existing implementation.'
        else:
            r['availability_assessment']='Connector returned no usable body for this guessed path. The assigned tree does not cover this package, so this packet does not independently establish whole-tree absence.'
        r['resolved_source_paths']=replacement.get(p,['AGENTS.md'] if p.endswith('/AGENTS.md') else [])
        r['semantic_effect']='No critical runtime claim depends on the failed guessed path. Correct implementation paths or inherited root authority were captured; package-local missing authority is not invented.'
        failures.append(r)
        continue
    body=(B/r['local_capture_file']).read_bytes()
    assert len(body)==r['byte_length']
    assert hashlib.sha256(body).hexdigest()==r['sha256']
    assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==r['git_blob_sha']
    r['assigned_population_member']=p in assigned
    if p in assigned:
        assert r['git_blob_sha']==assigned[p]['sha']
        r['assigned_tree_blob_verified']=True
    if p.endswith(('.webp','.jpg','.png')):
        r['read_scope']={'kind':'binary-structure','witness_file':'binary-inspection.json','limit':'Decoded image format/dimensions/mode and byte identity; not a visual or authorship review.'}
    else:
        line_count=len(body.decode('utf-8').splitlines())
        r['line_count']=line_count
        intervals=[]
        for lo,hi in sorted(witnesses.get(p,[])):
            assert 1<=lo<=hi<=line_count
            if intervals and lo<=intervals[-1][1]+1:intervals[-1][1]=max(intervals[-1][1],hi)
            else:intervals.append([lo,hi])
        r['read_scope']={'kind':'selected-text-spans','logged_requested_ranges':intervals,'witness_file':'read-witnesses.json' if intervals else None,'limit':'Logged bounds record requested inspection windows, not a guarantee that a long tool output was entirely displayed. Earlier reads preceded the range logger; source-grounded narrative and exact decisive excerpts identify relied-on spans. No whole-file audit is claimed.'}
        if p.endswith('.svg'):
            r['read_scope']['kind']='vector-header-and-bytes'
            r['read_scope']['limit']='SVG header, approved-asset note and byte identity inspected; no rendered visual comparison.'
    records.append(r)
assert len(records)==251 and len({r['path'] for r in records})==251
assert len(failures)==10
assert all(p in {r['path'] for r in records} for f in failures for p in f['resolved_source_paths'])
result={
 'schema':'genesis-source-captures/v2','unit':'app-session','repository':'gustavomhss/hugr-orchestra','source_commit':PIN,
 'protocol_commit':'ee2521a5b966bd505cc95bd1c733e09e12f33531','successful_captures':len(records),
 'assigned_source_captures':sum(r['assigned_population_member'] for r in records),'boundary_source_captures':sum(not r['assigned_population_member'] for r in records),
 'hash_method':'Python hashlib.sha256(exact decoded content bytes); Git SHA-1 over b"blob "+decimal byte length+b"\\0"+content bytes. All 251 match connector Git blob identity; 236 assigned captures additionally match frozen input tree.',
 'original_attempt_ledger':'capture-attempts.json','original_connector_responses':'captures/batch-01.json through captures/batch-09.json; full responses retained unchanged',
 'failed_attempts_are_not_source_captures':True,'failed_attempt_count':len(failures),
 'failed_attempts':failures,'records':records,
 'external_maintenance_guidance':{'file':'captures/playwright-guidance.json','role':'Official current Playwright guidance required by e2e AGENTS; not pinned repository evidence and not a product execution result.'},
}
(B/'sources.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['successful_captures','assigned_source_captures','boundary_source_captures','failed_attempt_count']}))
