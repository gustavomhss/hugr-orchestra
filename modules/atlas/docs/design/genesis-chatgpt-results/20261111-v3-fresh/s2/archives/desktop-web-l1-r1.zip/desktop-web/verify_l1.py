from pathlib import Path
import collections, hashlib, json, re

ROOT=Path('/workspace/scratch/992c54067adf/genesis-s2/producers/desktop-web')
INPUT=Path('/workspace/scratch/992c54067adf/genesis-s2/deliverable/inputs/desktop-web-tree.json')
SOURCE='1cde2ff7a71bcf7aecb5d030917b577165135d38'
PROTOCOL='ee2521a5b966bd505cc95bd1c733e09e12f33531'
tree=json.loads(INPUT.read_text()); original={x['path']:x for x in tree}
coverage=json.loads((ROOT/'coverage.json').read_text())
sources=json.loads((ROOT/'sources.json').read_text())
entries=coverage['entries']; mapped={x['path']:x for x in entries}
assert len(entries)==len(mapped)==len(tree)==532
assert mapped.keys()==original.keys()
for p,e in original.items():
    for k,v in e.items(): assert mapped[p][k]==v,(p,k)
assert coverage['input_sha256']==hashlib.sha256(INPUT.read_bytes()).hexdigest()
assert coverage['source_commit']==SOURCE and coverage['protocol_commit']==PROTOCOL
assert sources['source_commit']==SOURCE and sources['protocol_commit']==PROTOCOL
read={x['path']:x for x in sources['sources']}
captured=sources['sources']+sources['captured_not_directly_inspected']
assert len(captured)==len({x['path'] for x in captured})==193
capture_bytes=0
for e in captured:
    raw=(ROOT/e['local_capture_file']).read_bytes()
    raw.decode('utf-8')
    assert e['commit']==SOURCE
    assert len(raw)==e['byte_length']
    assert hashlib.sha256(raw).hexdigest()==e['sha256']
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert blob==e['git_blob_sha']
    response=json.loads((ROOT/e['connector_response_file']).read_text())
    body=response['structuredContent']
    assert body['sha']==blob and body['content'].encode('utf-8')==raw
    if e['path'] in original:
        assert original[e['path']]['sha']==blob
        assert original[e['path']]['size']==len(raw)
    lines=raw.decode().splitlines()
    assert all(1<=a<=b<=len(lines) for a,b in e.get('selected_line_ranges',[]))
    capture_bytes+=len(raw)

family_counts=collections.Counter(x['family'] for x in entries)
assert set(family_counts)=={f['id'] for f in coverage['families']}
for f in coverage['families']:
    assert family_counts[f['id']]==f['entry_count']
    assert sum(f['depth_counts'].values())==f['entry_count']
for e in entries:
    assert e['evidence_depth'] in ('inspected','family-supported','metadata-only')
    assert e['representative_source_paths']
    for p in e['representative_source_paths']: assert p in read,(e['path'],p)
    assert (e['path'] in read)==(e['evidence_depth']=='inspected')

l1=(ROOT/'l1.md').read_text()
prefix={'M':'apps/desktop/src/main','R':'apps/desktop/src/renderer','P':'apps/desktop/src/preload','H':'apps/desktop/resources/linux/app-dock-accessibility'}
citation_count=0
for token in re.findall(r'`([^`]+)`',l1):
    if not re.match(r'^(M|R|P|H|apps|docs|\.orchestra)/',token): continue
    if token.endswith('/'): continue  # Explicit path-alias definitions, not file citations.
    path,*parts=token.split(':',1)
    lead=path.split('/')[0]
    if lead in prefix: path=prefix[lead]+path[len(lead):]
    assert path in read,('unread citation',path)
    if parts:
        total=len((ROOT/read[path]['local_capture_file']).read_text().splitlines())
        for span in parts[0].split(','):
            match=re.fullmatch(r'(\d+)(?:[–-](\d+))?',span)
            assert match,(path,span)
            a=int(match[1]);b=int(match[2] or a)
            assert 1<=a<=b<=total,(path,a,b,total)
    citation_count+=1

evidence=(ROOT/'decisive-evidence.md').read_text()
index=json.loads((ROOT/'evidence-index.json').read_text())
for e in index:
    raw=(ROOT/'sources'/e['path']).read_bytes(); lines=raw.decode().splitlines()
    assert hashlib.sha256(raw).hexdigest()==e['source_sha256']
    expected='\n'.join(f'{i}: {lines[i-1]}' for i in range(e['start_line'],e['end_line']+1))
    assert '```text\n'+expected+'\n```' in evidence,e

artifacts={}
for name in ['l1.md','coverage.json','sources.json','decisive-evidence.md','response.md']:
    raw=(ROOT/name).read_bytes();raw.decode('utf-8')
    artifacts[name]={'byte_length':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
result={
    'schema':'genesis-l1-mechanical-verification/v1','unit':'desktop-web',
    'source_commit':SOURCE,'protocol_commit':PROTOCOL,
    'scope':'Artifact accounting, UTF-8/source hashes, original connector body equivalence and citation/excerpt consistency only. This is not product testing or semantic acceptance.',
    'exact_population_entries':len(entries),'family_count':len(family_counts),
    'depth_counts':dict(collections.Counter(x['evidence_depth'] for x in entries)),
    'verified_source_capture_count':len(captured),'verified_source_bytes':capture_bytes,
    'read_source_count':len(read),'captured_not_directly_inspected_count':len(captured)-len(read),
    'l1_word_count':len(l1.split()),'l1_source_citation_count':citation_count,
    'decisive_evidence_sections':len({x['evidence_id'] for x in index}),
    'decisive_source_clips':len(index),
    'decisive_source_lines':sum(e['end_line']-e['start_line']+1 for e in index),
    'artifact_hashes':artifacts,'mechanical_consistency':'verified',
    'product_tests_run':False,'product_runtime_or_build_run':False,'remote_mutation':False,
    'remaining_limits':['Representative family coverage is not individual-file behavioral review.','OS/provider/native integration behavior was not executed.','Unsuccessful extra pt.ts lookup is outside the assigned population and retained as a capture error.']}
(ROOT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['artifact_hashes','remaining_limits']},ensure_ascii=False,indent=2))
