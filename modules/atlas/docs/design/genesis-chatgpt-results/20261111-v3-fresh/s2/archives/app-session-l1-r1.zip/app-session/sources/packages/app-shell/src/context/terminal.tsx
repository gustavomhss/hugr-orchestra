import { createStore, produce } from "solid-js/store"
import { createSimpleContext } from "@orchestra/ui/context"
import { batch, createEffect, createMemo, createRoot, on, onCleanup } from "solid-js"
import { useParams } from "@solidjs/router"
import { useSDK, type DirectorySDK } from "./sdk"
import { useLanguage } from "./language"
import { usePlatform } from "./platform"
import { useServerSDK } from "./server-sdk"
import { base64Encode } from "@orchestra/core/util/encode"
import { defaultTitle, titleNumber } from "./terminal-title"
import { Persist, persisted } from "@/utils/persist"
import { showToast } from "@/utils/toast"
import { describeError, formatServerError } from "@/utils/server-errors"
import { ScopedKey, ServerScope, type ServerScope as ServerScopeValue } from "@/utils/server-scope"

export type LocalPTY = {
  id: string
  title: string
  titleNumber: number
  rows?: number
  cols?: number
  buffer?: string
  scrollY?: number
  cursor?: number
  // Set on an agent's tab when its command ended.
  exitCode?: number
}

export type TerminalCreateResult = { status: "created"; id: string } | { status: "failed"; error?: unknown }

const WORKSPACE_KEY = "__workspace__"
const MAX_TERMINAL_SESSIONS = 20

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
}

function text(value: unknown) {
  return typeof value === "string" ? value : undefined
}

function num(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) ? value : undefined
}

/** A pty the server no longer has is already closed, so closing it again is not a failure. */
export function isTerminalGoneError(error: unknown) {
  if (!record(error)) return false
  if (error._tag === "PtyNotFoundError") return true
  return error instanceof Error && record(error.cause) && error.cause.status === 404
}

function numberFromTitle(title: string) {
  return titleNumber(title, MAX_TERMINAL_SESSIONS)
}

function pty(value: unknown): LocalPTY | undefined {
  if (!record(value)) return

  const id = text(value.id)
  if (!id) return

  const title = text(value.title) ?? ""
  const number = num(value.titleNumber)
  const rows = num(value.rows)
  const cols = num(value.cols)
  const buffer = text(value.buffer)
  const scrollY = num(value.scrollY)
  const cursor = num(value.cursor)
  const exitCode = num(value.exitCode)

  return {
    id,
    title,
    titleNumber: number && number > 0 ? number : (numberFromTitle(title) ?? 0),
    ...(rows !== undefined ? { rows } : {}),
    ...(cols !== undefined ? { cols } : {}),
    ...(buffer !== undefined ? { buffer } : {}),
    ...(scrollY !== undefined ? { scrollY } : {}),
    ...(cursor !== undefined ? { cursor } : {}),
    ...(exitCode !== undefined ? { exitCode } : {}),
  }
}

export function migrateTerminalState(value: unknown) {
  if (!record(value)) return value

  const seen = new Set<string>()
  const all = (Array.isArray(value.all) ? value.all : []).flatMap((item) => {
    const next = pty(item)
    if (!next || seen.has(next.id)) return []
    seen.add(next.id)
    return [next]
  })

  const active = text(value.active)

  return {
    active: active && seen.has(active) ? active : all[0]?.id,
    all,
  }
}

export function getWorkspaceTerminalCacheKey(dir: string, scope: ServerScopeValue = ServerScope.local) {
  return ScopedKey.from(scope, dir, WORKSPACE_KEY)
}

export function getLegacyTerminalStorageKeys(dir: string, legacySessionID?: string) {
  if (!legacySessionID) return [`${dir}/terminal.v1`]
  return [`${dir}/terminal/${legacySessionID}.v1`, `${dir}/terminal.v1`]
}

type TerminalSession = ReturnType<typeof createWorkspaceTerminalSession>

type TerminalCacheEntry = {
  value: TerminalSession
  dispose: VoidFunction
}

const caches = new Set<Map<string, TerminalCacheEntry>>()

const trimTerminal = (pty: LocalPTY) => {
  if (!pty.buffer && pty.cursor === undefined && pty.scrollY === undefined) return pty
  return {
    ...pty,
    buffer: undefined,
    cursor: undefined,
    scrollY: undefined,
  }
}

// The server owns a PTY's title and size, so a local edit must reach it or it reverts on the next load.
export function updateServerPty(
  api: Pick<DirectorySDK["api"]["pty"], "update">,
  location: { directory: string },
  pty: Partial<LocalPTY> & { id: string },
) {
  return api.update({
    ptyID: pty.id,
    location,
    title: pty.title,
    size: pty.cols && pty.rows ? { rows: pty.rows, cols: pty.cols } : undefined,
  })
}

// Titles the server gives to terminals that run an agent's command (see AgentTerminal in core).
const AGENT_TAB_PREFIX = "agent: "
const LONG_COMMAND_MS = 10_000

function terminalPersistTarget(scope: ServerScopeValue, dir: string, legacy?: string[]) {
  return Persist.serverWorkspace(scope, dir, "terminal", legacy)
}

function createWorkspaceTerminalSession(
  sdk: DirectorySDK,
  dir: string,
  scope: ServerScopeValue,
  legacySessionID?: string,
  notifyFailure?: (action: "create" | "close", error: unknown) => void,
  notifyFinished?: (title: string, exitCode: number) => void,
) {
  const location = { directory: sdk.directory }
  const legacy = scope === ServerScope.local ? getLegacyTerminalStorageKeys(dir, legacySessionID) : []

  const [store, setStore, _, ready] = persisted(
    {
      ...terminalPersistTarget(scope, dir, legacy),
      migrate: migrateTerminalState,
    },
    createStore<{
      active?: string
      all: LocalPTY[]
    }>({
      all: [],
    }),
  )
  const [ui, setUi] = createStore({
    focus: undefined as { request: number; id?: string; pending: boolean } | undefined,
  })
  const focus = { request: 0 }

  const requestFocus = (id?: string, pending = false) => {
    focus.request += 1
    setUi("focus", { request: focus.request, id, pending })
    return focus.request
  }

  const focusRequested = (id?: string) => {
    if (!id) return false
    if (!ui.focus || ui.focus.pending) return false
    return !ui.focus.id || ui.focus.id === id
  }

  const consumeFocus = (id: string) => {
    if (!focusRequested(id)) return
    setUi("focus", undefined)
  }

  const cancelFocus = (request?: number) => {
    if (request !== undefined && ui.focus?.request !== request) return
    setUi("focus", undefined)
  }

  if (typeof document !== "undefined") {
    const cancelOnOutsideFocus = (event: FocusEvent) => {
      if (!ui.focus) return
      if (!(event.target instanceof Element)) return
      if (event.target.closest("#terminal-panel")) return
      cancelFocus()
    }
    document.addEventListener("focusin", cancelOnOutsideFocus)
    onCleanup(() => document.removeEventListener("focusin", cancelOnOutsideFocus))
  }

  const pickNextTerminalNumber = () => {
    const existingTitleNumbers = new Set(
      store.all.flatMap((pty) => {
        const direct = Number.isFinite(pty.titleNumber) && pty.titleNumber > 0 ? pty.titleNumber : undefined
        if (direct !== undefined) return [direct]
        const parsed = numberFromTitle(pty.title)
        if (parsed === undefined) return []
        return [parsed]
      }),
    )

    return (
      Array.from({ length: existingTitleNumbers.size + 1 }, (_, index) => index + 1).find(
        (number) => !existingTitleNumbers.has(number),
      ) ?? 1
    )
  }

  const removeExited = (id: string) => {
    const all = store.all
    const index = all.findIndex((x) => x.id === id)
    if (index === -1) return
    const active = store.active === id ? (index === 0 ? all[1]?.id : all[0]?.id) : store.active
    batch(() => {
      setStore("active", active)
      setStore(
        "all",
        produce((draft) => {
          draft.splice(index, 1)
        }),
      )
    })
  }

  // A command the agent runs gets its own tab, started by the server rather than by this client.
  const isAgentTab = (title?: string) => title?.startsWith(AGENT_TAB_PREFIX) === true
  // When each agent command was seen starting; in memory only, since a reload ends the wait for its news.
  const started = new Map<string, number>()

  const unsub = sdk.event.on("pty.exited", (event: { properties: { id: string; exitCode?: number } }) => {
    // An agent's tab stays after its command ends, so the owner can read what ran; closing it removes it.
    const index = store.all.findIndex((x) => x.id === event.properties.id)
    if (index >= 0 && isAgentTab(store.all[index]?.title)) {
      const exitCode = event.properties.exitCode
      if (exitCode !== undefined) setStore("all", index, "exitCode", exitCode)
      const since = started.get(event.properties.id)
      started.delete(event.properties.id)
      // A long command that ends where nobody is looking is the one worth interrupting for.
      const unseen = typeof document !== "undefined" && document.hidden ? true : store.active !== event.properties.id
      if (exitCode !== undefined && since !== undefined && Date.now() - since >= LONG_COMMAND_MS && unseen)
        notifyFinished?.(store.all[index]?.title.slice(AGENT_TAB_PREFIX.length) ?? "", exitCode)
      return
    }
    removeExited(event.properties.id)
  })
  onCleanup(unsub)

  const unsubCreated = sdk.event.on("pty.created", (event: { properties: { info: { id: string; title: string; exitCode?: number } } }) => {
    const info = event.properties.info
    if (!isAgentTab(info.title) || store.all.some((x) => x.id === info.id)) return
    if (info.exitCode === undefined) started.set(info.id, Date.now())
    // A command can end before the event reaches us, and then pty.exited never comes for this tab.
    setStore("all", store.all.length, {
      id: info.id,
      title: info.title,
      titleNumber: 0,
      ...(info.exitCode === undefined ? {} : { exitCode: info.exitCode }),
    })
  })
  onCleanup(unsubCreated)

  const update = (pty: Partial<LocalPTY> & { id: string }) => {
    const index = store.all.findIndex((x) => x.id === pty.id)
    const previous = index >= 0 ? store.all[index] : undefined
    if (index >= 0) {
      setStore("all", index, (item) => ({ ...item, ...pty }))
    }
    updateServerPty(sdk.api.pty, location, pty).catch((error: unknown) => {
      if (previous) {
        const currentIndex = store.all.findIndex((item) => item.id === pty.id)
        if (currentIndex >= 0) setStore("all", currentIndex, previous)
      }
      // A pty that already exited has nothing left to update; the exit event removes its tab.
      if (isTerminalGoneError(error)) return
      console.error(`Failed to update terminal: ${describeError(error)}`)
    })
  }

  const clone = async (id: string) => {
    const index = store.all.findIndex((x) => x.id === id)
    const pty = store.all[index]
    if (!pty) return
    const data = await (async () => {
      return (
        await sdk.api.pty.create({
          location,
          title: pty.title,
        })
      ).data
    })().catch((error: unknown) => {
      console.error(`Failed to clone terminal: ${describeError(error)}`)
      return undefined
    })
    if (!data?.id) return

    const active = store.active === pty.id

    batch(() => {
      setStore("all", index, {
        id: data.id,
        title: data.title ?? pty.title,
        titleNumber: pty.titleNumber,
        buffer: undefined,
        cursor: undefined,
        scrollY: undefined,
        rows: undefined,
        cols: undefined,
      })
      if (active) {
        setStore("active", data.id)
      }
    })
  }

  return {
    ready,
    all: createMemo(() => store.all),
    active: createMemo(() => store.active),
    clear() {
      batch(() => {
        setStore("active", undefined)
        setStore("all", [])
      })
    },
    // Always fulfill: existing fire-and-forget callers must not gain unhandled rejections.
    new(options?: { focus?: boolean }): Promise<TerminalCreateResult> {
      const nextNumber = pickNextTerminalNumber()
      const focusRequest = options?.focus ? requestFocus(undefined, true) : undefined

      // The shell in the active tab reports where it is (OSC 7, kept by the server); a new tab starts there.
      const doCreate = async () => {
        const title = defaultTitle(nextNumber)
        const active = store.active
        const cwd = active
          ? await sdk.api.pty
              .get({ ptyID: active, location })
              .then((result) => result.data.cwd)
              .catch(() => undefined)
          : undefined
        if (!cwd) return (await sdk.api.pty.create({ location, title })).data
        // The directory may be gone by now, and then the shell cannot start in it.
        return (await sdk.api.pty.create({ location, title, cwd }).catch(() => sdk.api.pty.create({ location, title }))).data
      }
      return doCreate()
        .then((data): TerminalCreateResult => {
          const id = data?.id
          if (!id) {
            if (focusRequest !== undefined) cancelFocus(focusRequest)
            notifyFailure?.("create", undefined)
            return { status: "failed" }
          }
          const newTerminal = {
            id,
            title: data?.title ?? defaultTitle(nextNumber),
            titleNumber: nextNumber,
          }
          batch(() => {
            setStore("all", store.all.length, newTerminal)
            setStore("active", id)
            if (focusRequest !== undefined && ui.focus?.request === focusRequest) {
              setUi("focus", { request: focusRequest, id, pending: false })
            }
          })
          return { status: "created", id }
        })
        .catch((error: unknown): TerminalCreateResult => {
          if (focusRequest !== undefined) cancelFocus(focusRequest)
          console.error("Failed to create terminal", error)
          notifyFailure?.("create", error)
          return { status: "failed", error }
        })
    },
    update(pty: Partial<LocalPTY> & { id: string }) {
      update(pty)
    },
    trim(id: string) {
      const index = store.all.findIndex((x) => x.id === id)
      if (index === -1) return
      setStore("all", index, (pty) => trimTerminal(pty))
    },
    trimAll() {
      setStore("all", (all) => {
        const next = all.map(trimTerminal)
        if (next.every((pty, index) => pty === all[index])) return all
        return next
      })
    },
    async clone(id: string) {
      await clone(id)
    },
    bind() {
      return {
        trim(id: string) {
          const index = store.all.findIndex((x) => x.id === id)
          if (index === -1) return
          setStore("all", index, (pty) => trimTerminal(pty))
        },
        update(pty: Partial<LocalPTY> & { id: string }) {
          update(pty)
        },
        async clone(id: string) {
          await clone(id)
        },
      }
    },
    open(id: string) {
      setStore("active", id)
    },
    requestFocus(id?: string) {
      requestFocus(id)
    },
    focusRequested(id?: string) {
      return focusRequested(id)
    },
    consumeFocus(id: string) {
      consumeFocus(id)
    },
    cancelFocus() {
      cancelFocus()
    },
    next() {
      const index = store.all.findIndex((x) => x.id === store.active)
      if (index === -1) return
      const nextIndex = (index + 1) % store.all.length
      setStore("active", store.all[nextIndex]?.id)
    },
    previous() {
      const index = store.all.findIndex((x) => x.id === store.active)
      if (index === -1) return
      const prevIndex = index === 0 ? store.all.length - 1 : index - 1
      setStore("active", store.all[prevIndex]?.id)
    },
    async close(id: string) {
      const index = store.all.findIndex((f) => f.id === id)
      const closed = index === -1 ? undefined : { ...store.all[index] }
      const next = store.active === id ? (index > 0 ? store.all[index - 1]?.id : store.all[1]?.id) : undefined
      if (index !== -1) {
        batch(() => {
          if (store.active === id) setStore("active", next)
          setStore(
            "all",
            produce((all) => {
              all.splice(index, 1)
            }),
          )
        })
      }

      const failed = await (async () => {
        return sdk.api.pty.remove({ ptyID: id, location })
      })().then(
        () => undefined,
        (error: unknown) => ({ error }),
      )
      if (!failed || isTerminalGoneError(failed.error)) return

      console.error(`Failed to close terminal: ${describeError(failed.error)}`)
      // The process is still running on the server, so the tab comes back instead of hiding it.
      if (closed && !store.all.some((x) => x.id === id)) {
        batch(() => {
          setStore(
            "all",
            produce((all) => {
              all.splice(Math.min(index, all.length), 0, closed)
            }),
          )
          if (store.active === next) setStore("active", id)
        })
      }
      notifyFailure?.("close", failed.error)
    },
    move(id: string, to: number) {
      const index = store.all.findIndex((f) => f.id === id)
      if (index === -1) return
      setStore(
        "all",
        produce((all) => {
          all.splice(to, 0, all.splice(index, 1)[0])
        }),
      )
    },
  }
}

export const { use: useTerminal, provider: TerminalProvider } = createSimpleContext({
  name: "Terminal",
  gate: false,
  init: () => {
    const sdk = useSDK()
    const serverSDK = useServerSDK()
    const params = useParams()
    const language = useLanguage()
    const platform = usePlatform()
    const cache = new Map<string, TerminalCacheEntry>()
    const scope = () => serverSDK().scope
    const directory = createMemo(() => base64Encode(sdk().directory))

    caches.add(cache)
    onCleanup(() => caches.delete(cache))

    const disposeAll = () => {
      for (const entry of cache.values()) {
        entry.dispose()
      }
      cache.clear()
    }

    onCleanup(disposeAll)

    const prune = () => {
      while (cache.size > MAX_TERMINAL_SESSIONS) {
        const first = cache.keys().next().value
        if (!first) return
        const entry = cache.get(first)
        entry?.dispose()
        cache.delete(first)
      }
    }

    const notifyFailure = (action: "create" | "close", error: unknown) =>
      showToast({
        variant: "error",
        title: language.t(
          action === "create" ? "orchestra.chat.terminal.createFailed" : "orchestra.chat.terminal.closeFailed",
        ),
        description: error === undefined ? undefined : formatServerError(error, language.t),
      })

    const notifyFinished = (command: string, exitCode: number) => {
      const title =
        exitCode === 0
          ? language.t("orchestra.chat.terminal.agentFinished")
          : language.t("orchestra.chat.terminal.agentFailed", { code: exitCode })
      showToast({ variant: exitCode === 0 ? "success" : "error", title, description: command })
      if (typeof document !== "undefined" && document.hidden) void platform.notify(title, command)
    }

    const loadWorkspace = (dir: string, legacySessionID: string | undefined, serverScope: ServerScopeValue) => {
      // Terminals are workspace-scoped so tabs persist while switching sessions in the same directory.
      const key = getWorkspaceTerminalCacheKey(dir, serverScope)
      const existing = cache.get(key)
      if (existing) {
        cache.delete(key)
        cache.set(key, existing)
        return existing.value
      }

      const entry = createRoot((dispose) => ({
        value: createWorkspaceTerminalSession(sdk(), dir, serverScope, legacySessionID, notifyFailure, notifyFinished),
        dispose,
      }))

      cache.set(key, entry)
      prune()
      return entry.value
    }

    const workspace = createMemo(() => loadWorkspace(directory(), params.id, scope()))

    createEffect(
      on(
        () => ({ dir: directory(), id: params.id, scope: scope() }),
        (next, prev) => {
          if (!prev?.dir) return
          if (next.dir === prev.dir && next.id === prev.id && next.scope === prev.scope) return
          if (next.dir === prev.dir && next.id && next.scope === prev.scope) return
          loadWorkspace(prev.dir, prev.id, prev.scope).trimAll()
        },
        { defer: true },
      ),
    )

    return {
      ready: () => workspace().ready(),
      all: () => workspace().all(),
      active: () => workspace().active(),
      new: (options?: { focus?: boolean }) => workspace().new(options),
      update: (pty: Partial<LocalPTY> & { id: string }) => workspace().update(pty),
      trim: (id: string) => workspace().trim(id),
      trimAll: () => workspace().trimAll(),
      clone: (id: string) => workspace().clone(id),
      bind: () => workspace(),
      open: (id: string) => workspace().open(id),
      requestFocus: (id?: string) => workspace().requestFocus(id),
      focusRequested: (id?: string) => workspace().focusRequested(id),
      consumeFocus: (id: string) => workspace().consumeFocus(id),
      cancelFocus: () => workspace().cancelFocus(),
      close: (id: string) => workspace().close(id),
      move: (id: string, to: number) => workspace().move(id, to),
      next: () => workspace().next(),
      previous: () => workspace().previous(),
    }
  },
})
