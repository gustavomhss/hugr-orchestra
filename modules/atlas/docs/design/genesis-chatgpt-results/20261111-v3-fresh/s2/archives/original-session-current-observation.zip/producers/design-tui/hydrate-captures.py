import base64, hashlib, json, pathlib
ROOT=pathlib.Path("/workspace/scratch/992c54067adf/genesis-s2/producers/design-tui")
PIN="1cde2ff7a71bcf7aecb5d030917b577165135d38"
TREE={x["path"]:x for x in json.loads(pathlib.Path("/workspace/scratch/992c54067adf/genesis-s2/deliverable/inputs/design-tui-tree.json").read_text())}
records=[]; failures=[]
for cap in sorted((ROOT/"captures").glob("*.json")):
    raw=json.loads(cap.read_text())
    s=raw.get("structuredContent")
    if not s or "content" not in s:
        failures.append({"capture":str(cap.relative_to(ROOT)),"error":raw}); continue
    url=s.get("display_url","")
    marker="/blob/"+PIN+"/"
    path=url.split(marker,1)[1] if marker in url else cap.name[:-5].replace("__","/")
    if not path or ".." in pathlib.PurePosixPath(path).parts: raise ValueError(path)
    data=base64.b64decode(s["content"]) if s.get("encoding")=="base64" else s["content"].encode("utf-8")
    dest=ROOT/"sources"/path; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
    blob=hashlib.sha1(("blob "+str(len(data))+"\0").encode()+data).hexdigest()
    expected=s.get("sha")
    if expected and blob!=expected:
        failures.append({"capture":str(cap.relative_to(ROOT)),"path":path,"error":"connector response body does not match advertised blob SHA", "expected":expected,"captured_byte_length":len(data)}); dest.unlink(missing_ok=True); continue
    if path in TREE and blob!=TREE[path]["sha"]: raise ValueError("Assigned tree mismatch "+path)
    records.append({"commit":PIN,"path":path,"git_blob_sha":expected,"verified_git_blob_sha":blob,"sha256":hashlib.sha256(data).hexdigest(),"byte_length":len(data),"local_capture_file":str(dest.relative_to(ROOT)),"connector_response_file":str(cap.relative_to(ROOT)),"in_assigned_population":path in TREE})
for cap in sorted((ROOT/"blob-captures").glob("*.json")):
    raw=json.loads(cap.read_text()); path=cap.name[:-5].replace("__","/"); data=raw["structuredContent"]["content"].encode("utf-8")
    blob=hashlib.sha1(("blob "+str(len(data))+"\0").encode()+data).hexdigest(); expected=TREE[path]["sha"]
    if blob != expected: raise ValueError("Blob transport mismatch "+path)
    dest=ROOT/"sources"/path; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
    records.append({"commit":PIN,"path":path,"git_blob_sha":expected,"verified_git_blob_sha":blob,"sha256":hashlib.sha256(data).hexdigest(),"byte_length":len(data),"local_capture_file":str(dest.relative_to(ROOT)),"connector_response_file":str(cap.relative_to(ROOT)),"in_assigned_population":True,"capture_method":"fetch_blob after empty fetch_file body"})
(ROOT/"sources.json").write_text(json.dumps({"source_commit":PIN,"source_capture_method":"GitHub connector fetch_file at exact ref; original response retained; hashes computed by Python","captures":records,"failed_captures":failures},ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"captures":len(records),"bytes":sum(x["byte_length"] for x in records),"verified_git_blobs":sum(x["git_blob_sha"]==x["verified_git_blob_sha"] for x in records),"failures":len(failures)}))

