# ROOT-ONLY transport seal/request template — {{JUDGE}}

This is a template for the S2 principal to inspect and send only after actual literal delivery of all {{PART_COUNT}} parts. Creating this file does not send it, prove delivery or seal a Git handoff. Preserve real send/receipt observations separately; local byte hashes do not measure host serialization.

## Request to send after complete transport

You are the existing persistent independent reviewer {{JUDGE}}. Remain TOOL-FREE: no tools, browsing, filesystem reads, code execution, new delegates or contact with the peer. Use the supplied literal closure packet and your own prior content reviews at the exact accepted body identities listed. Do not inherit the peer's reasoning. Public two-PASS metadata is supplied, not the peer's raw opinions.

The principal seals literal packet SHA-256 `{{PACKET_SHA256}}`, parts 1 through {{PART_COUNT}}. Confirm that the full numbered packet is available in your context, or identify exact missing parts. Hashes are externally supplied identity receipts, not hashes you have recomputed without tools. Do not assume successful delivery from this template.

Assess this actual evidence bundle against the frozen local contract. The included work file is explicitly a draft; its provisional local states are not prescribed answers. A prior artifact PASS does not establish runtime binding, consumer execution, CI, publication or delivery. An observed failed operation does not by itself establish that all independent local work has been exhausted. No closure verdict is predetermined.

Cover every frozen criterion ID exactly once in your final `criterion_groups`; grouping IDs with the same explicit disposition is permitted, but neither omissions nor duplicates are permitted. Required IDs:
{{CRITERION_IDS}}

For each group, state: (1) satisfied local portions and exact packet evidence/scope; (2) remaining local obligations and their evidence or absence; (3) your local disposition under the registered statuses; and (4) exclusively global complement owned by ROOT. Do not transfer missing S2 readers, cases, gates or production to ROOT. Missing tools/evidence are not a scope reason for N/A.

Explicitly distinguish source/body preservation; thirteen artifact content acceptances; native prepare versus binding/publication; all fourteen real Atlas-only consumer obligations and frozen bounds; S2-U1's declared-graph prediction versus actual update/rebuild/reuse; current scoped CI/compatibility observations versus historical failures; native usage UNKNOWN versus historical GLOBAL_UNRECONCILED; and historical public-write rejections versus any evidenced later authorization/publication. The prediction-only graph is not execution proof. No reserved consumer answer key is supplied.

The separate frozen S2-U1 expectation includes the complete declared build and navigation edges and the two direct input consumers. Independently assess that expected affected set against those declarations and your prior accepted dependency reviews, if the supplied evidence permits it. Explicitly distinguish any validation of the expectation from an actual source mutation, rebuild, result reuse or restoration; none is implied. Identify a concrete missing premise if expectation validation cannot be decided.

Identify every remaining obligation that is independently executable with the evidenced authority/capability, including the concrete next operation and why it is independent. For blocked obligations, give the observed operation/error, exhausted or unproven route, and exact unblock condition. Do not invent permissions, a reader, a new release, costs, successful gates or publication, and do not propose bypassing an actual refusal.

Then assess the true current local closure state using the supplied completion protocol. State whether evidence is sufficient to decide it, whether any mandatory correction/evidence is still needed, and whether any independent authorized local work remains. Keep local completion, global integration, owner acceptance, landing and activation distinct. This assessment does not create a handoff or authorize a remote write. Review the fixed bar; do not reopen nonblocking wording suggestions or demand unrelated optional refinement.

Return one compact original JSON decision (plain JSON or one JSON fence) with:
- `reviewer`: your existing reviewer identity; exact source/protocol/packet identities and transport completeness/limits.
- `criterion_groups`: groups with `ids`, `local_status`, `satisfied_local_portions`, `remaining_local_obligations`, `evidence_refs`, and `global_complement` with owner ROOT. You choose each disposition from the evidence.
- `independently_executable_obligations`: concrete operations with evidence of capability/authority, or an explicitly reasoned empty list.
- `blocked_obligations`: observed blockers and exact unblock conditions.
- `mandatory_findings`: only fixed-bar closure defects or missing decisive evidence, with stable finding IDs.
- `closure_assessment`: your independently assessed state, scope, evidence sufficiency and reason; no default verdict is supplied.
- `acceptance_limits`: what this assessment does not establish.

Do not reproduce the peer's opinions, invent case answers or treat drafting, delegation, plans, predictions, tests alone or incomplete transport as delivery.
