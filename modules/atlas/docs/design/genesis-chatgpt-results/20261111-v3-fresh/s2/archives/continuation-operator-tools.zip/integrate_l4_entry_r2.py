"""Integrate the single authorized L4 entry routing correction, preserving all r1 bytes."""
import copy
import importlib.util
import json
import os
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("native_layer_mechanics", root / "assembly-tools/integrate_native_layer.py")
mechanics = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mechanics)
sha = mechanics.sha
encode = mechanics.encoded
reads = mechanics.Reads(root)
out = root / "deliverable"
prefix = mechanics.PREFIX + "/"
package_raw = reads.read("deliverable/native-package.json")
package = json.loads(package_raw)
artifacts = {a["key"]: a for a in package["artifacts"]}
key = "s2.l4.entry"
old = artifacts[key]
assert old["validity"] == "blocked" and old["semantic_review_refs"] == []
assert old["body"]["sha256"] == "5a91d69ebe975b4c6dff50ad7cb1e76102ed8c35a4d1d43931737d52d6187c67"
assert not (out / "accepted/l4.json").exists()
old_body = reads.read("deliverable/" + old["body"]["path"])
assert sha(old_body) == old["body"]["sha256"]
producer = "later-producers/app-session/l4-entry-r2"
raw = {name: reads.read(producer + "/" + name) for name in mechanics.FILES}
for name in ["body.diff", "delta.md"]:
    raw[name] = reads.read(producer + "/" + name)
for name in ["body.md", "decisive-evidence.md", "response.md", "delta.md"]:
    assert raw[name].decode("utf-8").strip()

def sections(data):
    values = re.split(r"(?m)(?=^## )", data.decode())
    return {v.splitlines()[0]: v for v in values}

before_sections, after_sections = sections(old_body), sections(raw["body.md"])
assert before_sections.keys() == after_sections.keys()
changed_sections = [k for k in before_sections if before_sections[k] != after_sections[k]]
assert changed_sections == ["## Verification and boundaries"], changed_sections
assert all(len(v.encode()) <= 16000 for k, v in after_sections.items() if k.startswith("## "))
assert sha(raw["body.md"]) == "e816f0085875b72b53ed35f4fdba2d04efbfb8130ab13c21b11ca0ebf5dde0b1"
assert len(raw["body.md"]) == 5849
insertion = raw["body.md"][4688:4688 + 544]
assert sha(insertion) == "60d43bd14179f0cc48cb58c5fe045894582c99782ee4f3e8f4a2e4ca7fe851be"
assert raw["body.md"][:4688] + raw["body.md"][4688 + 544:] == old_body
for name in ["sources.json", "dependencies.json", "decisive-evidence.md"]:
    assert raw[name] == reads.read("deliverable/layers/l4/entry/" + name), name
canonical, canonical_manifests = mechanics.canonical_sources(reads, package["source_revision"])
source_manifest = json.loads(raw["sources.json"])
assert source_manifest["source_revision"] == package["source_revision"]
refs, source_checks = [], []
for source in source_manifest["sources"]:
    ref = {k: source[k] for k in ["commit", "path", "git_blob_sha", "sha256"]}
    assert ref["commit"] == package["source_revision"]
    checked = mechanics.verified_source(ref, canonical, reads)
    assert checked is not None
    refs.append(ref)
    source_checks.append(checked)
assert len({r["path"] for r in refs}) == len(refs)
assert refs == old["source_refs"], "Direct source identities must remain unchanged."
dependencies = json.loads(raw["dependencies.json"])
assert dependencies["build"] == [d["key"] for d in old["build_dependencies"]]
assert dependencies["navigation"] == old["navigation"]
consumed, accepted_keys = mechanics.consumed_manifests(SimpleNamespace(layer=4, consumed_manifest=[]), dependencies, reads, package, artifacts)
assert all(k in accepted_keys for k in dependencies["build"])
request_path = "requests/l4-entry-r2-correction.md"
request = reads.read("deliverable/" + request_path)
assert sha(request) == "0dff7a29abe4560a5e4a6eb222cc97d56314a72ed0fc8050b3671d05ca3bfc53"
history = "history/l4-r1/entry"
assert not (out / history).exists()
destination = "layers/l4/entry"
other_artifacts = []
for item in package["artifacts"]:
    if item["key"] == key:
        continue
    data = reads.read("deliverable/" + item["body"]["path"])
    assert sha(data) == item["body"]["sha256"] and len(data) == item["body"]["byte_length"]
    other_artifacts.append({"key": item["key"], "metadata_sha256": sha(encode(item)), "body_sha256": sha(data)})
receipt = {"schema": "genesis-s2-bounded-l4-entry-correction-mechanical/v1", "recorded_at": datetime.now(timezone.utc).isoformat(), "artifact_key": key, "revision": 2, "producer_root": producer, "package_before_sha256": sha(package_raw), "utility_sha256": sha(Path(__file__).read_bytes()), "source_revision": package["source_revision"], "old_body": {"sha256": sha(old_body), "byte_length": len(old_body), "preserved_path": history + "/body.md"}, "body": mechanics.section_receipts(raw["body.md"]), "changed_sections": changed_sections, "unrelated_body_sections_byte_identical": True, "source_checks": source_checks, "new_direct_source_records": [r for r in refs if r not in old["source_refs"]], "new_canonical_captures": 0, "canonical_source_manifests": canonical_manifests, "consumed_layer_manifests": consumed, "other_artifacts_unchanged": other_artifacts, "semantic_status": "PENDING_SAME_PAIR_REEVALUATION", "runtime_status": "NOT_RUN"}
raw["mechanical-receipt.json"] = encode(receipt)
updated = copy.deepcopy(old)
updated["body"] = {"path": destination + "/body.md", "encoding": "utf-8", "byte_length": len(raw["body.md"]), "sha256": sha(raw["body.md"])}
updated["source_refs"] = refs
recipe = {"payload_path": prefix + request_path, "sha256": sha(request)}
updated["recipe_ref"] = recipe
updated["producer_request_ref"] = recipe
updated["producer_response_ref"] = {"payload_path": prefix + destination + "/response.md", "sha256": sha(raw["response.md"])}
updated["authority"]["basis"] = "User-assigned S2 partition; actual native bounded correction at later-producers/app-session/l4-entry-r2; original request, r1 body, primary captures and correction request preserved. Mechanical integration is not semantic acceptance."
updated["gaps"] = ["Awaiting both original judges' actual reevaluation of the exact corrected body.", "Runtime binding, publication, consumers and applicable CI require separate receipts."]
updated["input_keys"] = list(dict.fromkeys(old["input_keys"] + ["file:" + r["path"] for r in refs] + ["file:" + recipe["payload_path"], "file:" + prefix + history + "/body.md"]))
updated["evidence"] = [json.dumps({"payload_path": prefix + destination + "/" + name, "sha256": sha(data)}, sort_keys=True, separators=(",", ":")) for name, data in raw.items() if name != "body.md"]
after = copy.deepcopy(package)
after["artifacts"] = [updated if a["key"] == key else a for a in after["artifacts"]]
assert {k: v for k, v in after.items() if k != "artifacts"} == {k: v for k, v in package.items() if k != "artifacts"}
assert [a for a in after["artifacts"] if a["key"] != key] == [a for a in package["artifacts"] if a["key"] != key]
reads.unchanged()
if "--apply" in sys.argv:
    shutil.copytree(out / destination, out / history)
    snapshot = out / "history" / ("native-package-before-l4-entry-r2-" + sha(package_raw) + ".json")
    assert not snapshot.exists()
    snapshot.write_bytes(package_raw)
    preserved = out / "history/l4-r2-producer-originals/entry"
    assert not preserved.exists()
    preserved.mkdir(parents=True)
    for file in sorted((root / producer).iterdir()):
        if file.is_file():
            (preserved / file.name).write_bytes(file.read_bytes())
    for name, data in raw.items():
        target = out / destination / name
        temporary = target.with_name(target.name + ".r2-new")
        mechanics.write_new(temporary, data)
        os.replace(temporary, target)
    temporary = out / "native-package.r2-new.json"
    mechanics.write_new(temporary, encode(after))
    os.replace(temporary, out / "native-package.json")
    assert (out / history / "body.md").read_bytes() == old_body
    for name, data in raw.items():
        assert (out / destination / name).read_bytes() == data
print(json.dumps({"status": "INTEGRATED_BLOCKED" if "--apply" in sys.argv else "VERIFIED_NOT_APPLIED", "key": key, "body_sha256": sha(raw["body.md"]), "body_bytes": len(raw["body.md"]), "changed_sections": changed_sections, "source_refs": len(refs), "new_direct_source_records": receipt["new_direct_source_records"], "package_after_sha256": sha(encode(after)), "other_artifacts_unchanged": len(other_artifacts), "semantic_acceptance": False, "runtime_execution": False}, indent=2))
