#!/usr/bin/env python3
"""Mechanical L1 evidence validation only. Does not execute product code."""
import base64
import collections
import hashlib
import json
import re
from pathlib import Path

BASE=Path('/workspace/scratch/992c54067adf/genesis-s2/producers/design-tui')
INPUT=Path('/workspace/scratch/992c54067adf/genesis-s2/deliverable/inputs/design-tui-tree.json')
tree=json.loads(INPUT.read_text())
coverage=json.loads((BASE/'coverage.json').read_text())
sources=json.loads((BASE/'sources.json').read_text())
excerpts=json.loads((BASE/'decisive-excerpts.json').read_text())
old=json.loads((BASE/'coverage-v1.json').read_text())
original={v['path']:v for v in tree}
entries={v['path']:v for v in coverage['entries']}
captures={v['path']:v for v in sources['captures']}
assert len(entries)==len(coverage['entries'])==len(original)==2087
assert set(entries)==set(original)
for p,v in original.items():
    assert all(entries[p][k]==val for k,val in v.items()),p
for f in coverage['families']:
    assert f['path_count']==sum(v['family']==f['id'] for v in entries.values())
    assert all(p in captures for p in f['representative_source_paths'])
for p,v in captures.items():
    assert v['commit']=='1cde2ff7a71bcf7aecb5d030917b577165135d38'
    data=(BASE/v['local_capture_file']).read_bytes()
    assert len(data)==v['byte_length']
    assert hashlib.sha256(data).hexdigest()==v['sha256']
    blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert blob==v['git_blob_sha']==v['verified_git_blob_sha'],p
    if p in original: assert blob==original[p]['sha'] and len(data)==original[p]['size'],p
    raw=json.loads((BASE/v['connector_response_file']).read_text())['structuredContent']
    body=base64.b64decode(raw['content']) if raw.get('encoding')=='base64' else raw['content'].encode('utf-8')
    assert body==data,p

decisive=(BASE/'decisive-evidence.md').read_text()
for e in excerpts['excerpts']:
    row=captures[e['path']]
    assert row['git_blob_sha']==e['git_blob_sha']
    lines=(BASE/row['local_capture_file']).read_text().splitlines(keepends=True)
    assert 1<=e['first_line']<=e['last_line']<=len(lines)
    selected=''.join(lines[e['first_line']-1:e['last_line']]).rstrip('\n')
    assert selected in decisive,(e['path'],e['first_line'])

# Validate every ordinary path:line citation. Brace-group path citations are
# separately expanded and checked for captured file existence below.
l1=(BASE/'l1.md').read_text()
checked=[]
for token in re.findall(r'`([^`]+)`',l1):
    if ':' not in token or not re.search(r':\d',token): continue
    path,spans=token.split(':',1)
    assert path in captures,('citation path',path)
    count=len((BASE/captures[path]['local_capture_file']).read_text().splitlines())
    for span in spans.split(','):
        nums=[int(x) for x in re.findall(r'\d+',span)]
        assert nums and min(nums)>=1 and max(nums)<=count,(path,span,count)
    checked.append(token)

grouped=[]
for token in re.findall(r'`([^`]+)`',l1):
    if '{' not in token: continue
    m=re.fullmatch(r'(.*?)\{([^}]+)\}(.*)',token)
    assert m,token
    for name in m.group(2).split(','):
        p=m.group(1)+name+m.group(3)
        assert p in captures,('group citation',p)
        grouped.append(p)

assert (BASE/'sources/schema/theme.json').read_bytes()==(BASE/'sources/packages/ui/src/theme/desktop-theme.schema.json').read_bytes()
required=['l1.md','coverage.json','sources.json','decisive-evidence.md','response.md']
for name in required:
    data=(BASE/name).read_bytes()
    assert data and data.decode('utf-8')

depth=dict(collections.Counter(v['evidence-depth'] for v in entries.values()))
assert depth==coverage['depth_counts']
remaining=[p for p,v in entries.items() if v['evidence-depth']=='metadata-only']
assert all(p.startswith('docs/images/readme/') or p=='packages/ui/LICENSE' or p.startswith('packages/ui/src/components/app-icons/') for p in remaining)
closed=[v['path'] for v in old['entries'] if v['family'] in ['tui-auxiliary-unread','tui-demo-replay-unread','ui-context-unread']]
assert len(closed)==31 and all(entries[p]['evidence-depth']=='inspected' for p in closed)
word_count=len(l1.split())
assert 2500<=word_count<=4500,word_count

result={
 'unit':'design-tui','layer':'L1','validation_kind':'mechanical artifact checks only; no product code executed',
 'source_commit':coverage['source_commit'],'protocol_commit':coverage['protocol_commit'],
 'assigned_paths':len(original),'covered_paths':len(entries),'unique_paths':len(entries),
 'original_tree_fields_preserved':True,'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),
 'families':len(coverage['families']),'depth_counts':depth,
 'source_captures':len(captures),'verified_git_blobs':len(captures),'verified_sha256':len(captures),
 'source_bytes':sum(v['byte_length'] for v in captures.values()),
 'original_connector_bodies_match':True,
 'desktop_schema_mirror_byte_identical':True,
 'tui_schema_bytes':captures['schema/tui.json']['byte_length'],
 'observer_limit_bytes_reported_by_controller':256000,
 'tui_schema_source_available':True,'tui_schema_observer_import_exceeds_reported_limit':True,
 'initial_empty_schema_fetch_recovered':True,
 'verbatim_slices_checked':len(excerpts['excerpts']),
 'quoted_source_lines':excerpts['quoted_source_lines'],
 'ordinary_line_citations_checked':len(checked),'grouped_file_citations_checked':len(grouped),
 'l1_whitespace_word_count':word_count,'required_files_utf8_nonempty':required,
 'v1_implementation_entries_closed':len(closed),
 'remaining_metadata_only_paths':remaining,
 'product_tests_executed':False,'builds_executed':False,'generators_executed':False,
 'native_or_browser_execution':False,'remote_mutations':False,
 'required_file_hashes':{name:hashlib.sha256((BASE/name).read_bytes()).hexdigest() for name in required},
 'result':'PASS: mechanical evidence integrity only; semantic judgment pending'}
(BASE/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
