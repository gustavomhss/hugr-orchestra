from pathlib import Path
import json, hashlib

ROOT=Path('/workspace/scratch/992c54067adf/genesis-s2/producers/desktop-web')
M='apps/desktop/src/main/'
H='apps/desktop/resources/linux/app-dock-accessibility/'
specs=[
 ('Owned readiness gates initialization','The actual ordering awaits health before publishing credentials; renderer commentary does not override it.',[(M+'index.ts',467,475)]),
 ('Stable-exit restart discrepancy','Static inference: a stable exit sets failures=0, then indexes BACKOFF[-1], reaching the undefined branch. This was not reproduced at runtime.',[(M+'owned-serve.ts',76,86)]),
 ('Enforced versus report-only CSP','The fuller policy is declared separately from the enforced safe subset.',[(M+'renderer-origin.ts',25,45)]),
 ('General IPC origin wrapper','This registration wrapper checks sender-frame origin; separate registration modules must be inspected separately.',[(M+'ipc.ts',69,82)]),
 ('Direct live and WSL registration','These handlers register directly and validate arguments where shown; no general origin wrapper appears in these registrations. Reachability/exploitability is not established.',[(M+'live-ipc.ts',29,40),(M+'wsl/ipc.ts',43,55)]),
 ('Draft buffering and blob ownership','These are implementation operations, not an executed database receipt.',[(M+'draft-store.ts',42,76)]),
 ('WAL test negative control','Read but unexecuted test: a copied main file misses newer WAL-backed data. Test code is not a passing result.',[(M+'draft-store.node.test.ts',25,43)]),
 ('Dock view isolation and stale attachment','Remote browser view options and generation-aware attachment guards constrain the visible host boundary.',[(M+'app-dock.ts',237,244),(M+'app-dock-utils.ts',35,44)]),
 ('Fullscreen permission exception','Session policy is not accurately summarized as deny every permission.',[(M+'app-dock-session.ts',117,125)]),
 ('Profile revision contract','Manifest mutation uses expected revision and validates referenced active profiles.',[(M+'app-dock-profile-registry.ts',289,303)]),
 ('Host confirmation of workspace roots','Fresh runtime and process census precede confirmation of helper-proposed roots.',[(M+'app-dock-native-workspace.ts',27,37)]),
 ('Native cancellation test boundary','Unexecuted memory-channel test retains a slot until the original terminal, even after cancel acknowledgment.',[(M+'app-dock-native-client-admission.test.ts',35,58)]),
 ('Native observations and actions are non-atomic','Snapshot and action response bodies explicitly avoid asserting logical identity or a verified effect.',[(H+'snapshot.py',62,66),(H+'actions.py',35,53)]),
 ('Local runtime locator and current session','Source checks local endpoint shape and current session file/process identity; no Docker or guest command ran.',[(M+'app-dock-runtime-backend.ts',97,102),('apps/desktop/resources/linux-runtime/workspace.py',319,333)]),
 ('WSL authenticated health','Positive authenticated body and rejected wrong password are both required.',[(M+'wsl/startup.ts',7,17)]),
 ('Live transcription key storage','The key is read through safeStorage/environment fallback and stored only when encryption is available.',[(M+'live-key.ts',1,27)]),
 ('Response capability and irreversible commit','Owner checks tie the capability to the originating frame; rename submission and unowned temporary-file cleanup have distinct handling.',[(M+'response-download.ts',89,101),(M+'response-download.ts',56,71)]),
 ('CLI cached artifact revalidation','A manifest/hash-named installation is not reused without companion and artifact checks.',[(M+'cli-install.ts',34,55)]),
 ('Shipped runtime resource boundary','Native icons, Python helper and Linux runtime are copied as extraResources outside the application archive.',[('apps/desktop/electron-builder.config.ts',175,191)]),
 ('Updater persisted state and installation','Stored version does not skip the update check; installation requires ready state and stops resources first.',[(M+'updater-controller.ts',82,103)]),
 ('Web token removal','The browser host removes the auth_token query entry from history after extraction.',[('apps/web/src/entry.tsx',99,110)]),
 ('English locale fallback','Representative non-English dictionary branches merge over English rather than replacing it.',[('apps/desktop/src/renderer/i18n/index.ts',114,128)]),
 ('Generated corpus provenance','The generator writes four consolidated documents and per-invariant pages, emitting measured labels from literal test references. No tests run in this excerpt.',[('apps/desktop/docs/corpus/app-dock/generate-corpus.mjs',704,726)]),
 ('Proof setup is not semantic readiness','The development testbed documentation states limits of launch receipts and future package resolution.',[('apps/desktop/test/native/README.md',3,5),('apps/desktop/test/native/README.md',21,24)]),
 ('Main-fiber failure and localization instruction','Observed fallback logs the formatted cause, shows a native error box and exits. The visible title/Logs label are literals; the separate instruction requires typed localization. This is a source/instruction conflict, not an executed failure.',[(M+'index.ts',498,508),('apps/desktop/AGENTS.md',5,9)]),
]
manifest=json.loads((ROOT/'sources.json').read_text())
by={x['path']:x for x in manifest['sources']}
out=['# Decisive L1 evidence — desktop-web','',
     'Source pin: `1cde2ff7a71bcf7aecb5d030917b577165135d38`. Protocol pin: `ee2521a5b966bd505cc95bd1c733e09e12f33531`.',
     '', 'These are bounded verbatim source-line excerpts. The numeric prefixes are added line labels; source text after each prefix is unchanged. Source byte hashes refer to the complete exact capture in `sources/`. Full connector responses remain in `captures/`. Implementation and test excerpts are explicitly distinguished; no product execution is represented.', '']
index=[]
for i,(title,note,clips) in enumerate(specs,1):
    key=f'E{i:02d}'
    out += [f'## {key}. {title}', '', note,'']
    for p,start,end in clips:
        data=(ROOT/'sources'/p).read_bytes()
        rows=data.decode('utf-8').splitlines()
        assert p in by and 1<=start<=end<=len(rows),(p,start,end,len(rows))
        sha=hashlib.sha256(data).hexdigest()
        assert sha==by[p]['sha256']
        out += [f'`{p}:{start}–{end}` · Git blob `{by[p]["git_blob_sha"]}` · SHA-256 `{sha}`','', '```text']
        out += [f'{j}: {rows[j-1]}' for j in range(start,end+1)]
        out += ['```','']
        index.append({'evidence_id':key,'path':p,'start_line':start,'end_line':end,'git_blob_sha':by[p]['git_blob_sha'],'source_sha256':sha})
out += ['## Reading limits','', 'A source check is evidence that the guard/state transition exists at this commit. It is not proof of actual provider behavior, process disappearance, installation integrity, UI outcome, platform permission or a passing test. Historical measured/ready labels and development-only proof recipes remain documentary claims. See `l1.md` for family context and `coverage.json` for every assigned leaf.','']
(ROOT/'decisive-evidence.md').write_text('\n'.join(out))
(ROOT/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'sections':len(specs),'source_clips':len(index),'quoted_source_lines':sum(x['end_line']-x['start_line']+1 for x in index)},indent=2))
