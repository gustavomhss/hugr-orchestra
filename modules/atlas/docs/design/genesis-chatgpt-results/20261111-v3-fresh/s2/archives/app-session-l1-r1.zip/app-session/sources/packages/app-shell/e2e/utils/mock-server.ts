import type { Page, Route } from "@playwright/test"
import { railDefaulted } from "./review-rail"

const emptyList = new Set(["/skill", "/command", "/lsp", "/formatter", "/vcs/status", "/vcs/diff", "/pty/shells"])
const emptyObject = new Set(["/global/config", "/config", "/provider/auth", "/mcp", "/experimental/resource"])

export interface MockServerConfig {
  // Orchestra opens the review rail once per app storage. Mocked pages start after that default unless a
  // spec asks for a fresh profile, so specs that toggle the rail keep exact open/closed oracles.
  freshRail?: boolean
  provider: unknown | (() => unknown)
  integrationMethods?: Record<string, unknown[]>
  onConnectKey?: (input: { integrationID: string; body: unknown }) => void
  onInstanceDispose?: () => void
  directory: string
  project: unknown
  sessions: ({ id: string } & Record<string, unknown>)[]
  pageMessages: (sessionId: string, limit: number, before?: string) => { items: unknown[]; cursor?: string }
  vcsDiff?: unknown[]
  messageDelay?: number
  beforeMessagesResponse?: (input: { sessionID: string; before?: string }) => Promise<void>
  onMessages?: (input: { sessionID: string; before?: string; phase: "start" | "end" }) => void
  message?: (sessionID: string, messageID: string) => unknown
  // V2 per-turn diff (`GET /api/session/:id/message/:messageID/diff`); an unknown turn has none.
  diffs?: (sessionID: string, messageID: string) => unknown[]
  onMessage?: (input: { sessionID: string; messageID: string }) => void
  onPrompt?: (input: { sessionID: string; body: unknown }) => void
  events?: () => unknown[]
  eventRetry?: number
  todos?: (sessionID: string) => unknown[]
  permissions?: unknown[] | (() => unknown[])
  questions?: unknown[] | (() => unknown[])
  fileList?: (path: string) => unknown | Promise<unknown>
  fileContent?: (path: string) => unknown | Promise<unknown>
  findFiles?: (input: { query: string; dirs?: string; limit?: number }) => unknown | Promise<unknown>
  sessionStatus?: Record<string, unknown> | (() => Record<string, unknown>)
  activity?: (period: string) => unknown
  // The host pull request routes; a reply is the HTTP status and JSON body the server would send.
  pullRequests?: {
    list?: (url: URL) => PullRequestReply | Promise<PullRequestReply>
    create?: (input: { url: URL; body: unknown }) => PullRequestReply | Promise<PullRequestReply>
  }
}

export type PullRequestReply = { status: number; body: unknown }

export async function mockOrchestraServer(page: Page, config: MockServerConfig) {
  if (!config.freshRail) await page.addInitScript(railDefaulted)
  const cursors = new Map<string, string>()
  let nextCursor = 0
  const staticRoutes: Record<string, unknown> = {
    "/path": {
      state: config.directory,
      config: config.directory,
      worktree: config.directory,
      directory: config.directory,
      home: "C:/Orchestra",
    },
    "/project": [config.project],
    "/project/current": config.project,
    // Orchestra runs every session on its native maestro agent.
    "/agent": [{ name: "maestro", mode: "primary" }],
    "/vcs": { branch: "main", default_branch: "main" },
    "/session": config.sessions,
  }

  await page.route("**/*", async (route) => {
    const url = new URL(route.request().url())
    const targetPort = process.env.PLAYWRIGHT_SERVER_PORT ?? "4096"
    const appPort = new URL(
      process.env.PLAYWRIGHT_BASE_URL ?? `http://127.0.0.1:${process.env.PLAYWRIGHT_PORT ?? "3000"}`,
    ).port
    if (url.port !== targetPort && url.port !== appPort) return route.fallback()

    const path = url.pathname
    if (path === "/global/event" || path === "/event" || path === "/api/event") {
      const events = config.events?.()
      return sse(
        route,
        path === "/api/event"
          ? [{ id: "evt_mock_connected", type: "server.connected", data: {} }, ...(events?.map(currentEvent) ?? [])]
          : [
              ...(path === "/global/event"
                ? [{ payload: { id: "evt_mock_connected", type: "server.connected", properties: {} } }]
                : []),
              ...(events ?? []),
            ],
        config.eventRetry,
      )
    }
    if (path === "/api/health") return json(route, { healthy: true, version: "2.0.0", pid: 1 })
    if (path === "/experimental/capabilities") return json(route, { backgroundSubagents: true })
    if (path === "/provider")
      return json(route, typeof config.provider === "function" ? config.provider() : config.provider)
    if (path === "/provider/auth") return json(route, config.integrationMethods ?? {})
    const legacyAuth = path.match(/^\/auth\/([^/]+)$/)?.[1]
    if (legacyAuth && route.request().method() === "PUT") {
      config.onConnectKey?.({ integrationID: legacyAuth, body: route.request().postDataJSON() })
      return json(route, true)
    }
    if (path === "/instance/dispose" && route.request().method() === "POST") {
      config.onInstanceDispose?.()
      return json(route, true)
    }
    if (path === "/permission")
      return json(route, typeof config.permissions === "function" ? config.permissions() : (config.permissions ?? []))
    if (path === "/question")
      return json(route, typeof config.questions === "function" ? config.questions() : (config.questions ?? []))
    if (path === "/session/status")
      return json(
        route,
        typeof config.sessionStatus === "function" ? config.sessionStatus() : (config.sessionStatus ?? {}),
      )
    if (path === "/vcs/diff" && config.vcsDiff) return json(route, config.vcsDiff)
    if (path === "/api/fs/list" && config.fileList)
      return json(route, {
        location: location(config),
        data: await config.fileList(url.searchParams.get("path") ?? ""),
      })
    if (path === "/api/fs/read" && config.fileContent) {
      const file = (await config.fileContent(url.searchParams.get("path") ?? "")) as { content?: string }
      return route.fulfill({
        status: 200,
        contentType: "application/octet-stream",
        headers: { "access-control-allow-origin": "*" },
        body: file.content ?? "",
      })
    }
    if (path === "/file" && config.fileList)
      return json(route, await config.fileList(url.searchParams.get("path") ?? ""))
    if (path === "/file/content" && config.fileContent)
      return json(route, await config.fileContent(url.searchParams.get("path") ?? ""))
    if (path === "/find/file" && config.findFiles)
      return json(
        route,
        await config.findFiles({
          query: url.searchParams.get("query") ?? "",
          dirs: url.searchParams.get("dirs") ?? undefined,
          limit: url.searchParams.has("limit") ? Number(url.searchParams.get("limit")) : undefined,
        }),
      )
    if (path === "/api/reference")
      return json(route, {
        location: {
          directory: config.directory,
          project: { id: (config.project as { id?: string }).id, directory: config.directory },
        },
        data: [],
      })
    if (/^\/api\/agent\/[^/]+\/detail$/.test(path))
      return json(route, { location: location(config), data: { tools: [], skills: [], engines: [] } })
    if (path === "/api/agent")
      return json(route, {
        location: location(config),
        data: [
          {
            id: "maestro",
            name: "Maestro",
            mode: "primary",
            hidden: false,
            request: { settings: {}, headers: {}, body: {} },
            permissions: [],
          },
        ],
      })
    if (path === "/api/provider" || path === "/api/model" || path === "/api/model/default") {
      const catalog = currentCatalog(typeof config.provider === "function" ? config.provider() : config.provider)
      const data =
        path === "/api/provider" ? catalog.providers : path === "/api/model" ? catalog.models : catalog.default
      return json(route, { location: location(config), data })
    }
    if (path === "/api/command") return json(route, { location: location(config), data: [] })
    if (path === "/api/mcp") return json(route, { location: location(config), data: [] })
    if (path === "/api/mcp/resource")
      return json(route, { location: location(config), data: { resources: [], templates: [] } })
    const integration = path.match(/^\/api\/integration\/([^/]+)$/)?.[1]
    if (integration && route.request().method() === "GET")
      return json(route, {
        location: location(config),
        data: { id: integration, name: integration, methods: [{ type: "key", label: "API key" }], connections: [] },
      })
    const integrationConnect = path.match(/^\/api\/integration\/([^/]+)\/connect\/key$/)?.[1]
    if (integrationConnect && route.request().method() === "POST") {
      config.onConnectKey?.({ integrationID: integrationConnect, body: route.request().postDataJSON() })
      return route.fulfill({ status: 204, headers: { "access-control-allow-origin": "*" } })
    }
    if (path === "/api/location") return json(route, location(config))
    if (path === "/api/location/paths") return json(route, { home: "C:/Orchestra" })
    if (path === "/api/project") return json(route, [config.project])
    // project.current resolves through the location route; the server has no /api/project/current.
    if (path === "/api/location") return json(route, location(config))
    if (path.startsWith("/api/project/") && route.request().method() === "PATCH") return json(route, config.project)
    if (path === "/api/path")
      return json(route, {
        state: config.directory,
        config: config.directory,
        worktree: config.directory,
        directory: config.directory,
        home: "C:/Orchestra",
      })
    if (path === "/api/permission/request")
      return json(route, {
        location: location(config),
        data: (typeof config.permissions === "function" ? config.permissions() : (config.permissions ?? [])).map(
          currentPermission,
        ),
      })
    if (path === "/api/question/request")
      return json(route, {
        location: location(config),
        data: typeof config.questions === "function" ? config.questions() : (config.questions ?? []),
      })
    if (path === "/api/pull-request" && config.pullRequests) {
      const request = route.request()
      const reply =
        request.method() === "POST"
          ? await config.pullRequests.create?.({ url, body: request.postDataJSON() })
          : request.method() === "GET"
            ? await config.pullRequests.list?.(url)
            : undefined
      if (reply) return json(route, reply.body, undefined, reply.status)
    }
    if (path === "/api/vcs")
      return json(route, { location: location(config), data: { branch: "main", default_branch: "main" } })
    if (path === "/api/vcs/status") return json(route, { location: location(config), data: [] })
    if (path === "/api/vcs/diff") return json(route, { location: location(config), data: config.vcsDiff ?? [] })
    if (path === "/api/pty/shells") return json(route, { location: location(config), data: [] })
    if (path === "/api/config/shells") return json(route, [])
    // The global trust list the MCP page and Settings read; the mock trusts nothing.
    if (path === "/api/trust") return json(route, [])
    if (/^\/api\/pty\/[^/]+\/connect-token$/.test(path))
      return json(route, { location: location(config), data: { ticket: "e2e-ticket", expires_in: 60 } })
    if (emptyObject.has(path)) return json(route, {})
    if (emptyList.has(path)) return json(route, [])
    if (path === "/api/session") {
      const directory = url.searchParams.get("directory")
      const parentID = url.searchParams.get("parentID")
      const limit = Number(url.searchParams.get("limit") ?? 50)
      const offset = Number(url.searchParams.get("cursor") ?? 0)
      const sessions = config.sessions
        .filter((session) => !directory || session.directory === directory)
        .filter((session) => parentID !== "null" || session.parentID === undefined)
        .filter((session) => {
          const search = url.searchParams.get("search")?.toLowerCase()
          return (
            !search ||
            String(session.title ?? "")
              .toLowerCase()
              .includes(search)
          )
        })
      const ordered = url.searchParams.get("order") === "asc" ? sessions.toReversed() : sessions
      // The limit pages roots; a root's child sessions always travel with it.
      const roots = ordered.filter((session) => session.parentID === undefined)
      const page = roots.slice(offset, offset + limit)
      const data = ordered.filter((session) =>
        session.parentID === undefined ? page.includes(session) : page.some((root) => root.id === session.parentID),
      )
      const next = offset + limit < roots.length ? String(offset + limit) : undefined
      return json(route, {
        data: data.map((session) => currentSession(session, config.directory)),
        cursor: { next },
      })
    }
    if (path === "/api/session/active") {
      const statuses = (config.sessionStatus ?? {}) as Record<string, { type?: string }>
      return json(route, {
        data: Object.fromEntries(
          Object.entries(statuses).flatMap(([id, status]) =>
            status.type === "idle" ? [] : [[id, { type: "running" }]],
          ),
        ),
      })
    }
    if (/^\/api\/session\/[^/]+\/shell$/.test(path) && route.request().method() === "POST") {
      return route.fulfill({ status: 204, headers: { "access-control-allow-origin": "*" } })
    }
    const promptMatch = path.match(/^\/api\/session\/([^/]+)\/prompt$/)
    if (promptMatch && route.request().method() === "POST") {
      const body = route.request().postDataJSON()
      config.onPrompt?.({ sessionID: promptMatch[1]!, body })
      return json(route, {
        data: {
          admittedSeq: 1,
          id: body?.id ?? "msg_mock_admitted",
          sessionID: promptMatch[1],
          prompt: body?.prompt ?? { parts: [] },
          delivery: body?.delivery ?? "steer",
          timeCreated: Date.now(),
        },
      })
    }
    if (/^\/api\/session\/[^/]+\/question\/[^/]+\/(reply|reject)$/.test(path) && route.request().method() === "POST") {
      return route.fulfill({ status: 204, headers: { "access-control-allow-origin": "*" } })
    }
    if (/^\/api\/session\/[^/]+\/permission\/[^/]+\/reply$/.test(path) && route.request().method() === "POST") {
      return route.fulfill({ status: 204, headers: { "access-control-allow-origin": "*" } })
    }
    if (/^\/question\/[^/]+\/(reply|reject)$/.test(path) && route.request().method() === "POST") {
      return json(route, true)
    }
    if (/^\/session\/[^/]+\/permissions\/[^/]+$/.test(path) && route.request().method() === "POST") {
      return json(route, true)
    }
    if (
      /^\/api\/session\/[^/]+\/(archive|rename|interrupt|agent|model|revert\/clear|revert\/commit)$/.test(path) &&
      route.request().method() === "POST"
    ) {
      return route.fulfill({ status: 204, headers: { "access-control-allow-origin": "*" } })
    }
    if (/^\/api\/session\/[^/]+$/.test(path) && route.request().method() === "DELETE") {
      return route.fulfill({ status: 204, headers: { "access-control-allow-origin": "*" } })
    }
    if (path in staticRoutes) return json(route, staticRoutes[path])
    // Home's KPI reads; "activity" is a route, not a session ID.
    if (path === "/session/activity") {
      const period = url.searchParams.get("period") ?? "30d"
      return json(route, config.activity?.(period) ?? sessionActivity(config.sessions, period))
    }
    if (path === "/api/activity/session") {
      const period = url.searchParams.get("period") ?? "30d"
      return json(route, {
        location: location(config),
        data: config.activity?.(period) ?? sessionActivity(config.sessions, period),
      })
    }
    if (path === "/vcs/activity")
      return json(route, {
        repository: true,
        since: Number(url.searchParams.get("since") ?? 0),
        until: Number(url.searchParams.get("until") ?? Date.now()),
        totals: { commits: 0, merges: 0, authors: 0, additions: 0, deletions: 0, filesChanged: 0 },
        days: [],
        topPaths: [],
        recent: [],
        ahead: null,
        behind: null,
        truncated: false,
      })
    if (path === "/api/vcs/activity")
      return json(route, {
        location: location(config),
        data: {
          repository: true,
          since: Number(url.searchParams.get("since") ?? 0),
          until: Number(url.searchParams.get("until") ?? Date.now()),
          totals: { commits: 0, merges: 0, authors: 0, additions: 0, deletions: 0, filesChanged: 0 },
          days: [],
          topPaths: [],
          recent: [],
          ahead: null,
          behind: null,
          truncated: false,
        },
      })

    const currentSessionMatch = path.match(/^\/api\/session\/([^/]+)$/)
    if (currentSessionMatch) {
      const session = config.sessions.find((item) => item.id === currentSessionMatch[1])
      if (!session) return json(route, { error: "Session not found" }, undefined, 404)
      return json(route, {
        data: currentSession(session, config.directory),
      })
    }

    const sessionMatch = path.match(/^\/session\/([^/]+)$/)
    if (sessionMatch) {
      const session = config.sessions.find((s) => s.id === sessionMatch[1])
      return json(route, session ?? {})
    }

    const projectMatch = path.match(/^\/project\/([^/]+)$/)
    if (projectMatch) return json(route, config.project)

    const messageMatch = path.match(/^\/session\/([^/]+)\/message\/([^/]+)$/)
    if (messageMatch) {
      config.onMessage?.({ sessionID: messageMatch[1]!, messageID: messageMatch[2]! })
      if (config.messageDelay !== undefined) await new Promise((resolve) => setTimeout(resolve, config.messageDelay))
      const message = config.message?.(messageMatch[1]!, messageMatch[2]!)
      if (message === undefined) return json(route, { error: "Message not found" }, undefined, 404)
      return json(route, message)
    }

    const todoMatch = path.match(/^\/session\/([^/]+)\/todo$/)
    if (todoMatch) return json(route, config.todos?.(todoMatch[1]!) ?? [])
    if (/^\/session\/[^/]+\/(children|diff)$/.test(path)) return json(route, [])

    const currentDiffMatch = path.match(/^\/api\/session\/([^/]+)\/message\/([^/]+)\/diff$/)
    if (currentDiffMatch) return json(route, { data: config.diffs?.(currentDiffMatch[1]!, currentDiffMatch[2]!) ?? [] })

    const currentMessagesMatch = path.match(/^\/api\/session\/([^/]+)\/message$/)
    if (currentMessagesMatch) {
      const token = url.searchParams.get("cursor") ?? undefined
      const before = token ? cursors.get(token) : undefined
      if (token && !before) return json(route, { error: "Invalid cursor" }, undefined, 400)
      config.onMessages?.({ sessionID: currentMessagesMatch[1], before, phase: "start" })
      await config.beforeMessagesResponse?.({ sessionID: currentMessagesMatch[1]!, before })
      if (config.messageDelay !== undefined) await new Promise((resolve) => setTimeout(resolve, config.messageDelay))
      const pageData = config.pageMessages(currentMessagesMatch[1], Number(url.searchParams.get("limit") ?? 50), before)
      config.onMessages?.({ sessionID: currentMessagesMatch[1], before, phase: "end" })
      const cursor = pageData.cursor ? `cursor_${++nextCursor}` : undefined
      if (cursor) cursors.set(cursor, pageData.cursor!)
      return json(route, {
        data: pageData.items.flatMap(currentMessage).reverse(),
        cursor: { next: cursor },
      })
    }

    const messagesMatch = path.match(/^\/session\/([^/]+)\/message$/)
    if (messagesMatch) {
      if (route.request().method() === "POST") {
        config.onPrompt?.({ sessionID: messagesMatch[1]!, body: route.request().postDataJSON() })
        return json(route, { info: {}, parts: [] })
      }
      const token = url.searchParams.get("before") ?? undefined
      const before = token ? cursors.get(token) : undefined
      if (token && !before) return json(route, { error: "Invalid cursor" }, undefined, 400)
      config.onMessages?.({ sessionID: messagesMatch[1], before, phase: "start" })
      await config.beforeMessagesResponse?.({ sessionID: messagesMatch[1]!, before })
      if (config.messageDelay !== undefined) await new Promise((resolve) => setTimeout(resolve, config.messageDelay))
      const limit = Number(url.searchParams.get("limit") ?? 80)
      const pageData = config.pageMessages(messagesMatch[1], limit, before)
      config.onMessages?.({ sessionID: messagesMatch[1], before, phase: "end" })
      if (!pageData.cursor) return json(route, pageData.items)
      const cursor = `cursor_${++nextCursor}`
      cursors.set(cursor, pageData.cursor)
      return json(route, pageData.items, { "x-next-cursor": cursor })
    }

    if (url.port === targetPort && targetPort !== appPort) return json(route, {})
    return route.fallback()
  })
}

// Every root session has one user message on the last day of the period, in UTC days.
export function sessionActivity(sessions: MockServerConfig["sessions"], period: string) {
  const day = 86_400_000
  const end = Math.floor(Date.now() / day) * day + day
  const length = ({ "7d": 7, "30d": 30, "90d": 90 } as Record<string, number>)[period] ?? 1
  const count = Math.min(8, length)
  const start = end - length * day
  const bars = Array.from({ length: count + 1 }, (_, index) => start + Math.floor((index * length) / count) * day)
  const edges = period === "all" ? bars : [start - length * day, ...bars]
  const roots = sessions.filter((session) => !session.parentID)
  const time = (session: (typeof sessions)[number]) => (session.time ?? {}) as { created?: number; updated?: number }
  return {
    period,
    edges,
    days: edges.map((edge) => new Date(edge).toISOString().slice(0, 10)),
    previous: period !== "all",
    activeMs: edges.slice(1).map(() => 0),
    truncated: false,
    sessions: roots.map((session) => ({
      id: session.id,
      title: String(session.title ?? ""),
      parentID: null,
      created: time(session).created ?? 0,
      updated: time(session).updated ?? time(session).created ?? 0,
      additions: null,
      deletions: null,
      files: null,
    })),
    facts: roots.map((session) => ({
      bucket: edges.length - 2,
      sessionID: session.id,
      providerID: null,
      modelID: null,
      user: 1,
      assistant: 0,
      failed: 0,
      tokens: 0,
    })),
  }
}

function location(config: MockServerConfig) {
  return {
    directory: config.directory,
    project: { id: (config.project as { id?: string }).id, directory: config.directory },
  }
}

// Serves a fixture's legacy-shaped provider catalog through the V2 provider, model and default model routes. Only
// connected providers are listed, as the V2 server lists only the providers it can run; a fixture without a
// connected list connects all of them.
function currentCatalog(value: unknown) {
  type LegacyModel = {
    id: string
    name?: string
    family?: string
    status?: string
    attachment?: boolean
    limit?: { context: number; output?: number }
    cost?: { input?: number; output?: number; cache?: { read?: number; write?: number } }
    variants?: Record<string, Record<string, unknown>>
  }
  const catalog = (value ?? {}) as {
    all?: { id: string; name?: string; models?: Record<string, LegacyModel> }[]
    connected?: string[]
    default?: Record<string, string>
  }
  const providers = (catalog.all ?? []).filter((provider) => catalog.connected?.includes(provider.id) ?? true)
  const models = providers.flatMap((provider) =>
    Object.values(provider.models ?? {}).map((model) => ({
      id: model.id,
      modelID: model.id,
      providerID: provider.id,
      name: model.name ?? model.id,
      family: model.family,
      capabilities: { input: model.attachment ? ["text", "image"] : ["text"], output: ["text"], tools: true },
      variants: Object.entries(model.variants ?? {}).map(([id, settings]) => ({ id, settings })),
      time: { released: 1 },
      cost: model.cost
        ? [
            {
              input: model.cost.input ?? 0,
              output: model.cost.output ?? 0,
              cache: { read: model.cost.cache?.read ?? 0, write: model.cost.cache?.write ?? 0 },
            },
          ]
        : [],
      status: model.status ?? "active",
      enabled: true,
      limit: { context: model.limit?.context ?? 200_000, output: model.limit?.output ?? 8192 },
    })),
  )
  // The fixture default is either one { providerID, modelID } pair or a model per provider.
  const preferred = catalog.default?.providerID
    ? [{ providerID: catalog.default.providerID, modelID: catalog.default.modelID }]
    : Object.entries(catalog.default ?? {}).map(([providerID, modelID]) => ({ providerID, modelID }))
  const defaults = preferred.flatMap((pick) =>
    models.filter((model) => model.providerID === pick.providerID && model.id === pick.modelID),
  )
  return {
    providers: providers.map((provider) => ({ id: provider.id, name: provider.name ?? provider.id, settings: {} })),
    models,
    default: defaults[0] ?? models[0] ?? null,
  }
}

function currentPermission(value: unknown) {
  const permission = value as Record<string, unknown>
  if (permission.action) return permission
  const tool = permission.tool as { messageID?: string; callID?: string } | undefined
  return {
    id: permission.id,
    sessionID: permission.sessionID,
    action: permission.permission,
    resources: permission.patterns ?? [],
    save: permission.always,
    metadata: permission.metadata,
    source:
      tool?.messageID && tool.callID ? { type: "tool", messageID: tool.messageID, callID: tool.callID } : undefined,
  }
}

export function currentSession(session: { id: string } & Record<string, unknown>, fallbackDirectory?: string) {
  const time = session.time && typeof session.time === "object" ? session.time : {}
  return {
    id: session.id,
    parentID: session.parentID,
    projectID: session.projectID ?? "project",
    agent: session.agent ?? "build",
    model: session.model ?? { id: "mock-model", providerID: "mock-provider" },
    cost: session.cost ?? 0,
    tokens: session.tokens ?? { input: 0, output: 0, reasoning: 0, cache: { read: 0, write: 0 } },
    time: {
      created: "created" in time && typeof time.created === "number" ? time.created : 0,
      updated: "updated" in time && typeof time.updated === "number" ? time.updated : 0,
      ...(session.time && typeof session.time === "object" && "archived" in session.time
        ? { archived: session.time.archived }
        : {}),
    },
    title: session.title ?? session.id,
    location: {
      directory: typeof session.directory === "string" ? session.directory : fallbackDirectory,
      ...(typeof session.workspaceID === "string" ? { workspaceID: session.workspaceID } : {}),
    },
    subpath: session.path,
    revert: session.revert,
  }
}

function currentMessage(value: unknown): unknown[] {
  const item = value as {
    info: Record<string, unknown> & { id: string; role: "user" | "assistant"; time: { created: number } }
    parts: Array<Record<string, unknown> & { type: string }>
  }
  if (item.info.role === "user") {
    const texts = item.parts.filter((part) => part.type === "text" && typeof part.text === "string")
    return [
      // V2 records a comment as its own synthetic message, just before the prompt it came with.
      ...texts
        .filter((part) => part.synthetic)
        .map((part, index) => ({
          id: `${item.info.id}_synthetic_${index}`,
          type: "synthetic",
          time: { created: item.info.time.created - 1 },
          metadata: part.metadata,
          text: part.text,
          description: part.text,
        })),
      {
        id: item.info.id,
        type: "user",
        time: item.info.time,
        text: texts
          .filter((part) => !part.synthetic)
          .map((part) => part.text)
          .join("\n"),
        files: item.parts.flatMap((part) => {
          if (part.type !== "file") return []
          const url = String(part.url)
          return [
            {
              data: url.startsWith("data:") ? (url.split("base64,")[1] ?? "") : "",
              mime: part.mime,
              name: part.filename,
              source: url.startsWith("data:") ? { type: "inline" } : { type: "uri", uri: url },
              mention: mention(part.source),
            },
          ]
        }),
        agents: item.parts.flatMap((part) =>
          part.type === "agent" ? [{ name: part.name, mention: mention(part.source) }] : [],
        ),
      },
    ]
  }
  const compaction = item.parts.find((part) => part.type === "compaction")
  const error = item.info.error as { name: string; data: { message: string } } | undefined
  return [
    // V2 records a compaction as its own turn; the assistant work after it replies to it.
    ...(compaction
      ? [
          {
            id: `${item.info.id}_compaction`,
            type: "compaction",
            status: "completed",
            reason: compaction.auto ? "auto" : "manual",
            summary: "",
            recent: "",
            time: { created: item.info.time.created - 1 },
          },
        ]
      : []),
    {
      id: item.info.id,
      type: "assistant",
      time: item.info.time,
      agent: item.info.agent ?? "build",
      model: { id: item.info.modelID ?? "model", providerID: item.info.providerID ?? "provider" },
      cost: item.info.cost,
      tokens: item.info.tokens,
      // A fixture { name, data: { message } } becomes V2 { type, message }.
      error: error ? { type: error.name, message: error.data.message } : undefined,
      content: item.parts.flatMap<unknown>((part) => {
        if (part.type === "text" || part.type === "reasoning") return [{ type: part.type, text: part.text ?? "" }]
        if (part.type !== "tool") return []
        const state = part.state as Record<string, unknown>
        return [
          {
            type: "tool",
            id: part.id,
            name: part.tool,
            time: toolTime(state.time, item.info.time.created),
            state:
              state.status === "pending"
                ? { status: "streaming", input: state.raw ?? JSON.stringify(state.input ?? {}) }
                : state.status === "completed"
                  ? {
                      status: "completed",
                      input: state.input ?? {},
                      metadata: state.metadata ?? {},
                      structured: state.metadata ?? {},
                      content: [{ type: "text", text: state.output ?? "" }],
                    }
                  : state.status === "error"
                    ? {
                        status: "error",
                        input: state.input ?? {},
                        metadata: state.metadata ?? {},
                        structured: state.metadata ?? {},
                        content: [],
                        error: { type: "ToolError", message: state.error ?? "Tool failed" },
                      }
                    : {
                        status: "running",
                        input: state.input ?? {},
                        metadata: state.metadata ?? {},
                        structured: state.metadata ?? {},
                        content: [],
                      },
          },
        ]
      }),
    },
  ]
}

// Fixture sources are { value, start, end } for agents and { text: { value, start, end } } for files; V2 mentions are
// { text, start, end }.
function mention(value: unknown) {
  const source = value as {
    value?: string
    start?: number
    end?: number
    text?: { value: string; start: number; end: number }
  }
  const found = source?.text ?? source
  if (typeof found?.value !== "string" || found.start === undefined || found.end === undefined) return undefined
  return { text: found.value, start: found.start, end: found.end }
}

// The fixtures write legacy tool times ({start, end}); V2 records {created, completed}.
function toolTime(value: unknown, fallback: number) {
  const time = (value ?? {}) as { start?: number; end?: number; created?: number; completed?: number }
  return { created: time.created ?? time.start ?? fallback, completed: time.completed ?? time.end }
}

function json(route: Route, body: unknown, headers?: Record<string, string>, status = 200) {
  return route.fulfill({
    status,
    contentType: "application/json",
    headers: {
      "access-control-allow-origin": "*",
      "access-control-expose-headers": "x-next-cursor",
      ...headers,
    },
    body: JSON.stringify(body ?? null),
  })
}

function sse(route: Route, events?: unknown[], retry?: number) {
  return route.fulfill({
    status: 200,
    contentType: "text/event-stream",
    body: `${retry === undefined ? "" : `retry: ${retry}\n\n`}${events?.map((event) => `data: ${JSON.stringify(event)}\n\n`).join("") || ": ok\n\n"}`,
  })
}

function currentEvent(input: unknown) {
  if (!input || typeof input !== "object" || !("payload" in input)) return input
  const envelope = input as { directory?: string; payload?: unknown }
  if (!envelope.payload || typeof envelope.payload !== "object") return input
  const payload = envelope.payload as { id?: string; type?: string; properties?: unknown }
  if (!payload.type) return input
  return {
    id: payload.id ?? `evt_mock_${Date.now()}`,
    created: Date.now(),
    type: payload.type,
    data: payload.properties ?? {},
    location: envelope.directory && envelope.directory !== "global" ? { directory: envelope.directory } : undefined,
  }
}
