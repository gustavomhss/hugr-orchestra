"""Preserve completed literal-transport records without changing authored content."""
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
out = root / "deliverable"
layer = int(sys.argv[1])
units = ["desktop-web", "app-session", "design-tui"] + (["entry"] if layer == 4 else [])
destination = out / "judgments" / f"l{layer}-r1" / "transport"
assert not destination.exists(), "Preserve existing receipts; use a new explicit revision."
checks = []
for unit in units:
    parent = root / "later-producers" / ("app-session" if unit == "entry" else unit) / (f"l{layer}-entry" if unit == "entry" else f"l{layer}")
    packet = parent / "review-frozen-r1"
    transport = parent / "transport-r1"
    assert packet.is_dir() and transport.is_dir(), (unit, "both packet and completed transport records required")
    manifest = json.loads((packet / "manifest.json").read_text())
    for part in manifest["parts"]:
        data = (packet / part["file"]).read_bytes()
        assert len(data) == part["byte_length"]
        assert hashlib.sha256(data).hexdigest() == part["sha256"]
    checks.append({"unit": unit, "manifest": manifest, "packet": packet, "transport": transport})
destination.mkdir(parents=True)
records = []
for check in checks:
    unit = check["unit"]
    for kind in ["packet", "transport"]:
        source = check[kind]
        target = destination / unit / kind
        shutil.copytree(source, target)
        for file in sorted(target.rglob("*")):
            if not file.is_file():
                continue
            data = file.read_bytes()
            assert data == (source / file.relative_to(target)).read_bytes()
            records.append({"path": str(file.relative_to(out)), "byte_length": len(data), "sha256": hashlib.sha256(data).hexdigest()})
record = {"schema": "genesis-s2-preserved-transport/v1", "layer": layer, "recorded_at": datetime.now(timezone.utc).isoformat(), "files": records, "limits": ["Exact local copies and hashes; no host-internal serialization or received-byte hashes are exposed.", "Completion is based on the sender's actual native-call receipts and root review, not inferred from the existence of packet files.", "Native tokens, billing and provider physical attempts remain UNKNOWN."]}
(destination / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"layer": layer, "files": len(records), "manifest_sha256": hashlib.sha256((destination / "manifest.json").read_bytes()).hexdigest(), "logical_packet_bytes_per_judge": sum(sum(p["byte_length"] for p in c["manifest"]["parts"]) for c in checks), "parts_per_judge": sum(len(c["manifest"]["parts"]) for c in checks)}, indent=2))
