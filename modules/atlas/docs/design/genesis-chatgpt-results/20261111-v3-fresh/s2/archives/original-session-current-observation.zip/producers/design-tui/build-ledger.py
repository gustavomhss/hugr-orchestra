#!/usr/bin/env python3
"""Build the assigned-path ledger; verifies artifacts, never runs product code."""
from pathlib import Path
import collections
import hashlib
import json

BASE = Path('/workspace/scratch/992c54067adf/genesis-s2/producers/design-tui')
INPUT = Path('/workspace/scratch/992c54067adf/genesis-s2/deliverable/inputs/design-tui-tree.json')
COMMIT = '1cde2ff7a71bcf7aecb5d030917b577165135d38'
PROTOCOL = 'ee2521a5b966bd505cc95bd1c733e09e12f33531'
tree = json.loads(INPUT.read_text())
manifest = json.loads((BASE / 'sources.json').read_text())
captured = {v['path']: v for v in manifest['captures']}
families = {}

def family(key, purpose, reps, source, consumer, maintenance, limits='', metadata=False):
    assert key not in families
    for rep in reps:
        assert rep in captured, (key, rep)
    families[key] = dict(id=key, purpose=purpose, representative_source_paths=reps,
                         source_implications=source, consumer_implications=consumer,
                         maintenance_implications=maintenance, semantic_limits=limits,
                         metadata_only=metadata)

family('tui-package', 'Terminal package manifest, ownership and build configuration',
 ['packages/tui/README.md','packages/tui/package.json','packages/tui/src/index.tsx'],
 'Explicit run/config/runtime/context/plugin exports; current terminal-ui ownership permits core.',
 'CLI runTui adapts transport/config/global paths into run.',
 'Preserve public exports; generated README module-contract block has a separate owner.',
 'Ancillary bun/TypeScript configuration inventoried; no package command executed.')
family('tui-lifecycle-routes', 'Renderer lifetime, application provider composition and navigation',
 ['packages/tui/src/app.tsx','packages/tui/src/context/route.tsx','packages/tui/src/context/runtime.tsx','packages/tui/src/runtime.tsx','packages/tui/src/routes/home.tsx','apps/cli/src/tui.ts','packages/tui/test/app-lifecycle.test.tsx'],
 'run acquires renderer under Effect scope, wires providers and waits for shutdown; route union is home/session/plugin.',
 'Host supplies transport and plugin lifetime; CLI host at this pin is no-op.',
 'Maintain cleanup ordering, route validation and continue/fork hydration ordering.',
 'Provider wiring is inspected; not every small supporting context/component implementation is read. Mock-renderer lifecycle test is unexecuted.')
family('tui-v2-transport-state', 'V2 event transport, catalog mapping, hydration and client actions',
 ['packages/tui/src/context/sdk.tsx','packages/tui/src/context/event.ts','packages/tui/src/context/sync.tsx','packages/tui/src/context/session-history.ts','packages/tui/src/context/data.tsx','packages/tui/src/context/catalog.ts','packages/tui/src/context/session-actions.ts','packages/tui/src/types.ts','packages/tui/test/cli/cmd/tui/sync-live-hydration.test.tsx','packages/tui/test/context/session-actions.test.ts'],
 'Injected events or SSE feed projection; history hydration merges live-touched rows; actions call V2.',
 'Sessions render bounded projections; separate location cache keys include directory/workspace.',
 'Preserve idempotent event application and hydration coalescing; verify actual transport when changing contracts.',
 'Client/server internals outside boundary; no network, reconnection, or product tests executed.')
family('tui-selection-persistence', 'Model/agent selection and process state persistence',
 ['packages/tui/src/context/local.tsx','packages/tui/src/context/kv.tsx','packages/tui/src/context/project.tsx','packages/tui/src/util/agent.ts','packages/tui/src/util/persistence.ts'],
 'Local selection uses stable agent keys and catalog-validated models; state files use Global paths and atomic replacement.',
 'Prompt consumes selection; dialogs consume project and KV preferences.',
 'Keep stable identity distinct from display name; preserve save ordering.',
 'Atomic replacement plus file locking does not prove cross-process merge semantics.')
family('tui-prompt', 'Prompt admission, completion, parts and project/session movement',
 ['packages/tui/src/component/prompt/index.tsx','packages/tui/src/component/prompt/autocomplete.tsx','packages/tui/src/component/prompt/move.tsx','packages/tui/src/context/editor.ts','packages/tui/test/cli/tui/prompt-submit-race.test.ts'],
 'Submit guard spans awaited admission; input extmarks expand into typed parts; moves can create a project copy or move an existing session.',
 'V2 actions receive selected agent/model, attachments, source spans and optional editor context.',
 'Retain in-flight guard and clear timing; audit actual mounted prompt when changing asynchronous dispatch.',
 'Part/display/trait/local-attachment leaf algorithms are family-supported by prompt call sites, not separately audited. Race test mirrors implementation and is unexecuted.')
family('tui-prompt-history', 'Local history, stash, frecency and compatibility exports',
 ['packages/tui/src/prompt/history.tsx','packages/tui/src/prompt/stash.tsx','packages/tui/src/component/prompt/history.tsx','packages/tui/src/component/prompt/stash.tsx','packages/tui/src/component/prompt/frecency.tsx','packages/tui/src/component/prompt/index.tsx'],
 'History/stash persist bounded JSONL records; component-level compatibility files re-export prompt modules.',
 'Prompt restores prior input and stash entries; this is not the server conversation journal.',
 'Preserve tolerant parsing and bounded retention; compatibility import paths remain relevant.',
 'Frecency ranking internals not inspected.')
family('tui-empty-placeholder', 'Verified empty prompt placeholder',
 ['packages/tui/src/component/prompt/cwd.ts'],
 'Exact source bytes are empty and match the Git empty-blob SHA.',
 'No runtime behavior can be attributed to this file.',
 'Do not infer a CWD implementation from its filename.')
family('tui-session-view', 'Session route, message/tool projection and supporting presentation',
 ['packages/tui/src/routes/session/index.tsx','packages/tui/src/routes/session/message.tsx','packages/tui/src/routes/session/tool.tsx'],
 'Session route synchronizes directory/workspace, editor and history; message/tool components dispatch typed views.',
 'Root and child sessions share displayed request state; sidebar depends on terminal width and preferences.',
 'Retain message ordering and generic tool fallback; separate display preferences from server state.',
 'Timeline, subagent, draft and tool-parsing helpers are covered through route imports/call sites; their complete behavior is not separately audited.')
family('tui-permission-question', 'Permission decisions, question tabs and automatic approval setting',
 ['packages/tui/src/routes/session/permission.tsx','packages/tui/src/routes/session/question.tsx','packages/tui/src/context/permission.tsx','packages/tui/src/context/sync.tsx'],
 'Requests are keyed by session/request; permission stages once/always/reject; question replies preserve question order.',
 'Session route hides normal prompt during pending interaction; auto mode changes handling of asked events.',
 'Keep explicit request identity and rejection paths; permission wording is not a server-side policy proof.',
 'Server authorization semantics outside this unit; no interactive terminal verification.')
family('tui-config-keymap', 'Configuration schema, legacy key translation and mode routing',
 ['packages/tui/src/config/index.tsx','packages/tui/src/config/keybind.ts','packages/tui/src/keymap.tsx','apps/cli/src/tui-config.ts','packages/tui/test/config.test.tsx','packages/tui/test/keymap.test.tsx'],
 'Effect schema resolves defaults; CLI merges config maps; mode stack and leader routing are centralized.',
 'Prompt/autocomplete/dialog/plugin commands compete through modes and bindings.',
 'Keep parse/resolve and schema generation aligned; mode disposers must tolerate out-of-order cleanup.',
 'Core configuration file discovery is delegated outside the inspected boundary.')
family('tui-dialogs-widgets', 'Terminal selection/dialog primitives and feature dialog call sites',
 ['packages/tui/src/ui/dialog.tsx','packages/tui/src/ui/dialog-select.tsx','packages/tui/src/app.tsx','packages/tui/src/component/prompt/index.tsx'],
 'Shared modal stack captures focus, consumes escape and restores focus; DialogSelect exposes typed filtering/options/actions.',
 'App commands and prompt invoke feature dialogs through shared primitives.',
 'Preserve focus/mode stack coordination and input ownership.',
 'Individual agent/model/provider/status/rename/export/toast widget behavior not separately inspected; grouping establishes shared integration only.')
family('tui-plugin-facade', 'Injectable plugin host, route registry, slots and adapters',
 ['packages/tui/src/plugin/runtime.tsx','packages/tui/src/plugin/api.ts','packages/tui/src/plugin/slots.tsx','packages/tui/src/plugin/adapters.tsx','apps/cli/src/tui.ts','packages/tui/test/plugin/runtime.test.ts'],
 'Host is a start/dispose contract; route registry is last-registration-wins; slots use a separately set-up registry.',
 'App supplies adapters and readiness; current CLI supplies empty host methods.',
 'Do not treat facade lifecycle placeholders as full plugin disposal; verify owning host integration.',
 'Feature existence does not establish installation/enabling on the inspected CLI path.')
family('tui-feature-plugins', 'Built-in home/sidebar/system plugin contributions',
 ['packages/tui/src/feature-plugins/builtins.ts','packages/tui/src/feature-plugins/sidebar/context.tsx','packages/tui/src/feature-plugins/system/diff-viewer.tsx','packages/tui/src/feature-plugins/system/which-key.tsx','packages/tui/src/feature-plugins/system/plugins.tsx','packages/tui/src/feature-plugins/system/notifications.ts'],
 'Builtins factory enumerates contributions; diff plugin registers a route; which-key supplies commands/slots; notifications deduplicate request events.',
 'Plugin host, command registry, slots and KV determine availability and preferences.',
 'Preserve registration disposal and route parameters; feature contribution is distinct from host activation.',
 'Small sidebar/home and diff model/tree/helper leaf semantics are family-supported, not individually inspected.')
family('tui-terminal-editor', 'Native terminal, clipboard and editor integration',
 ['packages/tui/src/terminal-win32.ts','packages/tui/src/editor.ts','packages/tui/src/context/editor.ts','packages/tui/src/clipboard.ts','script/spawn-allowlist.json'],
 'Platform-guarded Windows handling, OSC52/native clipboard, external editor suspend/resume and loopback editor integration.',
 'Prompt receives pending editor context and attachments; terminal renderer owns suspension/cleanup.',
 'Preserve finally/cleanup behavior and explicit subprocess allowlist ownership.',
 'No OS, clipboard, websocket, Zed or real terminal validation; editor-zed leaf adapter is not independently read.')
family('tui-attention-audio', 'Focus-aware notifications and lazy audio resources',
 ['packages/tui/src/attention.ts','packages/tui/src/audio.ts','packages/tui/src/config/index.tsx','packages/tui/src/feature-plugins/system/notifications.ts'],
 'Attention is disabled by default; normalizes content, chooses sound fallbacks and disposes listeners; audio lazily caches loads.',
 'Feature notifications call attention; mp3 bytes are exported from UI package.',
 'Preserve disabled/no-audio behavior, listener disposal and sanitized bounded notification text.',
 'No audio audition or native notification execution.')
family('tui-theme-engine', 'Terminal palette loading, theme resolution and reload lifecycle',
 ['packages/tui/src/theme/index.ts','packages/tui/src/context/theme.tsx','packages/tui/test/theme.test.ts'],
 'Terminal ThemeJson defs/theme format is separate from DesktopTheme; built-in/plugin/custom/system precedence is explicit.',
 'Renderer palette and theme context feed widgets and plugin adapters.',
 'Preserve fallback, config/KV precedence and reload listeners; do not validate terminal presets with desktop schema.',
 'Not all palette branches or preset values are individually evaluated.')
family('tui-theme-data', 'Checked-in terminal preset and example theme data',
 ['packages/tui/src/theme/assets/aura.json','packages/tui/src/theme/index.ts','packages/tui/src/context/theme.tsx','.orchestra/themes/mytheme.json'],
 'Thirty-three preset JSONs are imported; representative custom example has terminal format.',
 'Theme resolver consumes this data; preset filenames alone do not imply generator provenance.',
 'Preserve terminal schema shape; upstream preset authorship/generation is unverified.',
 'Representative parse and consumer inspection; no per-theme contrast/appearance audit.')
family('tui-presentation-helpers', 'Model/file/path/locale labels, epilogue art and environment descriptions',
 ['packages/tui/src/logo.ts','packages/tui/src/util/format.ts','packages/tui/src/util/locale.ts','packages/tui/src/util/model.ts','packages/tui/src/util/filetype.ts','packages/tui/src/util/path.ts','packages/tui/src/util/presentation.ts','packages/tui/src/util/session.ts','packages/tui/src/util/system.ts','packages/tui/src/component/prompt/index.tsx','packages/tui/src/routes/session/tool.tsx'],
 'Explicit pure-format helpers except environment/path reads: duration units, model provider parsing, extension mapping, Windows realpath fallback, default-title regex and ANSI epilogue.',
 'Prompt/tool/session/app use compact labels, paths, model names and session continuation presentation.',
 'Keep duration units distinct, stable IDs separate from display names, and platform-dependent path behavior explicit.',
 'All leaf source contracts inspected; environment rendering and locale/timezone output unexecuted. Related util tests are inventoried, not executed.')
family('tui-message-export-helpers', 'Tool state extraction, bounded previews, revert summaries and Markdown transcript export',
 ['packages/tui/src/util/collapse-tool-output.ts','packages/tui/src/util/session-message.ts','packages/tui/src/util/tool-display.ts','packages/tui/src/util/revert-diff.ts','packages/tui/src/util/transcript.ts','packages/tui/src/routes/session/index.tsx','packages/tui/src/routes/session/tool.tsx'],
 'Helpers distinguish pending/running/settled tool state, bound previews by lines/code points, parse revert file counts and format ordered transcripts with explicit omission/options.',
 'Session copy/export and tool/revert renderers consume derived display data; they do not modify server history.',
 'Preserve synthetic/system-message omission in exports, metadata precedence and graceful malformed-patch fallback.',
 'All leaf contracts inspected; parser dependency behavior and actual clipboard/file export unexecuted. Matching util tests inventoried.')
family('tui-render-input-helpers', 'Renderer destruction, pre-layout geometry, selection copy, scroll and reactive timers',
 ['packages/tui/src/util/layout.ts','packages/tui/src/util/renderer.ts','packages/tui/src/util/scroll.ts','packages/tui/src/util/selection.ts','packages/tui/src/util/signal.ts','packages/tui/src/app.tsx','packages/tui/src/component/prompt/index.tsx'],
 'Helpers cache previous siblings per frame, clear title before guarded destroy, choose acceleration/speed, handle selection Ctrl-C/Escape and clean debounce/fade timers.',
 'App selection keys and prompt animation use these contracts; renderer owns actual terminal geometry.',
 'Preserve early pre-layout timing and event ownership; asynchronous copy clears selection before write settles.',
 'All leaf implementations inspected; no real frame timing, clipboard, animation or native terminal execution.')
family('tui-error-shapes', 'Unknown-error decoding and logging/presentation contracts',
 ['packages/tui/src/util/error.ts','packages/tui/src/util/record.ts','packages/tui/src/component/prompt/index.tsx','packages/tui/src/routes/session/index.tsx'],
 'Formats Error/tagged/wire objects, config/provider messages and enumerable/nonenumerable data; CliError decoding can set process.exitCode.',
 'Prompt and route failures show concise errorMessage; structured formatter supports diagnostic callers.',
 'Do not assume all formatters are pure: preserve the explicit exitCode side effect and cancellation empty-string convention.',
 'Full source inspected; wording may reflect older server capabilities and is not current MCP feature proof; util/error test unexecuted.')
family('tui-parser-config', 'Additional terminal syntax parser declarations and query ownership',
 ['packages/tui/src/parsers-config.ts','packages/tui/src/routes/session/index.tsx','packages/tui/src/util/filetype.ts'],
 'Default export lists 34 parser configurations; session module registers them through addDefaultParsers. Built-in Markdown/JS/TS are excluded in the comment.',
 'Terminal code/diff rendering can load declared WASM and query URLs; filetype helper maps extensions to renderer language IDs.',
 'Respect query inheritance/version compatibility; query URLs mix revision/release pins and moving master refs.',
 'Parser records structurally inventoried with selected query/provenance cases inspected. No download, checksum, parser compatibility or syntax rendering validation.')
family('tui-demo-runtime', 'Provider-free demo command construction and local request settlement',
 ['packages/tui/src/context/demo.ts','packages/tui/src/context/demo-run.ts','packages/tui/src/context/sdk.tsx','packages/tui/src/context/sync.tsx','packages/tui/src/component/prompt/index.tsx'],
 'mini+demo prompt branch parses fmt/permission/question commands, constructs synthetic messages with demo_ IDs and emits local asked/replied events; waiting map entries are deleted by settle.',
 'Permission/question UI can be demonstrated without provider calls; SDK intercepts demo request IDs and Sync patches synthetic tools.',
 'Keep demo IDs and interception aligned; unmatched input continues through normal dispatch; unanswered waiting entries have no cleanup shown here.',
 'Full demo source inspected, no demo run; synthetic fixture content is not an actual provider/tool execution result. context/demo test inventoried.')
family('tui-replay-thinking', 'Mini replay projection and persisted reasoning disclosure mode',
 ['packages/tui/src/context/replay.ts','packages/tui/src/context/thinking.ts','packages/tui/src/routes/session/index.tsx'],
 'replayWindow leaves ordinary sessions unchanged and filters/slices mini messages; thinking defaults hide, migrates legacy boolean/minimal values, and splits a bold summary heading.',
 'Session route consumes replay arguments and KV-backed disclosure preference; reasoning content is display metadata.',
 'Preserve openedAt boundary and preference migration; helper does not validate CLI limit constraints.',
 'Full helper source inspected; replay/thinking test files inventoried and unexecuted; no live reasoning stream verification.')
family('tui-tests', 'Terminal regression sources read or inventoried, all unexecuted',
 ['packages/tui/test/app-lifecycle.test.tsx','packages/tui/test/cli/cmd/tui/sync-live-hydration.test.tsx','packages/tui/test/cli/tui/prompt-submit-race.test.ts','packages/tui/test/context/session-actions.test.ts','packages/tui/test/keymap.test.tsx','packages/tui/test/config.test.tsx','packages/tui/test/plugin/runtime.test.ts','packages/tui/test/theme.test.ts'],
 'Read tests provide intended assertions; mounted/mock-renderer, real helper and mirrored prompt tests have different evidentiary strength.',
 'Maintainers can use the permitted CI workflow after the appropriate phase.',
 'Do not report source assertions or historical results as this task\'s execution result.',
 'Unread tests are identified inventory only; their assertions are not claimed.')
family('tui-test-fixtures', 'Test harnesses, fake transports and stored snapshot fixture',
 ['packages/tui/test/cli/cmd/tui/sync-fixture.tsx','packages/tui/test/fixture/tui-sdk.ts','packages/tui/test/app-lifecycle.test.tsx'],
 'Fixtures fake transport/environment/rendering to isolate UI state.',
 'Regression tests use these instead of a real terminal/backend.',
 'Keep mocks aligned with contracts; snapshot generation history is unverified.',
 'Fixture depth is representative; no fixture/test was executed.')
family('ui-package', 'Solid UI package ownership, exports and build boundaries',
 ['packages/ui/README.md','packages/ui/AGENTS.md','packages/ui/package.json','packages/ui/vite.config.ts','script/module-readme.ts'],
 'Both component generations are current; exports are explicit plus asset/style wildcards; no workspace dependencies.',
 'App-shell/session-ui add higher layers; Storybook, desktop and TUI consume the library.',
 'Preserve public exports, i18n policy and generated module-contract block.',
 'Ancillary TypeScript/bun/ignore configuration not individually audited.')
family('ui-license-unread', 'License notice retained in exact path inventory',
 ['packages/ui/README.md'],
 'README explicitly instructs preserving LICENSE; full license text not captured.',
 'Distribution obligations cannot be inferred from package role.',
 'Read license before redistribution/licensing conclusions.', 'No legal analysis or license compliance claim.', True)
family('ui-primitives', 'First-generation controls and overlay presentation',
 ['packages/ui/src/components/button.tsx','packages/ui/src/components/dialog.tsx','packages/ui/src/components/tooltip.tsx','packages/ui/src/context/dialog.tsx','packages/ui/README.md'],
 'Representative controls wrap Kobalte and use data attributes for styling; dialogs translate close labels and manage focus.',
 'Higher-level applications supply content, labels and state.',
 'Preserve public props and styling hooks; inspect each leaf before changing its semantics.',
 'Other controls, media, logo and feedback components are supported at library-family level only; no universal accessibility claim.')
family('ui-v2-primitives', 'Second-generation controls, composed fields and keyboard interactions',
 ['packages/ui/src/v2/components/field-v2.tsx','packages/ui/src/v2/components/dialog-v2.tsx','packages/ui/src/v2/components/segmented-control-v2.tsx','packages/ui/README.md'],
 'Field wires control IDs/labels/descriptions/errors; dialog composes slots; segmented control supports controlled state and DOM-order arrows.',
 'New-layout consumers use v2 data slots/CSS contracts.',
 'Preserve label wiring; verify RTL keyboard behavior rather than assuming visual mirroring establishes it.',
 'Remaining v2 leaf controls/styles family-supported; no screen-reader/browser test.')
family('ui-motion', 'Spring and text/number animation components',
 ['packages/ui/src/components/motion-spring.tsx','packages/ui/src/styles/animations.css','packages/ui/README.md'],
 'Representative spring helper attaches Motion values, snaps on a state key and destroys subscriptions on cleanup.',
 'Animated controls consume animation helpers/CSS.',
 'Preserve snap/cleanup semantics; inspect individual animation and reduced-motion behavior before changing it.',
 'Text/number animation leaves are not individually inspected; no motion or reduced-motion visual validation.')
family('ui-list-scroll', 'Virtualized lists, scroll ownership and auto-scroll hooks',
 ['packages/ui/src/components/list.tsx','packages/ui/src/components/scroll-view.tsx','packages/ui/src/hooks/create-auto-scroll.tsx','packages/ui/src/hooks/use-filtered-list.tsx','packages/ui/src/components/scroll-view.test.ts'],
 'List limits visible range with active/focused exceptions; scroll helper avoids stealing nested or editable input; auto-scroll tracks user interruption.',
 'Consumers own selection/filtering and scroll content.',
 'Preserve focus retention, nested scroll boundaries and resize/cleanup behavior.',
 'Read helper tests are unexecuted; no layout or browser input confirmation.')
family('ui-dialog-context', 'Overlay stack ownership, focus and removal lifecycle',
 ['packages/ui/src/context/dialog.tsx','packages/ui/src/components/dialog.tsx','packages/ui/src/v2/components/dialog-v2.tsx'],
 'Provider stacks owned roots; show replaces stack, showOwned couples caller lifetime; removal attempts focus restoration.',
 'Both UI generations and Storybook use the provider.',
 'Preserve root disposal and focus restoration around delayed closing.',
 'No DOM or assistive-technology execution.')
family('ui-markdown', 'Markdown parser, syntax themes and math rendering context',
 ['packages/ui/src/context/marked.tsx','packages/ui/src/context/marked-parser.tsx','packages/ui/src/context/marked-theme.tsx','packages/ui/src/context/marked-parser.test.ts'],
 'Marked custom links, Shiki highlighting and KaTeX are configured; language load failures fall back to text.',
 'Screens/Storybook provide theme and highlighter context.',
 'Preserve parser/highlighter contracts; separately inspect final HTML sanitization/rendering boundary.',
 'No renderer-wide sanitization assurance; worker support not covered by this family.')
family('ui-context-services', 'Readiness-gated contexts, injected file component and caller-owned worker pools',
 ['packages/ui/src/context/helper.tsx','packages/ui/src/context/file.tsx','packages/ui/src/context/worker-pool.tsx','packages/ui/src/context/index.ts','packages/ui/src/custom-elements.d.ts'],
 'createSimpleContext initializes once, optionally gates children on reactive ready, and throws for missing/falsy context; file/pool providers inject caller values; JSX declaration adds diffs-container typing.',
 'Consumers select injected file component or unified/split diff pool; barrel reexports helper/file/dialog/i18n.',
 'Pool provider neither creates nor disposes workers: caller owns lifetime; TypeScript declaration does not register custom element runtime.',
 'Complete small sources inspected; no worker execution, custom-element runtime or DOM readiness test. No dedicated test captured for these wrappers.')
family('ui-i18n-runtime', 'Locale provider, English fallback and plural/template helpers',
 ['packages/ui/src/context/i18n.tsx','packages/ui/src/context/i18n.test.ts','packages/ui/AGENTS.md','packages/ui/src/i18n/edit-review.ts'],
 'Provider separates layoutLocale from locale, templates parameters and caches Intl plural rules; fallback is English.',
 'Controls use useI18n; applications provide translations/layout locale.',
 'Preserve visible-string key policy and plural categories; dictionaries are not strict exhaustiveness proof.',
 'Plural tests read, unexecuted; translation quality not audited.')
family('ui-localization-data', 'Locale dictionaries and shared edit-review copy',
 ['packages/ui/src/i18n/en.ts','packages/ui/src/i18n/ar.ts','packages/ui/src/i18n/edit-review.ts','packages/ui/src/context/i18n.tsx','.orchestra/glossary/README.md'],
 'Sixty-three files in i18n include locale and shared-copy modules; representative English/Arabic key/template data inspected.',
 'UI provider/app translation adapters consume copy; TUI explicitly has a separate English-only policy.',
 'Apply locale/glossary policy; require locale review for semantic changes.',
 'Repetitive dictionaries receive family support, not language-by-language correctness or completeness claims.')
family('ui-theme-engine', 'Desktop theme schema, color resolution and provider/loader APIs',
 ['packages/ui/src/theme/types.ts','packages/ui/src/theme/context.tsx','packages/ui/src/theme/loader.ts','packages/ui/src/theme/resolve.ts','packages/ui/src/theme/color.ts','packages/ui/src/theme/v2/resolve.ts','packages/ui/src/theme/default-themes.ts','packages/ui/src/theme/desktop-theme.schema.json'],
 'DesktopTheme light/dark seeds or palettes resolve v1/v2 CSS; provider persists preferences, follows media/storage and supports previews.',
 'Browser surfaces and Storybook consume themes; imperative loader has a separate style element/API.',
 'Preserve preview identity/commit/cancel and data/storage keys; distinguish terminal format.',
 'No palette-by-palette contrast check; URL loader returns JSON without runtime schema validation.')
family('ui-theme-data', 'Desktop preset data including partially generated oc-2 overrides',
 ['packages/ui/src/theme/themes/oc-2.json','packages/ui/src/theme/default-themes.ts','packages/ui/src/theme/context.tsx','packages/ui/script/build-oc2-v2-overrides.ts'],
 'Thirty-seven checked-in preset files are discoverable; only oc-2 v2Overrides has a verified rewrite generator here.',
 'Theme provider lazily imports presets.',
 'Preserve handwritten/generated ownership at field level; other preset provenance unverified.',
 'Only representative preset structure inspected; no visual equivalence or regeneration run.')
family('ui-styles', 'Shared CSS tokens, base styles, Tailwind and component CSS',
 ['packages/ui/src/styles/index.css','packages/ui/src/styles/base.css','packages/ui/src/styles/theme.css','packages/ui/src/styles/animations.css','packages/ui/src/v2/styles/theme.css','packages/ui/src/components/button.tsx','packages/ui/src/v2/components/field-v2.tsx'],
 'Stylesheets compose tokens/utilities and component data-attribute/data-slot contracts.',
 'Both component generations and app new-layout surfaces load exported styles.',
 'Keep style layers and token names consistent with runtime theme resolvers.',
 'CSS family support does not establish every selector, responsive state or contrast condition.')
family('ui-tailwind-generation', 'Color source, Tailwind generator and verified generated output path',
 ['packages/ui/script/tailwind.ts','packages/ui/README.md'],
 'tailwind.ts reads script/colors.txt and writes src/styles/tailwind/colors.css.',
 'Exported Tailwind styles consume generated utilities.',
 'Change generator/input and regenerate through authorized workflow; not all CSS is generated.',
 'Generator inspected but not executed; output byte equivalence not recomputed.')
family('ui-oc2-generation', 'Script that rewrites only default-theme v2Overrides',
 ['packages/ui/script/build-oc2-v2-overrides.ts','packages/ui/src/theme/themes/oc-2.json','packages/ui/src/v2/styles/theme.css'],
 'Generator derives override differences from v2 theme CSS/default primitives and preserves other JSON fields.',
 'Theme resolver applies resulting overrides last.',
 'Do not treat entire preset JSON as generated.', 'No generator run.')
family('ui-icon-consumers', 'File/provider/app icon renderers and font placeholder',
 ['packages/ui/src/components/file-icon.tsx','packages/ui/src/components/provider-icon.tsx','packages/ui/src/components/app-icon.tsx','packages/ui/src/components/font.tsx','packages/ui/package.json'],
 'File/provider consumers reference sprites; AppIcon uses raw source assets; Font component returns null.',
 'App consumers select named icons or import exported font bytes separately.',
 'Preserve names/export paths; binary font presence is not proof of runtime font loading.',
 'No rendering or complete icon-name/path audit.')
family('ui-generated-icon-products', 'File/provider sprite and type generation products',
 ['packages/ui/vite.config.ts','packages/ui/src/components/file-icons/types.ts','packages/ui/src/components/provider-icons/types.ts','packages/ui/src/components/file-icon.tsx','packages/ui/src/components/provider-icon.tsx'],
 'iconsSpritesheet withTypes maps file-types/provider source directories to their respective component output directories.',
 'Renderers and exported types depend on stable names.',
 'Maintain generator inputs and outputs together through authorized generation.',
 'No generator execution or all-sprite visual/byte equivalence check.')
family('ui-app-sprite-provenance', 'App sprite/type artifacts whose producer is unverified',
 ['packages/ui/vite.config.ts','packages/ui/src/components/app-icon.tsx','packages/ui/README.md'],
 'Assigned app-icons sprite/types exist; inspected Vite config only declares file/provider generators.',
 'AppIcon currently imports raw assets; legacy/other consumer for these products is unverified.',
 'Find actual producer/consumer before declaring these generated, obsolete or safe to modify.',
 'Existence is metadata-only; no content or provenance claim.', True)
family('ui-file-icon-assets', 'Large file-type SVG input family',
 ['packages/ui/src/assets/icons/file-types/abap.svg','packages/ui/vite.config.ts','packages/ui/src/components/file-icon.tsx'],
 '1,089 assigned SVG inputs feed the verified spritesheet pipeline.',
 'FileIcon consumes generated sprite names.',
 'Keep input names stable; upstream authorship/import tooling unverified.',
 'Representative SVG and pipeline only; no individual render/license/provenance audit.')
family('ui-provider-icon-assets', 'Provider SVG input family with network refresh source',
 ['packages/ui/src/assets/icons/provider/302ai.svg','packages/ui/vite.config.ts','packages/ui/src/components/provider-icon.tsx'],
 '105 assigned SVGs; providerIconsPlugin can refresh from models URL API/logo endpoints on dev/build.',
 'Spritesheet generator and ProviderIcon consume this directory.',
 'Build refresh can mutate source assets and depend on remote contents; pinning freshness was not established.',
 'Representative SVG inspected; refresh not executed; individual original provenance/appearance unverified.')
family('ui-app-image-assets', 'Application icon, favicon and general image assets',
 ['packages/ui/src/components/app-icon.tsx','packages/ui/package.json','packages/ui/README.md'],
 'Asset families and raw imports/export boundaries are established; no generator found for these bytes.',
 'Application identity/favicon/media consumers use bundled assets.',
 'Preserve paths; verify actual producers, rights and expected appearance before replacement.',
 'No binary image viewing or all-source provenance audit.')
family('ui-font-assets', 'Exported font binaries',
 ['packages/ui/package.json','packages/ui/src/components/font.tsx','packages/ui/README.md'],
 'Two assigned font binaries exported through fonts wildcard; Font component is null.',
 'Actual loading must be established in a consuming app/style boundary.',
 'Preserve file paths and independently verify license/loading before replacing.',
 'Binary bytes not captured; no font rendering, glyph or license audit.')
family('ui-audio-assets', 'Exported sound asset family',
 ['packages/ui/package.json','packages/tui/src/attention.ts','packages/tui/src/audio.ts'],
 'Ninety assigned audio files; TUI imports a concrete subset and lazy audio handles decode/cache.',
 'Attention config chooses built-in/pack/custom paths.',
 'Preserve package paths and fallback behavior; provenance of each recording unverified.',
 'No individual byte capture, audio audition or native playback.')
family('ui-stories-fixtures', 'Story examples and manufactured content fixtures',
 ['packages/ui/src/components/button.stories.tsx','packages/ui/src/storybook/fixtures.ts','packages/ui/src/storybook/scaffold.tsx','apps/storybook/.storybook/main.ts'],
 'Stories compose component variants and fixtures; some stories disable TypeScript checking.',
 'Storybook scans both component generations and higher-level package stories.',
 'Maintain examples and fixtures separately from runtime/test guarantees.',
 'Representative stories only; no full render, snapshot or interaction run.')
family('ui-tests', 'UI helper/parser/i18n regression source inventory',
 ['packages/ui/src/components/scroll-view.test.ts','packages/ui/src/context/i18n.test.ts','packages/ui/src/context/marked-parser.test.ts'],
 'Read assertions cover helper semantics, plural categories and parser behavior.',
 'Tests are a future CI verification aid, not execution evidence here.',
 'Preserve distinction between helper tests and full rendered accessibility/visual behavior.',
 'marked-regression test assertions not individually read; all tests unexecuted.')
family('storybook-config-ci', 'Workbench entry, providers, aliases, development CSS mutation and build workflow',
 ['apps/storybook/README.md','apps/storybook/package.json','apps/storybook/.storybook/main.ts','apps/storybook/.storybook/preview.tsx','apps/storybook/.storybook/playground-css-plugin.ts','.github/workflows/storybook.yml'],
 'Storybook composes real UI providers with mocked app boundaries, supports CSS-edit middleware and builds in label/manual workflow.',
 'Developers inspect shared UI plus app-shell/session-ui stories.',
 'Maintain aliases/theme wrappers; CSS middleware writes source files and is not a read-only preview.',
 'a11y test remains todo; no build/CI/browser/interaction verification performed.')
family('storybook-mocks', 'Local mock services, contexts, router and components',
 ['apps/storybook/.storybook/mocks/app/context/server-sdk.ts','apps/storybook/.storybook/mocks/app/context/sync.ts','apps/storybook/.storybook/main.ts'],
 'Alias map replaces application/transport contexts; representative mocks return static, pending or reduced values.',
 'Stories can render without live authenticated server services.',
 'Treat mocks as illustrative fixtures, not authoritative server wire contracts.',
 'Only representative mocks inspected; OAuth/network/security behavior not validated.')
family('schemas', 'TUI generated editor schema and desktop-theme mirrored schema',
 ['schema/tui.json','schema/theme.json','apps/cli/script/schema-files.ts','packages/tui/src/config/index.tsx','packages/ui/src/theme/desktop-theme.schema.json'],
 'schema-files.ts writes TuiConfig.Info-derived schema and copies handwritten desktop theme schema verbatim; exact theme copies match.',
 'Editors consume $schema documents; runtime uses owning source schema/types.',
 'Use actual source/generator; cli script generate.ts is a model-snapshot loader, not this schema generator.',
 'TUI schema captured exactly at 1,131,057 bytes; observer 256,000-byte cap is a runtime transport limit, not missing source. Generation not executed.')
family('repo-tui-examples', 'Repository-local terminal configuration and theme ignore rule',
 ['.orchestra/tui.json','.orchestra/themes/mytheme.json','apps/cli/src/tui-config.ts','packages/tui/src/context/theme.tsx'],
 'Repository config/examples are consumed through configuration/theme discovery, distinct from package defaults.',
 'CLI loads external config using core file discovery.',
 'Keep examples consistent with the correct terminal schema.',
 'Ignore rule content and full discovery implementation not inspected.')
family('glossary-policy', 'Locale terminology guidance and template glossary files',
 ['.orchestra/glossary/README.md','.orchestra/glossary/ar.md','packages/ui/AGENTS.md'],
 'Guidance includes locale aliases and glossary maintenance; representative Arabic file lacks PR-backed entries.',
 'Translation maintainers use this as guidance, not executable locale selection.',
 'Verify locale-specific entries/corpora before translation approval.',
 'Other locale documents family-supported; no translation-quality audit.')
family('rtl-policy', 'RTL-aware development guidance',
 ['.orchestra/skills/rtl-aware-development/SKILL.md','packages/ui/src/context/i18n.tsx','packages/ui/src/v2/components/segmented-control-v2.tsx'],
 'Skill specifies independent layout/text direction, logical CSS and behavioral verification.',
 'UI maintainers must compare intended RTL behavior with actual components.',
 'Do not substitute visual mirroring for keyboard order validation.',
 'Guidance is intent; no RTL runtime/accessibility certification.')
family('user-guides', 'User-facing appearance and instruction/TUI setup guidance',
 ['docs/guides/appearance.md','docs/guides/instructions-and-tui.md','apps/cli/src/tui-config.ts'],
 'Documents appearance settings and config discovery/order; CLI adapter partially corroborates merge behavior.',
 'Users configure higher-level app settings or terminal inputs.',
 'Validate app/core-owned behavior before asserting entire guide is current.',
 'App settings implementation and core discovery are outside this inspected unit.')
family('historical-plans', 'Architecture phase cards and old TUI extraction proposal',
 ['docs/architecture/phase-plans/70-90-briefs/FAC-TUI.md','docs/architecture/phase-plans/70-90-briefs/RN-UI.md','docs/specs/tui-package.md','packages/tui/README.md'],
 'Cards/proposal record earlier baselines/targets; old no-core target conflicts with current pinned manifest/imports.',
 'Historical rationale only; not a current execution instruction or completed implementation proof.',
 'Compare dates/pins and implementation before carrying rules forward.',
 'Unsampled cards are family-supported historical records, not semantically current authority.')
family('visual-recovery-history', 'Visual handoff, migration, relay and historical verification records',
 ['docs/specs/frontend-recovery-receipt.json','docs/specs/orchestra-visual/DELIVERY.md','docs/specs/orchestra-visual/MIGRATION.md','docs/specs/orchestra-visual/VERIFICATION.md'],
 'Records contain prior baselines, acceptance limits and historic verification outcomes.',
 'Maintainers may locate design decisions and known limitations.',
 'Do not promote old PASS/results or external asset references into current evidence.',
 'Linked external repos/assets and all relay narratives not independently revalidated.')
family('projects-board-design', 'Projects board design contract, journeys, plan and mock catalog',
 ['docs/specs/projects-board/README.md','docs/specs/projects-board/CONTRACT.md','docs/specs/projects-board/MOCKS.md'],
 'Design contract describes writer/interaction rules and stable seat identity; catalog dates approved mock iterations.',
 'A future/current app implementation can be assessed against these intended journeys.',
 'Keep design intent separate from runtime implementation and authorization.',
 'No implementation mapping or rendered mock review; journeys/plan full contents not inspected.')
family('projects-board-mock-assets', 'Nine image mock design references',
 ['docs/specs/projects-board/MOCKS.md','docs/specs/projects-board/README.md'],
 'Catalog identifies approved design references; image bytes were not viewed.',
 'Design-review references, not evidence of running UI.',
 'Preserve catalog/path mapping; generator/original artwork provenance unverified.',
 'Family support only; no visual equivalence or accessibility conclusions.')
family('brand-assets', 'Brand family and documented identity relocation',
 ['assets/brand/README.md'],
 'README records six PNG/SVG assets moved from packages/identity and distinguishes desktop/public logos.',
 'Documentation/branding consumers; relocation identity not independently checked against prior commit.',
 'Keep canonical location distinct from app icon variants.',
 'No binary/render/license verification; doc claim is not a cross-revision hash proof.')
family('readme-render-sources', 'Documentation illustration HTML/CSS/JS and headless render script',
 ['docs/images/readme/src/render.sh','docs/images/readme/src/architecture.html','docs/images/readme/src/wires.js'],
 'Script loops HTML files, renders dark/light PNGs using Chrome at 2x and quantizes with Pillow; wires derives SVG from DOM.',
 'README illustration assets explain intended architecture/workflow.',
 'Edit source then run authorized rendering; illustration is not a runtime dependency graph.',
 'Only representative HTML/JS inspected; renderer not executed.')
family('readme-generated-images', 'PNG outputs whose basenames map to inspected render loop inputs',
 ['docs/images/readme/src/render.sh','docs/images/readme/src/architecture.html'],
 'Assigned basename correspondence plus actual script establishes generation relationship for these paths.',
 'README documentation consumes static rendered illustrations.',
 'Regenerate from matching HTML through the recorded script when authorized.',
 'Current binary equivalence to script output and historical producer invocation not verified.')
family('readme-other-images', 'Screenshot/illustration images without a demonstrated producer',
 ['docs/images/readme/src/render.sh','docs/images/readme/src/architecture.html'],
 'These paths have no matching HTML input in assigned render-source tree.',
 'Documentation image use is apparent from assigned location; exact capture/generation provenance unverified.',
 'Find original source/capture workflow before replacing or calling generated.',
 'Binary content not inspected; no visual assertions.', True)

def route(p):
    if p == '.github/workflows/storybook.yml': return 'storybook-config-ci', 'configuration'
    if p.startswith('.orchestra/glossary/'): return 'glossary-policy', 'documentation'
    if p.startswith('.orchestra/skills/'): return 'rtl-policy', 'skill'
    if p == '.orchestra/themes/mytheme.json': return 'tui-theme-data', 'configuration-example'
    if p.startswith('.orchestra/'): return 'repo-tui-examples', 'configuration'
    if p.startswith('apps/storybook/'):
        if '/mocks/' in p: return 'storybook-mocks', 'fixture'
        return 'storybook-config-ci', 'documentation' if p.endswith('.md') else ('implementation' if p.endswith(('.ts','.tsx')) else 'configuration')
    if p.startswith('assets/brand/'): return 'brand-assets', 'documentation' if p.endswith('.md') else 'binary-or-vector-asset'
    if p.startswith('schema/'): return 'schemas', 'generated-schema' if p.endswith('tui.json') else 'mirrored-handwritten-schema'
    if p.startswith('docs/architecture/') or p == 'docs/specs/tui-package.md': return 'historical-plans', 'historical-proposal'
    if p.startswith('docs/guides/'): return 'user-guides', 'documentation'
    if p.startswith('docs/specs/orchestra-visual/') or p.endswith('frontend-recovery-receipt.json'): return 'visual-recovery-history', 'historical-record'
    if p.startswith('docs/specs/projects-board/'):
        return ('projects-board-mock-assets','binary-asset') if '/mocks/' in p else ('projects-board-design','design-contract')
    if p.startswith('docs/images/readme/src/'): return 'readme-render-sources', 'documentation-render-source'
    if p.startswith('docs/images/readme/'):
        stems = {Path(v['path']).stem for v in tree if v['path'].startswith('docs/images/readme/src/') and v['path'].endswith('.html')}
        stem = Path(p).stem
        matched = any(stem == s+'-dark' or stem == s+'-light' for s in stems)
        return ('readme-generated-images','generated-asset') if matched else ('readme-other-images','binary-asset')
    if p.startswith('packages/tui/'):
        rel=p.removeprefix('packages/tui/')
        if '/' not in rel: return 'tui-package','documentation' if rel.endswith('.md') else 'configuration'
        if rel.startswith('test/'):
            fixture = '/fixture/' in rel or '/lib/' in rel or 'sync-fixture' in rel or '__snapshots__' in rel
            return ('tui-test-fixtures','fixture') if fixture else ('tui-tests','test-unexecuted')
        s=rel.removeprefix('src/')
        if s=='component/prompt/cwd.ts': return 'tui-empty-placeholder','empty'
        if s.startswith('theme/assets/'): return 'tui-theme-data','theme-data'
        if s.startswith('theme/') or s=='context/theme.tsx': return 'tui-theme-engine','implementation'
        if s.startswith('config/') or s=='keymap.tsx': return 'tui-config-keymap','implementation'
        if s.startswith('plugin/'): return 'tui-plugin-facade','implementation'
        if s.startswith('feature-plugins/'): return 'tui-feature-plugins','implementation'
        if s in ['context/permission.tsx','routes/session/permission.tsx','routes/session/question.tsx']: return 'tui-permission-question','implementation'
        if s.startswith('routes/session/'): return 'tui-session-view','implementation'
        if s in ['attention.ts','audio.ts','audio.d.ts']: return 'tui-attention-audio','type-declaration' if s.endswith('.d.ts') else 'implementation'
        if s in ['terminal-win32.ts','clipboard.ts','editor.ts','editor-zed.ts','context/editor.ts','context/clipboard.tsx']: return 'tui-terminal-editor','implementation'
        if s in ['context/catalog.ts','context/data.tsx','context/event.ts','context/sdk.tsx','context/session-actions.ts','context/session-history.ts','context/sync.tsx','types.ts']: return 'tui-v2-transport-state','implementation'
        if s in ['context/local.tsx','context/kv.tsx','context/project.tsx','util/agent.ts','util/persistence.ts']: return 'tui-selection-persistence','implementation'
        if s in ['context/demo-run.ts','context/demo.ts']: return 'tui-demo-runtime','implementation'
        if s in ['context/replay.ts','context/thinking.ts']: return 'tui-replay-thinking','implementation'
        if s in ['prompt/history.tsx','prompt/stash.tsx','prompt/frecency.tsx','component/prompt/history.tsx','component/prompt/stash.tsx','component/prompt/frecency.tsx']: return 'tui-prompt-history','compatibility-export' if s.startswith('component/') else 'implementation'
        if s.startswith(('component/prompt/','prompt/')): return 'tui-prompt','implementation'
        if s.startswith('ui/') or s.startswith('component/dialog-') or s=='component/command-palette.tsx': return 'tui-dialogs-widgets','implementation'
        if s=='parsers-config.ts': return 'tui-parser-config','configuration-source'
        if s in ['util/error.ts','util/record.ts']: return 'tui-error-shapes','implementation'
        if s in ['util/collapse-tool-output.ts','util/session-message.ts','util/tool-display.ts','util/revert-diff.ts','util/transcript.ts']: return 'tui-message-export-helpers','implementation'
        if s in ['util/layout.ts','util/renderer.ts','util/scroll.ts','util/selection.ts','util/signal.ts']: return 'tui-render-input-helpers','implementation'
        if s.startswith('util/') or s=='logo.ts': return 'tui-presentation-helpers','implementation'
        if s in ['index.tsx','app.tsx','runtime.tsx'] or s.startswith(('context/','routes/home','component/')): return 'tui-lifecycle-routes','implementation'
        raise ValueError(p)
    if p.startswith('packages/ui/'):
        rel=p.removeprefix('packages/ui/')
        if rel=='LICENSE': return 'ui-license-unread','license-notice'
        if '/' not in rel: return 'ui-package', 'documentation' if rel.endswith('.md') else ('implementation' if rel.endswith('.ts') else 'configuration')
        if rel in ['script/tailwind.ts','script/colors.txt','src/styles/tailwind/colors.css']: return 'ui-tailwind-generation','generated' if rel.endswith('.css') else ('generator' if rel.endswith('.ts') else 'generator-input')
        if rel=='script/build-oc2-v2-overrides.ts': return 'ui-oc2-generation','generator'
        s=rel.removeprefix('src/')
        if s.endswith(('.test.ts','.test.tsx')): return 'ui-tests','test-unexecuted'
        if s.endswith('.stories.tsx') or s.startswith('storybook/'): return 'ui-stories-fixtures','story' if s.endswith('.stories.tsx') else 'fixture'
        if s.startswith('i18n/'): return 'ui-localization-data','localization'
        if s.startswith('assets/icons/file-types/'): return 'ui-file-icon-assets','vector-asset-source'
        if s.startswith('assets/icons/provider/'): return 'ui-provider-icon-assets','vector-asset-source'
        if s.startswith('assets/fonts/'): return 'ui-font-assets','binary-asset'
        if s.startswith('assets/audio/'): return 'ui-audio-assets','binary-asset'
        if s.startswith('assets/'): return 'ui-app-image-assets','binary-or-vector-asset'
        if s.startswith(('components/file-icons/','components/provider-icons/')): return 'ui-generated-icon-products','generated'
        if s.startswith('components/app-icons/'): return 'ui-app-sprite-provenance','asset-or-declaration-provenance-unverified'
        if s.startswith('theme/themes/'): return 'ui-theme-data', 'partially-generated-theme-data' if s.endswith('oc-2.json') else 'theme-data'
        if s.startswith('theme/'): return 'ui-theme-engine','handwritten-schema' if s.endswith('.schema.json') else 'implementation'
        if s.startswith(('styles/','v2/styles/')) or s.endswith('.css'): return 'ui-styles','stylesheet'
        if s=='context/dialog.tsx': return 'ui-dialog-context','implementation'
        if s=='context/i18n.tsx': return 'ui-i18n-runtime','implementation'
        if s.startswith('context/marked'): return 'ui-markdown','implementation'
        if s.startswith('context/') or s=='custom-elements.d.ts': return 'ui-context-services','type-declaration' if s.endswith('.d.ts') else 'implementation'
        if s.startswith('hooks/') or s in ['components/list.tsx','components/scroll-view.tsx']: return 'ui-list-scroll','implementation'
        if s in ['components/file-icon.tsx','components/provider-icon.tsx','components/app-icon.tsx','components/font.tsx']: return 'ui-icon-consumers','implementation'
        if s.startswith('v2/components/'): return 'ui-v2-primitives','implementation'
        if s in ['components/motion-spring.tsx','components/animated-number.tsx','components/text-reveal.tsx','components/text-shimmer.tsx','components/text-strikethrough.tsx','components/typewriter.tsx']: return 'ui-motion','implementation'
        if s.startswith('components/'): return 'ui-primitives','implementation'
        raise ValueError(p)
    raise ValueError(p)

entries=[]
for item in tree:
    fid, classification = route(item['path'])
    f = families[fid]
    if item['path'] in captured:
        depth='inspected'
        reason='Exact source captured and inspected in selected semantic or structural scope; see l1.md and decisive-evidence.md. This does not mean every branch/value was audited. '+f['semantic_limits']
    elif f['metadata_only']:
        depth='metadata-only'
        reason='Assigned-tree identity and boundary references only; file content not inspected. '+f['semantic_limits']
    else:
        depth='family-supported'
        reason='Unread individual entry grouped through the listed inspected producer, consumer or representative. '+f['source_implications']+' '+f['semantic_limits']
    entries.append({**item, 'family':fid, 'classification':classification, 'evidence-depth':depth,
                    'representative_source_paths':f['representative_source_paths'], 'reason':reason})

assert len(entries)==2087
assert len({v['path'] for v in entries})==2087
assert {v['path'] for v in entries}=={v['path'] for v in tree}
for f in families.values():
    members=[v for v in entries if v['family']==f['id']]
    f['path_count']=len(members)
    f['byte_count']=sum(v.get('size',0) for v in members)
    f['depth_counts']=dict(collections.Counter(v['evidence-depth'] for v in members))
    f['classification_counts']=dict(collections.Counter(v['classification'] for v in members))
    assert members, f['id']

coverage = {
 'unit':'design-tui', 'layer':'L1', 'status':'submitted; judgment pending',
 'source_commit':COMMIT, 'protocol_commit':PROTOCOL,
 'input_file':str(INPUT), 'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),
 'assigned_path_count':len(tree), 'covered_path_count':len(entries),
 'depth_definition':{
   'inspected':'Exact captured source received focused semantic/structural inspection; not a claim that every line/branch/value was audited.',
   'family-supported':'Individual bytes not read; bounded facts come from named inspected representative, producer or consumer. No individual assertion/render/provenance implied.',
   'metadata-only':'Only assigned-tree identity and external boundary references; no claimed semantic understanding of the file.'},
 'execution_status':'No product tests, builds, typechecks, generation, app rendering, terminal sessions or remote mutations executed.',
 'depth_counts':dict(collections.Counter(v['evidence-depth'] for v in entries)),
 'classification_counts':dict(collections.Counter(v['classification'] for v in entries)),
 'families':list(families.values()), 'entries':entries}
(BASE/'coverage.json').write_text(json.dumps(coverage,indent=2,ensure_ascii=False)+'\n')

for row in manifest['captures']:
    data=(BASE/row['local_capture_file']).read_bytes()
    assert len(data)==row['byte_length']
    assert hashlib.sha256(data).hexdigest()==row['sha256']
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['git_blob_sha']
    row['inspection_scope']='Focused semantic/structural source inspection; l1.md cites claims and bounded line ranges. Full captured bytes retained; no whole-file behavioral completeness claim.'
for row in manifest.get('failed_captures',[]):
    if row['path']=='schema/tui.json':
        row['resolution']='Recovered complete exact bytes with GitHub fetch_blob and verified against the assigned Git blob SHA.'
        row['resolved_by']='blob-captures/schema__tui.json.json'
manifest['source_capture_method']='GitHub connector fetch_file at exact ref; schema/tui.json recovered with fetch_blob by exact assigned SHA. Original responses retained; Python verifies SHA-256, byte length and Git blob SHA.'
manifest['read_scope_note']='Captured bytes are complete; semantic inspection is focused and family-bounded. Original connector responses may include transport metadata. Failed initial empty schema response is retained as resolved transport evidence.'
(BASE/'sources.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'paths':len(entries),'families':len(families),'depth_counts':coverage['depth_counts'],
                  'source_captures':len(captured),'source_bytes':sum(v['byte_length'] for v in captured.values()),
                  'boundary_captures':sum(v['path'] not in {e['path'] for e in tree} for v in captured.values())},indent=2))
