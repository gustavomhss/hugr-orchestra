// @atlas/cli — src/mine-pool.ts  (WP-FIX-CONCURRENCY — the bounded proposer pool)
//
// The `POOL_WIDTH`-wide worker pool behind `ControllerDeps.visitAll`. It parallelizes exactly ONE thing:
// `SiteProposer.propose`, the network-bound S2 model call that costs ~18s per site and made a 200-site
// genesis run take 54 minutes. Admission, ranking and every durable write stay on the main thread.
//
// THE MAIN THREAD BLOCKS, AND THAT IS DELIBERATE. `GenesisApi.genesis` is synchronous and must stay so —
// its only production caller is `mine.ts`, but ~40 call sites across the frozen test suites read
// `api.genesis(...).seeded` directly, so turning the surface into a `Promise` is not a change this seam is
// allowed to make. So the pool dispatches a batch to the workers, blocks on `Atomics.wait` until all of
// them have answered, and returns the answers in SLOT order. Concurrency stays entirely inside one
// synchronous call, which is precisely what lets the run controller remain unaware of it.
//
// REASSEMBLY IS BY SLOT, NEVER BY ARRIVAL. Every answer carries the index of the job that produced it and
// is written to `out[slot]`. Completion order is therefore not merely ignored — it is never represented
// anywhere, so there is no ordering for a later edit to accidentally start honouring.

import { existsSync } from "node:fs"
import { fileURLToPath } from "node:url"
import { MessageChannel, receiveMessageOnPort, Worker } from "node:worker_threads"
import type { MessagePort } from "node:worker_threads"
import { loadModelConfig, ModelCommandError, ModelConfigError } from "@atlas/adapter-io"
import { POOL_WIDTH } from "@atlas/genesis"
import type { Candidate, ExtractResult, SiteProposer, VisitAttempt } from "@atlas/genesis"
import type { MineSlot } from "./mine-proposer.js"
import type { PoolAnswer } from "./mine-worker.js"

/** The compiled worker entry, resolved RELATIVE TO THIS MODULE so it is correct from `dist/` without any
 *  knowledge of the install layout. */
const WORKER_ENTRY = new URL("./mine-worker.js", import.meta.url)

/**
 * Is the pool actually usable here? A worker thread loads a FILE, so this capability exists only where the
 * package has been COMPILED — beside `mine-pool.js` in `dist/`. Anything running this module straight from
 * TypeScript source (the test runner) sits next to `mine-worker.ts`, and `./mine-worker.js` is simply not
 * there.
 *
 * ASKED, NOT ASSUMED, AND THAT IS THE POINT. Constructing a `Worker` over a missing entry does not fail
 * usefully: the thread never answers, the pool waits out its liveness bound, every site in the batch faults,
 * and the process is left holding handles it cannot join. That is a hang, and it is one this seam CAUSED
 * rather than found — the pre-change suite exited cleanly and the first build of this pool made it stop
 * exiting. So availability is a question with an answer, and when the answer is no the caller keeps the
 * sequential path, which is not a degraded mode but the exact behaviour that shipped before.
 */
export function proposerPoolAvailable(): boolean {
  return existsSync(fileURLToPath(WORKER_ENTRY))
}

/** Poll the shared completion counter without relying on parent-thread event callbacks. */
const WAIT_SLICE_MS = 250
/** Initial allowance for worker/module/prompt initialization, in addition to every queued command's cap.
 *  This is a liveness policy, not a calibrated model latency limit. */
const STARTUP_GRACE_MS = 30_000

/** The pool's answer for one site — the proposer's seed, or the fault that stopped it. */
export type PoolResult =
  | { readonly ok: true; readonly seed: ReturnType<SiteProposer["propose"]> }
  | { readonly ok: false; readonly error: Error }

export interface ProposerPool {
  /** Propose at every candidate, in parallel, returning one result per candidate POSITIONALLY ALIGNED with
   *  the input. Never throws: a fault is an `ok: false` result for the site it belongs to. */
  proposeAll(cands: readonly Candidate[]): readonly PoolResult[]
  /** Terminate every worker. Idempotent. Must be called or the process will not exit. */
  close(): void
}

/** Rebuild an Error carrying the worker's ORIGINAL `name`. The name is what `mine.ts` classifies on
 *  (`ModelCommandError` ⇒ a wiring fault, not a mining outcome), and it does not survive a structured clone
 *  of a custom subclass — so it is carried as a field and reattached here. Known model failure tags rebuild
 *  their original error class; arbitrary worker error names/reasons never select that constructor. */
function rehydrate(a: Extract<PoolAnswer, { ok: false }>): Error {
  if (a.name === "ModelCommandError" && (a.reason === "not-found" || a.reason === "timeout" || a.reason === "nonzero-exit")) {
    return new ModelCommandError(a.reason, a.message)
  }
  const e = new Error(a.message)
  e.name = a.name
  return e
}

interface Seat {
  readonly worker: Worker
  readonly port: MessagePort
}

/**
 * Start a pool of `width` workers, each able to rebuild the operator's proposer from `(repoPath, env, slot)`.
 *
 * Workers are started EAGERLY (one thread each, ~2.5s of module loading) but resolve their proposer LAZILY,
 * so the startup cost is paid once, in parallel, rather than once per site.
 *
 * `slot` is the arm the main thread resolved for this pass (`runMineArms` threads one per arm). It MUST cross
 * into `workerData`: without it every worker falls back to `resolveMineSlot(env)`, so a multi-arm run would
 * mine every arm with the advisory proposer while the in-thread path used the right one. Absent ⇒ the worker
 * resolves the arm from `env`, exactly as the in-thread path does.
 */
export function createProposerPool(
  repoPath: string,
  env: NodeJS.ProcessEnv,
  slot?: MineSlot,
  width: number = POOL_WIDTH,
): ProposerPool {
  if (!Number.isSafeInteger(width) || width <= 0) throw new Error("the proposer pool width must be a positive integer")
  // No config means no model call; otherwise use the resolved operator timeout, including its default.
  const modelTimeoutMs = loadModelConfig(repoPath, env)?.timeoutMs ?? 0
  if (!Number.isSafeInteger(modelTimeoutMs) || modelTimeoutMs < 0) {
    throw new ModelConfigError("malformed", "the proposer pool timeout must be a safely representable integer")
  }
  const sab = new SharedArrayBuffer(4)
  const done = new Int32Array(sab)
  const seats: Seat[] = []
  for (let k = 0; k < width; k++) {
    const { port1, port2 } = new MessageChannel()
    const worker = new Worker(WORKER_ENTRY, {
      workerData: { sab, port: port2, repoPath, env, slot },
      transferList: [port2],
    })
    // Neither the thread nor the channel may keep the CLI alive; `close()` is what ends them.
    worker.unref()
    port1.unref()
    seats.push({ worker, port: port1 })
  }
  let closed = false
  let died = 0
  // These callbacks run between synchronous calls, NOT while the parent is blocked in Atomics.wait.
  // They can short-circuit a later call; only the clock deadline below guarantees this call terminates.
  for (const s of seats) {
    s.worker.on("exit", () => void (died += 1))
    s.worker.on("error", () => void (died += 1))
  }
  const close = (): void => {
    if (closed) return
    closed = true
    for (const s of seats) {
      s.port.close()
      void s.worker.terminate()
    }
  }

  const proposeAll = (cands: readonly Candidate[]): readonly PoolResult[] => {
    const n = cands.length
    const out = new Array<PoolResult | undefined>(n)
    if (n === 0) return []
    if (closed) return cands.map(() => ({ ok: false, error: new Error("the proposer pool is closed") }))

    const waitMs = Math.ceil(n / seats.length) * modelTimeoutMs + STARTUP_GRACE_MS
    const deadline = performance.now() + waitMs
    if (!Number.isSafeInteger(waitMs) || !Number.isFinite(deadline) || deadline > Number.MAX_SAFE_INTEGER) {
      return cands.map(() => ({
        ok: false,
        error: new ModelCommandError("timeout", "the proposer pool cannot represent the configured batch liveness bound"),
      }))
    }
    Atomics.store(done, 0, 0)
    cands.forEach((cand, slot) => seats[slot % seats.length]!.port.postMessage({ slot, cand }))

    // BLOCK until every job has answered. `Atomics.wait` is the only primitive that lets a synchronous
    // function wait on work happening on other threads. Slices alone do NOT guarantee liveness: a dead
    // worker cannot increment the counter, and the parent's exit/error callbacks cannot run here.
    let landed = 0
    let expired = false
    while (landed < n) {
      const seen = Atomics.load(done, 0)
      if (seen >= n) break
      const remaining = deadline - performance.now()
      if (remaining <= 0) {
        expired = true
        break
      }
      Atomics.wait(done, 0, seen, Math.min(WAIT_SLICE_MS, remaining))
      landed = Atomics.load(done, 0)
      if (landed < n && died > 0) break // a worker exited without answering — stop waiting, fault below
    }

    // Drain every port. A message names its own slot, so this is order-insensitive by construction.
    for (const s of seats) {
      let m: { message: { slot: number; answer: PoolAnswer } } | undefined
      while ((m = receiveMessageOnPort(s.port) as typeof m) !== undefined) {
        const { slot, answer } = m.message
        out[slot] = answer.ok ? { ok: true, seed: answer.seed } : { ok: false, error: rehydrate(answer) }
      }
    }
    // A slot with no answer is a fault for THAT SITE — never a silently dropped site, and never an
    // abstention: "the model said nothing" and "the worker never answered" are different claims and only
    // one of them is a fact about the repository.
    // Drain first, then retire the pool so a late response cannot be mistaken for another batch's slot.
    if (expired || died > 0) close()
    // Array#map skips holes. Every missing position must instead become a dense, governed run fault.
    return Array.from({ length: n }, (_, slot): PoolResult => out[slot] ?? {
      ok: false,
      error: new ModelCommandError(
        died > 0 ? "nonzero-exit" : "timeout",
        "the proposer pool returned no answer for this site within its worker liveness bound",
      ),
    })
  }

  return {
    proposeAll,
    close,
  }
}

/**
 * The one per-site expression, supplied by the driver: extract at `cand` using `proposer`.
 *
 * It is a PARAMETER rather than something this file assembles, and that is the whole trick behind the
 * byte-identity contract. The sequential path calls it with the real proposer; the batched path calls it
 * with a proposer holding the already-fetched claim. There is therefore only ONE admission expression, one
 * budget and one gate in the process — so the two paths cannot drift apart while both stay green, which is
 * exactly what would happen if this file rebuilt the call itself from the same ingredients.
 */
export type SiteVisit = (cand: Candidate, proposer: SiteProposer) => ExtractResult

/**
 * Build the `ControllerDeps.visitAll` port over a pool.
 *
 * THE SHAPE OF THE WORK IS SPLIT, NOT MOVED: the model calls for the whole batch happen first and in
 * parallel (`proposeAll`), then each site is admitted on THIS thread, in the order the batch was handed
 * over. Admission is mechanical and local, so it costs nothing to keep here — and keeping it here is what
 * lets the gate, the index and the store remain single-threaded.
 *
 * FAULTS ARE REPORTED IN RANK ORDER. `onFault` fires as the loop walks ascending rank, so the fault an
 * operator is shown is the FIRST BY RANK — never the first by wall-clock, which with several calls in
 * flight is an arbitrary choice among them and would make the reported cause of a failed run depend on
 * which thread happened to finish first. Sites past the first fault are still reported here; the caller's
 * first-write-wins capture is what keeps only the lowest-ranked one, matching a sequential run exactly.
 */
export function makeVisitAll(
  pool: ProposerPool,
  visitWith: SiteVisit,
  onFault?: (e: Error) => void,
): (cands: readonly Candidate[]) => readonly VisitAttempt[] {
  return (cands) => {
    const seeds = pool.proposeAll(cands)
    const attempts: VisitAttempt[] = []
    cands.forEach((cand, k) => {
      const r = seeds[k]
      if (r === undefined || !r.ok) {
        const error = r?.error ?? new Error("the proposer pool returned no answer for this site")
        if (error.name === "ModelCommandError") onFault?.(error)
        attempts.push({ ok: false, error })
        return
      }
      // The seed is rebuilt around the LOCAL `cand`. A structured clone is value-equal but not
      // identity-equal, and the gate receives both the seed and the candidate — so handing it a cloned
      // `seed.cand` would put two different objects for one site into a seam that has every right to
      // expect one.
      // Tags carry no candidate. Rebind EVERY real proposal, including nested collection members.
      const held: SiteProposer = {
        propose: () => {
          const seed = r.seed
          if (seed === null || "abstain" in seed) return seed
          if ("proposals" in seed) {
            return { proposals: seed.proposals.map((item) => "abstain" in item ? item : { ...item, cand }) }
          }
          return { ...seed, cand }
        },
      }
      try {
        attempts.push({ ok: true, value: visitWith(cand, held) })
      } catch (error) {
        attempts.push({ ok: false, error })
      }
    })
    return attempts
  }
}
