from pathlib import Path
import json, re, hashlib, collections

ROOT = Path('/workspace/scratch/992c54067adf/genesis-s2/producers/desktop-web')
INPUT = Path('/workspace/scratch/992c54067adf/genesis-s2/deliverable/inputs/desktop-web-tree.json')
COMMIT = '1cde2ff7a71bcf7aecb5d030917b577165135d38'
PROTOCOL = 'ee2521a5b966bd505cc95bd1c733e09e12f33531'
D = 'apps/desktop/'
M = D + 'src/main/'
R = D + 'src/renderer/'
P = D + 'src/preload/'
S = D + 'scripts/'
H = D + 'resources/linux/app-dock-accessibility/'

# Family contracts are semantic summaries of the cited captured witnesses. A leaf
# inheriting a family has not thereby received a whole-file implementation review.
F = {}
def family(key, purpose, reps, consumer, maintenance, limits):
    F[key] = dict(id=key, purpose=purpose, representative_source_paths=reps,
                  consumers_and_boundary=consumer, maintenance_implications=maintenance,
                  evidence_limits=limits)

family('authority-guides', 'Repository instructions, host READMEs and operating guides distinguish thin hosts from shared application behavior.',
       [D+'AGENTS.md', 'apps/web/AGENTS.md', 'packages/app-shell/AGENTS.md', '.orchestra/skills/desktop-startup-maintenance/SKILL.md', 'docs/guides/desktop-startup.md', 'docs/guides/keep-awake.md'],
       'Developers and maintainers; docs and repository skills are maintenance inputs, not shipped runtime logic.',
       'Check current source before carrying forward performance, startup, error-copy or first-run claims. Keep main/preload/renderer and localization rules aligned.',
       'Guides contain intent and historical measurements. Shared shell and backend internals are outside this unit; guide assertions are not fresh product evidence.')
family('startup-owned-server', 'Electron main owns launch/quit, initialization Deferred and the default authenticated CLI serve child.',
       [M+'index.ts', M+'owned-serve.ts', M+'server.ts', M+'initialization.ts', M+'index.test.ts', M+'owned-serve.test.ts'],
       'Renderer awaitInitialization consumes URL/credentials only after owned health resolves; shared-daemon selector is an alternate branch.',
       'Preserve readiness/error forwarding, scoped state/cwd, output redaction, stop ordering and real child-close semantics. Stable-exit backoff indexing is an identified static discrepancy. The main-fiber failure observer logs, shows a hardcoded-English native dialog and exits; its visible copy conflicts with desktop AGENTS localization requirements.',
       'Source inspection only; startup timing, child reaping and OS behavior were not executed. The small mode test does not cover restart timing.')
family('window-lifecycle', 'Window identity/state restoration, close flushing, navigation restrictions and recovery connect Electron windows to persisted per-window state.',
       [M+'windows.ts', M+'window-registry.ts', M+'window-flush.ts', M+'window-flush.test.ts', M+'renderer-origin.ts', M+'renderer-origin.test.ts'],
       'Electron BrowserWindow, renderer unload callbacks, settings stores and OS window managers.',
       'Keep window IDs independent, flush bounded to three seconds, sandboxed preloads, trusted renderer origin and recovery paths coherent. Full CSP is report-only.',
       'Fake-window tests were read but not run; display backend, multi-monitor placement and recovery dialogs were not exercised.')
family('ipc-capabilities', 'General renderer IPC wraps origin validation; typed preload exposes selected APIs; picked files use sender-scoped tokens and budgets.',
       [M+'ipc.ts', P+'index.ts', M+'attachment-picker.ts', M+'renderer-origin.ts'],
       'window.api to Electron main; separate Dock, live, WSL and response handlers must be reviewed under their own admission policy.',
       'Preserve payload validation and native picker authority; do not assume direct ipcMain.handle registrations use the general wrapper.',
       'Preload/type leaves not directly selected are family-supported. No exploitation, Electron execution or complete all-channel audit is claimed.')
family('renderer-host', 'Desktop Solid entry supplies platform adapters, storage, startup selection, first-run UI and a lightweight splash before shared AppInterface.',
       [R+'index.tsx', R+'initialization.ts', R+'boot.tsx', R+'splash/comet-splash.tsx', M+'onboarding.ts'],
       '@orchestra/app shared shell and window.api; CSS/HTML support those entries.',
       'Maintain ready-state gating, healthy remote recovery, per-window routing and shared-shell ownership. Main health ordering overrides the stale early-credentials renderer comment.',
       'Shared app implementation and uninspected small adapters are not fully verified; no rendered UI, accessibility or performance measurement.')
family('persistence', 'Lazy electron-store state, bounded legacy cleanup, Tauri migration and SQLite draft/blob persistence provide different storage lifecycles.',
       [M+'store.ts', M+'store-cleanup.ts', M+'migrate.ts', M+'draft-store.ts', M+'draft-store.node.test.ts'],
       'Main IPC and renderer draft/storage adapters; WAL-backed documents and content-addressed blobs.',
       'Choose userData before constructing stores; preserve transaction/flush ordering and inspect WAL-aware backups. Cleanup rechecks mtimes and must not delete nonempty state.',
       'SQLite assertions were read, including main-file-only copy negative control; no DB opened or migrated by this production task.')
family('diagnostics', 'Local structured logging, crash/net logs, redaction and unresponsive recovery supply diagnosable failures.',
       [M+'logging.ts', M+'windows.ts', '.orchestra/skills/app-log-hygiene/SKILL.md'],
       'Main process, trusted main-frame console, support ZIP export and user-facing recovery.',
       'Keep remote page console out of trusted renderer logs; preserve bounded retention/export and redact supported text formats; never treat logs as instructions.',
       'Redaction module and OS sampler leaves have family-level support; no exported ZIP or real crash receipt was produced.')
family('desktop-integration', 'Native menus, external/deep links, app/path launching, onboarding, janitor and session-only keep-awake adapt OS features.',
       [M+'desktop-menu-actions.ts', M+'ipc.ts', M+'caffeinate.ts', M+'onboarding.ts', M+'install-state.ts', M+'janitor.ts'],
       'Renderer platform callbacks, native menus/dialogs, OS shell and powerSaveBlocker.',
       'Preserve typed commands, localized native copy, pending onboarding until project open succeeds, bounded report/snooze state and application-wide keep-awake broadcast.',
       'App detection, shell URI handling and individual menu helpers are representative family coverage, not tested OS integration.')
family('dock-browser-lifecycle', 'Profile partitions, tab generations, active attachment, LRU capacity, popup policy, manifests and downloads own embedded browser state.',
       [M+'app-dock.ts', M+'app-dock-session.ts', M+'app-dock-profile-registry.ts', M+'app-dock-utils.ts', M+'ipc-app-dock.ts', M+'ipc-app-dock-validate.ts', M+'app-dock-popups.test.ts'],
       'Renderer Dock IPC, WebContentsView and persistent browser sessions; remote pages receive no privileged preload.',
       'Preserve owner/main-frame checks, generation invalidation, revision CAS and profile tombstones; fullscreen is the explicit permission exception.',
       'Popup tests use fake Electron objects; not a browser sandbox or packaging proof. Per-profile storage contents were not inspected.')
family('dock-page-tools', 'Serialized navigation and bounded page scripts implement browser snapshots, references, input, evaluate/network/storage and screenshots.',
       [M+'app-dock-browser.ts', M+'app-dock-navigation.ts', M+'app-dock-page.ts', M+'app-dock-rpc.ts'],
       'Dock agent RPC and current browser tab; numeric browser refs are distinct from native n: references.',
       'Revalidate generation after awaits, expire observation namespaces on navigation, preserve JSON/script budgets and browser/native selector separation.',
       'Script strings are handwritten source builders, not proven generated artifacts. Individual interaction helper leaves and actual page behavior remain unexecuted.')
family('dock-native-host', 'Native protocol, admission queues, binding identities and helper channel manage scoped Linux accessibility requests and honest uncertain outcomes.',
       [M+'app-dock-native.ts', M+'app-dock-native-protocol.ts', M+'app-dock-native-client.ts', M+'app-dock-native-channel.ts', M+'app-dock-native-runtime.ts', M+'app-dock-native-workspace.ts', M+'app-dock-native-client-admission.test.ts', M+'app-dock-rpc-workspace-rebind.test.ts'],
       'AppDockRPC, Docker helper channel and Python AT-SPI bridge; full runtime/session/binding/process identity crosses the boundary.',
       'Retain admission reservations while teardown is uncertain, release only on terminal/reap evidence, distinguish not-dispatched from unknown, and prevent stale binding reuse.',
       'Memory-channel race tests read but unexecuted. Dedicated-container resource checks and real provider effects are not runtime-proven here.')
family('linux-runtime', 'Local Docker runtime metadata and lifecycle own the Xpra desktop, visible browser view, TLS viewer and guest session.',
       [M+'app-dock-runtime.ts', M+'app-dock-runtime-backend.ts', M+'app-dock-runtime-docker.ts', M+'app-dock-linux.ts', D+'resources/linux-runtime/Dockerfile', D+'resources/linux-runtime/README.md', D+'resources/linux-runtime/workspace.py', M+'app-dock-runtime-identity.test.ts'],
       'Main-only secrets/owner metadata to local Docker socket or named pipe; renderer receives runtime DTO and viewer placement.',
       'Pin immutable container ID and local endpoint, reverify ownership before actions, keep ordinary workspace readiness separate from native readiness, preserve session file permissions and process birth identity.',
       'No Docker daemon, image build, Xpra/TLS display or integration test ran. Seccomp provenance is documented; its bytes, signing key and apt package closure were not independently authenticated.')
family('linux-access', 'Separate linux.rpc transport provides guest exec, bounded file operations and session-owned terminals with explicit cancellation.',
       [M+'linux-workspace-rpc.ts', M+'linux-workspace-access.ts', M+'linux-workspace-files.ts', M+'linux-workspace-omni.ts', D+'resources/linux-runtime/workspace-access.py'],
       'Agent channel to verified workspace container; terminal owner/session and runtime start identity fence operations.',
       'Keep cancel/reap and session-close ownership, output/input limits and transport termination distinct. Absolute guest paths are not a host filesystem sandbox.',
       'Guest process, file and PTY behavior not executed; source only establishes checks and intended authority.')
family('native-accessibility-helper', 'Python AT-SPI helper discovers host-confirmed windows, fences process/ancestry identities, observes bounded trees and admits guarded actions.',
       [H+'main.py', H+'bindings.py', H+'context.py', H+'refs.py', H+'snapshot.py', H+'actions.py'],
       'Host native client over framed JSON; D-Bus/AT-SPI providers, X11 focus/pointer and keyboard helpers.',
       'Preserve explicit host confirmation, protected-field suppression, finite budgets, non-atomic observations and unverified logical identity/postconditions.',
       'Keyboard and bus leaves are family-supported by callers; no GTK/Qt/Electron UI, focus, mutation effect or timing claim was re-proved.')
family('wsl', 'Windows distro manager verifies Linux CLI artifacts, starts authenticated per-distro sidecars and publishes typed runtime state.',
       [M+'wsl/servers.ts', M+'wsl/runtime.ts', M+'wsl/artifact.ts', M+'wsl/sidecar.ts', M+'wsl/startup.ts', M+'wsl/policy.ts', M+'wsl/ipc.ts', R+'wsl/connections.ts'],
       'WSL IPC/preload to wsl.exe/guest binaries and renderer server selection.',
       'Keep generation fences, regular-file/hash/version checks, sanitized guest env and authenticated positive plus wrong-password health checks. Direct WSL registrations are separate from the general IPC origin wrapper.',
       'No Windows, WSL install, distro command or guest binary ran; shell quoting and every artifact replacement branch lack execution evidence.')
family('live-senses', 'Live orchestration owns capture, readiness, settings/key, audio conditioning, transcription and durable meeting/session delivery.',
       [M+'live-loop.ts', M+'live-senses.ts', M+'live-capture.ts', M+'live-readiness.ts', M+'live-audio.ts', M+'live-settings.ts', M+'live-settings.test.ts', M+'live-key.ts', M+'live-transcriber.ts', M+'live-meeting-client.ts', M+'live-session-client.ts', M+'live-ipc.ts', P+'live-capture.ts'],
       'Hidden isolated capture renderer, OS media permissions, Deepgram WebSocket, authenticated backend meeting/session endpoints and main overlay state.',
       'Preserve source eligibility, one answer at a time, bounded audio replay, stable segment IDs and stop/flush ordering; direct live IPC needs its own admission review.',
       'No microphone, screen, provider, WebSocket or paid model call; backend endpoint semantics and consent handling were not independently audited.')
family('live-overlay', 'Main-owned live overlay state, narrow preload and Solid view support answers, captions, navigation and protected always-on-top display.',
       [M+'live-overlay.ts', M+'live-overlay-state.ts', P+'live.ts', R+'live/index.tsx'],
       'Main live loop to overlay window; actions are filtered by overlay sender/main frame.',
       'Keep overlay positioning/hotkey registration and source/answer state coherent; content protection requires platform verification. Overlay copy is separate English/Brazilian Portuguese, not the locale dictionary mechanism.',
       'Only representative renderer spans selected; full visual layout, all action transitions and actual screen-sharing protection are unverified.')
family('response-transfer', 'Native save capability and renderer stream adapter transfer raw bytes with bounded in-flight writes and atomic final rename.',
       [M+'response-download.ts', R+'response-download.ts', P+'index.ts', M+'response-download.test.ts'],
       'Renderer response body to native dialog, opaque handle, temporary file and user-selected destination.',
       'Bind capability to originating main frame, maintain sequence/backpressure and distinguish cancellation before rename from final committed result.',
       'Tests read include foreign sender, malformed sequence and unowned temp collision; none executed. Platform native save dialogs remain unverified.')
family('cli-process', 'Manifest-bound CLI installation, shared daemon discovery, shell environment and optional Omni adapters provide executable/process boundaries.',
       [M+'cli-artifacts.ts', M+'cli-install.ts', M+'background-cli.ts', M+'shell-env.ts', M+'omni-process.ts', M+'omni-host.ts', M+'omni-boot.ts', M+'server.ts'],
       'Main owned/shared server, WSL and Linux access launch sites; core Omni/ripgrep/tree-sitter loaders are external boundaries.',
       'Preserve digest-target cache checks, companion resources, version equality, environment stripping and child exit-versus-close/backpressure semantics.',
       'Signature, version and process checks are source behavior only. Core native addon internals and all small environment fixtures are not fully inspected.')
family('packaging', 'Electron build configuration and staging scripts lay out signed executable resources, platform installers and update metadata.',
       [D+'electron-builder.config.ts', D+'electron.vite.config.ts', S+'cli-staging.ts', S+'prebuild.ts', S+'predev.ts', S+'copy-icons.ts'],
       'electron-vite, electron-builder and release pipeline; packaged runtime resolves extraResources outside app.asar.',
       'Keep exact manifests/signature checks before and after packing, avoid post-hash executable rewriting, stage required notices and independent main/preload/renderer entries.',
       'No install/build/sign/notarization/update feed ran. Claude/Omni and metadata helper leaves are family-supported, not full script audits.')
family('updater', 'Main updater controller checks/downloads/persists ready state and stops resources before explicit installation.',
       [M+'updater.ts', M+'updater-controller.ts', M+'updater-controller.test.ts', P+'index.ts'],
       'electron-updater to subscribed renderer; unsupported self-update builds announce a release URL.',
       'Maintain single-flight checks and authoritative ready state; persisted version alone is not acceptance of cached bytes.',
       'Mock backend assertions read; no network update, cache, installer or restart execution.')
family('localization', 'Desktop locale dictionaries and typed native message bridge provide host copy with English fallback.',
       [R+'i18n/index.ts', R+'i18n/en.ts', R+'i18n/ar.ts', M+'native-translations.ts'],
       'Desktop renderer translator and shared desktop-native language contract; native messages reach menus/dialogs through main.',
       'Update English contract and shared key validation first; locale dictionaries merge onto English. Keep live overlay separate copy visible as an exception.',
       'Representative dictionaries only; no translation-quality, key-parity or all-locale rendering audit. No generator is inferred for locale files.')
family('assets-icons-splash', 'Channel icon assets and pre-rendered splash media are consumed by platform packaging and renderer splash.',
       [D+'icons/README.md', S+'mac-icons.py', S+'copy-icons.ts', D+'electron-builder.config.ts', R+'splash/comet-splash.tsx'],
       'Native window/Dock/tray/installers and splash video/reduced-motion still.',
       'mac-icons.py explicitly generates only macOS icon.icns/dock.png from a pinned official SVG/toolchain; other renditions follow their documented kit and copy path.',
       'No binary pixels, video, signature or original source kit authenticated. Tray/splash authorship is not established; do not describe every binary as generated.')
family('web-host', 'Vite browser host supplies platform/default-server/token/draft adapters to shared AppInterface.',
       ['apps/web/src/entry.tsx', 'apps/web/vite.config.ts', 'apps/web/README.md'],
       'Browser storage/Notification/external navigation and backend HTTP origin; shared shell owns product screens.',
       'Preserve auth_token removal from address bar and selected-server behavior, allowed external schemes and optional Sentry/sourcemap handling.',
       'No browser run; CLI serving and production origin deployment are documented boundary intent, not independently verified implementation.')
family('generated-dock-corpus', 'Generator renders a handwritten invariant register into four consolidated and per-invariant Markdown artifacts.',
       [D+'docs/corpus/app-dock/generate-corpus.mjs', D+'docs/corpus/app-dock/00-invariant-register.md', D+'docs/corpus/app-dock/invariants/https-only.md', D+'docs/corpus/app-dock/invariants/ipc-sender-validation.md'],
       'Maintainers and reviewers of historic Dock requirements/goldens/cards; no runtime consumer observed.',
       'Edit/check generator literals and actual cited tests together; emitted measured/ready labels are not execution receipts.',
       'Representative outputs read. Generator not run and every historical test line reference not revalidated; source golden files are not reserved Genesis judges/oracles.')
family('historical-proposals', 'Dated Dock accessibility/Linux campaigns, contracts, handoffs and desktop brief record design and prior closure claims.',
       [D+'docs/plans/dock-accessibility/contract.md', D+'docs/plans/dock-accessibility/closeout.md', D+'docs/plans/linux-workspace/CAMPAIGN.md', D+'docs/plans/linux-workspace/skeleton-handoff.md', 'docs/architecture/phase-plans/70-90-briefs/RD-DESKTOP.md'],
       'Historical implementation planning and maintenance context, subordinate to current source and task authority.',
       'Retain dates/baselines and incomplete production boundaries; never carry historical PASS or requested future API forward as present proof.',
       'Representative historical documents inspected; other leaves are family-supported, not read assertions or instructions followed.')
family('native-proof-harness', 'Development-only native images, probes, scenario/contract fixtures and assertion suites support real-provider validation.',
       [D+'test/native/README.md', D+'test/native/apps/README.md', H+'main.py', M+'app-dock-native-client-admission.test.ts'],
       'Developer proof environment for GTK/Qt/Electron, native helper and independent filesystem/config effects.',
       'Retain environment/version/image receipts, process birth identity and independent effects; setup success does not prove semantics and dev flags are not production policy.',
       'No probes, fixtures, Docker recipes or Python/product tests executed. Most harness leaves are purpose/family supported, not individually audited.')
family('omni-proof-harness', 'Packaged Electron smoke matrix distinguishes production shutdown cells from diagnostic and mutation controls.',
       [D+'test/omni-smoke/matrix.ts', M+'omni-process.ts', M+'omni-boot.ts'],
       'Packaged Electron proof harness and isolated process/keychain/LLM fixtures.',
       'Verify actual packaged provenance, live process counts and ownership before crash/quit; emergency cleanup cannot stand for an observed shutdown pass.',
       'Matrix entry/control assertions inspected, supporting harness leaves family-supported. No packaged run or mutation control was executed.')
family('runtime-proof-tools', 'Operator scripts and standalone proof entrypoints drive Dock/Linux runtime or WSL transport for development checks.',
       [M+'app-dock-runtime.ts', M+'linux-workspace-access.ts', D+'test/native/README.md', M+'wsl/runtime.ts'],
       'Developer CLI/manual proof drivers; production runtime modules supply the semantic boundary.',
       'Keep proof configuration isolated and label actual source/runtime identities; scripts may create containers/processes and must not be mistaken for receipts.',
       'Scripts captured where available but not fully selected; family-level purpose only, no execution or command-level assurance.')
family('tooling-config', 'Workspace/toolchain declarations and ignore rules support desktop build, tests and dependency/type resolution.',
       [D+'electron.vite.config.ts', D+'electron-builder.config.ts', M+'draft-store.node.test.ts'],
       'Build/test tooling; Node SQLite tests differ from Bun tests by source declaration.',
       'Maintain cross-platform artifact targets and entrypoint/alias consistency. Configuration existence does not establish a passing build.',
       'Uncaptured config/ignore leaves are metadata-only; no dependency resolution or effective compiler configuration audit.')

def get_family(p):
    n = Path(p).name
    if '/docs/corpus/' in p: return 'generated-dock-corpus'
    if '/docs/plans/' in p or p.startswith('docs/architecture/'): return 'historical-proposals'
    if p.startswith('apps/web/'): return 'web-host'
    if p.endswith('AGENTS.md') or p.startswith('.orchestra/skills/') or p.startswith('docs/guides/') or p in [D+'README.md', M+'README.md', D+'docs/linux-runtime.md', D+'docs/linux-workspace-access.md']: return 'authority-guides'
    if p.startswith(D+'icons/') or p in [S+'mac-icons.py', S+'copy-icons.ts'] or p.startswith(R+'splash/'): return 'assets-icons-splash'
    if p.startswith(D+'test/omni-smoke/'): return 'omni-proof-harness'
    if p.startswith(D+'test/native/'): return 'native-proof-harness'
    if p.startswith(H): return 'native-accessibility-helper'
    if p.startswith(D+'resources/linux-runtime/'): return 'linux-runtime'
    if p.startswith(S+'linux-runtime/') or p.startswith(S) and n.startswith(('app-dock-native-proof','app-dock-workspace-proof','linux-workspace','native-proof-docker','wsl-transport')): return 'runtime-proof-tools'
    if p.startswith(S) or n.startswith(('electron-builder','electron.vite')) or p.startswith(D+'resources/'): return 'packaging'
    if p.startswith(R+'i18n/'): return 'localization'
    if p.startswith(M+'wsl/') or p.startswith(R+'wsl/'): return 'wsl'
    if 'response-download' in n: return 'response-transfer'
    if p.startswith(R+'live/') or n.startswith('live-overlay') or p == P+'live.ts': return 'live-overlay'
    if n.startswith('live-') or n == 'live-plist.test.ts': return 'live-senses'
    if n.startswith('app-dock-native'): return 'dock-native-host'
    if n.startswith(('app-dock-runtime','app-dock-linux','docker-engine')): return 'linux-runtime'
    if n.startswith('linux-workspace'): return 'linux-access'
    if n.startswith(('app-dock-rpc','app-dock-browser','app-dock-page','app-dock-navigation','app-dock-input','app-dock-api','app-dock-tools','app-dock-youtube')) or n.startswith('dock-channel'): return 'dock-page-tools'
    if n.startswith(('app-dock','ipc-app-dock')): return 'dock-browser-lifecycle'
    if n.startswith(('draft-store','store','migrate')): return 'persistence'
    if n.startswith(('window-','windows','renderer-origin','titlebar-frame')): return 'window-lifecycle'
    if n.startswith(('updater',)): return 'updater'
    if n.startswith(('logging','log-redact','unresponsive','debug')): return 'diagnostics'
    if n.startswith(('cli-','background-cli','omni-','ripgrep-env','shell-env')): return 'cli-process'
    if n.startswith(('menu','desktop-menu','apps.','caffeinate','deep-links','external-url','janitor','onboarding','install-state')) and p.startswith(M): return 'desktop-integration'
    if p.startswith(R): return 'renderer-host'
    if n == 'native-translations.ts': return 'localization'
    if p.startswith(P) or n.startswith(('ipc.','attachment-picker')): return 'ipc-capabilities'
    if n.startswith(('index.','owned-serve','server.','initialization.','constants.')) and p.startswith(M): return 'startup-owned-server'
    if n.startswith(('electron-mock','rejection.fixture')): return 'native-proof-harness'
    return 'tooling-config'

def classify(p, f):
    n = Path(p).name
    if re.search(r'\.(png|jpg|mp4|ico|icns)$',n): return 'binary-asset'
    if n.endswith('.asc'): return 'public-key-resource'
    if f == 'generated-dock-corpus': return 'generator-source' if n.endswith('.mjs') else 'generated-documentation'
    if f == 'historical-proposals': return 'historical-proposal-or-report'
    if n == 'SKILL.md': return 'repository-maintenance-skill'
    if n == 'AGENTS.md': return 'repository-instructions'
    if n.endswith('.md'): return 'documentation'
    if f == 'localization' and '/i18n/' in p and n != 'index.ts': return 'localization-dictionary'
    if '.fixture.' in n or n in ['replies.json','invalid-replies.json','scenarios.json','workspace-scenarios.json'] or n.startswith('app-dock-security.') and '.test.' not in n: return 'test-fixture'
    if '.test.' in n or n.startswith('test_'): return 'test-source-unexecuted'
    if f in ['native-proof-harness','omni-proof-harness','runtime-proof-tools'] and n.endswith(('.ts','.py','.mjs','.sh','.cjs')): return 'proof-harness-unexecuted'
    if n.endswith(('.css','.html')): return 'presentation-source'
    if n.startswith('.gitignore'): return 'ignore-metadata'
    if n.endswith(('.json','.toml','.plist','.pref','.sources')) or n == 'Dockerfile' or 'config.' in n or n.endswith('.d.ts') or n.endswith('.desktop'): return 'build-runtime-or-type-configuration'
    if p.startswith(S): return 'build-script-source'
    return 'implementation-source'

tree = json.loads(INPUT.read_text())
selections = json.loads((ROOT/'inspection.json').read_text())
capture_manifest = json.loads((ROOT/'sources.json').read_text())
capture_manifest['sources'] = list({e['path']:e for e in capture_manifest['sources'] + capture_manifest.get('captured_not_directly_inspected',[])}.values())
capture_by_path = {e['path']:e for e in capture_manifest['sources']}
# Files read before the numbered selection helper was introduced. They remain
# distinguishable from helper-selected spans and do not imply exhaustive review.
earlier_reads = [
    'AGENTS.md', D+'AGENTS.md', 'apps/web/AGENTS.md', 'packages/app-shell/AGENTS.md',
    D+'README.md', M+'README.md', 'apps/web/README.md', D+'package.json', 'apps/web/package.json',
    M+'index.ts', M+'owned-serve.ts', M+'server.ts', M+'initialization.ts', M+'renderer-origin.ts',
]
read_paths = set(selections) | set(earlier_reads)

rows=[]
for e in tree:
    p=e['path']; f=get_family(p); c=classify(p,f)
    if p in read_paths:
        depth='inspected'
        reason='Pinned source content was read in bounded selections; see sources.json for selected spans and the L1 narrative for the claims actually established.'
        if c=='test-source-unexecuted': reason='Selected test assertions and their fixture boundary were read; the test was not executed and its existence is not a passing result.'
        if c=='localization-dictionary': reason='Representative dictionary content was read to establish key/template structure; linguistic quality and all-locale parity were not validated.'
    elif f=='tooling-config':
        depth='metadata-only';reason='Exact pinned tree entry accounted; effective contents were not read. Family build witnesses supply context only, not understanding of this configuration.'
    else:
        depth='family-supported'
        reason={
            'binary-asset':'Exact tree identity and consumer/build chain accounted; this binary was not decoded or authenticated. Provenance is limited to the explicit representative script/document statements.',
            'public-key-resource':'Resource belongs to the pinned runtime build context; key bytes and external trust provenance were not independently authenticated.',
            'localization-dictionary':'Repetitive locale leaf supported by the importing/fallback translator and English/Arabic representatives; this locale was not read or language-reviewed.',
            'generated-documentation':'Generator explicitly writes this output family from literal invariants; representative output inspected. This leaf and its historical measured labels were not independently validated.',
            'historical-proposal-or-report':'Dated design/campaign family supported by inspected contracts and closeout/handoff documents; this leaf was not read and no contained claim becomes current authority.',
            'test-source-unexecuted':'Assigned assertion-suite leaf mapped to its implementation and representative test family; this file was not read or executed, so no assertion completeness or result is claimed.',
            'test-fixture':'Fixture family connected to the inspected helper/consumer or test harness; leaf values and fidelity were not audited and fixtures were not run.',
            'proof-harness-unexecuted':'Proof driver belongs to the inspected runtime/native or packaged-process boundary; only family purpose is established, not this driver control flow or any pass result.',
        }.get(c, 'Supported at family depth by the inspected entrypoint, contract and representative implementation. This individual leaf was not semantically reviewed; no line-level guarantee is made for it.')
    reps = ([p] if p in read_paths else []) + [q for q in F[f]['representative_source_paths'] if q != p]
    rows.append({**e,'family':f,'classification':c,'evidence_depth':depth,'representative_source_paths':reps,'reason':reason})

for f,v in F.items():
    members=[r for r in rows if r['family']==f]
    v['entry_count']=len(members)
    v['depth_counts']=dict(collections.Counter(r['evidence_depth'] for r in members))
    v['classification_counts']=dict(collections.Counter(r['classification'] for r in members))

out={
    'schema':'genesis-l1-coverage/v1','unit':'desktop-web','source_repository':'gustavomhss/hugr-orchestra',
    'source_commit':COMMIT,'protocol_commit':PROTOCOL,'input_file':str(INPUT),
    'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),'population_count':len(tree),
    'depth_definitions':{
        'inspected':'Content read in full or bounded selections. Not a guarantee of complete-file review. Tests remain unexecuted.',
        'family-supported':'Leaf accounted through representative source/consumer/provenance chain; individual behavior or data content is not claimed inspected.',
        'metadata-only':'Tree identity/classification only; contents unexamined and not presented as understood.'},
    'counts_by_depth':dict(collections.Counter(r['evidence_depth'] for r in rows)),
    'counts_by_classification':dict(collections.Counter(r['classification'] for r in rows)),
    'families':list(F.values()),'entries':rows,
    'limits':['No product test, application, browser, Docker, WSL, provider or build execution.',
              'All binary and most repetitive locale/fixture leaves are representative family coverage.',
              'Boundary captures outside the assigned population are source references only and are not added to the population.']}
assert len(rows)==532 and len({r['path'] for r in rows})==532
assert {r['path'] for r in rows}=={r['path'] for r in tree}
assert all(v['entry_count'] for v in F.values())
(ROOT/'coverage.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')

def ranges(nums):
    groups=[]
    for n in sorted(set(nums)):
        if groups and n==groups[-1][1]+1: groups[-1][1]=n
        else: groups.append([n,n])
    return groups

used=[];unselected=[]
for e in capture_manifest['sources']:
    p=e['path']
    e['git_blob_sha_verified']=True
    e['assigned_population']=p in {r['path'] for r in rows}
    if p in read_paths:
        e['read_status']='read-in-bounded-selections-or-earlier-direct-read'
        e['selected_line_ranges']=ranges(selections.get(p,[]))
        e['earlier_direct_read']=p in earlier_reads
        used.append(e)
    else:
        e['read_status']='captured-but-not-used-as-direct-inspection'
        unselected.append(e)
manifest={
    'schema':'genesis-source-captures/v1','source_repository':'gustavomhss/hugr-orchestra','source_commit':COMMIT,
    'protocol_commit':PROTOCOL,'hash_method':'Python hashlib SHA256 over exact UTF-8 source bytes; Git SHA1 over b"blob "+decimal byte length+b"\\0"+bytes; compared with connector blob and assigned tree when present.',
    'inspection_note':'Line selections are retrieval/read locations, not a claim of exhaustive file review. Some early combined outputs were truncated; L1 claims and decisive excerpts identify the bounded content relied on. Original connector payload and full exact source bytes are retained.',
    'sources':used,'captured_not_directly_inspected':unselected,
    'capture_errors':capture_manifest.get('capture_errors',capture_manifest.get('errors',[])),
    'unsuccessful_lookup_note':'One extra lookup of apps/desktop/src/renderer/i18n/pt.ts returned an error. That path is not in the assigned population; the actual locale index imports br.ts. Its error response is retained without fabricating source bytes.',
    'verified_capture_count':len(capture_manifest['sources']),
    'read_source_count':len(used),'captured_not_directly_inspected_count':len(unselected)}
(ROOT/'sources.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'entries':len(rows),'families':len(F),'depths':out['counts_by_depth'],'read_captures':len(used),'unused_captures':len(unselected),'metadata_only':[r['path'] for r in rows if r['evidence_depth']=='metadata-only']},indent=2))
