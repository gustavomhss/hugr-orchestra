import type { WslDistroProbe, WslOrchestraCheck } from "../../preload/types"

export function clearWslDistroState(
  distroProbes: Record<string, WslDistroProbe>,
  orchestraChecks: Record<string, WslOrchestraCheck>,
  distro: string,
) {
  const nextDistroProbes = { ...distroProbes }
  const nextOrchestraChecks = { ...orchestraChecks }
  delete nextDistroProbes[distro]
  delete nextOrchestraChecks[distro]
  return { distroProbes: nextDistroProbes, orchestraChecks: nextOrchestraChecks }
}

export function wslTerminalArgs(distro?: string | null) {
  return ["/c", "start", "", "wsl", ...(distro ? ["-d", distro] : [])]
}

export function requireWslIpcString(name: string, value: unknown) {
  if (typeof value === "string" && value.length > 0) return value
  throw new Error(`Invalid ${name}`)
}

export function requireWslIpcStrings(name: string, value: unknown) {
  if (!Array.isArray(value)) throw new Error(`Invalid ${name}`)
  const values = value.map((item) => requireWslIpcString(name, item))
  if (values.length > 0) return values
  throw new Error(`Invalid ${name}`)
}
