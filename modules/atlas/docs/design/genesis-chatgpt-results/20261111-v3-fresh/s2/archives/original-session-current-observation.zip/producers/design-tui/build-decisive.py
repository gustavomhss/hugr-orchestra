#!/usr/bin/env python3
"""Extract bounded, unchanged source slices for a tool-free L1 review."""
from pathlib import Path
import json

BASE=Path('/workspace/scratch/992c54067adf/genesis-s2/producers/design-tui')
manifest=json.loads((BASE/'sources.json').read_text())
sources={row['path']:row for row in manifest['captures']}

# Each slice is verbatim. Explanatory headings are separate from source text.
specs=[
 ('Current boundary and language policy',
  'Current terminal ownership permits core and says V2. The language policy is English-only; the UI has its own i18n instruction.',
  [('packages/tui/README.md',17,18),('packages/tui/README.md',28,30),('packages/ui/AGENTS.md',3,5)]),
 ('The inspected CLI supplies an empty plugin host',
  'Feature source existence cannot establish activation by this adapter.',
  [('apps/cli/src/tui.ts',23,40)]),
 ('Renderer and injected host cleanup are scoped',
  'This source registers plugin/audio cleanup and SIGHUP shutdown; the test below uses a mocked renderer.',
  [('packages/tui/src/app.tsx',211,230),('packages/tui/test/app-lifecycle.test.tsx',50,60)]),
 ('Injected event source and SSE have distinct ownership',
  'The selected source branch and cleanup are visible; no live transport was used.',
  [('packages/tui/src/context/sdk.tsx',114,128)]),
 ('History hydration retains rows changed by live events',
  'This is the production merge and lifecycle, including the history-error fallback. It is not a claim that the test executed.',
  [('packages/tui/src/context/sync.tsx',498,537),('packages/tui/test/cli/cmd/tui/sync-live-hydration.test.tsx',163,174)]),
 ('Prompt action order uses the V2 adapter',
  'Selection, optional synthetic editor input and prompt dispatch are ordered here.',
  [('packages/tui/src/context/session-actions.ts',38,53)]),
 ('Production submission guard and mirrored test limit',
  'The guard protects admission; the regression source explicitly says its test is a mirror.',
  [('packages/tui/src/component/prompt/index.tsx',919,934),('packages/tui/test/cli/tui/prompt-submit-race.test.ts',17,20)]),
 ('Facade lifecycle is a placeholder',
  'The host must supply meaningful lifecycle behavior elsewhere; this facade does not implement disposal registration.',
  [('packages/tui/src/plugin/api.ts',42,51)]),
 ('Terminal defaults and suspend compatibility',
  'Attention remains disabled by default; subordinate notification/sound values do not enable it.',
  [('packages/tui/src/config/index.tsx',101,120)]),
 ('Transcript is a sorted display projection',
  'Export sorts by time and ID, and omits message kinds outside its explicit cases.',
  [('packages/tui/src/util/transcript.ts',22,46)]),
 ('Selection copy is asynchronous and clears immediately',
  'This preserves the actual timing contract; no clipboard operation ran.',
  [('packages/tui/src/util/selection.ts',26,43)]),
 ('Reactive helper cleans its timer',
  'The debounce setter replaces pending work and disposes it with its owner.',
  [('packages/tui/src/util/signal.ts',3,17)]),
 ('Demo request identity and local interception',
  'Demo IDs are intercepted before permission replies can reach the V2 server; synthetic UI results are not tool results.',
  [('packages/tui/src/context/demo.ts',49,54),('packages/tui/src/context/sdk.tsx',130,145),('packages/tui/src/context/demo.ts',224,233)]),
 ('Replay projection is mini-specific',
  'The helper itself has no CLI-argument validation; ordinary sessions retain their input message array.',
  [('packages/tui/src/context/replay.ts',1,12)]),
 ('Thinking preference migrates stored values',
  'The default is hide, with legacy boolean migration; this is disclosure state.',
  [('packages/tui/src/context/thinking.ts',29,36),('packages/tui/src/context/thinking.ts',48,61)]),
 ('Parser source mixes pinned and moving external references',
  'This is declared configuration, not proof that external grammar/query bytes were downloaded or compatible.',
  [('packages/tui/src/parsers-config.ts',1,19),('packages/tui/src/routes/session/index.tsx',69,69)]),
 ('UI provider keeps layout locale separate',
  'The fallback and provider wiring do not certify translation completeness.',
  [('packages/ui/src/context/i18n.tsx',52,68)]),
 ('Field synchronizes control accessibility attributes',
  'This is a concrete source mechanism; no screen-reader test ran.',
  [('packages/ui/src/v2/components/field-v2.tsx',81,109)]),
 ('Segmented-control arrows use DOM-order increments',
  'The shown key handler has no direction lookup, leaving RTL behavioral verification open.',
  [('packages/ui/src/v2/components/segmented-control-v2.tsx',158,169)]),
 ('Context readiness and worker ownership',
  'Readiness gates consumers. Pools are injected and selected, with no creation or disposal in this wrapper.',
  [('packages/ui/src/context/helper.tsx',20,35),('packages/ui/src/context/worker-pool.tsx',9,20)]),
 ('Theme formats have different contracts',
  'Terminal defs/theme and desktop light/dark variants must not be treated as one schema.',
  [('packages/tui/src/theme/index.ts',120,128),('packages/ui/src/theme/types.ts',35,49)]),
 ('Actual schema generator and mirror source',
  'These are the precise owners of the assigned editor schemas. Python additionally verified exact desktop-schema copy equality; no generator ran.',
  [('apps/cli/script/schema-files.ts',68,80)]),
 ('Verified file and provider sprite generation',
  'The config declares these two outputs. It does not declare an app-icons producer.',
  [('packages/ui/vite.config.ts',10,24),('packages/ui/vite.config.ts',47,58)]),
 ('Bundled fonts do not establish loading',
  'The exported Font component is empty. Actual font loading requires a consumer boundary.',
  [('packages/ui/src/components/font.tsx',1,1)]),
 ('Storybook accessibility remains a todo',
  'A configured workbench is not a test pass.',
  [('apps/storybook/.storybook/preview.tsx',98,110)]),
 ('Workbench CSS editing writes source',
  'The development middleware is capable of source mutation; no middleware request was made.',
  [('apps/storybook/.storybook/playground-css-plugin.ts',113,124)]),
 ('Historical verification is explicitly limited',
  'This past receipt is not a current product test result.',
  [('docs/specs/frontend-recovery-receipt.json',66,71)]),
 ('README render relationship is explicit',
  'Only assigned output basenames matching HTML inputs are mapped to this loop; binary equivalence is unverified.',
  [('docs/images/readme/src/render.sh',1,19)]),
]

out=['# Decisive evidence — design-tui L1','',
     f"All source excerpts are from `{manifest['source_commit']}`. Excerpts are unchanged UTF-8 source lines; each block names its inclusive line interval and Git blob SHA. Source bytes, SHA-256 and original connector responses are retained in `sources.json` and the referenced capture files.", '',
     'These witnesses establish selected critical mechanisms and limitations. They are not execution evidence. All product tests, builds, typechecks, generators, terminal/browser sessions and remote mutations remain unexecuted. See `l1.md` and `coverage.json` for the full family disposition.', '']
excerpts=[]
total=0
for n,(title,note,blocks) in enumerate(specs,1):
    out += [f'## E{n:02d}. {title}','',note,'']
    for p,lo,hi in blocks:
        row=sources[p]
        lines=(BASE/row['local_capture_file']).read_text().splitlines(keepends=True)
        assert 1<=lo<=hi<=len(lines),(p,lo,hi,len(lines))
        value=''.join(lines[lo-1:hi])
        lang='json' if p.endswith('.json') else ('bash' if p.endswith('.sh') else ('typescript' if p.endswith(('.ts','.tsx')) else 'text'))
        out += [f"**Source:** `{p}:{lo}–{hi}` · blob `{row['git_blob_sha']}`",'',f'```{lang}',value.rstrip('\n'),'```','']
        excerpts.append({'id':f'E{n:02d}','path':p,'first_line':lo,'last_line':hi,'git_blob_sha':row['git_blob_sha']})
        total += hi-lo+1
out += ['## Evidence integrity and unresolved transport boundary','',
        'The initial `fetch_file` response for `schema/tui.json` supplied an empty body. A second read using the assigned exact blob SHA recovered 1,131,057 bytes and passed Git blob SHA verification. Both original responses remain in the capture record. The controller-reported 256,000-byte observer limit is an import/runtime constraint; the semantic source is available here.', '',
        f'This document contains {len(specs)} critical-claim groups, {len(excerpts)} bounded source slices and {total} quoted source lines. No historical PASS label has been promoted to a result of this task.', '']
(BASE/'decisive-evidence.md').write_text('\n'.join(out))
(BASE/'decisive-excerpts.json').write_text(json.dumps({'source_commit':manifest['source_commit'],'quoted_source_lines':total,'excerpts':excerpts},indent=2)+'\n')
print(json.dumps({'groups':len(specs),'slices':len(excerpts),'quoted_source_lines':total}))
