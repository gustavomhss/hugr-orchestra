#!/usr/bin/env python3
"""Mechanically integrate an actual native producer output; never judge or prepare it.

Read-only by default. --apply preserves the current package, creates a new layer
destination, and appends one blocked artifact. Only the principal should write the
package, serially with accept_layer.py and other integrations.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import tempfile
import unicodedata


PREFIX = "modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2"
UNITS = ("desktop-web", "app-session", "design-tui")
NEEDS = {2: "component", 3: "flow", 4: "ownership"}
FILES = ("body.md", "sources.json", "dependencies.json", "decisive-evidence.md", "response.md")
ARTIFACT_FIELDS = {
    "key", "scope", "title", "layer", "need", "body", "authority", "validity", "gaps", "evidence",
    "input_keys", "source_refs", "recipe_ref", "build_dependencies", "navigation", "producer_request_ref",
    "producer_response_ref", "semantic_review_refs", "runtime_receipt_refs",
}


class IntegrationError(Exception):
    def __init__(self, code, message, details=None):
        super().__init__(message)
        self.code, self.details = code, details


def require(condition, code, message, details=None):
    if not condition:
        raise IntegrationError(code, message, details)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def text(value, label):
    require(isinstance(value, str) and bool(value.strip()), "INVALID_TEXT", label)
    require(unicodedata.normalize("NFC", value) == value, "NON_NFC_METADATA", label)
    return value


def native_path(value):
    value = text(value, "path must be nonempty NFC text")
    forbidden = re.search(r'[\\:*?"<>|\x00-\x1f\x7f]', value)
    parts = value.split("/")
    require(not forbidden and all(p and p not in (".", "..") and p.lower() not in (".git", ".atlas")
                                 and not p.endswith((".", " ")) for p in parts), "INVALID_PATH", value)
    return value


def digest(value, length, label):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{%d}" % length, value) is not None,
            "INVALID_DIGEST", label)
    return value


def strings(value, label):
    require(isinstance(value, list), "INVALID_ARRAY", label)
    result = [text(item, label) for item in value]
    require(len(set(result)) == len(result), "DUPLICATE_VALUE", label)
    return result


def layer_of(key):
    match = re.fullmatch(r"s2\.l([1-4])\.(desktop-web|app-session|design-tui|entry)", key)
    require(match is not None and (match[2] != "entry" or match[1] == "4"), "INVALID_ARTIFACT_KEY", key)
    return int(match[1])


def json_object(data, label):
    value = json.loads(data.decode("utf-8"))
    require(isinstance(value, dict), "INVALID_OBJECT", label)
    return value


class Reads:
    """Bounded path checks and a record used to detect changed inputs before commit."""
    def __init__(self, root):
        self.root, self.files = root, {}

    def path(self, relative):
        native_path(relative)
        current = self.root
        for part in relative.split("/"):
            current = current / part
            require(not current.is_symlink(), "SYMLINK_REFUSED", str(current))
        return current

    def read(self, relative):
        path = self.path(relative)
        require(path.is_file(), "MISSING_INPUT", str(path))
        data = path.read_bytes()
        if path in self.files:
            require(self.files[path] == sha(data), "INPUT_CHANGED", str(path))
        self.files[path] = sha(data)
        return data

    def unchanged(self):
        for path, expected in self.files.items():
            self.path(path.relative_to(self.root).as_posix())
            require(path.is_file() and sha(path.read_bytes()) == expected, "INPUT_CHANGED", str(path))


def canonical_sources(reads, revision):
    by_path, manifests = {}, []
    for unit in UNITS:
        rel = f"producers/{unit}/sources.json"
        data = reads.read(rel)
        manifest = json_object(data, rel)
        fields = {"desktop-web": ("sources", "captured_not_directly_inspected"),
                  "app-session": ("records",), "design-tui": ("captures",)}[unit]
        manifests.append({"path": rel, "sha256": sha(data)})
        for field in fields:
            require(isinstance(manifest.get(field), list), "CANONICAL_MANIFEST_FORMAT", f"{rel}:{field}")
            for source in manifest[field]:
                path = native_path(source["path"])
                identity = (source["commit"], source["git_blob_sha"], source["sha256"])
                require(source["commit"] == revision, "CANONICAL_REVISION_MISMATCH", path)
                if path in by_path:
                    previous = by_path[path]
                    require(previous["identity"] == identity, "CONFLICTING_CANONICAL_CAPTURE", path)
                else:
                    capture = native_path(source["local_capture_file"])
                    by_path[path] = {"identity": identity, "capture": f"producers/{unit}/{capture}",
                                     "byte_length": source["byte_length"]}
    return by_path, manifests


def verified_source(ref, canonical, reads):
    path = native_path(ref["path"])
    digest(ref["commit"], 40, "source commit")
    digest(ref["git_blob_sha"], 40, "source Git blob")
    digest(ref["sha256"], 64, "source SHA-256")
    capture = canonical.get(path)
    if capture is None:
        return None
    require(capture["identity"] == (ref["commit"], ref["git_blob_sha"], ref["sha256"]),
            "SOURCE_CONFLICT", f"Declared source differs from canonical capture: {path}")
    data = reads.read(capture["capture"])
    require(sha(data) == ref["sha256"] and blob(data) == ref["git_blob_sha"] and len(data) == capture["byte_length"],
            "CANONICAL_SOURCE_DRIFT", path)
    return {**ref, "byte_length": len(data), "canonical_capture": capture["capture"],
            "sha256_verified": True, "git_blob_verified": True}


def consumed_manifests(args, dependencies, reads, package, artifacts):
    declared = dependencies.get("consumed_layer_manifests", [])
    require(isinstance(declared, list), "INVALID_CONSUMED_MANIFESTS", "consumed_layer_manifests must be a list")
    declared = copy.deepcopy(declared)
    for value in args.consumed_manifest:
        require("=" in value, "INVALID_CONSUMED_MANIFEST", "Use accepted/lN.json=<exact-sha256>")
        path, expected = value.rsplit("=", 1)
        declared.append({"path": path, "sha256": expected})
    refs, by_key, seen = [], {}, {}
    for item in declared:
        require(isinstance(item, dict) and set(item) == {"path", "sha256"}, "INVALID_CONSUMED_MANIFEST", str(item))
        path = native_path(item["path"])
        expected = digest(item["sha256"], 64, "consumed manifest SHA-256")
        require(path.startswith("accepted/") and path.endswith(".json"), "INVALID_CONSUMED_MANIFEST_PATH", path)
        if path in seen:
            require(seen[path] == expected, "CONFLICTING_CONSUMED_MANIFEST", path)
            continue
        seen[path] = expected
        data = reads.read("deliverable/" + path)
        require(sha(data) == expected, "CONSUMED_MANIFEST_DRIFT", path)
        manifest = json_object(data, path)
        require(manifest.get("schema") == "genesis-s2-accepted-layer/v1"
                and manifest.get("status") == "SEMANTIC_LAYER_ACCEPTED", "MANIFEST_NOT_ACCEPTED", path)
        require(manifest.get("source_revision") == package["source_revision"]
                and manifest.get("protocol_revision") == package["protocol_ref"]["commit"], "MANIFEST_PIN_MISMATCH", path)
        require(type(manifest.get("layer")) is int and 1 <= manifest["layer"] < args.layer,
                "MANIFEST_LAYER_ORDER", path)
        require(isinstance(manifest.get("artifacts"), list), "MANIFEST_ARTIFACTS_MISSING", path)
        for entry in manifest["artifacts"]:
            key = entry["key"]
            require(key in artifacts and layer_of(key) == manifest["layer"], "MANIFEST_KEY_MISMATCH", key)
            actual = artifacts[key]
            require(actual["validity"] == "supported" and len(actual["semantic_review_refs"]) >= 2,
                    "PREDECESSOR_NOT_SUPPORTED", key)
            require(entry["body_sha256"] == actual["body"]["sha256"]
                    and entry["byte_length"] == actual["body"]["byte_length"]
                    and entry["body_path"] == actual["body"]["path"], "ACCEPTED_BODY_BINDING_MISMATCH", key)
            by_key.setdefault(key, []).append(path)
        refs.append({"path": path, "payload_path": PREFIX + "/" + path, "sha256": expected,
                     "layer": manifest["layer"], "consumption_basis": "Explicit producer metadata or principal CLI declaration; not inferred."})
    return refs, by_key


def section_receipts(body):
    headings, offset, fence = [], 0, None
    for line_number, line in enumerate(body.decode("utf-8").splitlines(keepends=True), 1):
        marker = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        if marker:
            token = marker[1]
            if fence is None:
                fence = (token[0], len(token))
            elif token[0] == fence[0] and len(token) >= fence[1]:
                fence = None
        elif fence is None:
            match = re.match(r"^ {0,3}(#{1,6})[ \t]+(.+?)[ \t]*#*[ \t]*(?:\r?\n)?$", line)
            if match:
                headings.append({"level": len(match[1]), "heading": match[2], "line": line_number, "byte_start": offset})
        offset += len(line.encode("utf-8"))
    for index, heading in enumerate(headings):
        end = headings[index + 1]["byte_start"] if index + 1 < len(headings) else len(body)
        heading.update({"byte_end_exclusive": end, "sha256": sha(body[heading["byte_start"]:end])})
    return {"method": "ATX headings outside fenced blocks; each slice ends at the next heading; no semantic completeness assertion",
            "byte_length": len(body), "sha256": sha(body), "line_count": len(body.decode("utf-8").splitlines()), "sections": headings}


def assemble(args, reads):
    package_bytes = reads.read("deliverable/native-package.json")
    package = json_object(package_bytes, "native-package.json")
    require(package.get("schema") == "genesis-native-package/v1" and package.get("session") == "S2",
            "PACKAGE_SCHEMA", "Expected the existing S2 native package")
    unit = args.unit
    require(unit != "entry" or args.layer == 4, "ENTRY_LAYER", "entry must be L4")
    key = f"s2.l{args.layer}.{unit}"
    required = strings(package["required_artifact_keys"], "required_artifact_keys")
    require(key in required, "UNASSIGNED_ARTIFACT", key)
    artifacts = {a["key"]: a for a in package["artifacts"]}
    require(len(artifacts) == len(package["artifacts"]) and key not in artifacts, "ARTIFACT_ALREADY_EXISTS", key)
    require(package["missing_required_artifact_keys"] == [k for k in required if k not in artifacts],
            "PACKAGE_MISSING_LIST_DRIFT", "Principal must reconcile the existing missing list first")
    old_layers = [a["layer"] for a in package["artifacts"]]
    require(old_layers == sorted(old_layers) and all(n <= args.layer for n in old_layers),
            "PACKAGE_LAYER_ORDER", "Do not insert an earlier layer after a later layer")
    canonical, canonical_manifests = canonical_sources(reads, package["source_revision"])
    earlier = []
    for old in package["artifacts"]:
        require(layer_of(old["key"]) == old["layer"], "ARTIFACT_LAYER_MISMATCH", old["key"])
        body = reads.read("deliverable/" + native_path(old["body"]["path"]))
        require(sha(body) == old["body"]["sha256"] and len(body) == old["body"]["byte_length"], "EARLIER_BODY_DRIFT", old["key"])
        for source in old["source_refs"]:
            require(verified_source(source, canonical, reads) is not None, "EARLIER_SOURCE_NOT_CANONICAL", source["path"])
        earlier.append({"key": old["key"], "body_sha256": sha(body), "artifact_metadata_sha256": sha(encoded(old))})
    producer = "later-producers/app-session/l4-entry" if unit == "entry" else f"later-producers/{unit}/l{args.layer}"
    destination = f"layers/l{args.layer}/{unit}"
    require(not reads.path("deliverable/" + destination).exists(), "DESTINATION_EXISTS", destination)
    raw = {name: reads.read(producer + "/" + name) for name in FILES}
    for name in ("body.md", "decisive-evidence.md", "response.md"):
        require(bool(raw[name].decode("utf-8").strip()), "EMPTY_PRODUCER_FILE", producer + "/" + name)
    sources = json_object(raw["sources.json"], "producer sources.json")
    require(sources.get("source_revision") == package["source_revision"], "PRODUCER_SOURCE_REVISION", producer)
    require(isinstance(sources.get("sources"), list) and bool(sources["sources"]), "EMPTY_SOURCE_REFS", producer)
    refs, source_checks, missing = [], [], []
    for source in sources["sources"]:
        require(isinstance(source, dict) and all(field in source for field in ("commit", "path", "git_blob_sha", "sha256")),
                "INVALID_SOURCE_REF", producer + "/sources.json: each source needs commit, path, git_blob_sha and sha256")
        ref = {field: source[field] for field in ("commit", "path", "git_blob_sha", "sha256")}
        require(ref["commit"] == package["source_revision"], "SOURCE_REVISION_MISMATCH", ref["path"])
        check = verified_source(ref, canonical, reads)
        if check is None:
            missing.append(ref)
        else:
            source_checks.append(check)
        refs.append(ref)
    require(not missing, "SOURCE_RECONCILIATION_REQUIRED", "New sources need principal reconciliation into canonical producer captures; no files or package were changed.", missing)
    require(len({ref["path"] for ref in refs}) == len(refs), "DUPLICATE_SOURCE_REF", producer)
    dependencies = json_object(raw["dependencies.json"], "dependencies.json")
    build = strings(dependencies.get("build"), "dependencies.build")
    navigation = strings(dependencies.get("navigation"), "dependencies.navigation")
    consumed, accepted_keys = consumed_manifests(args, dependencies, reads, package, artifacts)
    dependency_checks = []
    for predecessor in build:
        require(predecessor in artifacts, "MISSING_BUILD_PREDECESSOR", predecessor)
        artifact = artifacts[predecessor]
        require(layer_of(predecessor) < args.layer and artifact["layer"] == layer_of(predecessor),
                "BUILD_LAYER_ORDER", f"{key} -> {predecessor}: build predecessors must be from an earlier layer")
        require(artifact["validity"] == "supported", "PREDECESSOR_NOT_SUPPORTED", predecessor)
        require(predecessor in accepted_keys, "CONSUMED_ACCEPTED_MANIFEST_REQUIRED", predecessor)
        dependency_checks.append({"key": predecessor, "body_sha256": artifact["body"]["sha256"],
                                  "accepted_manifests": accepted_keys[predecessor], "supported": True})
    for target in navigation:
        require(target != key and target in required, "UNKNOWN_NAVIGATION_TARGET", target)
    dispatch_name = "l4-entry-dispatch.md" if unit == "entry" else f"l{args.layer}-{unit}-dispatch.md"
    dispatch_path = "requests/" + dispatch_name
    dispatch = reads.read("deliverable/" + dispatch_path)
    require(bool(dispatch.decode("utf-8").strip()), "EMPTY_DISPATCH", dispatch_path)
    recipe = {"payload_path": PREFIX + "/" + dispatch_path, "sha256": sha(dispatch)}
    receipt = {"schema": "genesis-s2-native-layer-mechanical/v1", "artifact_key": key, "layer": args.layer,
               "producer_root": producer, "destination": destination, "source_revision": package["source_revision"],
               "package_before_sha256": sha(package_bytes), "utility_sha256": sha(Path(__file__).read_bytes()),
               "body": section_receipts(raw["body.md"]), "source_checks": source_checks,
               "canonical_source_manifests": canonical_manifests, "build_dependencies": dependency_checks,
               "navigation": navigation, "navigation_targets_pending": [n for n in navigation if n not in artifacts],
               "consumed_layer_manifests": consumed, "recipe": recipe,
               "producer_files": [{"name": n, "byte_length": len(data), "sha256": sha(data)} for n, data in raw.items()],
               "earlier_artifacts_unchanged": earlier, "semantic_status": "PENDING_ACTUAL_JUDGMENTS",
               "runtime_status": "NOT_RUN", "limits": ["Mechanical identity and dependency bookkeeping only; no semantic judgment or new acceptance gate.",
               "Manifest consumption is explicitly declared, not inferred or authenticated by this utility.",
               "Declared build dependency completeness and navigation usefulness remain for the actual judgments."]}
    raw["mechanical-receipt.json"] = encoded(receipt)
    evidence = [json.dumps({"payload_path": PREFIX + "/" + destination + "/" + n, "sha256": sha(raw[n])},
                           ensure_ascii=False, sort_keys=True, separators=(",", ":")) for n in FILES if n != "body.md"]
    evidence.append(json.dumps({"payload_path": PREFIX + "/" + destination + "/mechanical-receipt.json", "sha256": sha(raw["mechanical-receipt.json"])},
                               ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    inputs = ["file:" + ref["path"] for ref in refs] + ["file:" + recipe["payload_path"]] + ["file:" + ref["payload_path"] for ref in consumed]
    artifact = {"key": key, "scope": package["scope"], "title": text(args.title or f"L{args.layer} {unit} {('entry' if unit == 'entry' else NEEDS[args.layer])}", "title"),
                "layer": args.layer, "need": "entry" if unit == "entry" else NEEDS[args.layer],
                "body": {"path": destination + "/body.md", "encoding": "utf-8", "byte_length": len(raw["body.md"]), "sha256": sha(raw["body.md"])},
                "authority": {"scope": package["scope"], "basis": f"User-assigned S2 partition; actual native output at {producer}; exact dispatch and canonical source captures preserved. Mechanical integration does not assert semantic acceptance."},
                "validity": "blocked", "gaps": ["Awaiting actual independent semantic judgments for this exact artifact.", "Runtime binding, publication, consumers and applicable CI are not established by this integration."],
                "evidence": evidence, "input_keys": list(dict.fromkeys(inputs)), "source_refs": refs, "recipe_ref": recipe,
                "build_dependencies": [{"key": predecessor, "same_package": True} for predecessor in build],
                "navigation": navigation, "producer_request_ref": recipe,
                "producer_response_ref": {"payload_path": PREFIX + "/" + destination + "/response.md", "sha256": sha(raw["response.md"])},
                "semantic_review_refs": [], "runtime_receipt_refs": []}
    require(set(artifact) == ARTIFACT_FIELDS, "INTERNAL_ARTIFACT_FIELDS", key)
    updated = copy.deepcopy(package)
    updated["artifacts"].append(artifact)
    updated["missing_required_artifact_keys"] = [k for k in required if k not in artifacts and k != key]
    require(updated["artifacts"][:-1] == package["artifacts"] and updated["roots"] == package["roots"], "INTERNAL_EARLIER_MUTATION", key)
    return {"key": key, "destination": destination, "files": raw, "before": package_bytes,
            "after": encoded(updated), "artifact": artifact, "receipt": receipt}


def write_new(path, data):
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    require(path.read_bytes() == data, "WRITE_VERIFICATION_FAILED", str(path))


def apply_bundle(args, reads, bundle):
    out = reads.root / "deliverable"
    destination = reads.path("deliverable/" + bundle["destination"])
    history = reads.path("deliverable/history")
    lock = reads.root / "assembly-tools/integration.lock"
    require(lock.parent.is_dir(), "TOOLS_DIRECTORY_MISSING", str(lock.parent))
    lock_fd = None
    package_tmp = None
    created_destination = committed = False
    try:
        try:
            lock_fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            raise IntegrationError("INTEGRATION_LOCKED", "Another integration holds assembly-tools/integration.lock; principal must reconcile an interrupted operation before retrying.")
        os.write(lock_fd, encoded({"pid": os.getpid(), "artifact": bundle["key"], "package_before_sha256": sha(bundle["before"])}))
        reads.unchanged()
        require(not destination.exists(), "DESTINATION_EXISTS", str(destination))
        history.mkdir(parents=True, exist_ok=True)
        snapshot = history / ("native-package-before-" + bundle["key"].replace(".", "-") + "-" + sha(bundle["before"]) + ".json")
        if snapshot.exists():
            require(not snapshot.is_symlink() and snapshot.read_bytes() == bundle["before"], "HISTORY_CONFLICT", str(snapshot))
        else:
            write_new(snapshot, bundle["before"])
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.mkdir(exist_ok=False)
        created_destination = True
        for name, data in bundle["files"].items():
            write_new(destination / name, data)
        with tempfile.NamedTemporaryFile(prefix="native-package-integration-", suffix=".tmp", dir=out, delete=False) as stream:
            package_tmp = Path(stream.name)
            stream.write(bundle["after"])
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(package_tmp, stat.S_IMODE((out / "native-package.json").stat().st_mode))
        reads.unchanged()
        os.replace(package_tmp, out / "native-package.json")
        committed = True
        package_tmp = None
        require((out / "native-package.json").read_bytes() == bundle["after"], "PACKAGE_WRITE_VERIFICATION_FAILED", str(out))
        return str(snapshot.relative_to(reads.root))
    finally:
        if package_tmp is not None and package_tmp.exists():
            package_tmp.unlink()
        if created_destination and not committed:
            shutil.rmtree(destination)
        if lock_fd is not None:
            os.close(lock_fd)
            lock.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("layer", type=int, choices=(2, 3, 4))
    parser.add_argument("unit", choices=UNITS + ("entry",))
    parser.add_argument("--workspace", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--consumed-manifest", action="append", default=[], metavar="accepted/lN.json=SHA256",
                        help="Exact accepted manifest actually consumed by the producer; repeat as needed")
    parser.add_argument("--title", help="Optional actual artifact title; no semantic summary is generated")
    parser.add_argument("--apply", action="store_true", help="Write the new destination and append the blocked artifact; otherwise read-only")
    args = parser.parse_args()
    root = args.workspace.absolute()
    require(root.is_dir() and root.resolve() == root, "WORKSPACE_PATH", "Use the real nonsymlink workspace directory")
    reads = Reads(root)
    bundle = assemble(args, reads)
    snapshot = apply_bundle(args, reads, bundle) if args.apply else None
    result = {"status": "INTEGRATED_BLOCKED" if args.apply else "MECHANICAL_PLAN_READY",
              "artifact": bundle["key"], "destination": "deliverable/" + bundle["destination"],
              "package_before_sha256": sha(bundle["before"]), "package_proposed_sha256": sha(bundle["after"]),
              "package_snapshot": snapshot, "body_sha256": bundle["artifact"]["body"]["sha256"],
              "source_refs": len(bundle["artifact"]["source_refs"]), "build_dependencies": bundle["artifact"]["build_dependencies"],
              "consumed_manifests": bundle["receipt"]["consumed_layer_manifests"],
              "navigation_targets_pending": bundle["receipt"]["navigation_targets_pending"],
              "semantic_reviews": [], "roots_changed": False, "prepare_executed": False}
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except IntegrationError as error:
        print(json.dumps({"status": "ERROR", "code": error.code, "message": str(error), "details": error.details}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(2)
    except (OSError, UnicodeError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({"status": "ERROR", "code": "INVALID_OR_MISSING_INPUT", "message": str(error)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(2)
