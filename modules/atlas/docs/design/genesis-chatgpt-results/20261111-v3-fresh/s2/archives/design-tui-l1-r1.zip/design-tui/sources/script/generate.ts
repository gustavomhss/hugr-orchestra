#!/usr/bin/env bun

import { $ } from "bun"

await $`bun run generate`.cwd("packages/client")

await $`./script/format.ts`
