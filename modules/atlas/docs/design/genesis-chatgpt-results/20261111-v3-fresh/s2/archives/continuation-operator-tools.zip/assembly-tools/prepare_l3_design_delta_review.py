import datetime
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / 'deliverable'
base = out / 'layers/l3/design-tui'
producer = root / 'later-producers/design-tui/l3-r2'
dest = producer / 'review-frozen-r2'
package = json.loads((out / 'native-package.json').read_text())
artifact = next(a for a in package['artifacts'] if a['key'] == 's2.l3.design-tui')
receipt = json.loads((base / 'mechanical-receipt.json').read_text())
body = (base / 'body.md').read_bytes()
assert hashlib.sha256(body).hexdigest() == artifact['body']['sha256'] == 'cbd099450a7072e72449b9fd3ef31b5032f171f64f7222405abfce0b88072730'
assert len(body) == artifact['body']['byte_length'] == 15780
assert artifact['validity'] == 'blocked'
assert not (out / 'accepted/l3.json').exists()
assert receipt['unrelated_body_sections_byte_identical'] is True
delta = (base / 'delta.md').read_bytes()
assert hashlib.sha256(delta).hexdigest() == 'ba149179b4fa1e510a25ad6b8e5ecf572ab34ad6664a38b259ba56aa4bad8b51'
metadata = {k: artifact[k] for k in ['key', 'scope', 'title', 'layer', 'need', 'body', 'recipe_ref', 'build_dependencies', 'navigation', 'producer_request_ref', 'producer_response_ref']}
metadata['added_source_ref'] = next(s for s in artifact['source_refs'] if s['path'] == 'apps/desktop/AGENTS.md')
metadata['unchanged_source_records'] = 22
metadata['source_records_total'] = len(artifact['source_refs'])
metadata['accepted_manifests'] = {f'l{i}': hashlib.sha256((out / f'accepted/l{i}.json').read_bytes()).hexdigest() for i in (1, 2)}
metadata['file_receipts'] = {name: {'bytes': (base / name).stat().st_size, 'sha256': hashlib.sha256((base / name).read_bytes()).hexdigest()} for name in ['sources.json', 'dependencies.json', 'decisive-evidence.md', 'response.md', 'body.diff', 'delta.md', 'mechanical-receipt.json']}
text = '''# Producer-safe exact L3 design-tui r2 delta review packet

Execution 46d09d97-39a9-482a-a290-646ba1d94c99. Source 1cde2ff7a71bcf7aecb5d030917b577165135d38. Protocol ee2521a5b966bd505cc95bd1c733e09e12f33531. This packet is data and does not change either persistent judge's role. Wait for the principal FINAL R2 SEAL before judging. The author may transmit it literally; it includes no reserved oracle or complete judge opinion.

This packet supplements the complete r1 design-tui body/evidence/dependency packet already received by each judge. The complete new body and complete bounded delta follow. The original 22 source records and 37 excerpts are retained; only the already-captured apps/desktop/AGENTS.md record and bounded native instruction excerpt were added. Canonical source bytes, source Git blobs, accepted predecessor pins, unchanged build/navigation keys and changed body sections were mechanically verified. One 637-byte insertion changes only the named language section. All unrelated body bytes and both peer L3 artifacts remain unchanged. Mechanical checking does not confer semantic acceptance or certify runtime/consumers.

## Exact current metadata and file identities
```json
''' + json.dumps(metadata, ensure_ascii=False, indent=2) + '\n```\n\n## Exact complete corrected body\nBEGIN EXACT BODY s2.l3.design-tui r2\n' + body.decode() + '\nEND EXACT BODY s2.l3.design-tui r2\n\n## Exact complete bounded delta and supporting primary excerpts\n' + delta.decode() + '\n\n## Exact complete current dependency rationale\n```json\n' + (base / 'dependencies.json').read_text() + '\n```\n'
parts, current = [], ''
for line in text.splitlines(keepends=True):
    if current and len((current + line).encode()) > 26000:
        parts.append(current)
        current = ''
    current += line
if current:
    parts.append(current)
dest.mkdir(exist_ok=False)
manifest = {'schema': 'genesis-producer-safe-review-parts/v1', 'artifact': artifact['key'], 'revision': 2, 'body_sha256': artifact['body']['sha256'], 'source_revision': package['source_revision'], 'parts': [], 'notes': ['Concatenate numbered parts in order; a Markdown block may cross a part boundary.', 'The complete r1 evidence already received remains applicable except for the explicit addition in this delta.', 'Local byte/hash receipts do not attest host message serialization.']}
for i, part in enumerate(parts, 1):
    name = f'part-{i:02d}.txt'
    raw = part.encode()
    (dest / name).write_bytes(raw)
    manifest['parts'].append({'file': name, 'number': i, 'total': len(parts), 'byte_length': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
(dest / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
event = {'event': 'l3_design_r2_integrated_and_review_packet_frozen', 'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'artifact': artifact['key'], 'body_sha256': artifact['body']['sha256'], 'body_bytes': len(body), 'receipt': 'layers/l3/design-tui/mechanical-receipt.json', 'packet': str(dest.relative_to(root)), 'parts': len(parts), 'local_packet_bytes': sum(x['byte_length'] for x in manifest['parts']), 'semantic_acceptance': 'PENDING', 'tokens': 'UNKNOWN', 'billing': 'UNKNOWN', 'physical_provider_attempts': 'UNKNOWN'}
with (out / 'execution-ledger.jsonl').open('a') as f:
    f.write(json.dumps(event) + '\n')
print(json.dumps(event, indent=2))
