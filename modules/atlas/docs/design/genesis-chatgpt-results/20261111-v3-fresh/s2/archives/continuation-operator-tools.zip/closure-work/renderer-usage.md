# Final work renderer — bounded usage

`render_final_work.py` reads existing evidence and writes a **new draft**, never a judgment, product operation, publication or handoff. Run it only after all thirteen required artifacts have actual whole-layer acceptance in `accepted/l1.json` through `accepted/l4.json` and the requested final operation/readbacks have been preserved.

## Invoke

Set these three variables to **existing, actual JSON receipt files**, then choose a nonexistent directory beneath `closure-work`:

```bash
python /workspace/scratch/7b5d6430f420/genesis-s2/closure-work/render_final_work.py \
  --runtime-operation-receipt "$S2_RUNTIME_RECEIPT" \
  --remote-readback "$S2_REMOTE_READBACK" \
  --ci-readback "$S2_CI_READBACK" \
  --output-dir /workspace/scratch/7b5d6430f420/genesis-s2/closure-work/final-render-01
```

The variable names are inputs to fill with real paths, not evidence already present. `final-render-01` is a proposed output directory. Repeat `--ci-readback` for additional actual runs. Relative input paths resolve from the `genesis-s2` root; absolute paths are safest.

The only generated files are:

- `work.md`: current semantic acceptance, observed runtime/remote/CI fields, source preservation, all fourteen consumer states, S2-U1 graph prediction versus supplied execution, open actions, accounting limits and the fifty-ID matrix.
- `final-obligations.json`: the complete machine-readable draft, exact normative lines, original review identities/scopes, receipt hashes and input snapshot.

Neither file overwrites `deliverable/work.md`. The output directory must not exist. Validation failure exits **2** before output creation; wrong body/review hashes, absent final inputs, missing keys, broken roots/dependencies, changed source/oracle pins and concurrent file changes cause refusal.

## Required receipt inputs

**Runtime:** generic JSON object with an actual `native_package_sha256` (alias `package_sha256`, `native_package.sha256` or `package.sha256`) matching the current final native-package bytes. Preserve the real argv/cwd, start/end, exit code, implementation pin, stdout/stderr references and CAS before/after evidence. Only include prepared output/candidate identifiers when real. A local reference object `{ "path": "…", "sha256": "…" }` is resolved and hash-checked; remote references also require their immutable commit and remain labelled as not reread by the renderer. Do not present intended output paths as existing hashed outputs.

An optional `--runtime-status HOLD`, `NOT_RUN` or `FAIL` is allowed only when explicit receipt states, execution flags or exit code support it. There is no PASS override. A zero exit is quoted as an observed operation result, never converted into runtime/binding/consumer acceptance. No permanent r1 candidate or size-limit conclusion is hardcoded.

**Remote readback:** actual own-branch head plus exact S4 discovery pin. The simplest recognized shape is `own_branch_head: "<actual 40-hex>"` and `s4_discovery: { "commit": "<actual 40-hex>", "path": "<actual path>", "sha256": "<actual hash>" }`. Nested `own_branch` head/sha/commit forms and S4 discovery/release-commit fields are also recognized. Read-only discovery does not establish payload publication or lift a prior refusal.

**CI:** actual JSON readback containing identifiable run/result fields, preferably `run_id`, `candidate_revision` or `head_sha`, `status`, `conclusion`, step results and the workflow scope. The renderer quotes those observations and keeps full S2 gate closure separate. Historical failures are not overwritten by successful individual steps or by a newer unrelated run.

## Optional actual proofs

- `--consumer-receipts PATH`: an object bound to the current package hash, with `cases[]`. Each entry uses one frozen `id`, an observed `state`, and actual `trace_ref` or `trace_refs`; optional `evaluation_refs` link independent decisions. References need paths and SHA-256. Optional counts/versions/isolation observations are quoted. No trace means NOT_RUN; unsupported execution claims without traces are rejected. Supplied traces remain HOLD for final independent assessment. No questions or answer keys are exported.
- `--update-receipt PATH`: actual package-bound receipt with `id` or `case_id` equal to `S2-U1`. Optional `actual_affected_keys` is compared with the final declared build graph. Matching sets are labelled as a recorded set comparison, not rebuild, restoration, reuse or semantic proof. Navigation edges do not propagate the predicted rebuild closure.
- `--control-receipt PATH`: repeat for actual common/local control receipts. The renderer binds available files but does not decide their scope/version compatibility.

## Limits that remain explicit

All thirteen artifact PASS decisions are verified against the original same-pair responses and exact bytes. **Whole-criterion local states remain HOLD for the principal’s final same-pair closure assessment.** Criterion-specific scope is copied only where an original decision explicitly names the criterion; no inferred fifty-criterion PASS is generated. Old r2 FIX-FIRST statuses are not carried forward as if still current after final acceptance.

The renderer preserves the all-1,231-file original-preservation receipt and its late-transport distinction, both historical automatic public-write refusals, native token/billing/provider-attempt **UNKNOWN**, historical **GLOBAL_UNRECONCILED**, and exclusively global complement owner **ROOT**. It does not retry a refused write, request approval, seal `handoff.json`, assign an artifact commit or claim `DELIVERY_COMPLETE`. The principal reviews the new draft and obtains the actual final closure assessment before merging appropriate content into the single live work file.
