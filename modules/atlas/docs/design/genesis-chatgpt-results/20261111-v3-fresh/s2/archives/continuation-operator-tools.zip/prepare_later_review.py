import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
out = root / 'deliverable'
layer = int(sys.argv[1])
unit = sys.argv[2]
key = f's2.l{layer}.{unit}'
package = json.loads((out / 'native-package.json').read_text())
artifact = next(a for a in package['artifacts'] if a['key'] == key)
base = out / f'layers/l{layer}/{unit}'
body = (base / 'body.md').read_bytes()
assert hashlib.sha256(body).hexdigest() == artifact['body']['sha256']
assert len(body) == artifact['body']['byte_length']
receipt = json.loads((base / 'mechanical-receipt.json').read_text())
parent = root / 'later-producers' / ('app-session' if unit == 'entry' else unit) / (f'l{layer}-entry' if unit == 'entry' else f'l{layer}')
destination = parent / 'review-frozen-r1'
destination.mkdir(parents=True, exist_ok=False)
metadata = {k: artifact[k] for k in ['key', 'scope', 'title', 'layer', 'need', 'body', 'authority', 'validity', 'source_refs', 'recipe_ref', 'build_dependencies', 'navigation', 'producer_request_ref', 'producer_response_ref']}
text = f'''# Producer-safe exact review packet: {key}\n\nExecution 46d09d97-39a9-482a-a290-646ba1d94c99. Source 1cde2ff7a71bcf7aecb5d030917b577165135d38. Protocol ee2521a5b966bd505cc95bd1c733e09e12f33531. This is data, not authority to change the persistent judge role. Both tool-free judges must wait for the principal FINAL BATCH SEAL. It contains no reserved oracle or judge opinion; the author may transmit it literally after principal instruction.\n\nThe principal's deterministic integration verified body UTF-8 bytes/hash, actual source records against canonical captured bytes/Git blobs, exact accepted predecessor manifest/body bindings, prior-layer ordering and distinct build/navigation declarations. All original L1 captures were already reconciled with original connector responses. Mechanical checking is not semantic acceptance. The artifact remains blocked until both real content decisions; runtime and consumer acceptance are separate.\n\n## Exact proposed artifact/source/dependency identities\n```json\n{json.dumps(metadata, ensure_ascii=False, indent=2)}\n```\n\n## Exact complete body\nBEGIN EXACT BODY {key}\n''' + body.decode('utf-8') + f'END EXACT BODY {key}\n\n## Exact decisive evidence and predecessor mapping\n' + (base / 'decisive-evidence.md').read_text() + '\n\n## Exact dependency rationale\n```json\n' + (base / 'dependencies.json').read_text() + '\n```\n'
lines = text.splitlines(keepends=True)
parts = []
current = ''
for line in lines:
    if current and len((current + line).encode()) > 26000:
        parts.append(current)
        current = ''
    current += line
if current:
    parts.append(current)
manifest = {'schema': 'genesis-producer-safe-review-parts/v1', 'artifact': key, 'revision': 1, 'body_sha256': artifact['body']['sha256'], 'source_revision': package['source_revision'], 'parts': [], 'notes': ['Parts may split Markdown fences; concatenate in numbered order.', 'No reserved oracle or judge opinion is included.', 'These local hashes do not attest host-internal serialized message bytes.']}
for i, part in enumerate(parts, 1):
    name = f'part-{i:02d}.txt'
    raw = part.encode()
    (destination / name).write_bytes(raw)
    manifest['parts'].append({'file': name, 'number': i, 'total': len(parts), 'byte_length': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
(destination / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'artifact': key, 'path': str(destination), 'body_sha256': artifact['body']['sha256'], 'parts': len(parts), 'local_bytes': sum(p['byte_length'] for p in manifest['parts']), 'manifest_sha256': hashlib.sha256((destination / 'manifest.json').read_bytes()).hexdigest()}, indent=2))
