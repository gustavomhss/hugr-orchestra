# Integração mecânica de produção nativa posterior

`integrate_native_layer.py` integra **um artefato real por execução**. Por padrão só verifica e imprime o plano. `--apply` copia os arquivos exatos, preserva um snapshot do pacote anterior e acrescenta o artefato como `blocked`, com reviews vazios. Não é produção semântica, aceite, novo gate, preparação Atlas ou publicação.

## Uso após o produtor terminar

Executar a partir de `genesis-s2`, usando os hashes exatos dos manifests que o produtor recebeu e consumiu. Não calcular silenciosamente um hash de uma revisão mais recente para substituir o pin do despacho.

```bash
python assembly-tools/integrate_native_layer.py 2 desktop-web \
  --consumed-manifest "accepted/l1.json=${L1_DISPATCH_SHA}"

# A mesma integração, com escrita deliberada pela principal:
python assembly-tools/integrate_native_layer.py 2 desktop-web \
  --consumed-manifest "accepted/l1.json=${L1_DISPATCH_SHA}" \
  --apply
```

Camadas: `2`, `3`, `4`. Unidades: `desktop-web`, `app-session`, `design-tui` e `entry` somente em L4. Há também `--workspace /caminho/real/genesis-s2` e `--title "Título efetivo"`.

```bash
python assembly-tools/integrate_native_layer.py 4 entry \
  --consumed-manifest "accepted/l1.json=${L1_DISPATCH_SHA}" \
  --consumed-manifest "accepted/l2.json=${L2_DISPATCH_SHA}" \
  --consumed-manifest "accepted/l3.json=${L3_DISPATCH_SHA}" \
  --apply
```

Só passar os manifests efetivamente consumidos. A declaração explícita também pode estar em `dependencies.json`; o utilitário confere os bytes e os vínculos, mas não infere nem autentica a leitura pelo produtor.

## Entradas e destinos

| Artefato | Produtor | Destino no deliverable | Receita existente |
| --- | --- | --- | --- |
| `s2.lN.UNIT` | `later-producers/UNIT/lN/` | `layers/lN/UNIT/` | `requests/lN-UNIT-dispatch.md` |
| `s2.l4.entry` | `later-producers/app-session/l4-entry/` | `layers/l4/entry/` | `requests/l4-entry-dispatch.md` |

Cada pasta de produtor precisa conter `body.md`, `sources.json`, `dependencies.json`, `decisive-evidence.md` e `response.md`. Todos são copiados sem normalização de bytes; o corpo permanece `body.md`. O destino deve ser novo. O utilitário não sobrescreve artefatos ou destinos já existentes.

### sources.json

```json
{
  "source_revision": "<mesmo SHA40 do pacote>",
  "sources": [
    {
      "commit": "<SHA40 efetivo>",
      "path": "<caminho relativo real no repositório>",
      "git_blob_sha": "<SHA40 do blob>",
      "sha256": "<SHA256 dos bytes>"
    }
  ]
}
```

A lista deve ser não vazia e sem caminhos duplicados. Campos extras permanecem no sidecar original; os `source_refs` nativos contêm exclusivamente `commit`, `path`, `git_blob_sha` e `sha256`, retirados dessa lista efetiva. Não é feita expansão para todas as capturas disponíveis.

Os refs são confrontados com a união dos manifests canônicos em `producers/{desktop-web,app-session,design-tui}/sources.json` e com os bytes de suas capturas. Fonte ainda não reconciliada retorna `SOURCE_RECONCILIATION_REQUIRED` com os refs necessários, sem escrita. Divergência de identidade ou bytes falha explicitamente. A ferramenta não busca novas fontes nem muda o baseline.

### dependencies.json

```json
{
  "build": ["s2.l1.desktop-web"],
  "navigation": ["s2.l1.desktop-web"],
  "rationale": "<justificativa efetiva do produtor; preservada sem interpretação>",
  "consumed_layer_manifests": [
    {"path": "accepted/l1.json", "sha256": "<SHA256 efetivamente consumido>"}
  ]
}
```

`consumed_layer_manifests` é opcional quando esses mesmos vínculos são passados por `--consumed-manifest`. Os caminhos são relativos ao deliverable e devem ficar em `accepted/`. Hashes conflitantes são recusados.

Todo predecessor de `build` deve existir, pertencer a uma camada anterior, estar `supported` e estar vinculado a um manifest de camada aceita explicitamente consumido, com corpo/caminho/tamanho iguais aos do pacote. O utilitário não deduz dependências semânticas omitidas. A ordem existente das camadas deve ser não decrescente; não se insere uma camada anterior depois de uma posterior.

Navegação é independente de build. Pode apontar a uma chave já declarada em `required_artifact_keys` ainda não materializada; o recibo marca esses destinos pendentes. Não pode introduzir uma chave desconhecida ou apontar ao próprio artefato. **Entry usa build apenas de L1–L3 aceitos e pode navegar às 12 chaves de unidade.** Não depende por build de L4 ainda bloqueado. A principal faz a finalização de roots/nav; a ferramenta não inventa roots nem altera os anteriores.

## O que a integração escreve

- Os cinco arquivos do produtor, idênticos aos originais, em um destino exclusivo.
- `mechanical-receipt.json` no mesmo destino: hash/tamanho do corpo; posições e hashes de seções ATX fora de blocos cercados; refs de fonte verificados; hashes dos manifests canônicos; dependências aceitas; manifests declarados como consumidos; receita; preservação dos artefatos anteriores. Contagem de seções não é avaliação de completude.
- Um snapshot exato anterior em `deliverable/history/native-package-before-<chave>-<sha256-anterior>.json`, antes de substituir o pacote.
- O pacote atualizado por substituição atômica, acrescentando apenas o artefato e retirando sua chave da lista de ausentes. Objetos anteriores, corpos, fonte, roots, contrato e estado do pacote são preservados.

Mapeamento de need: L2 `component`, L3 `flow`, L4 de unidade `ownership`, entry `entry`. Inputs: todos os `file:` dos source_refs efetivos, a receita do despacho e os manifests aceitos explicitamente consumidos. Não são inventados `members:` ou versões kernel. Evidências são strings JSON canônicas, conforme o campo `string[]` do parser atual. Os vínculos de build têm somente `key` e `same_package: true`.

`validity` fica `blocked`; `semantic_review_refs` e `runtime_receipt_refs` ficam vazios. Isso respeita o formato dos campos, mas **não satisfaz o gate completo de prepare**, que exige pareceres reais e seleção completa. A principal continua usando `accept_layer.py` quando possuir os julgamentos efetivos. A ferramenta não abre o oracle nem os corpos dos pareceres; consulta somente metadados dos manifests de camada aceita.

## Falhas, concorrência e limites

Falhas esperadas saem com código 2 e JSON com `code`, `message` e `details`. Sem `--apply`, não há escrita. Na escrita, há lock exclusivo entre integrações, checagem de deriva dos inputs e do pacote, snapshot anterior, destino novo e verificação de bytes. Se a transação falhar antes de substituir o pacote, remove apenas sua própria cópia incompleta; o produtor e o snapshot histórico ficam preservados.

A principal deve serializar esta ferramenta com `accept_layer.py` e qualquer outro escritor: o script de aceite existente não usa o mesmo lock. Um lock deixado por interrupção é um impedimento a reconciliar, não um convite a repetir a operação incertamente.

O utilitário não resolve limites de tamanho do runtime, não executa testes e não concede autoridade. Não foi executado contra as futuras camadas durante sua criação; foi feita somente verificação sintática estática do arquivo Python.
