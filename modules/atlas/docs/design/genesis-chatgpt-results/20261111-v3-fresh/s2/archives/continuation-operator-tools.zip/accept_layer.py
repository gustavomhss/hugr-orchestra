import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
out = root / 'deliverable'
layer = int(sys.argv[1])
binding_path = Path(sys.argv[2]).resolve()
bindings = json.loads(binding_path.read_text())
package_path = out / 'native-package.json'
package = json.loads(package_path.read_text())
prefix = 'modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2/'
expected_judges = {'/root/s2_resume_j1', '/root/s2_resume_j2'}
assert {r['judge'] for r in bindings['reviews']} == expected_judges
assert len(bindings['reviews']) == 2
required = [k for k in package['required_artifact_keys'] if k.startswith(f's2.l{layer}.')]
artifacts = {a['key']: a for a in package['artifacts']}
assert all(k in artifacts for k in required)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

accepted = []
for key in required:
    artifact = artifacts[key]
    body = (out / artifact['body']['path']).read_bytes()
    digest = sha(body)
    assert digest == artifact['body']['sha256']
    assert len(body) == artifact['body']['byte_length']
    reviews = []
    refs = []
    for review in bindings['reviews']:
        entry = next(v for v in review['artifacts'] if v['key'] == key)
        assert entry['body_sha256'] == digest
        assert entry['verdict'] == 'PASS'
        assert entry['mandatory_findings_open'] == 0
        response_path = entry.get('response_path', review.get('response_path'))
        response_sha256 = entry.get('response_sha256', review.get('response_sha256'))
        assert response_path and response_sha256
        path = out / response_path
        raw = path.read_bytes()
        assert sha(raw) == response_sha256
        refs.append({'payload_path': prefix + response_path, 'sha256': sha(raw)})
        reviews.append({'judge': review['judge'], 'verdict': 'PASS', 'response_path': response_path, 'response_sha256': sha(raw)})
    artifact['validity'] = 'supported'
    artifact['semantic_review_refs'] = refs
    artifact['gaps'] = ['Semantic acceptance is scoped to the captured baseline and the documented evidence limits. Runtime binding, publication, actual consumers and applicable CI require separate receipts.']
    accepted.append({'key': key, 'body_path': artifact['body']['path'], 'body_sha256': digest, 'byte_length': len(body), 'reviews': reviews})

manifest = {'schema': 'genesis-s2-accepted-layer/v1', 'execution_id': '46d09d97-39a9-482a-a290-646ba1d94c99', 'layer': layer, 'status': 'SEMANTIC_LAYER_ACCEPTED', 'recorded_at': datetime.now(timezone.utc).isoformat(), 'source_revision': package['source_revision'], 'protocol_revision': package['protocol_ref']['commit'], 'population': 4506, 'paths_sha256': '8b70f96dcbb623bdd1cc2a48b61d51d255d9d9ce90836efc9a5cd05f1fc5a582', 'artifacts': accepted, 'limits': ['This mechanical manifest records actual independent semantic decisions; it is not a new judgment.', 'No runtime, consumer, CI, financial or global integration PASS is implied.']}
dest = out / 'accepted' / f'l{layer}.json'
assert not dest.exists(), 'Never overwrite an accepted-layer manifest; create a new revision and preserve the old.'
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
package['known_limits'] = [v for v in package['known_limits'] if v != 'No semantic layer accepted yet.' and not v.startswith('Semantic layer acceptance currently records') and not v.startswith('Runtime release pending;')]
accepted_numbers = sorted(int(p.stem[1:]) for p in (out / 'accepted').glob('l[1-4].json'))
package['known_limits'].insert(0, f'Semantic layer acceptance currently records L{", L".join(str(n) for n in accepted_numbers)} only. Runtime binding, publication, consumers, applicable CI and global gates are separate obligations.')
if layer == 4:
    assert package['missing_required_artifact_keys'] == []
    package['package_state'] = 'SEMANTIC_ACCEPTED_RUNTIME_PENDING'
package_path.write_text(json.dumps(package, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'layer': layer, 'keys': required, 'manifest_sha256': sha(dest.read_bytes()), 'semantic_status': manifest['status'], 'runtime_status': 'NOT_ACCEPTED'}, indent=2))
