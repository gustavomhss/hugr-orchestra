import { beforeAll, describe, expect, test } from "bun:test"
import { ServerScope } from "@/utils/server-scope"

let getWorkspaceTerminalCacheKey: typeof import("./terminal").getWorkspaceTerminalCacheKey
let getLegacyTerminalStorageKeys: (dir: string, legacySessionID?: string) => string[]
let migrateTerminalState: (value: unknown) => unknown
let isTerminalGoneError: (error: unknown) => boolean
let updateServerPty: typeof import("./terminal").updateServerPty

beforeAll(async () => {
  const mod = await import("./terminal")
  getWorkspaceTerminalCacheKey = mod.getWorkspaceTerminalCacheKey
  getLegacyTerminalStorageKeys = mod.getLegacyTerminalStorageKeys
  migrateTerminalState = mod.migrateTerminalState
  isTerminalGoneError = mod.isTerminalGoneError
  updateServerPty = mod.updateServerPty
})

describe("getWorkspaceTerminalCacheKey", () => {
  test("uses workspace-only directory cache key", () => {
    expect(String(getWorkspaceTerminalCacheKey("/repo"))).toBe("local\u0000/repo\u0000__workspace__")
  })

  test("can include a server scope", () => {
    expect(String(getWorkspaceTerminalCacheKey("/repo", "ssh:debian" as ServerScope))).toBe(
      "ssh:debian\u0000/repo\u0000__workspace__",
    )
  })
})

describe("getLegacyTerminalStorageKeys", () => {
  test("keeps workspace storage path when no legacy session id", () => {
    expect(getLegacyTerminalStorageKeys("/repo")).toEqual(["/repo/terminal.v1"])
  })

  test("includes legacy session path before workspace path", () => {
    expect(getLegacyTerminalStorageKeys("/repo", "session-123")).toEqual([
      "/repo/terminal/session-123.v1",
      "/repo/terminal.v1",
    ])
  })
})

describe("migrateTerminalState", () => {
  test("drops invalid terminals and restores a valid active terminal", () => {
    expect(
      migrateTerminalState({
        active: "missing",
        all: [
          null,
          { id: "one", title: "Terminal 2" },
          { id: "one", title: "duplicate", titleNumber: 9 },
          { id: "two", title: "logs", titleNumber: 4, rows: 24, cols: 80 },
          { title: "no-id" },
        ],
      }),
    ).toEqual({
      active: "one",
      all: [
        { id: "one", title: "Terminal 2", titleNumber: 2 },
        { id: "two", title: "logs", titleNumber: 4, rows: 24, cols: 80 },
      ],
    })
  })

  test("keeps a valid active id", () => {
    expect(
      migrateTerminalState({
        active: "two",
        all: [
          { id: "one", title: "Terminal 1" },
          { id: "two", title: "shell", titleNumber: 7 },
        ],
      }),
    ).toEqual({
      active: "two",
      all: [
        { id: "one", title: "Terminal 1", titleNumber: 1 },
        { id: "two", title: "shell", titleNumber: 7 },
      ],
    })
  })
})

describe("isTerminalGoneError", () => {
  test("treats a pty the server no longer has as already closed", () => {
    expect(isTerminalGoneError({ _tag: "PtyNotFoundError", ptyID: "pty_1", message: "gone" })).toBe(true)
    expect(isTerminalGoneError(Object.assign(new Error("request failed"), { cause: { status: 404 } }))).toBe(true)
  })

  test("keeps every other close failure visible", () => {
    expect(isTerminalGoneError(new Error("offline"))).toBe(false)
    expect(isTerminalGoneError({ _tag: "PtyForbiddenError" })).toBe(false)
    expect(isTerminalGoneError(Object.assign(new Error("request failed"), { cause: { status: 500 } }))).toBe(false)
    expect(isTerminalGoneError(undefined)).toBe(false)
  })
})

describe("updateServerPty", () => {
  test("sends the renamed title and size to the V2 pty route", async () => {
    const calls: unknown[] = []
    const api = { update: async (input: unknown) => void calls.push(input) } as unknown as Parameters<typeof updateServerPty>[0]
    await updateServerPty(api, { directory: "/repo" }, { id: "pty_1", title: "logs", cols: 100, rows: 30 })
    expect(calls).toEqual([
      { ptyID: "pty_1", location: { directory: "/repo" }, title: "logs", size: { rows: 30, cols: 100 } },
    ])
  })
})
