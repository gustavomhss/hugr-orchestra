**Ferramenta entregue, sem executar integração nem alterar o pacote atual.**

- [integrate_native_layer.py](sandbox:/workspace/scratch/7b5d6430f420/genesis-s2/assembly-tools/integrate_native_layer.py)
- [README.md — uso e schemas](sandbox:/workspace/scratch/7b5d6430f420/genesis-s2/assembly-tools/README.md)
- [verification.json](sandbox:/workspace/scratch/7b5d6430f420/genesis-s2/assembly-tools/verification.json)

A ferramenta verifica fontes contra as capturas canônicas, preserva corpo e sidecars exatos, exige build predecessors de camadas anteriores já suportados e vinculados aos manifests explicitamente consumidos. Com `--apply`, cria destino exclusivo, preserva o snapshot anterior e acrescenta somente um artefato `blocked`, com reviews vazios e recibo mecânico. Sem `--apply`, apenas verifica e imprime o plano.

Uso futuro:

```bash
python assembly-tools/integrate_native_layer.py 2 desktop-web \
  --consumed-manifest "accepted/l1.json=${L1_DISPATCH_SHA}" \
  --apply
```

Entry usa `4 entry`, destino `layers/l4/entry/`, build somente de L1–L3 aceitos e navegação às chaves required declaradas. Roots e aceite continuam com a principal e `accept_layer.py`.

**Verificação feita:** parse sintático estático do Python. Nenhum teste, integração, oracle, pacote de revisão ou prepare foi executado/lido. O SHA-256 do pacote permaneceu `70a76c24d80af669a4b13b88eb26635294ef0ad28c490fd73066eb2f1ce293ef`.

SHA-256 da ferramenta: `664bbd0c1be81d9ec8606eb6a8f8909cb8434c1e17be3114c3ad1165750ff918`.
