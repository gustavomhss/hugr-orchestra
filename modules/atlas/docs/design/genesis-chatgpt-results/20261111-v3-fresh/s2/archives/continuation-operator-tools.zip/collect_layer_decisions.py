import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
out = root / 'deliverable'
layer = int(sys.argv[1])
files = sys.argv[2:]
assert files
package = json.loads((out / 'native-package.json').read_text())
expected = {a['key']: a for a in package['artifacts'] if a['layer'] == layer}
required = {k for k in package['required_artifact_keys'] if k.startswith(f's2.l{layer}.')}
assert set(expected) == required
grouped = {'/root/s2_resume_j1': [], '/root/s2_resume_j2': []}
unselected = []
# A mixed historical response can be selected explicitly per artifact without
# rewriting it or silently treating its other (possibly vetoed) entries as PASS.
# Example: judgments/l3-r1/j1.json::s2.l3.desktop-web,s2.l3.app-session
for selection in files:
    rel, separator, selected_text = selection.partition('::')
    selected_keys = set(selected_text.split(',')) if separator else None
    if selected_keys is not None:
        assert selected_keys and '' not in selected_keys
    path = out / rel
    raw = path.read_bytes()
    text = raw.decode().strip()
    if text.startswith('```json\n'):
        assert text.endswith('\n```')
        text = text[len('```json\n'):-len('\n```')]
    data = json.loads(text)
    reviewer = data.get('reviewer', data.get('reviewer_id'))
    judge = {'parallel-v3-fresh/S2/J1': '/root/s2_resume_j1', 'parallel-v3-fresh/S2/J2': '/root/s2_resume_j2'}[reviewer]
    assert data['source_revision'] == package['source_revision']
    assert data['protocol_revision'] == package['protocol_ref']['commit']
    if selected_keys is not None:
        assert selected_keys <= {entry['key'] for entry in data['artifacts']}
    for entry in data['artifacts']:
        key = entry['key']
        if selected_keys is not None and key not in selected_keys:
            unselected.append({'response_path': rel, 'response_sha256': hashlib.sha256(raw).hexdigest(), 'key': key, 'body_sha256': entry['body_sha256'], 'verdict': entry['verdict'], 'reason': 'Explicit per-artifact selection; original entry remains preserved and is not accepted by this record.'})
            continue
        assert key in expected
        assert entry['body_sha256'] == expected[key]['body']['sha256']
        assert entry['verdict'] == 'PASS', (judge, key, entry['verdict'])
        assert entry['mandatory_findings'] == [], (judge, key, 'mandatory findings remain')
        assert not any(x['key'] == key for x in grouped[judge]), (judge, key, 'duplicate final judgment')
        grouped[judge].append({'key': key, 'body_sha256': entry['body_sha256'], 'verdict': 'PASS', 'mandatory_findings_open': 0, 'response_path': rel, 'response_sha256': hashlib.sha256(raw).hexdigest()})
for judge, entries in grouped.items():
    assert {v['key'] for v in entries} == required, (judge, 'whole-layer coverage missing')
result = {'schema': 'genesis-s2-independent-decision-bindings/v1', 'layer': layer, 'scope': 'Semantic artifact decisions only; all actual original responses remain referenced and unchanged.', 'reviews': [{'judge': judge, 'artifacts': entries} for judge, entries in grouped.items()], 'unselected_historical_entries': unselected}
target = out / 'judgments' / f'l{layer}-accepted-decision-bindings.json'
assert not target.exists()
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(str(target))
