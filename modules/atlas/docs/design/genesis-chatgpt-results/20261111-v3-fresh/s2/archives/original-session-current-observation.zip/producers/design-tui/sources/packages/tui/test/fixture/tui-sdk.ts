import type { GlobalEvent } from "../../src/types"
import type { EventSource } from "../../src/context/sdk"

export const worktree = "/tmp/orchestra"
export const directory = `${worktree}/packages/tui`

export function json(data: unknown, init?: ResponseInit) {
  return new Response(JSON.stringify(data), {
    ...init,
    headers: { "content-type": "application/json", ...(init?.headers ?? {}) },
  })
}

export function eventSource(): EventSource {
  return { subscribe: async () => () => {} }
}

export function createEventSource() {
  let fn: ((event: GlobalEvent) => void) | undefined
  let stream: ReadableStreamDefaultController<Uint8Array> | undefined
  const pending: Uint8Array[] = []
  return {
    source: {
      subscribe: async (handler: (event: GlobalEvent) => void) => {
        fn = handler
        return () => {
          if (fn === handler) fn = undefined
        }
      },
    } satisfies EventSource,
    emit(event: GlobalEvent) {
      if (!fn) throw new Error("event source not ready")
      fn(event)
      const chunk = new TextEncoder().encode(
        `data: ${JSON.stringify({
          ...event.payload,
          location: { directory: event.directory, workspaceID: event.workspace },
        })}\n\n`,
      )
      if (stream) return stream.enqueue(chunk)
      pending.push(chunk)
    },
    response() {
      return new Response(
        new ReadableStream<Uint8Array>({
          start(controller) {
            stream = controller
            for (const chunk of pending.splice(0)) controller.enqueue(chunk)
          },
          cancel() {
            stream = undefined
          },
        }),
        { headers: { "content-type": "text/event-stream" } },
      )
    },
  }
}

// A V2 Session as `/api/session` routes return it.
export function v2Session(input: { id: string; title?: string; directory?: string; subpath?: string }) {
  return {
    id: input.id,
    projectID: "proj_test",
    title: input.title ?? input.id,
    cost: 0,
    tokens: { input: 0, output: 0, reasoning: 0, cache: { read: 0, write: 0 } },
    time: { created: 0, updated: 0 },
    location: { directory: input.directory ?? directory },
    subpath: input.subpath,
  }
}

export type FetchHandler = (url: URL) => Response | Promise<Response> | undefined

export function createFetch(override?: FetchHandler, events?: ReturnType<typeof createEventSource>) {
  const session = [] as URL[]
  const fetch = (async (input: RequestInfo | URL) => {
    const url = new URL(input instanceof Request ? input.url : String(input))
    if (url.pathname === "/api/session") session.push(url)
    const overridden = await override?.(url)
    if (overridden) return overridden
    if (url.pathname === "/api/event" && events) return events.response()

    if (url.pathname === "/api/location") return json({ directory, project: { id: "proj_test", directory: worktree } })
    if (
      ["/api/agent", "/api/model", "/api/provider", "/api/integration", "/api/command", "/api/skill"].includes(
        url.pathname,
      )
    )
      return json({
        location: { directory, project: { id: "proj_test", directory: worktree } },
        data: [],
      })
    if (["/api/formatter", "/api/lsp", "/api/mcp"].includes(url.pathname))
      return json({ location: { directory, project: { id: "proj_test", directory: worktree } }, data: [] })
    if (url.pathname === "/api/model/default")
      return json({ location: { directory, project: { id: "proj_test", directory: worktree } }, data: null })
    if (url.pathname === "/api/vcs")
      return json({
        location: { directory, project: { id: "proj_test", directory: worktree } },
        data: { branch: "main" },
      })
    if (url.pathname === "/api/config") return json({ disabledProviders: [] })
    if (url.pathname === "/api/session") return json({ data: [], cursor: {} })
    if (url.pathname === "/api/session/active") return json({ data: {} })
    if (url.pathname === "/api/project/proj_test/directories") return json([])
    if (url.pathname === "/api/reference")
      return json({ location: { directory, project: { id: "proj_test", directory } }, data: [] })
    throw new Error(`unexpected request: ${url.pathname}`)
  }) as typeof globalThis.fetch
  return { fetch, session }
}
