# Final closure review packet builder

This helper prepares literal transport for the **existing tool-free J1/J2 pair**. It does not contact judges, execute runtime/native operations, issue a judgment, change canonical files, publish, or seal a handoff.

Run only after the principal has an actual final-render directory produced by `render_final_work.py`, all thirteen artifact acceptances, actual native-operation stdout/stderr, final readbacks, and verified compact S4 CI/compatibility observations.

The inspectable root-only request source is `root-seal-request.template.md`; the builder fills only judge identity, packet identity, part count and the frozen ID list. It contains no chosen verdict.

## Invocation

Set `S2_FINAL_RENDER` to the existing rendered directory and `S2_S4_OBSERVATIONS` to an existing compact operational JSON receipt. Select a nonexistent output directory below `closure-work`:

```bash
python /workspace/scratch/7b5d6430f420/genesis-s2/closure-work/closure-review-tools/build_closure_review_packet.py \
  --final-render-dir "$S2_FINAL_RENDER" \
  --s4-observations "$S2_S4_OBSERVATIONS" \
  --output-dir /workspace/scratch/7b5d6430f420/genesis-s2/closure-work/final-closure-packet-01
```

The variables must name **real existing inputs**; `final-closure-packet-01` is only a proposed output directory. Repeat `--s4-observations` for additional actual JSON summaries. Their total must be at most **52,000 bytes**; the helper refuses larger input rather than truncating evidence. Supply compact operational observations with real pins and source references, never raw judge opinions.

Stdout and stderr are located through their exact path/SHA-256 bindings in the actual operation receipt. Recognized forms include `stdout_ref`/`stderr_ref`, nested stream reference objects, and paired `stdout_path`/`stdout_sha256` fields. If multiple genuine bindings are present, disambiguate with `--runtime-stdout` and `--runtime-stderr`; an override must still match a reference actually recorded in the operation receipt. Both streams are included in full, even if empty. Missing or unbound logs cause refusal.

## Outputs

- `packet.txt`: exact complete review payload.
- `packet-manifest.json`: full-packet hash, numbered part hashes, exact UTF-8 byte lengths, section offsets/hashes, thirteen body identities, fifty IDs and evidence snapshot.
- `parts/part-NNN-of-NNN.txt`: numbered **literal** message bodies, including headers, each at most **26,000 UTF-8 bytes**. `--max-part-bytes` can choose a smaller cap between 1,024 and 26,000. Payload segments reassemble exactly without truncation or character replacement.
- `root-only/seal-j1-request-template.md` and `root-only/seal-j2-request-template.md`: requests for the principal to inspect and send only after real complete part delivery. They are transport-seal templates, not Git handoffs or evidence of contact.

Both judges receive the same numbered evidence parts. The principal preserves real sends/receipts separately, then uses each appropriate request template. Local hashes do not establish host serialization or actual receipt; the requests make that limitation explicit.

## Included and excluded content

The packet contains the complete exact renderer-generated `work.md`; all fifty verbatim normative lines and local obligations; thirteen current body identities and four accepted-layer manifest pins; actual native receipt and full stdout/stderr; supplied scoped CI/compatibility/readback observations; original public-write refusal contents; consumer ID/state/read-bound metadata; source-preservation and usage scope; the pinned completion protocol; and S2-U1's declared-graph prediction explicitly separated from any execution evidence.

It does **not** serialize `actual_criterion_review_scopes`, optional peer comments, or original peer review responses. Public two-PASS metadata is permitted. Reserved consumer questions/answers are never emitted; the pinned oracle is used only to screen accidental literal contamination. Known opinion-bearing structures in supplied operational JSON are rejected. The principal must inspect supplied summaries and the final packet before transport.

`work.md` must match the exact output that the current renderer derives from its companion JSON. If it was edited, regenerate the final-render bundle; the helper refuses unverified additions. All current body, accepted-manifest, package and evidence identities are rechecked. Input drift or absent prerequisites causes refusal before output creation. Every output directory is exclusive; no canonical work file or original decision is overwritten.

## Requested independent assessment

Each template asks its existing judge to cover **all fifty IDs exactly once** (groups allowed), identify satisfied local portions, remaining local gates, exclusively global ROOT complements, independently executable work and observed blockers, then assess the true closure state. Draft HOLD labels and recorded artifact PASS are explicitly **not predetermined closure answers**. The templates neither choose a verdict nor authorize publication. Original judgments remain intact.

Preparation verification for this helper is **syntax validation only**. The builder has not been invoked; no review packet or judge contact is claimed by creating these tools.

## Principal-reported checkpoint at preparation

The principal reports that all three L4 unit guides have both PASS decisions, while the integrated L4 entry r2 (5,849 bytes; SHA-256 `e816f0085875b72b53ed35f4fdba2d04efbfb8130ab13c21b11ca0ebf5dde0b1`) is still awaiting completion of the same-pair transport/review gate. Native prepare is **NOT_RUN**. These are prerequisite notes, not final acceptance or operation evidence.

The supplied fresh readback is `deliverable/evidence/final-remote-recheck-01/readback-receipt.json`: S2 HEAD `ac972ff8dc1126b02f8a16f3942a142e417039ed`; S4 HEAD `c4a2992369f2309cbb5ffb8f166abbd7c3b81a4c`; release SHA-256 `6de0b5f7a8911eb40c7fbcf74e74210805175ee580c0c8482249c016af1c0016`. The principal reports the native candidate and 256,000-byte cap unchanged. The helper does not pin these checkpoint values as permanent conditions; the actual final-render bundle and operation receipt supplied at invocation control the packet. No new release, CI result, binding or prepare outcome is assumed here.
