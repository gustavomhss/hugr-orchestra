// @atlas/adapter-io — src/native-memory.ts  (the BOUND Memory composition — F3 work package A1)
//
// ── CALLERS ──────────────────────────────────────────────────────────────────────────────────────────────
// Orchestra's backend specialist composes this through the installed boundary package (F3 clause 27). The CLI/MCP
// doors compose Memory through `compose.ts`, which resolves the owner from `ATLAS_ACTOR ?? git user.email`, and F3
// clause 4 forbids exactly that route here. The one in-tree caller is the Atlas screen's surface
// (`surface/review.ts`), which calls `decideProjectRule`; it writes as the PROPOSAL's member and never as the
// surface's resolved actor, so clause 4 still holds.
//
// ── WHAT THIS FILE IS ────────────────────────────────────────────────────────────────────────────────────
// The four Memory doors (`createDurableMemory`, `createMemoryRead`, `createMemoryEmit`, the scanner) composed
// under ONE immutable `AtlasBinding` the harness supplies. Three things are FORCED from the binding and
// cannot be supplied by any input to the returned surface: the storage root (clause 30), the owner every
// read filters on and every write is minted with (clauses 2-4, 12), and the scanner path (clause 31).
// Nothing here reads `cwd`, the environment or git identity.
//
// ── IDENTITY IS RETURNED, NEVER RECOMPUTED BY A CONSUMER (clause 5) ──────────────────────────────────────
// `RecordRef = { contentHash, eventId }` is read from the durable log's own event envelope for every record
// this surface returns, and from `versioned([record])` — the exact event `append` writes — for an admitted
// write. Identity is content-derived: the same owner submitting an identical entry gets the same ref, the
// fold holds one record, and the log still gains a physical duplicate line.
//
// ── STORE STATE (clauses 7, 13) ──────────────────────────────────────────────────────────────────────────
// `complete` = every line parsed and self-verified; `partial` = at least one rejected line; `unavailable` =
// the file could not be read at all. An empty COMPLETE result is a legitimate "nothing recorded"; the other
// two are never presented as empty. A partial store still SERVES what verified (each line carries its own
// content hash, so a served record is sound) and says it is partial.
//
// ── EXACT FOLD RESOLUTION (clause 15) ────────────────────────────────────────────────────────────────────
// `resolveFold(unit, ref)` looks the record up by `eventId` in the folded log and checks owner, kind and
// unit id — it never consults `spawnFold`/`makeRespawn`, whose `archive.find` returns the FIRST own match in
// log order, i.e. the OLDEST checkpoint. Without a ref (no host receipt, clause 16) exactly one own record
// is selected; several refuse `ambiguous` (owner ruling F3-D3); log order is never read as "latest".
// The same rules hold for a `task` and a `pr` unit; only the projection differs (`taskClosingFold` /
// `prClosingFold`, clause 14).
//
// ── ATLAS OWNS A RULE'S FRECENCY (clause 22, owner ruling F3-D6) ─────────────────────────────────────────
// `write` and `reconcile` complete a `project` proposal with `INITIAL_PROJECT_FRECENCY`, so both derive the
// same record and the same ref. An entry that carries its own `frecency` is refused `template-invalid` before
// the emit door sees it; everything else is still judged by the door's own gates.
//
// ── ADMISSION CONCURRENCY, BOUNDED (clause 26, owner ruling F3-D8) ───────────────────────────────────────
// Correct for ONE writer process per storage root. The emit door reads the incumbent/cap state, scans, then
// appends; nothing serialises that sequence across processes, and this file adds no lock. Two processes
// writing `project` rules for one owner at once can each pass the cap against the same pre-state. Each
// append is still a single `O_APPEND` write, so no record is lost or spliced — the bound is on the GATES.

import { isAbsolute } from "node:path"
import { INITIAL_PROJECT_FRECENCY, prClosingFold, put, taskClosingFold, tok, validate, versioned } from "@atlas/memory"
import type {
  Awareness,
  ClosingFold,
  FacetState,
  MemberId,
  MemoryEntry,
  MemoryRecord,
  NamedScanner,
  Orientation,
  PrClosingFold,
  PrMemoryEntry,
  ProjectMemoryEntry,
  ResumeUnit,
  TaskMemoryEntry,
  TurnHeader,
} from "@atlas/memory"
import type { Hash } from "@atlas/contracts"
import { createDurableMemory } from "./memory-store.js"
import type { DurableMemory, MemoryRead } from "./memory-store.js"
import { createMemoryEmit } from "./memory-emit.js"
import type { MemoryRejected } from "./memory-emit.js"
import { createMemoryRead } from "./memory-read.js"
import { appendReview, foldReview, readReview, reviewLogPath } from "./review-log.js"
import { createAwarenessStore } from "./awareness-store.js"
import { createDurableOrientation } from "./orientation-store.js"
import { KNOWN_SCANNERS, detectAvailableScanner, runScanner } from "./scanner.js"
import type { ScannerBinarySpec } from "./scanner.js"

/** F3 clause 1. Supplied by the harness, frozen on entry; the model never supplies any field of it. */
export interface AtlasBinding {
  readonly storage: { readonly projectID: string; readonly root: string }
  readonly source: { readonly worktree: string; readonly revision: string }
  /** The stable roster member id (clause 2). The ONLY owner this surface writes as, and the owner it reads as. */
  readonly memoryOwner: MemberId
  /** Ids the SAME member's records were written under before its id was renamed. `recall`, `resolveFold` and the
   *  header's rules read a record owned by one of them as the binding owner's; nothing is ever written or minted
   *  under them, and a stored record is served unchanged. NOT in clause 1's field set — added for a harness seat
   *  rename. */
  readonly legacyOwners?: readonly MemberId[]
  /** Execution provenance. Carried for the host's receipt; never written into an entry or record (clause 3). */
  readonly execution: {
    readonly actor: { readonly memberId: string; readonly projectId: string; readonly sessionId: string }
    readonly executionSessionID: string
    readonly invocation?: { readonly callID: string; readonly assistantMessageID: string }
  }
  readonly unit?: ResumeUnit
  readonly logicalResumeID?: string
  /** An explicit scanner binary (the backend specialist toolkit's fetched `gitleaks`), tried before PATH (clause 31).
   *  NOT in clause 1's field set — added by the A1 brief; see the work package report. */
  readonly scanner?: { readonly name: ScannerBinarySpec["name"]; readonly command: string }
}

export type StoreState = "complete" | "partial" | "unavailable"
export interface RecordRef {
  readonly contentHash: string
  readonly eventId: string
}

export interface SlabStates {
  readonly awareness: { readonly [F in keyof Awareness]: FacetState }
  readonly rules: StoreState
}
export interface HeaderBound {
  readonly rulesWords: number
  readonly method: "whitespace-words"
}
/** Clause 7. `header` is absent exactly when the rules store is `unavailable`. */
export interface BoundHeader {
  readonly header?: TurnHeader
  readonly state: SlabStates
  readonly bound: HeaderBound
}

export type BoundRecallQuery =
  | { readonly kind: "task"; readonly taskId: string }
  | { readonly kind: "pr"; readonly prId: string }
export interface BoundRecall {
  readonly records: readonly MemoryRecord[]
  readonly refs: readonly RecordRef[]
  readonly store: StoreState
}

export type FoldRefusal =
  | "no-own-fold"
  | "record-not-found"
  | "foreign-owner"
  | "unit-mismatch"
  | "store-partial"
  | "store-unavailable"
  | "ambiguous"
/** Clause 15. `fold` is the `ClosingFold` of a `task` unit and the `PrClosingFold` of a `pr` unit. */
export type FoldVerdict =
  | {
      readonly ok: true
      readonly unit: ResumeUnit
      readonly ref: RecordRef
      readonly record: MemoryRecord
      readonly fold: ClosingFold | PrClosingFold
    }
  | { readonly ok: false; readonly refusal: FoldRefusal; readonly reason: string }

/** Clause 23. A refusal is the emit door's `MemoryRejected`, passed through verbatim. */
export type WriteVerdict =
  | { readonly ok: true; readonly record: MemoryRecord; readonly ref: RecordRef }
  | MemoryRejected

/** Clause 25. */
export type ReconcileVerdict =
  | { readonly present: true; readonly ref: RecordRef }
  | { readonly present: false; readonly store: StoreState }

/** R5 (D23): one of the binding owner's own `task` checkpoints, as a resume picker lists it. It carries no time: a
 *  record has none, and log order is never \"latest\" (F3-D3), so the list claims nothing about recency. */
export interface ResumableRecord {
  readonly ref: RecordRef
  readonly taskId: string
  readonly stoppedAt: string
  readonly lesson: string
}
/** R5 (D23). File order. An `unavailable` store lists nothing and says so; it is never an empty `complete` list. */
export interface ResumableList {
  readonly records: readonly ResumableRecord[]
  readonly store: StoreState
}
/** A `project` rule as a seat proposes it: Atlas owns the initial `frecency` (clause 22, work package A2), so the
 *  bound write takes no caller-supplied score. */
export type ProjectRuleProposal = Omit<ProjectMemoryEntry, "frecency">

/** R1 (D18): what proposing a `project` rule did. A refusal has the emit door's `MemoryRejected` shape. */
export type ProposalVerdict =
  | { readonly ok: true; readonly proposalId: string; readonly reconciled?: true }
  | MemoryRejected
/** The entries the bound write and reconcile doors accept: a seat's own `task`/`pr` checkpoint or `project` rule.
 *  `logbook` is orchestrator-only and never reaches a seat's binding. */
export type BoundEntry = TaskMemoryEntry | PrMemoryEntry | ProjectRuleProposal

export interface NativeMemory {
  readonly binding: AtlasBinding
  header(awareness: Awareness, orientation: Orientation): BoundHeader
  recall(query: BoundRecallQuery): BoundRecall
  resolveFold(unit: ResumeUnit, ref?: RecordRef): FoldVerdict
  write(entry: BoundEntry): WriteVerdict
  reconcile(entry: BoundEntry): ReconcileVerdict
  /** R5: the binding owner's own task checkpoints (its `legacyOwners` included). Takes no owner: the binding is the
   *  only owner this surface reads as (clauses 2-4). */
  listResumable(): ResumableList
}

export function createNativeMemory(input: AtlasBinding): NativeMemory {
  const binding = freezeBinding(input)
  const owner = binding.memoryOwner
  const owners = new Set([owner, ...(binding.legacyOwners ?? [])])
  const store = createDurableMemory(binding.storage.root)

  function resolveFold(unit: ResumeUnit, ref?: RecordRef): FoldVerdict {
    const read = store.read()
    const state = storeStateOf(read)
    if (state === "unavailable")
      return refuse("store-unavailable", `the memory log at '${store.path}' could not be read`)
    if (ref === undefined) return selectWithoutReceipt(read, state, unit)
    const ev = read.log.get(ref.eventId as Hash)
    if (ev === undefined || ev.contentHash !== ref.contentHash) {
      return state === "partial"
        ? refuse(
            "store-partial",
            `record ${ref.eventId} is not in the log, which has ${read.rejected} rejected line(s) it may be in`,
          )
        : refuse("record-not-found", `no record with eventId ${ref.eventId} and contentHash ${ref.contentHash}`)
    }
    return project(unit, ref, ev.payload as MemoryRecord)
  }

  function selectWithoutReceipt(read: MemoryRead, state: StoreState, unit: ResumeUnit): FoldVerdict {
    if (state === "partial") {
      return refuse(
        "store-partial",
        `cannot count ${unit.kind} '${unit.id}' checkpoints: ${read.rejected} rejected line(s)`,
      )
    }
    const own = [...read.log.entries()].filter(([, ev]) => isOwnUnit(ev.payload as MemoryRecord, unit))
    if (own.length === 0) return refuse("no-own-fold", `no own ${unit.kind} record for '${unit.id}' (owner '${owner}')`)
    if (own.length > 1) {
      return refuse(
        "ambiguous",
        `${own.length} own ${unit.kind} records for '${unit.id}' and no receipt names one; log order is not "latest"`,
      )
    }
    const [eventId, ev] = own[0]!
    return project(unit, { contentHash: ev.contentHash, eventId }, ev.payload as MemoryRecord)
  }

  function project(unit: ResumeUnit, ref: RecordRef, record: MemoryRecord): FoldVerdict {
    if (!owners.has(record.owner))
      return refuse("foreign-owner", `record ${ref.eventId} belongs to '${record.owner}', not '${owner}'`)
    if (!isOwnUnit(record, unit))
      return refuse("unit-mismatch", `record ${ref.eventId} is not the ${unit.kind} '${unit.id}'`)
    return {
      ok: true,
      unit: { kind: unit.kind, id: unit.id },
      ref,
      record,
      fold:
        unit.kind === "task"
          ? taskClosingFold(record.entry as TaskMemoryEntry)
          : prClosingFold(record.entry as PrMemoryEntry),
    }
  }

  function isOwnUnit(record: MemoryRecord, unit: ResumeUnit): boolean {
    const e = record.entry as { readonly taskId?: unknown; readonly prId?: unknown }
    return (
      owners.has(record.owner) && record.kind === unit.kind && (unit.kind === "task" ? e.taskId : e.prId) === unit.id
    )
  }

  return {
    binding,

    header: (awareness, orientation) => boundHeader(binding, store, awareness, orientation),

    recall(query): BoundRecall {
      const q = narrowRecall(query)
      const read = store.read()
      const state = storeStateOf(read)
      if (state === "unavailable") return { records: [], refs: [], store: state }
      // The owner is set HERE, after narrowing, from the binding — a caller-supplied `owner` never survives. Each
      // owner the binding reads as is recalled separately, and the union is served in the store's own order.
      const matched = new Set(
        [...owners].flatMap((o) =>
          createMemoryRead({ store: frozen(read, store.path), actor: o }).recall({ ...q, owner: o }),
        ),
      )
      const records = read.store.filter((r) => matched.has(r))
      const refOf = new Map(
        [...read.log.entries()].map(([eventId, ev]) => [ev.payload, { contentHash: ev.contentHash, eventId }]),
      )
      return { records, refs: records.map((r) => refOf.get(r)!), store: state }
    },

    resolveFold,

    write(entry): WriteVerdict {
      const complete = withAtlasFrecency(entry)
      if (complete === undefined) {
        return {
          ok: false,
          refusal: "template-invalid",
          reason: "`frecency` is assigned by Atlas policy (INITIAL_PROJECT_FRECENCY); an entry may not supply it",
        }
      }
      const verdict = createMemoryEmit({ store, actor: owner, ...scannerFor(binding) }).emit(complete)
      return verdict.ok ? { ok: true, record: verdict.record, ref: refOfRecord(verdict.record) } : verdict
    },

    reconcile(entry): ReconcileVerdict {
      const read = store.read()
      const state = storeStateOf(read)
      const complete = withAtlasFrecency(entry)
      const ref = complete === undefined ? undefined : admissibleRef(complete, owner)
      if (ref !== undefined && read.log.has(ref.eventId as Hash)) return { present: true, ref }
      return { present: false, store: state }
    },

    listResumable(): ResumableList {
      const read = store.read()
      const state = storeStateOf(read)
      if (state === "unavailable") return { records: [], store: state }
      // A partial store still lists what verified (each line carries its own content hash) and says it is partial.
      const records = [...read.log.entries()].flatMap(([eventId, ev]): ResumableRecord[] => {
        const record = ev.payload as MemoryRecord
        if (!owners.has(record.owner) || record.kind !== "task") return []
        const entry = record.entry as TaskMemoryEntry
        return [
          {
            ref: { contentHash: ev.contentHash, eventId },
            taskId: entry.taskId,
            stoppedAt: entry.stoppedAt,
            lesson: entry.lesson,
          },
        ]
      })
      return { records, store: state }
    },
  }
}

/** The part of `AtlasBinding` a header read needs (clauses 1, 2, 30). A header read writes nothing and mints no
 *  receipt, so it takes no execution provenance, and a host never has to fabricate one to read it. */
export type HeaderBinding = Pick<AtlasBinding, "storage" | "memoryOwner" | "legacyOwners">

/** Clauses 6-9 as one host read: the bound running header for `memoryOwner` (and its `legacyOwners`), with the
 *  shared Awareness and Orientation slabs assembled from the SAME storage root's own stores — the slabs
 *  `compose.ts` builds for the CLI/MCP header, without its `ATLAS_ACTOR ?? git user.email` owner (clause 4).
 *  Reads only; an Awareness or Orientation source that cannot be assembled throws, and the host renders that
 *  as a degraded header (clause 10). */
export function readBoundHeader(input: HeaderBinding): BoundHeader {
  const binding = freezeBinding(input)
  const root = binding.storage.root
  return boundHeader(
    binding,
    createDurableMemory(root),
    createAwarenessStore(root).read(),
    createDurableOrientation(root).orientation(),
  )
}

/**
 * R1 (D18) — a seat's `project` rule becomes a PROPOSAL in the shared review log (`.atlas/project/review.jsonl`, D14), never
 * a rule: a person indexes it (the host then `write`s it as the member) or discards it. It is judged as `write`
 * judges it up to the cap: the `project` template with Atlas's own frecency, the binding owner, and the NAMED
 * scanner — the review log travels in git, so an unscanned rule must never reach it. The MEM-3 cap is judged at
 * indexing. An identical OPEN proposal by the same owner reconciles to its id. `at` is the host's clock (ISO-8601).
 */
export function proposeProjectRule(input: AtlasBinding, entry: unknown, at: string): ProposalVerdict {
  const binding = freezeBinding(input)
  if (typeof at !== "string" || at === "") throw new Error("native-memory: proposeProjectRule needs the host's ISO time `at`")
  const owner = binding.memoryOwner
  const root = binding.storage.root
  const candidate = projectCandidate(entry)
  if (typeof candidate === "string") return { ok: false, refusal: "template-invalid", reason: candidate }
  const complete: ProjectMemoryEntry = { ...candidate, frecency: INITIAL_PROJECT_FRECENCY }
  const template = validate("project", complete)
  if (!template.valid) return { ok: false, refusal: "template-invalid", reason: `MEM-5 template: ${template.reasons.join("; ")}` }
  const read = readReview(root)
  const log = reviewLogPath(root)
  if (read.unreadable === true) return { ok: false, refusal: "store-unavailable", reason: `the review log at '${log}' could not be read` }
  if (read.rejected > 0) {
    const reason = `the review log at '${log}' has ${read.rejected} line(s) that do not verify, so an identical open proposal cannot be ruled out`
    return { ok: false, refusal: "store-partial", reason }
  }
  const open = foldReview(read.records).openMemoryProposals.find(
    (p) => p.member === owner && p.rule === complete.rule && p.scope === complete.scope,
  )
  if (open !== undefined) return { ok: true, proposalId: open.id, reconciled: true }
  const blocked = scanProposal(binding, put("memory", complete, owner))
  if (blocked !== undefined) return blocked
  const body = { kind: "memory-proposal", member: owner, rule: complete.rule, scope: complete.scope } as const
  return { ok: true, proposalId: appendReview(root, { ...body, at, by: owner }).id }
}

/** R1 (D30): what a person's decision on a memory proposal did. A refused `indexed` write is the door's own refusal. */
export type DecisionVerdict =
  | { readonly ok: true; readonly decisionId: string; readonly ref?: RecordRef }
  | MemoryRejected
  | { readonly ok: false; readonly refusal: "proposal-not-open"; readonly reason: string }
export type ProjectRuleDecision = { readonly proposalId: string; readonly verdict: "indexed" | "discarded"; readonly rule?: string; readonly scope?: string; readonly by: string }

/** R1 (D30) — `indexed` writes the rule through the bound `write` AS THE PROPOSAL'S MEMBER (template, MEM-3 cap and
 *  named scanner judged there), then appends the `memory-decision`; a refused write appends nothing and the proposal
 *  stays open. `discarded` only appends. A non-empty `rule`/`scope` replaces the proposal's text. The binding gives the
 *  storage root and the scanner; its `memoryOwner` never writes. */
export function decideProjectRule(input: AtlasBinding, decision: ProjectRuleDecision, at: string): DecisionVerdict {
  const binding = freezeBinding(input)
  const root = binding.storage.root
  const read = readReview(root)
  if (read.unreadable === true || read.rejected > 0) {
    const reason = `the review log at '${reviewLogPath(root)}' cannot be fully read, so the proposal's state is unknown`
    return { ok: false, refusal: read.unreadable === true ? "store-unavailable" : "store-partial", reason }
  }
  const proposal = foldReview(read.records).openMemoryProposals.find((p) => p.id === decision.proposalId)
  if (proposal === undefined) return { ok: false, refusal: "proposal-not-open", reason: `no open memory proposal has id '${decision.proposalId}'` }
  const decided = (verdict: "indexed" | "discarded") =>
    appendReview(root, { kind: "memory-decision", proposalId: proposal.id, verdict, ...(decision.rule ? { rule: decision.rule } : {}),
      ...(decision.scope ? { scope: decision.scope } : {}), at, by: decision.by }).id
  if (decision.verdict === "discarded") return { ok: true, decisionId: decided("discarded") }
  const member = { storage: binding.storage, source: binding.source, memoryOwner: proposal.member, execution: binding.execution }
  const entry = { rule: decision.rule || proposal.rule, scope: decision.scope || proposal.scope }
  const written = createNativeMemory({ ...member, ...(binding.scanner ? { scanner: binding.scanner } : {}) }).write(entry)
  if (!written.ok) return written
  return { ok: true, decisionId: decided("indexed"), ref: written.ref }
}

/** The proposal's own two fields, or why it is not one. D14's memory-proposal record has no `grounding`. */
function projectCandidate(entry: unknown): { readonly rule: string; readonly scope: string } | string {
  if (typeof entry !== "object" || entry === null) return "a project-rule proposal is an object {rule, scope}"
  const e = entry as Record<string, unknown>
  if ("frecency" in e) return "`frecency` is assigned by Atlas policy (INITIAL_PROJECT_FRECENCY); an entry may not supply it"
  const extra = Object.keys(e).filter((k) => k !== "rule" && k !== "scope")
  if (extra.length > 0) return `a project-rule proposal carries only \`rule\` and \`scope\` (D14); unexpected: ${extra.join(", ")}`
  if (typeof e.rule !== "string" || typeof e.scope !== "string" || e.rule.trim() === "" || e.scope.trim() === "")
    return "a project-rule proposal needs a non-empty string `rule` and `scope`"
  return { rule: e.rule, scope: e.scope }
}

/** MEM-9 on a proposal: the same named scanner `write` resolves. Absent or failing is refused, never passed. */
function scanProposal(binding: AtlasBinding, record: MemoryRecord): MemoryRejected | undefined {
  const scanner = scannerFor(binding).scanner
  const why = "MEM-9 pre-write scan:"
  if (scanner === undefined)
    return { ok: false, refusal: "scanner-unavailable", reason: `${why} no NAMED scanner is configured; nothing was appended`, scanner: "" }
  try {
    if (!scanner.scan(record)) return undefined
    return { ok: false, refusal: "scanner-blocked", reason: `${why} '${scanner.name}' found a secret in this rule`, scanner: scanner.name }
  } catch (e) {
    const reason = `${why} scanner '${scanner.name}' could not complete (${e instanceof Error ? e.message : String(e)}) — refused, never passed`
    return { ok: false, refusal: "scanner-unavailable", reason, scanner: scanner.name }
  }
}

/** Clause 7. A legacy owner's `project` rules rank as the binding owner's own: the read door ranks a snapshot in
 *  which those records carry `memoryOwner`, so a rule kept under the member's former id stays in its header and
 *  the same rule text under both ids folds to one. The log itself is never rewritten. */
function boundHeader(
  binding: HeaderBinding,
  store: DurableMemory,
  awareness: Awareness,
  orientation: Orientation,
): BoundHeader {
  const owner = binding.memoryOwner
  const legacy = new Set(binding.legacyOwners ?? [])
  const read = store.read()
  const rules = storeStateOf(read)
  const state = { awareness: facetStates(awareness), rules }
  if (rules === "unavailable") return { state, bound: { rulesWords: 0, method: "whitespace-words" } }
  const own = { ...read, store: read.store.map((r) => (legacy.has(r.owner) ? { ...r, owner } : r)) }
  const header = createMemoryRead({ store: frozen(own, store.path), actor: owner }).header(awareness, orientation)
  return {
    header,
    state,
    bound: { rulesWords: header.rules.reduce((n, r) => n + tok(r), 0), method: "whitespace-words" },
  }
}

/** Clause 7 — the one derivation of `StoreState` from a read. */
export function storeStateOf(read: MemoryRead): StoreState {
  if (read.unreadable === true) return "unavailable"
  return read.rejected > 0 ? "partial" : "complete"
}

const refuse = (refusal: FoldRefusal, reason: string): FoldVerdict => ({ ok: false, refusal, reason })

/** Clause 22: the entry the emit door judges. A `project` proposal gains `INITIAL_PROJECT_FRECENCY`; an entry
 *  carrying its own `frecency` is `undefined`, because a seat never sets a rule's rank. */
function withAtlasFrecency(entry: BoundEntry): MemoryEntry | undefined {
  // A runtime non-object reaches the emit door as is, which refuses it `undetermined-kind`.
  if (typeof entry !== "object" || entry === null) return entry
  if ("frecency" in entry) return undefined
  if ("rule" in entry) return { ...entry, frecency: INITIAL_PROJECT_FRECENCY }
  return entry
}

/** The exact event `DurableMemory.append` writes for `record` — the same `versioned` seam, so the ref a
 *  write returns is the key the next read finds it under. */
function refOfRecord(record: MemoryRecord): RecordRef {
  const [ev] = [...versioned([record]).values()]
  return { contentHash: ev!.contentHash, eventId: ev!.id }
}

/** The ref an admitted write of `entry` by `owner` would carry, or `undefined` when `put` would refuse it —
 *  an entry the door can never admit can never be present. */
function admissibleRef(entry: MemoryEntry, owner: MemberId): RecordRef | undefined {
  try {
    return refOfRecord(put("memory", entry, owner))
  } catch {
    return undefined
  }
}

/** One read, served to the read door as a fixed store, so a header or recall answers from the SAME snapshot
 *  its store state was derived from — a second read could see a different file. */
function frozen(read: MemoryRead, path: string): DurableMemory {
  return {
    path,
    read: () => read,
    append: () => {
      throw new Error("native-memory: a read snapshot is not writable")
    },
  }
}

function facetStates(a: Awareness): SlabStates["awareness"] {
  return {
    mission: a.mission.state,
    constitution: a.constitution.state,
    terrain: a.terrain.state,
    ontology: a.ontology.state,
    taste: a.taste.state,
  }
}

/** Clause 12, at runtime: only `{kind:'task',taskId}` / `{kind:'pr',prId}` with a non-empty id. Every other
 *  key — `owner` above all — is dropped by reconstruction, not by a deny-list that could miss one. */
function narrowRecall(query: unknown): BoundRecallQuery {
  const q = (typeof query === "object" && query !== null ? query : {}) as Record<string, unknown>
  if (q.kind === "task" && typeof q.taskId === "string" && q.taskId !== "") return { kind: "task", taskId: q.taskId }
  if (q.kind === "pr" && typeof q.prId === "string" && q.prId !== "") return { kind: "pr", prId: q.prId }
  throw new Error("native-memory: recall accepts only {kind:'task',taskId} or {kind:'pr',prId}")
}

/** Clause 31. The explicit binding path first, then PATH (`gitleaks`, then `trufflehog`), with the SAME
 *  calibrated argv. No binary ⇒ no scanner ⇒ the emit door refuses `scanner-unavailable`. The returned
 *  scanner keeps the THIRD verdict: `could-not-run` throws, which the door reports as `scanner-unavailable`
 *  (clause 23a) — `makeScannerAdapter` collapses it into a block, which would read as "a secret was found". */
function scannerFor(binding: AtlasBinding): { readonly scanner?: NamedScanner } {
  const explicit = binding.scanner
  const pinned =
    explicit === undefined
      ? []
      : KNOWN_SCANNERS.filter((s) => s.name === explicit.name).map((s) => ({ ...s, command: explicit.command }))
  const spec = detectAvailableScanner([...pinned, ...KNOWN_SCANNERS])
  if (spec === null) return {}
  return {
    scanner: {
      name: spec.name,
      scan(record: MemoryRecord): boolean {
        const verdict = runScanner(spec, record)
        if (verdict === "could-not-run")
          throw new Error(`'${spec.command}' did not return a documented clean or hit exit`)
        return verdict === "hit"
      },
    },
  }
}

/** Clause 1: a deep, frozen COPY, so neither the caller's object nor a later mutation of it can move the
 *  owner or the root after composition. Validated, because an empty owner or root is a host bug that would
 *  otherwise surface as an `unowned` refusal or a write into `cwd`. */
function freezeBinding<T extends HeaderBinding>(input: T): T {
  if (typeof input.memoryOwner !== "string" || input.memoryOwner === "") {
    throw new Error("native-memory: AtlasBinding.memoryOwner must be a non-empty roster member id")
  }
  if (
    input.legacyOwners !== undefined &&
    (!Array.isArray(input.legacyOwners) ||
      input.legacyOwners.some((o) => typeof o !== "string" || o === "" || o === input.memoryOwner))
  ) {
    throw new Error("native-memory: AtlasBinding.legacyOwners must be non-empty ids other than memoryOwner")
  }
  if (typeof input.storage?.root !== "string" || !isAbsolute(input.storage.root)) {
    throw new Error("native-memory: AtlasBinding.storage.root must be an absolute path")
  }
  return deepFreeze(structuredClone(input))
}

function deepFreeze<T>(value: T): T {
  if (typeof value === "object" && value !== null) {
    for (const v of Object.values(value)) deepFreeze(v)
    Object.freeze(value)
  }
  return value
}
