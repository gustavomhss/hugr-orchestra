export const dict = {
  "desktop.menu.checkForUpdates": "Check for Updates...",
  "desktop.menu.installCli": "Install CLI...",
  "desktop.menu.reloadWebview": "Reload Webview",
  "desktop.menu.restart": "Restart",

  "desktop.dialog.chooseFolder": "Choose a folder",
  "desktop.dialog.chooseFile": "Choose a file",
  "desktop.dialog.saveFile": "Save file",

  "desktop.updater.checkFailed.title": "Update Check Failed",
  "desktop.updater.checkFailed.message": "Failed to check for updates",
  "desktop.updater.none.title": "No Update Available",
  "desktop.updater.none.message": "You are already using the latest version of HuGR Orchestra",
  "desktop.updater.downloadFailed.title": "Update Failed",
  "desktop.updater.downloadFailed.message": "Failed to download update",
  "desktop.updater.downloaded.title": "Update Downloaded",
  "desktop.updater.downloaded.prompt":
    "Version {{version}} of HuGR Orchestra has been downloaded, would you like to install it and relaunch?",
  "desktop.updater.installFailed.title": "Update Failed",
  "desktop.updater.installFailed.message": "Failed to install update",

  "desktop.cli.installed.title": "CLI Installed",
  "desktop.cli.installed.message": "CLI installed to {{path}}\n\nRestart your terminal to use the 'orchestra' command.",
  "desktop.cli.failed.title": "Installation Failed",
  "desktop.cli.failed.message": "Failed to install CLI: {{error}}",

  "desktop.error.dev.rootNotFound":
    "Root element not found. Did you forget to add it to your index.html? Or maybe the id attribute got misspelled?",
}
