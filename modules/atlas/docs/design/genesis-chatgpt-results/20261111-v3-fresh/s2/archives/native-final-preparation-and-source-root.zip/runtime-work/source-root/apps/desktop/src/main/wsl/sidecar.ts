import { spawn } from "node:child_process"
import { createServer } from "node:net"
import { DesktopOmni } from "../omni-process"
import { type WslCommandLine, resolveWslOrchestra, runWslInDistro, shellEscape, wslArgs } from "./runtime"
import { checkWslAuthentication, pollWslHealth } from "./startup"
import { guestEnvironment, verifyWslGuestArtifact } from "./artifact"
import { nativeT } from "../native-translations"

export type WslSidecar = {
  listener: { stop: () => void; onExit: (cb: (code: number | null, signal: NodeJS.Signals | null) => void) => void }
  url: string
  username: string | null
  password: string
}

export async function spawnWslSidecar(
  distro: string,
  opts: {
    onLine?: (line: WslCommandLine) => void; healthTimeoutMs?: number; signal?: AbortSignal
    resolveOrchestra?: typeof resolveWslOrchestra
    artifact?: Parameters<typeof verifyWslGuestArtifact>[2]
  } = {},
): Promise<WslSidecar> {
  opts.signal?.throwIfAborted()
  const orchestra = await (opts.resolveOrchestra ?? resolveWslOrchestra)(distro, { signal: opts.signal })
  if (!orchestra) throw new Error(nativeT("desktop.wsl.error.serverNotInstalled", { distro }))
  await verifyWslGuestArtifact(distro, orchestra, { ...opts.artifact, signal: opts.signal })
  opts.signal?.throwIfAborted()

  const port = await allocatePort()
  const credential = await runWslInDistro(
    ["bash", "-c", `${guestEnvironment}\nexec ${shellEscape(orchestra)} service password`],
    distro,
    { signal: opts.signal },
  )
  const password = credential.stdout.trim()
  if (credential.code !== 0 || !password || /[\r\n]/.test(password)) {
    throw new Error(nativeT("desktop.wsl.error.serverCannotRun"))
  }
  const username = "orchestra"
  // Behind ORCHESTRA_EXPERIMENTAL_OMNI_SPAWNER the WSL server runs through omni, so it ends with this app.
  const child: DesktopOmni.Spawned = DesktopOmni.enabled()
    ? DesktopOmni.spawn("wsl", wslArgs(["bash", "-se"], distro), { signal: opts.signal })
    : spawn("wsl", wslArgs(["bash", "-se"], distro), {
        stdio: ["pipe", "pipe", "pipe"],
        windowsHide: true,
        signal: opts.signal,
      })
  child.stdin.end(wslServeScript(orchestra, port))

  const recentOutput: string[] = []
  const emit = (line: WslCommandLine) => {
    const safe = { ...line, text: line.text.replaceAll(password, "[redacted]") }
    if (!safe.text.trim()) return
    recentOutput.push(`[${safe.stream}] ${safe.text}`)
    if (recentOutput.length > 12) recentOutput.shift()
    opts.onLine?.(safe)
  }
  forwardLines(child.stdout, "stdout", emit)
  forwardLines(child.stderr, "stderr", emit)

  const exit = new Promise<never>((_, reject) => {
    child.once("error", reject)
    child.once("exit", (code, signal) => reject(new Error(startupFailure(code, signal, recentOutput))))
  })
  const url = `http://127.0.0.1:${port}`
  const startup = new AbortController()
  const healthSignal = opts.signal ? AbortSignal.any([opts.signal, startup.signal]) : startup.signal
  const health = pollWslHealth(
    () => checkWslAuthentication(url, password, healthSignal).catch(() => false), healthSignal,
  ).then(() => healthSignal.throwIfAborted())
  const timeoutMs = opts.healthTimeoutMs ?? 20_000
  let timeout: ReturnType<typeof setTimeout>
  const timedOut = new Promise<never>(
    (_, reject) =>
      (timeout = setTimeout(
        () => reject(new Error(nativeT("desktop.wsl.error.healthTimeout", { distro, timeout: timeoutMs }))),
        timeoutMs,
      )),
  )

  await Promise.race([health, exit, timedOut])
    .catch((error) => {
      child.kill()
      throw error
    })
    .finally(() => {
      clearTimeout(timeout)
      startup.abort()
    })
  return {
    listener: {
      stop: () => child.kill(),
      onExit: (cb) => child.once("exit", cb),
    },
    url,
    username,
    password,
  }
}

export function wslServeScript(orchestra: string, port: number) {
  return [
    guestEnvironment,
    'cd "$HOME" || cd /',
    "export ORCHESTRA_EXPERIMENTAL_DISABLE_FILEWATCHER=true",
    "export ORCHESTRA_CLIENT=desktop",
    `exec ${shellEscape(orchestra)} serve --hostname ${shellEscape("0.0.0.0")} --port ${shellEscape(String(port))}`,
  ].join("\n")
}

function allocatePort() {
  return new Promise<number>((resolve, reject) => {
    const server = createServer()
    server.on("error", reject)
    server.listen(0, "127.0.0.1", () => {
      const address = server.address()
      if (typeof address !== "object" || !address) {
        server.close()
        reject(new Error(nativeT("desktop.wsl.error.failedPort")))
        return
      }
      server.close(() => resolve(address.port))
    })
  })
}

function forwardLines(
  stream: NodeJS.ReadableStream,
  source: WslCommandLine["stream"],
  onLine: (line: WslCommandLine) => void,
) {
  let pending = ""
  stream.setEncoding("utf8")
  stream.on("data", (chunk: string) => {
    pending += chunk
    const lines = pending.split(/\r?\n/g)
    pending = lines.pop() ?? ""
    lines.forEach((text) => onLine({ stream: source, text }))
  })
  stream.on("end", () => {
    if (pending) onLine({ stream: source, text: pending })
  })
}

function startupFailure(code: number | null, signal: NodeJS.Signals | null, recentOutput: string[]) {
  const suffix = recentOutput.length ? `\n${recentOutput.join("\n")}` : ""
  return nativeT("desktop.wsl.error.serverExitedBeforeHealthy", {
    code: code ?? "null",
    signal: signal ?? "null",
    output: suffix,
  })
}
