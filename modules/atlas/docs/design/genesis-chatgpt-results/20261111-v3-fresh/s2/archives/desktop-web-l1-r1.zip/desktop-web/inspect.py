import sys,json,pathlib,re
base=pathlib.Path(__file__).parent
logpath=base/'inspection.json'
log=json.loads(logpath.read_text()) if logpath.exists() else {}
for arg in sys.argv[1:]:
    parts=arg.split('::');path=parts[0];lines=(base/'sources'/path).read_text().splitlines()
    wanted=set()
    if len(parts)==1: wanted.update(range(1,len(lines)+1))
    elif parts[1].startswith('~'):
        pattern=parts[1][1:]
        for i,l in enumerate(lines,1):
            if re.search(pattern,l):wanted.update(range(max(1,i-2),min(len(lines),i+5)+1))
    else:
        for span in parts[1].split(','):
            a,_,z=span.partition('-');a=int(a);z=int(z) if z else a
            wanted.update(range(a,min(z,len(lines))+1))
    print('\nSOURCE',path,'TOTAL',len(lines),'LINES')
    last=0
    for i in sorted(wanted):
        if i!=last+1:print('...')
        print(f'{i:4}: {lines[i-1]}');last=i
    spans=[]
    for i in sorted(set(log.get(path,[]))|wanted):spans.append(i)
    log[path]=spans
logpath.write_text(json.dumps(log,indent=2)+'\n')
