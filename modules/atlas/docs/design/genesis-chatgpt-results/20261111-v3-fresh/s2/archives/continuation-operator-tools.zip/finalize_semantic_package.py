"""Finalize only mechanically proven semantic metadata; never runtime acceptance."""
import hashlib
import json
from collections import deque
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
out = root / "deliverable"
package_path = out / "native-package.json"
raw_before = package_path.read_bytes()
package = json.loads(raw_before)
assert package["package_state"] == "SEMANTIC_ACCEPTED_RUNTIME_PENDING"
artifacts = {a["key"]: a for a in package["artifacts"]}
assert len(artifacts) == 13 == len(package["artifacts"])
assert set(artifacts) == set(package["required_artifact_keys"])
assert package["missing_required_artifact_keys"] == []
prefix = "modules/atlas/docs/design/genesis-chatgpt-results/20261111-v3-fresh/s2/"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check_ref(ref):
    assert ref["payload_path"].startswith(prefix), ref
    rel = ref["payload_path"][len(prefix):]
    path = out / rel
    assert path.resolve().is_relative_to(out.resolve())
    assert sha(path.read_bytes()) == ref["sha256"], rel
    return rel

accepted = {}
manifest_pins = []
for layer in range(1, 5):
    path = out / "accepted" / f"l{layer}.json"
    raw = path.read_bytes()
    doc = json.loads(raw)
    assert doc["status"] == "SEMANTIC_LAYER_ACCEPTED"
    assert doc["source_revision"] == package["source_revision"]
    assert doc["protocol_revision"] == package["protocol_ref"]["commit"]
    for item in doc["artifacts"]:
        assert item["key"] not in accepted
        accepted[item["key"]] = item
    manifest_pins.append({"path": str(path.relative_to(out)), "sha256": sha(raw)})
assert set(accepted) == set(artifacts)
body_records = []
for key, artifact in artifacts.items():
    assert artifact["validity"] == "supported"
    body = (out / artifact["body"]["path"]).read_bytes()
    assert len(body) == artifact["body"]["byte_length"] == accepted[key]["byte_length"]
    assert sha(body) == artifact["body"]["sha256"] == accepted[key]["body_sha256"]
    assert len(artifact["semantic_review_refs"]) == 2
    assert {x["judge"] for x in accepted[key]["reviews"]} == {"/root/s2_resume_j1", "/root/s2_resume_j2"}
    for ref in artifact["semantic_review_refs"]:
        check_ref(ref)
    for field in ["recipe_ref", "producer_request_ref", "producer_response_ref"]:
        check_ref(artifact[field])
    for dep in artifact["build_dependencies"]:
        assert dep["same_package"] is True
        assert dep["key"] in artifacts
        assert artifacts[dep["key"]]["layer"] < artifact["layer"]
    assert set(artifact["navigation"]) <= set(artifacts)
    sections = []
    heading = None
    section = ""
    for line in body.decode().splitlines(keepends=True):
        if line.startswith("## "):
            if heading is not None:
                sections.append({"heading": heading, "byte_length": len(section.encode())})
            heading = line[3:].strip()
            section = ""
        section += line
    if heading is not None:
        sections.append({"heading": heading, "byte_length": len(section.encode())})
    assert sections and len({s["heading"] for s in sections}) == len(sections)
    assert all(s["byte_length"] <= 16000 for s in sections), (key, sections)
    body_records.append({"key": key, "sha256": sha(body), "byte_length": len(body), "sections": sections})

assert artifacts["s2.l4.entry"]["need"] == "entry"
assert set(artifacts["s2.l4.entry"]["navigation"]) == set(artifacts) - {"s2.l4.entry"}
assert package["roots"] in [{}, {"entry": "s2.l4.entry"}]
roots = {"entry": "s2.l4.entry"}
seen = set()
queue = deque(roots.values())
while queue:
    key = queue.popleft()
    if key in seen:
        continue
    seen.add(key)
    queue.extend(artifacts[key]["navigation"])
    queue.extend(d["key"] for d in artifacts[key]["build_dependencies"])
assert seen == set(artifacts)

changed_input = "file:apps/desktop/src/main/owned-serve.ts"
direct = {key for key, artifact in artifacts.items() if changed_input in artifact["input_keys"]}
assert "s2.l1.desktop-web" in direct
affected = set(direct)
while True:
    new = {key for key, artifact in artifacts.items() if any(d["key"] in affected for d in artifact["build_dependencies"])} - affected
    if not new:
        break
    affected |= new
update = {"schema": "genesis-s2-update-expectation/v1", "case": "S2-U1", "frozen_before_execution": True, "recorded_at": datetime.now(timezone.utc).isoformat(), "changed_input": changed_input, "direct_input_artifacts": sorted(direct), "build_affected_closure": sorted(affected), "outside_build_closure": sorted(set(artifacts) - affected), "build_edges": [{"consumer": key, "dependency": d["key"]} for key, artifact in artifacts.items() for d in artifact["build_dependencies"]], "navigation_edges": [{"from": key, "to": target} for key, artifact in artifacts.items() for target in artifact["navigation"]], "status": "EXPECTED_ONLY_NOT_EXECUTED", "limits": ["This graph calculation is a frozen expectation, not runtime update, reuse, invalidation or reader proof.", "Navigation alone does not add an artifact to the expected build closure."]}
update_path = out / "oracles" / "update-final-graph-expectation.json"
assert not update_path.exists()
history = out / "history" / "native-package-before-final-roots.json"
assert not history.exists()
history.write_bytes(raw_before)
package["roots"] = roots
package_path.write_text(json.dumps(package, ensure_ascii=False, indent=2) + "\n")
update["native_package_sha256"] = sha(package_path.read_bytes())
update_path.write_text(json.dumps(update, indent=2) + "\n")
receipt = {"schema": "genesis-s2-final-semantic-reconciliation/v1", "recorded_at": datetime.now(timezone.utc).isoformat(), "source_revision": package["source_revision"], "protocol_revision": package["protocol_ref"]["commit"], "native_package_before_sha256": sha(raw_before), "native_package_sha256": sha(package_path.read_bytes()), "accepted_layer_manifests": manifest_pins, "artifact_count": len(artifacts), "roots": roots, "reachable_artifacts": sorted(seen), "bodies": body_records, "update_expectation_sha256": sha(update_path.read_bytes()), "scope": "Mechanical reconciliation of actual semantic decisions, exact bytes, references and graph only; no runtime, consumer, CI or publication PASS."}
receipt_path = out / "evidence" / "final-semantic-reconciliation.json"
assert not receipt_path.exists()
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"artifacts": len(artifacts), "total_body_bytes": sum(r["byte_length"] for r in body_records), "native_package_sha256": receipt["native_package_sha256"], "receipt_sha256": sha(receipt_path.read_bytes()), "update_affected": sorted(affected), "runtime_status": "NOT_ACCEPTED"}, indent=2))
