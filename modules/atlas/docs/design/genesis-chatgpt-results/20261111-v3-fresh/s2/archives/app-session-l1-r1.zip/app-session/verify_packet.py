from pathlib import Path
import json, hashlib, re, collections, base64

B=Path('/workspace/scratch/992c54067adf/genesis-s2/producers/app-session')
I=Path('/workspace/scratch/992c54067adf/genesis-s2/deliverable/inputs/app-session-tree.json')
PIN='1cde2ff7a71bcf7aecb5d030917b577165135d38'
A='packages/app-shell/'; S='packages/session-ui/'
checks=[]
def record(name,detail):checks.append({'check':name,'result':'PASS','detail':detail})
tree=json.loads(I.read_text()); by_path={x['path']:x for x in tree}
coverage=json.loads((B/'coverage.json').read_text())
entries=coverage['entries']; families={x['id']:x for x in coverage['families']}
assert len(entries)==len(tree)==1887
assert len({x['path'] for x in entries})==1887
assert {x['path'] for x in entries}==set(by_path)
assert all(all(e[k]==v for k,v in by_path[e['path']].items()) for e in entries)
assert coverage['input_sha256']==hashlib.sha256(I.read_bytes()).hexdigest()
assert coverage['source_commit']==PIN
record('exact population and original metadata','1887 exact paths, each once; all frozen metadata preserved; input SHA-256 matches')
assert all(e['family'] in families for e in entries)
assert all(e['evidence_depth'] in ['inspected','family-supported','metadata-only'] for e in entries)
for key,f in families.items():
    own=[e for e in entries if e['family']==key]
    assert f['path_count']==len(own)
    assert f['evidence_depth_counts']==dict(collections.Counter(e['evidence_depth'] for e in own))
    assert all(f.get(field) for field in ['source_implications','consumer_implications','maintenance_implications','limits'])
assert len(families)==59
assert not any(e['classification']=='implementation' and e['evidence_depth']=='metadata-only' for e in entries)
record('family semantics and depth totals',coverage['summary'])
v1=json.loads((B/'coverage-v1.json').read_text()); old={e['path']:e for e in v1['entries']}
gaps=json.loads((B/'required-gap-paths.json').read_text())
if isinstance(gaps,dict):gaps=gaps['paths']
assert len(gaps)==39
new={e['path']:e for e in entries}
assert all(old[p]['evidence_depth']=='metadata-only' and new[p]['evidence_depth']=='inspected' for p in gaps)
assert all(e['family'] not in ['utility','auxiliary-gap'] for e in entries)
record('required correction','v1 retained; 39 original metadata-only implementations now inspected; residual catchall families removed')
sources=json.loads((B/'sources.json').read_text()); records=sources['records']; source={r['path']:r for r in records}
assert len(source)==len(records)==251
responses={}
for r in records:
    assert r['commit']==PIN and r['status']=='captured'
    raw=(B/r['local_capture_file']).read_bytes()
    assert len(raw)==r['byte_length']
    assert hashlib.sha256(raw).hexdigest()==r['sha256']
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==r['git_blob_sha']==r['computed_git_blob_sha']
    if r['path'] in by_path:assert by_path[r['path']]['sha']==r['git_blob_sha']
    response_file=r['connector_response_file']
    if response_file not in responses:responses[response_file]=json.loads((B/response_file).read_text())
    original=next(x for x in responses[response_file] if x['path']==r['path'])['value']['structuredContent']
    exact=base64.b64decode(original['content']) if original.get('encoding')=='base64' else original['content'].encode('utf-8')
    assert raw==exact
assert all(p in source for f in families.values() for p in f['representative_source_paths'])
assert all(p in source for e in entries for p in e['representative_source_paths'])
record('source hashes and original connector bytes','251/251 exact bytes, SHA-256 and Git blob identities verified; every representative resolves')
failures=sources['failed_attempts'];assert len(failures)==10
assert all(f['path'] not in source for f in failures)
assert sum(f['path'].startswith('packages/app-shell/') for f in failures)==6
for f in failures:
    pointer=f['original_connector_response_pointer'];original=json.loads((B/pointer['file']).read_text())[pointer['array_index']]
    assert original['path']==f['path'] and original['value']==f['original_error_response']
    if f['path'].startswith('packages/app-shell/'):assert f['path'] not in by_path
record('failed attempt preservation','10 exact original error responses retained; 6 absent app-shell guesses confirmed by frozen tree; 4 outside-tree lookups explicitly limited')
evidence=(B/'decisive-evidence.md').read_text(); index=json.loads((B/'evidence-index.json').read_text())
assert index['excerpt_count']==len(index['excerpts'])==39
total=0
for e in index['excerpts']:
    lines=(B/source[e['path']]['local_capture_file']).read_text().splitlines()
    for r in e['ranges']:
        lo=r['start_line'];hi=r['end_line'];assert 1<=lo<=hi<=len(lines)
        exact='\n'.join(lines[lo-1:hi])+'\n'
        assert hashlib.sha256(exact.encode()).hexdigest()==r['excerpt_sha256']
        formatted='\n'.join(f'{n:4} | {lines[n-1]}' for n in range(lo,hi+1))
        assert formatted in evidence
        total+=hi-lo+1
assert total==index['source_line_count']==1159
record('verbatim evidence','39 bounded selections, 1159 source lines; source text, line numbers and excerpt hashes verified')
l1=(B/'l1.md').read_text(); citation_count=0
pattern=r'`((?:A|S)/[^`]+|(?:packages|script|docs|\.orchestra)/[^`]+|AGENTS\.md:[^`]+)`'
for match in re.finditer(pattern,l1):
    value=match.group(1);p,sep,loc=value.partition(':')
    p=A+p[2:] if p.startswith('A/') else S+p[2:] if p.startswith('S/') else p
    if p.endswith('/') or p=='packages/app':continue
    assert p in source,('citation source absent',value)
    if sep:
        count=len((B/source[p]['local_capture_file']).read_text().splitlines())
        for interval in loc.split(','):
            bounds=[int(x) for x in re.split('[–-]',interval)]
            assert 1<=min(bounds)<=max(bounds)<=count,(value,count)
        citation_count+=1
record('narrative source references',f'{citation_count} exact path/range citations resolve within captured bodies; A/S expansions explicit')
required=['l1.md','coverage.json','sources.json','decisive-evidence.md','response.md']
for name in required:
    raw=(B/name).read_bytes();assert raw and raw.decode('utf-8')
record('required UTF-8 artifacts','All five required files exist and decode as UTF-8')
result={'schema':'genesis-l1-artifact-verification/v1','unit':'app-session','source_commit':PIN,'result':'PASS','scope':'Artifact and source integrity only; no product test, build, benchmark or runtime execution.','checks':checks,'counts':{'paths':1887,'families':59,'sources':251,'failed_attempts':10,'excerpts':39,'source_lines_excerpted':1159,'l1_whitespace_words':len(l1.split())}}
(B/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':result['result'],'counts':result['counts'],'checks':len(checks)},indent=2))
