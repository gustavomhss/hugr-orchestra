import pathlib,sys,json
R=pathlib.Path('/workspace/scratch/992c54067adf/genesis-s2/producers/app-session')
log=R/'read-witnesses.json'
w=json.loads(log.read_text()) if log.exists() else {}
for arg in sys.argv[1:]:
    path,_,spec=arg.partition('::')
    lines=(R/'sources'/path).read_text().splitlines()
    intervals=[]
    if not spec:
        intervals=[(1,len(lines))]
    elif spec=='outline':
        intervals=[(1,min(28,len(lines)))]
        indices=[i for i,l in enumerate(lines,1) if l.startswith(('export ','function ','async function '))]
        intervals += [(i,min(i+9,len(lines))) for i in indices[:12]]
        intervals += [(max(1,len(lines)-15),len(lines))]
    else:
        for val in spec.split(','):
            a,_,b=val.partition('-'); intervals.append((int(a),min(int(b or a),len(lines))))
    merged=[]
    for a,b in sorted(intervals):
        if merged and a <= merged[-1][1]+1:merged[-1][1]=max(b,merged[-1][1])
        else:merged.append([a,b])
    print('\nFILE '+path+' ['+str(len(lines))+' lines]')
    for a,b in merged:
        for n in range(a,b+1):print(f'{n:4} {lines[n-1]}')
    w.setdefault(path,[]).extend(merged)
log.write_text(json.dumps(w,indent=2)+'\n')
