Concluído. Utilitário e documentação disponíveis em:

- [stage_final_native.py](sandbox:/workspace/scratch/7b5d6430f420/genesis-s2/assembly-tools/stage_final_native.py)
- [final_staging.md](sandbox:/workspace/scratch/7b5d6430f420/genesis-s2/assembly-tools/final_staging.md)
- [final-staging-report.md](sandbox:/workspace/scratch/7b5d6430f420/genesis-s2/assembly-tools/final-staging-report.md)
- [final-staging-receipt.json](sandbox:/workspace/scratch/7b5d6430f420/genesis-s2/assembly-tools/final-staging-receipt.json)

**Inventário real somente leitura: exit 0, 1315 arquivos resolvidos, 641 originais preservados, zero referências ausentes/divergentes e nenhuma captura pública adicional necessária para o pacote atual.** O snapshot auditado contém os seis artefatos L1/L2 aceitos; a utility deve ser rodada novamente após L4/entry.

Raiz final correta: `{"entry":"s2.l4.entry"}`. A utility exige o entry real e verifica alcance dos 13 artefatos; não altera roots nem decisões.

O [pedido prepare](sandbox:/workspace/scratch/7b5d6430f420/genesis-s2/assembly-tools/final-staging-inspection-02/inventory/prepare-request.json) registra o argv/cwd e caminhos exatos; o [template de recibo](sandbox:/workspace/scratch/7b5d6430f420/genesis-s2/assembly-tools/final-staging-inspection-02/prepare-execution-receipt-template.json) mantém a execução NOT_RUN. Ambos devem ser vinculados ao plano do pacote final.

Permanece o limite r1 de 256000 bytes para schema/tui.json e os dois tree snapshots grandes. Os arquivos permanecem íntegros. O CLI pode deixar CAS mesmo quando a escrita tardia de prepared.json falha; documentação exige preservar logs/estado e não repetir automaticamente.

**Não executei staging, prepare, testes, escrita remota ou alteração de conteúdo semântico.** `--apply` está implementado e ainda não foi exercido, conforme instrução. Libero o slot.
