import json, pathlib, hashlib, base64
base = pathlib.Path(__file__).parent
tree = {x['path']:x for x in json.loads(pathlib.Path('/workspace/scratch/992c54067adf/genesis-s2/deliverable/inputs/desktop-web-tree.json').read_text())}
records=[]
errors=[]
for capture in sorted((base/'captures').glob('*.json')):
    r=json.loads(capture.read_text())
    d=r.get('structuredContent',{})
    path=capture.name[:-5].replace('__','/')
    if r.get('isError') or 'content' not in d:
        errors.append({'path':path,'result':r})
        continue
    content=d['content']
    raw=base64.b64decode(content) if d.get('encoding')=='base64' else content.encode('utf-8')
    dst=base/'sources'/path
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(raw)
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    expected=tree.get(path,{}).get('sha',d.get('sha'))
    assert blob == expected, (path,blob,expected)
    assert d.get('sha') == blob, (path,'connector sha',d.get('sha'),blob)
    records.append({'commit':'1cde2ff7a71bcf7aecb5d030917b577165135d38','path':path,'git_blob_sha':blob,'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),'local_capture_file':str(dst.relative_to(base)),'connector_response_file':str(capture.relative_to(base)),'git_blob_sha_verified':True})
(base/'sources.json').write_text(json.dumps({'schema':'genesis-source-captures/v1','source_revision':'1cde2ff7a71bcf7aecb5d030917b577165135d38','sources':records,'errors':errors},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verified_source_count':len(records),'total_bytes':sum(x['byte_length'] for x in records),'capture_errors':len(errors)}))
