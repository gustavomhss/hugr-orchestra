from pathlib import Path
import json,re,collections,hashlib
B=Path('/workspace/scratch/992c54067adf/genesis-s2/producers/app-session')
INPUT=Path('/workspace/scratch/992c54067adf/genesis-s2/deliverable/inputs/app-session-tree.json')
TREE=json.loads(INPUT.read_text())
A='packages/app-shell/'
S='packages/session-ui/'
F={}
def family(key,title,reps,source,consumer,maintenance,limits):
    F[key]={'id':key,'title':title,'representative_source_paths':reps,'source_implications':source,'consumer_implications':consumer,'maintenance_implications':maintenance,'limits':limits}
def a(s):return A+s
def s(x):return S+x
family('authority','Package contracts and maintenance authority',
[a('AGENTS.md'),a('README.md'),a('package.json'),s('README.md'),s('package.json')],'Package manifests declare exported entrypoints and tasks; AGENTS establishes local maintenance rules. README module-contract blocks have a verified generator.','Desktop/web import app-shell; app-shell and Storybook use session-ui. Module architecture permits explicit browserSafe Core helpers.','Reconcile manifest and executable boundary policy before treating prose as import prohibition. Tests are CI-only in this run.','Build/config siblings are accounted structurally; no build, typecheck, or boundary runner was executed.')
family('history','Historical migration and reactive-refactor proposals',
['docs/architecture/phase-plans/70-90-briefs/EXP-SESSIONUI.md','docs/architecture/phase-plans/70-90-briefs/FAC-APP-CTX.md','docs/architecture/phase-plans/70-90-briefs/RN-SESSIONUI.md',a('create-effect-simplification-spec.md')],'Phase cards refer to an older base, worktree and expected mechanical outputs. The createEffect spec addresses the old packages/app path.','Useful provenance for earlier modularization intent, never evidence that current code meets each acceptance statement.','Keep historical commands as document content; do not execute their push or mutation instructions.','Historical completion and all original acceptance outputs are not verified.')
family('skills','Maintainer and onboarding skills',
['.orchestra/skills/agent-avatars-maintenance/SKILL.md','.orchestra/skills/agent-screen-maintenance/SKILL.md','.orchestra/skills/hugr-composer-maintenance/SKILL.md','.orchestra/skills/onboarding-usage/SKILL.md','.orchestra/skills/settings-usage/SKILL.md'],'These prescribe feature ownership and intended user workflows. HuGR Composer is described as an external MCP server for the backend seat.','Maintainers consume these; they are not application runtime skills or evidence of installed external services.','Use stable seat IDs; distinguish bundled portraits, uploaded avatars and the unrelated prompt composer.','External Composer repository/installability and full native-seat tool grants are outside inspected implementation.')
family('guides','User guides',
['docs/guides/home.md','docs/guides/settings.md','docs/guides/shortcuts.md','docs/guides/agent-screen.md','docs/guides/agent-avatars.md','docs/guides/hugr-composer.md'],'Guides state navigation, configuration and operational intent; several statements are cross-checked in current controllers.','Readers see expected Home, settings, agents and shortcut interactions.','Document the Composer guide warning about its unavailable dependency as a guide claim, not a fresh installation result.','No walkthrough, installation, restart or remote mutation was performed.')
family('bootstrap','App composition, route entry and host contracts',
[a('src/app.tsx'),a('src/index.ts'),a('src/context/platform.tsx'),a('src/pages/directory-layout.tsx'),a('src/orchestra/shell/ingress.tsx'),a('src/desktop-menu.ts')],'AppBaseProviders and AppInterface compose shared providers; server-target and draft routes own distinct keyed subtrees. Public host types cover menu, updater, titlebar, live and App Dock Linux bridges.','Web/desktop supply Platform; session-ui receives DataProvider state and callbacks from DirectoryDataProvider. Native ingress chooses the local server.','Keep server/directory ownership explicit; do not collapse a host type contract into evidence that the host implementation is present.','Native main-process implementations, packed releases and platform runtime behavior are not verified.')
family('transport','Server identity, SDK, readiness and event transport',
[a('src/context/server.tsx'),a('src/context/global.tsx'),a('src/context/server-sdk.tsx'),a('src/utils/server.ts'),a('src/utils/server-health.ts'),a('src/utils/server-ready.ts'),a('src/utils/server-stream-liveness.ts'),a('src/utils/scoped-fetch.ts')],'Server keys and credential identity have different lifetimes. Generated client calls and event stream share lifetime abort. Health polling considers raw stream liveness.','Per-server contexts serve shell/directory callers; adapter exposes app view contracts while protocol/schema own wire contracts.','Preserve credential replacement disposal, retryable readiness and cancellation composition. Heartbeat bytes matter even without decoded events.','Network scenarios and retained-stream behavior are source-level observations; not observed live.')
family('sync','Canonical session cache, projection and recovery',
[a('src/context/server-sync.tsx'),a('src/context/server-session.ts'),a('src/context/server-session-v2-reducer.ts'),a('src/context/server-event-native.ts'),a('src/context/session-recovery.ts'),a('src/context/global-sync/event-reducer.ts')],'One server-local cache reconciles page fetches with touched streamed state and generation fences; native events adapt to rendering projections.','Directory stores and timeline consume retained sessions/messages/parts; mounted session ownership pins cache entries.','Protect policy reads from intervening events and distinguish pending admitted input from promoted transcript messages.','No proof of complete replay, cross-process ordering, exhaustive reducer coverage or runtime losslessness.')
family('prompt','Prompt composer, admission and attachment construction',
[a('src/components/prompt-input-v2.tsx'),a('src/components/prompt-input/submit.ts'),a('src/components/prompt-input/submission-policy.ts'),a('src/components/prompt-input/submission-admission.ts'),a('src/components/prompt-input/submission-state.ts'),a('src/components/prompt-input/build-request-parts.ts'),a('src/components/prompt-input/submit-admission.suite.ts')],'App composer owns submission and session selection; policy/owner barriers and admission state survive async creation, receipt waits and remounts.','Session-ui editor emits interaction; app constructs prompt payload and consumes durable admission receipts.','Preserve IDs for ambiguous retries, generation checks across ABA, draft edits and canonical policy confirmation.','Representative admission tests were read only. All attachment/history input variants are not individually traced.')
family('persistence','Prompt drafts, tabs, scopes and storage',
[a('src/context/prompt.tsx'),a('src/context/prompt-state.ts'),a('src/context/tabs.tsx'),a('src/components/prompt-input/draft-session.ts'),a('src/utils/persist.ts'),a('src/utils/draft-store.ts'),a('src/utils/server-scope.ts')],'Scoped keys isolate server/workspace/session or draft identity. Draft persistence can use IndexedDB documents/blobs and migration/version guards.','Prompt, terminal, layout, model preferences and comment state use these facilities; tab-owned memory outlives composer mount.','Treat canonical local migration and remote namespaces separately; preserve edits during async hydration and blob write ordering.','Browser quota, migration on real user stores and crash consistency were not exercised.')
family('requests','Permission, question and composer request ownership',
[a('src/context/permission.tsx'),a('src/context/permission-auto-respond.ts'),a('src/pages/session/composer/session-request-tree.ts'),a('src/pages/session/composer/session-permission-dock.tsx'),a('src/pages/session/composer/session-question-dock.tsx'),a('src/components/settings-v2/view/saved-permissions-section.tsx')],'Request tree walks current session descendants; permission responses are server scoped and de-duplicated. Explicit false lineage overrides defeat directory fallback; Relay hook asks require live replies.','Composer docks display pending requests and callbacks; saved-permission settings mutate server records.','Keep request/session/location identity, pending-state checks, failure retry and always-scope eligibility.','Backend authorization enforcement and all keyboard/accessibility flows are not established by these UI reads.')
family('session-route','Session route ownership and layout lifetime',
[a('src/pages/session.tsx'),a('src/pages/session/session-lineage.ts'),a('src/pages/session/session-ownership.ts'),a('src/context/layout.tsx')],'Session resolution derives directory from lineage; workspace providers stay mounted within a server/directory. Session owner captures permanently expire when identity departs.','Timeline, composer, files and side panels share workspace lifetimes while targeting a session identity.','Use generation rather than value equality alone for async commits; keep error boundaries tied to target identity.','The large session page was inspected at owner/composition seams, not line-by-line across all layout affordances.')
family('timeline','App transcript projection, rows and navigation',
[a('src/pages/session/timeline/rows.ts'),a('src/pages/session.tsx'),a('src/context/server-session-v2-reducer.ts')],'Rows group user turns and assistant parts, preserve assistant content order, and distinguish retry, thinking, error and diff-summary rows.','App projection adapts native session log to session-ui rendering contracts.','Synthetic IDs are not a semantic content order; preserve turn parent joins and loaded-page boundaries.','Scroll anchoring, virtualization geometry and every projection variant were not individually inspected or benchmarked.')
family('files','Files, review and comment integration',
[a('src/context/file.tsx'),a('src/context/comments.tsx'),s('src/components/file.tsx'),s('src/pierre/file-runtime.ts'),s('src/components/session-review.tsx')],'FileProvider uses server/directory-scoped SDK and file-tree/content/view caches; comments retain selected-line state. Session-ui wraps Pierre viewers.','Review and file browser panels consume these contracts and route context into prompts.','Maintain lifetime cleanup, scoped file identity and stable comment collections; native shadow-view readiness has its own token guard.','Full tree, media, selection and diff interaction implementations are only family-supported.')
family('terminal','Workspace terminals and PTY transport',
[a('src/context/terminal.tsx'),a('src/components/terminal.tsx'),a('src/utils/pty-ticket.ts'),a('src/utils/terminal-websocket-url.ts'),a('src/context/terminal.test.ts')],'Terminal tabs are per server/workspace; connection tokens precede websocket attach and cursor tracks JavaScript string length. Exited agent terminals remain visible.','PTY HTTP/server boundary and host terminal widget provide output and resize; pipeline runner uses the same ticket helpers.','Preserve UTF-16 cursor semantics and reconnect/gone distinctions; agent PTY authorization is a separate Core concern.','No PTY process, websocket or slow-reader experiment was run.')
family('dock','App Dock browser and Linux host integration',
[a('src/pages/session/apps-panel-controller.ts'),a('src/pages/session/apps-panel.tsx'),a('src/app-dock-linux.ts'),a('src/pages/session/apps-panel-controller.test.ts')],'Controller is renderer-wide, scopes native profiles by server/directory and rejects stale tab generations/host attachments. Manifest updates use revisions.','Panel uses injected native App Dock API; Linux tab is a distinct host bridge and excluded from browser restore lists.','Persist only eligible HTTPS tabs, serialize manifest writes and preserve detach ownership across remounts.','Native browser/LXC/Electron behavior and all overlay/resizer races were not executed.')
family('home','Home, project selection and server navigation',
[a('src/pages/home.tsx'),a('src/pages/home/home-projects-controller.tsx'),a('src/orchestra/chapters/home-start.tsx'),a('src/orchestra/chapters/kpis-home.tsx'),a('src/orchestra/chapters/kpis-data.ts'),a('src/orchestra/claude-mode-entry.ts')],'Home selects server/project and opens drafts/sessions; folder start awaits trust approval. KPI parsing checks server-provided numeric shapes before display.','Home is a navigation/dashboard surface; account/engine entry can return to a task after provider setup.','Retain server target during project selection; distinguish missing numeric facts from zero and partial server data.','Detailed KPI arithmetic, all Home controller branches and real provider account flows are not exhaustively traced.')
family('commands','Commands, shortcut catalog and shell navigation',
[a('src/context/command.tsx'),a('src/orchestra/chapters/shortcuts-model.ts'),a('src/orchestra/shell/navigation-commands.tsx'),a('src/desktop-menu.ts')],'CommandProvider combines keyed registrations, persisted catalog and settings overrides; shortcut model detects collisions and rejects text-editing keys.','Shell lifetime commands and native menu command IDs target current route/server; settings can list inactive catalog entries.','Dispose registrations on owner cleanup; editable targets, open dialogs and suspended keybinds constrain dispatch.','No native-menu or keyboard interaction was run; every individual command is not reviewed.')
family('settings','Settings, model catalogs and provider selection',
[a('src/context/settings.tsx'),a('src/context/models.tsx'),a('src/context/local.tsx'),a('src/hooks/model-execution.ts'),a('src/orchestra/chapters/settings.tsx'),a('src/orchestra/chapters/providers.tsx'),a('src/components/settings-v2/general-controllers.ts'),a('src/components/settings-v2/view/trust-section.tsx')],'Window-wide model preferences coexist with scoped catalogs and session model selection. Settings separate project-required sections from global sections; trust is server owned.','Composer/model dialogs and chapter screens consume provider availability; host-only models require matching execution engine.','Do not infer API connectivity from a host-only model; preserve optimistic shell setting rollback and readiness.','Provider OAuth/credential storage, server-side trust effects and all model policy controls remain outside exhaustive review.')
family('agents','Agent screens, identity and avatars',
[a('src/orchestra/chapters/agents.tsx'),a('src/orchestra/chapters/agents-roster.ts'),a('src/orchestra/avatars.ts'),'.orchestra/skills/agent-screen-maintenance/SKILL.md'],'Roster/detail source uses stable agent IDs, hides hidden agents and limits direct chat to maestro; Atlas counts are deferred.','Cards, prompt mentions and settings consume identity and avatars; editing is described by maintenance/user docs.','Never use display names as persistent IDs; separate current controller facts from promised guide tabs.','Agent-file save/toolkit/skill-tree details are only family-supported; full native registry is outside this unit.')
family('actions','Actions chapter and native command receipts',
[a('src/orchestra/actions/api.ts'),a('src/orchestra/actions/commands.ts'),a('src/orchestra/actions/request-policy.ts')],'Actions transport decodes schema responses and pins host/location. Requests are blocked for stale binding, unsupported state or unknown command outcome.','Chapter view and request controls use immutable selections and receipt refresh after ambiguity.','Keep idempotent receipt recovery separate from blindly reissuing state-changing commands; sanitize provider errors.','Individual views and all command outcomes are family-supported; host action execution is not inspected end-to-end.')
family('relay','Relay workflow and hook editing',
[a('src/orchestra/relay/client.ts'),a('src/orchestra/relay/editor.tsx'),a('src/context/permission-auto-respond.ts')],'Relay client wraps generated document/publication/hook routes and classifies unsupported/offline/conflict/missing errors; editor keys document frames by ID.','Workflow/hook chapters consume Relay; hook Ask appears through explicit permission UI.','Separate draft, publication and live request identities; never auto-answer hook Ask.','Compiler, publication authority and every editor/history branch are not reviewed.')
family('atlas','Atlas memory and review chapter',
[a('src/orchestra/chapters/atlas/atlas-api.ts'),a('src/orchestra/chapters/atlas/atlas-controller.ts'),a('src/orchestra/chapters/agents.tsx')],'Generated Atlas methods are location-scoped. Controller cancels prior owners, rejects stale responses and separates unavailable/error/empty.','Atlas pages and agent Memory views use this boundary; numerous sheets/views share it.','Keep owner generation and normalized directory checks for read/write results.','The large visualization/sheet family is supported through controller/transport seams, not every UI action.')
family('integrations','Integration connection and binding management',
[a('src/orchestra/chapters/integrations-api.ts'),a('src/orchestra/chapters/integrations-model.ts')],'Transport pins host/location, schema-decodes pages and sends idempotency keys; model isolates credentials outside reactive presentation state and gates late operations.','Integration screens manage connection, target and session-binding state.','Retain generation/abort checks, pagination limits and unknown-outcome recovery without exposing secret values.','All connection providers, paging and mutation scenarios have not been individually traced or run.')
family('lean','Lean coverage dashboard',
[a('src/orchestra/chapters/lean-controller.ts')],'Controller owns selected native transport; validates directory and history item IDs, serial-orders accepted snapshots, and reconciles writes with a fresh GET.','Lean view consumes server dashboard facts, not inferred session-cache totals.','Preserve read/write error separation and cancellation on selection/dispose.','Transport schema and all dashboard widgets are family-supported; no dashboard runtime was exercised.')
family('board','Board issue lanes and review decisions',
[a('src/orchestra/chapters/board/model.ts')],'Pure model groups issues by stage, orders shipped entries and derives age/spend/decision presentation from Board schemas.','Board chapter consumes these derived values; router permits no project selected.','Keep unknown/blocked decisions distinct from successful completion and preserve stable issue joins.','Board API/controller and complete mutation lifecycle were not inspected; this family is only model-supported.')
family('guardrails','Guardrail verdict model',
[a('src/orchestra/chapters/guardrails/model.ts'),a('src/orchestra/chapter-route.tsx')],'Verdict logic distinguishes missing repo/base, error, no rules, blocked, warning and clean.','A guardrails source family exists, but chapterPages at the pin does not register a guardrails route.','Do not call these files a reachable standalone chapter based only on directory existence.','All consumers of this family are not resolved; current route non-registration is the bounded observation.')
family('schedule','Scheduled tasks and migration',
[a('src/orchestra/chapters/schedule-server.ts'),a('src/orchestra/chapters/schedule-model.ts')],'Server schedule lists recorded runs, polls while mounted and migrates device tasks using stable IDs. Pure model defines once/hourly/daily/weekly slots and deterministic retry IDs.','Schedule UI can fall back when an older server lacks routes.','Distinguish server scheduling from legacy device execution; keep DST/local-calendar and one-off lateness semantics.','Full device scheduler/claims and Core scheduling execution are not reviewed.')
family('rag','RAG Studio source and retrieval controls',
[a('src/orchestra/chapters/rag-studio/page.tsx'),a('src/orchestra/chapters/rag-studio/files.tsx'),a('src/orchestra/chapters/rag-studio/question.tsx'),a('src/orchestra/chapters/rag-studio/maintain.tsx')],'Files admits/parses sources; Question creates a revision then asks and fetches cited source span; Maintain issues scoped pipeline passes and boundary changes.','RAG screen shows corpus/search/model-delivery states from generated SDK responses.','Preserve server/directory arguments and source span identity; display retrieval-optional/embedding-off copy as UI facts.','Server retrieval quality, maintenance atomicity and error/late-response behavior are not established.')
family('mcp-skills','MCP and skill configuration screens',
[a('src/orchestra/chapters/mcp-actions.ts'),a('src/orchestra/chapters/skills.tsx'),'.orchestra/skills/hugr-composer-maintenance/SKILL.md'],'MCP actions deduplicate per-name pending calls; auth waits own abort controllers. Skills fetch a scoped list with warm cache and distinguish unavailable, empty and error.','Chapters configure server-provided capabilities; the Composer integration is an external MCP declaration.','Preserve cancellation and name-safe maps; do not classify repository maintainer skills as runtime configuration.','Full MCP source/edit and Skill file writes are family-supported, not exhaustively traced.')
family('plugins','Profile behavior plugins',
[a('src/orchestra/chapters/plugins.tsx'),a('src/utils/llm-behaviors.ts')],'Page persists behavior set and serially pushes instructions to server; only latest answer marks supported/applied. Built-in behavior starts disabled.','Composer/project sessions consume server-applied instructions, while UI distinguishes saved from active.','Keep server rejection/unsupported status visible; behavior draft state alone is not execution authorization.','Underlying server application and every behavior storage branch are not traced.')
family('workspace-tools','Workspace naming, environment documents and legacy CI runner',
[a('src/orchestra/chapters/workspaces-store.ts'),a('src/orchestra/chapters/env-document.ts'),a('src/orchestra/chapters/cicd-runner.ts'),a('src/orchestra/chapter-route.tsx')],'Workspace preferences are server-scoped; env parser retains BOM, comments and unknown syntax. Legacy pipeline runner persists per profile and keeps PTY streams beyond page lifetime.','Workspaces/env pages consume these. Router currently maps cicd to Actions, so legacy runner existence does not prove current menu reachability.','Preserve opaque env text and scoped identities; distinguish retained source from active routing.','Workspace copy operations, env server writes and complete legacy CI reachability are not established.')
family('live','Flight Engineer live capture and meetings',
[a('src/live.ts'),a('src/context/platform.tsx'),a('src/orchestra/live/commands.tsx'),a('src/orchestra/chapters/flight-engineer/run.ts'),a('src/orchestra/chapters/flight-engineer/source.ts')],'Native LiveSeatPlatform owns capture/readiness/permissions/settings; window shared run state subscribes and asks consent per start. Meeting list/read operations use server client.','Sidebar, Home card and chapter share run state; capability absent means unavailable; dev fixture path is separate.','Keep consent dialog and platform permission distinct; do not expose write-only transcription keys as renderer-readable values.','OS audio capture, secret storage, native consent enforcement and transcription execution are not verified.')
family('wsl','WSL host state',
[a('src/wsl/context.tsx'),a('src/context/server.tsx')],'Query is enabled only when Platform.wslServers exists; host subscriptions update one infinite-stale-time query and cleanup on owner disposal.','WSL settings/add-server views consume host state; server identity includes distro.','Retain native optionality and subscription cleanup.','Install/probe actions and actual Windows/WSL host behavior are not reviewed.')
family('cockpit','Session evidence, governance, tasks and artifacts',
[a('src/pages/session/orchestra-evidence.tsx'),a('src/pages/session/orchestra-governance.tsx'),a('src/pages/session/process-control-data.ts'),a('src/pages/session/tasks-data.ts'),a('src/pages/session/artifacts-api.ts'),a('src/pages/session/orchestra-cockpit-state.ts')],'Evidence replaces shell rendering only when parser yields evidence; process rows report last observed transcript state. Governance dialog offers reads/navigation, not approval controls. Artifact transport pins session/location/revision.','Cockpit aggregates synced task/agent/session facts and read-only governance; artifact mutations use idempotency keys.','Avoid presenting historic process results or partial tasks as live certainty; retain source/session anchors and stale callback protection.','Parsers and every artifact controller state are not exhaustively audited; fixture logs are not app test results.')
family('session-ui-contract','Session UI view contracts and general components',
[s('src/transcript-model.ts'),s('src/context/data.tsx'),s('src/components/message-part.tsx'),s('package.json')],'Transcript is explicitly a renderer view model, not the wire contract; DataProvider takes caller state and navigation/artifact callbacks. Message rendering dispatches through tool/part components.','App-shell projects server state into this package; Storybook may inject fixtures.','Keep UI contracts free from server ownership and preserve public export discipline.','Most specialized tool cards/styles are family-supported at entry seams, not individually inspected.')
family('session-ui-markdown','Markdown parsing, caching and worker lifecycle',
[s('src/components/markdown.tsx'),s('src/components/markdown-cache.tsx'),s('src/components/markdown-worker-queue.ts'),s('src/components/markdown-worker-queue.test.ts')],'Markdown uses sanitized parsed HTML, bounded cache, keyed blocks and latest-per-key worker queue with ordered disposal.','Message/review components consume Markdown with streaming/cache keys.','Preserve sanitization fail-closed behavior and worker ownership; generated HTML is runtime output, not checked-in generated source.','No browser security test, performance benchmark or full worker parser audit was run.')
family('session-ui-editor','Reusable prompt editor interaction',
[s('src/v2/components/prompt-input/machine.ts'),s('src/v2/components/prompt-input/store.ts'),a('src/components/prompt-input-v2.tsx')],'Pure interaction machine returns commands for normal/shell mode, completion popovers, navigation and IME-aware Enter; store is caller-supplied reactive state.','App composer binds this UI to persistence, policy and network submission.','Do not move durable admission ownership into generic editor state; preserve attachment/model/context contracts.','All DOM/clipboard/paste and drag/drop variants are family-supported.')
family('session-ui-review','Session review, file and Pierre rendering',
[s('src/components/file.tsx'),s('src/components/session-review.tsx'),s('src/pierre/file-runtime.ts')],'File/diff views integrate Pierre, virtualizer and shadow-root readiness; review exposes selected-line comments and normalized diff shapes.','App review/file panels and injected UI file component use these renderers.','Observe host/theme changes and remove observers; honor readiness ownership tokens and file/diff identities.','Geometry, media rendering, annotation and text-selection correctness are not proven by source reads.')
family('palette-source','Theme runtime and palette generator inputs',
[a('src/orchestra/palette/context.tsx'),a('src/orchestra/palette/generate.ts'),a('script/orchestra-palettes.ts'),a('vite.js'),a('public/oc-theme-preload.js')],'Runtime loads selected generated CSS with latest-request guard. Generator names source CSS inputs and contrast checks; Vite inlines first-paint and preload code.','App shell renders selected palettes before content; source CSS remains authored input.','Regenerate palette outputs through the verified script; do not label all CSS generated.','Contrast pass and byte reproduction were not executed; source headers retain an old package path.')
family('palette-generated','Generated palette styles',
[a('script/orchestra-palettes.ts'),a('src/orchestra/palette/generate.ts'),a('src/orchestra/palette/generated/first-paint.css'),a('src/orchestra/palette/context.tsx')],'Seven checked-in outputs have a verified generator path and explicit generated header on inspected representative.','Palette provider dynamically imports palette CSS; Vite embeds first-paint CSS.','Edit inputs/generator then regenerate; preserve full generated population in coverage.','No regeneration or all-output content comparison was performed.')
family('styles','Authored layout and component styles',
[a('src/orchestra/palette/generate.ts'),a('src/app.tsx'),s('src/components/file.tsx')],'Source styles support component/shell layouts and act as explicit palette-generation inputs for listed files.','App and session-ui import these through package/component entrypoints.','Treat non-generated CSS as maintained source unless a generator is positively identified.','Styles were accounted by consumer/family and generator inventory; pixel-level layout and provenance of each rule are not reviewed.')
family('localization','Localization dictionaries and translation workflow',
[a('src/context/language.tsx'),a('src/i18n/en.ts'),a('src/i18n/ar.ts'),a('src/i18n/lean/en.ts'),a('src/i18n/orchestra-chapters/agents.ts'),a('src/i18n/frontend-recovery.ts'),a('script/translate-app.ts'),a('script/translate-app.md')],'Language provider merges app/UI/domain dictionaries, caches locale modules, applies direction and invokes native-copy callback. Translation script preserves English and validates keys/placeholders.','All app surfaces use shared translation/plural APIs; domain dictionaries compose independently.','Do not infer every locale was generated by the script; preserve key/placeholder shape and RTL behavior.','Representative English/Arabic/domain reads support the family; other languages are not linguistically audited.')
family('avatars','Bundled agent portrait assets',
[a('src/orchestra/avatars.ts'),'.orchestra/skills/agent-avatars-maintenance/SKILL.md',a('src/orchestra/avatars/seat-backend.webp')],'Eager import glob resolves WebP portraits; seat files are omitted from selectable library. Representative binary was decoded and hashed.','Roster/detail use lib identifiers and stable seat fallback. Upload path separately crops to 192 square WebP and rejects SVG.','Preserve exact assets and role IDs; do not infer binary authorship or dimensions of every portrait.','90 files are family-supported; sampled seat portrait is 256 square, so documented generic 128px guidance is not universal measured fact.')
family('wallpaper-assets','Wallpaper imagery and catalog',
[a('src/orchestra/wallpaper/catalog.ts'),a('public/orchestra/README.md'),a('public/orchestra/mtn-src.jpg')],'Catalog pairs wallpaper full and thumbnail URLs; approved static README covers compact logos and mountain image specifically.','Wallpaper UI and shell background consume catalog assets.','Maintain catalog-to-file correspondence and distinguish approval note from provenance of all wallpapers.','Image metadata/hash checked for mountain only; other imagery creator/license/provenance not established.')
family('brand-assets','Brand, public-web and help assets',
[a('public/orchestra/README.md'),a('public/orchestra/hugr-horizontal-compact-primary.svg'),a('vite.js')],'Approved logo README and inspected SVG header establish identity/format for representative. Public icons/manifest/header files form web packaging.','App/host/web static entry surfaces consume these assets.','Preserve approved vector bytes; do not claim icon/image generators from extension.','Other public asset provenance and deployment header semantics are metadata-only where no direct consumer witness exists.')
family('zen-assets','Third-party Zen texture',
[a('src/pages/session/zen-assets/NOTICE.md'),a('src/pages/session/zen-assets/grain-bg.png')],'NOTICE identifies adapted Zen source revision and MPL-2.0; PNG dimensions and bytes were decoded/hashed.','Session visual texture family.','Retain notice with adapted asset and avoid extending its license to unrelated images.','No visual comparison to original upstream revision or legal conclusion is made.')
family('evidence-fixtures','Execution-output parser fixtures',
[a('src/pages/session/orchestra-evidence-fixtures/README.md'),a('src/pages/session/orchestra-evidence.tsx')],'README distinguishes recovered runner logs, real Jest capture, intentionally failing case inputs and adversarial synthetic footer.','Execution evidence parser/tests consume these as data.','Preserve whitespace/node IDs required by parser cases; never report fixture text as current product test success.','No fixture runner was executed and byte-level provenance of each log was not independently recreated.')
family('browser-tests','Browser-environment test harness and suites',
[a('test-browser/server-transport.test.ts'),a('test-browser/prompt-admission-owner.suite.ts'),a('package.json')],'Read assertions exercise actual provider ownership/transport with controlled fake network and DOM context.','Bun browser-condition suites validate renderer seams; suite imports/harness govern discovery.','Keep fixture transport distinct from a real server and preserve owner lifetime assertions.','All remaining browser suite files are family-supported by harness role; no suite ran and not every assertion was read.')
family('e2e-tests','Playwright product regressions and fixtures',
[a('playwright.config.ts'),a('e2e/AGENTS.md'),a('e2e/regression/draft-admission-handoff.spec.ts'),a('e2e/utils/mock-server.ts'),a('e2e/utils/sse-transport.ts')],'Playwright setup serves apps/web; regression assertions cover delayed admission response and same-ID retry. Mock server and controllable SSE are test infrastructure.','Regression/orchestra/smoke/user-story suites consume test helpers and deterministic sources.','Follow scoped locators/readiness/identity rules; a request receipt or fixture admission count is not proof of server durability.','No Playwright execution, visual validation or full test discovery audit was performed.')
family('benchmarks','Manual performance diagnostics',
[a('e2e/performance/AGENTS.md'),a('e2e/performance/README.md'),a('playwright.config.ts')],'Normal Playwright ignores performance directory; README calls metrics diagnostics without machine-dependent budgets or compositor-frame claims.','Maintainers invoke benchmark production-build harness explicitly when needed.','Preserve raw diagnostics, serial execution and distinction between scenario completion and performance acceptance.','Implementation internals and collected results are metadata/family supported only; no benchmark ran.')
family('test-support','Shared test support and stories',
[a('package.json'),a('e2e/utils/mock-server.ts'),s('package.json'),a('src/components/prompt-input/submit-admission.suite.ts')],'Fixture/harness/story files provide deterministic inputs and component mounting support, not runtime entrypoints.','Unit/browser/Storybook tests consume support through their runner or story entry.','Keep discovery and execution claims separate; generated status requires explicit source evidence.','Some support/story files only have tree-level purpose evidence; individual scenarios are not all inspected.')
family('entry-recovery','Shell entry, draft readiness and renderer recovery',
[a('src/pages/layout-new.tsx'),a('src/pages/new-session.tsx'),a('src/pages/error.tsx'),a('src/pages/error-description.ts')],'NewLayout waits for navigation readiness and mounts shell commands/ingress; NewSession waits for prompt/workspace hydration. ErrorPage formats chained errors and reports a fatal renderer failure through an optional host callback.','The router mounts these page boundaries; connection banner uses delayed server-health state and host capability determines available recovery controls.','Preserve readiness barriers and cleanup of delayed banners; error reporting, update controls and manual report actions have different trigger conditions.','Selected error/layout spans were read; native restart, updater installation and debug export were not performed or exhaustively traced.')
family('janitor','Janitor reports and scoped assistant pocket',
[a('src/context/janitor.tsx'),a('src/utils/janitor-report.ts'),a('src/components/janitor-pocket.tsx'),a('src/components/janitor-widget.tsx')],'Report parser bounds fields and drops scanner/ok findings. Provider filters report source and resets on owner change; pocket guards async session creation/adoption by generation, server scope and directory.','Widget resolves the current route/tab target and composes existing server, prompt, file and transcript providers for the pocket.','Keep late native notifications tied to the current report, explicit retry state and server/directory session-storage keys; dismiss/snooze invoke optional native bridge.','Native scanning implementation and complete widget markup were not inspected. No Janitor report or session was generated.')
family('controls','Confirmation, secret and external-link controls',
[a('src/components/secret-input-v2.tsx'),a('src/components/external-link.tsx'),a('src/components/dialog-confirm-choice.tsx'),a('src/components/ui/drawer.tsx')],'SecretInput defaults to password masking with an explicit reveal control; ExternalLink defaults to blank target and noopener/noreferrer, while props permit overrides. Confirmation and drawer wrappers expose caller-controlled actions and composition.','App pages consume reusable presentation/interaction contracts; these controls do not own credentials, navigation authorization or server validation.','Preserve accessible reveal labels and action ordering. Drawer source identifies adaptation from solid-ui without establishing upstream revision or all provenance.','No credential-storage guarantee, URL sanitizer, focus/accessibility proof or browser interaction result is inferred.')
family('diagnostics','Renderer performance and focus diagnostics',
[a('src/components/debug-bar.tsx'),a('src/pages/layout-new.tsx')],'Debug bar tracks optional renderer metrics and records route timing after two animation frames; native focus override is explicitly reset on cleanup.','Shell exposes the diagnostic surface through its debug-bar state; unknown metrics remain unavailable.','Treat these instrumented values as renderer diagnostics, not compositor-frame or production benchmark acceptance.','Performance observer implementation and metric accuracy were not fully audited; no measurements were collected.')
family('identity-utils','Path, display and local identifier helpers',
[a('src/utils/base64.ts'),a('src/utils/path-key.ts'),a('src/utils/id.ts'),a('src/utils/uuid.ts'),a('src/utils/same.ts'),a('src/utils/wildcard.ts'),a('src/utils/session-title.ts')],'Helpers normalize drive/UNC path separators and trailing slash, safely decode base64, compare arrays, match whole-string wildcards, format default session titles and create prefixed IDs/UUIDs.','Route/cache/model consumers use these exported pure contracts; path normalization is not filesystem canonicalization.','Identifier accepts supplied IDs by prefix only; random fallbacks use Math.random, so these helpers must not be described as authentication-token guarantees.','All listed helper bodies were read; platform filesystem equality and caller correctness are not proven.')
family('dom-input','DOM scheduling, menu dismissal and input adapters',
[a('src/utils/frame-resize-observer.ts'),a('src/utils/menu-dismiss-controller.ts'),a('src/utils/modal-active.ts'),a('src/utils/runtime-adapters.ts'),a('src/utils/search-keydown.ts')],'Resize observer delivery is coalesced to a cancellable animation frame. Menu dismissal waits for disconnected content and two frames. Search forwarding guards composition/editable targets; adapters test runtime shapes.','File/layout/input consumers call these exported scheduling and capability helpers; modal detection participates in command guarding.','Keep owner cleanup and event preconditions distinct; structural adapter checks establish supported shape, not native implementation correctness.','Search selection helper tail and all caller interactions were not individually read or executed.')
family('feedback','Downloads, sounds, labels, toasts and rejection handling',
[a('src/utils/download.ts'),a('src/utils/file-manager.ts'),a('src/utils/sound.ts'),a('src/utils/time.ts'),a('src/utils/toast.tsx'),a('src/utils/unhandled-rejection.ts')],'Helpers create/revoke download object URLs, select OS file-manager labels, lazy-load cached sound assets, format elapsed time, adapt toast regions and log non-abort unhandled rejections.','App UI callers supply bytes, sound ID, translated copy or error; these are feedback mechanisms rather than durable stores.','Sound play failures are caught; stopping pauses/resets playback. Download anchor cleanup and abort-error suppression are explicit.','No file save, audio playback, toast interaction or real error-reporting transport was exercised.')
family('pull-request','Server pull-request payload adapter',
[a('src/utils/pull-request.ts')],'Decoder recognizes typed CLI failure kinds, unsupported HTTP statuses and validated created/open pull-request payload shapes; created URLs must be HTTPS and numbers safe integers.','Commented contract places CLI work at server /api/pull-request routes; this app helper adapts responses and CLI labels.','Preserve unavailable/malformed/declared-failure distinctions and host/count validation.','Server CLI execution and every caller were not inspected. No pull request, CLI or remote mutation was invoked.')
F['bootstrap']['representative_source_paths'].append(a('src/components/orchestra/native-frame.ts'))
F['bootstrap']['source_implications']+=' Native titlebar measurement uses coalesced animation frames, host capability and disconnect/fullscreen cleanup; the native host owns zoom conversion.'
F['terminal']['representative_source_paths'].append(a('src/addons/serialize.ts'))
F['terminal']['source_implications']+=' The Ghostty serialize addon requires activation, can emit terminal state or active-buffer plain text, and optionally excludes alternate buffer/modes.'
F['terminal']['limits']+=' Mid-file cell/style conversion is not exhaustively reviewed; the xterm.js port header is provenance intent, not verified equivalence.'
F['home']['representative_source_paths'].append(a('src/pages/home-session-open.ts'))
F['files']['representative_source_paths'].append(a('src/constants/file-picker.ts'))
F['files']['source_implications']+=' File-picker filters derive deduplicated extensions from accepted MIME/type declarations; picker hints are not server validation.'
F['prompt']['representative_source_paths'] += [a('src/utils/prompt.ts'),a('src/utils/worktree.ts')]
F['prompt']['source_implications']+=' Undo restoration rebuilds text/file/agent/image parts; worktree readiness coalesces waiters and retains terminal ready/failed status.'
F['sync']['representative_source_paths'].append(a('src/utils/session.ts'))
F['sync']['source_implications']+=' Session normalization preserves unknown cost; policy merge distinguishes canonical read receipts, durable sequence and timestamps.'
F['timeline']['representative_source_paths'].append(a('src/utils/session-export.ts'))
F['timeline']['source_implications']+=' Export fetches log pages in ascending order and adapts canonical parts to the CLI-shaped export contract.'

# Explicit finite correction of the v1 residual families. Test/declaration leaves
# retain their lower evidence depth unless their own body was read.
CORRECTION={}
def corrected(f,*names):
    for name in names: CORRECTION[a('src/'+name)]=f
corrected('entry-recovery','pages/layout-new.tsx','pages/new-session.tsx','pages/error.tsx','pages/error-description.ts','pages/error-description.test.ts')
corrected('janitor','context/janitor.tsx','utils/janitor-report.ts','utils/janitor-report.test.ts','components/janitor-pocket.tsx','components/janitor-widget.tsx','components/janitor-widget.stories.tsx')
corrected('controls','components/secret-input-v2.tsx','components/external-link.tsx','components/dialog-confirm-choice.tsx','components/ui/drawer.tsx')
corrected('diagnostics','components/debug-bar.tsx')
corrected('bootstrap','components/orchestra/native-frame.ts')
corrected('terminal','addons/serialize.ts','addons/serialize.test.ts')
corrected('home','pages/home-session-open.ts','pages/home-session-open.test.ts')
corrected('files','constants/file-picker.ts')
corrected('identity-utils','utils/base64.ts','utils/path-key.ts','utils/id.ts','utils/uuid.ts','utils/uuid.test.ts','utils/same.ts','utils/wildcard.ts','utils/wildcard.test.ts','utils/session-title.ts')
corrected('dom-input','utils/frame-resize-observer.ts','utils/frame-resize-observer.test.ts','utils/menu-dismiss-controller.ts','utils/modal-active.ts','utils/runtime-adapters.ts','utils/runtime-adapters.test.ts','utils/search-keydown.ts')
corrected('feedback','utils/download.ts','utils/file-manager.ts','utils/sound.ts','utils/time.ts','utils/toast.tsx','utils/unhandled-rejection.ts','utils/unhandled-rejection.test.ts')
corrected('pull-request','utils/pull-request.ts','utils/pull-request.test.ts')
corrected('prompt','utils/prompt.ts','utils/prompt.test.ts','utils/worktree.ts','utils/worktree.test.ts')
corrected('sync','utils/session.ts','utils/session.test.ts','context/session-regression-lanes.test.ts')
corrected('timeline','utils/session-export.ts','utils/session-export.test.ts')
corrected('palette-source','theme-preload.test.ts')
corrected('authority','custom-elements.d.ts','env.d.ts','vite-env.d.ts')

def classify(p):
    n=p.rsplit('/',1)[-1]
    if '/palette/generated/' in p:return 'generated'
    if '/orchestra-evidence-fixtures/' in p:return 'fixture'
    if p.startswith('.orchestra/skills/'):return 'skill'
    if '/70-90-briefs/' in p or 'create-effect-simplification-spec' in p:return 'historical-proposal'
    if '/i18n/' in p and not re.search(r'\.(test|spec)\.',n):return 'localization'
    if n.endswith(('.png','.jpg','.jpeg','.webp','.gif','.ico','.svg','.aac','.woff','.woff2','.ttf')):return 'binary-or-vector-asset'
    if n.endswith('.md'):return 'documentation'
    if n.endswith('.css'):return 'style'
    if re.search(r'\.(test|spec|suite|visual)\.[cm]?[jt]sx?$',n):return 'test-unexecuted'
    if re.search(r'\.(fixture|test-helper|stories)\.[cm]?[jt]sx?$',n) or '/testing/' in p:return 'test-support-or-story'
    if '/e2e/' in p or '/test-browser/' in p or n=='happydom.ts':return 'test-support'
    if '/script/' in p:return 'maintenance-tool'
    if n in ['package.json','tsconfig.json','bunfig.toml','.gitignore','_headers','site.webmanifest','vite.js'] or n.endswith('.d.ts'):return 'configuration-or-declaration'
    return 'implementation'
def choose(p):
    n=p.rsplit('/',1)[-1];r=p[len(A):] if p.startswith(A) else p
    if p in CORRECTION:return CORRECTION[p]
    if p.startswith('.orchestra/skills/'):return 'skills'
    if '/70-90-briefs/' in p or 'create-effect-simplification-spec' in p:return 'history'
    if p.startswith('docs/guides/'):return 'guides'
    if '/orchestra-evidence-fixtures/' in p:return 'evidence-fixtures'
    if '/zen-assets/' in p:return 'zen-assets'
    if '/i18n/' in p or n=='language.tsx' or n.startswith('translate-app'):return 'localization'
    if '/palette/generated/' in p:return 'palette-generated'
    if '/palette/' in p or n=='orchestra-palettes.ts' or n=='oc-theme-preload.js':return 'palette-source'
    if '/orchestra/avatars/' in p:return 'avatars'
    if '/public/orchestra/wallpapers/' in p or '/orchestra/wallpaper/' in p or n=='mtn-src.jpg':return 'wallpaper-assets'
    if '/public/' in p or '/assets/help/' in p:return 'brand-assets'
    if '/e2e/performance/' in p:return 'benchmarks'
    if '/e2e/' in p or n=='playwright.config.ts':return 'e2e-tests'
    if '/test-browser/' in p:return 'browser-tests'
    if n in ['AGENTS.md','README.md','package.json','tsconfig.json','bunfig.toml','.gitignore'] or r=='vite.js':return 'authority'
    if '/src/' not in p:return 'authority'
    if p.startswith(S):
        if '/prompt-input/' in p or n.startswith('prompt-input'):return 'session-ui-editor'
        if 'markdown' in n:return 'session-ui-markdown'
        if '/pierre/' in p or any(x in n for x in ['file','review','comment','diff']):return 'session-ui-review'
        if n.endswith('.css'):return 'styles'
        return 'session-ui-contract'
    if n.endswith('.css'):return 'styles'
    if '/orchestra/actions/' in p or '/chapters/actions.' in p:return 'actions'
    if '/orchestra/relay/' in p or n in ['hooks.tsx','workflows.tsx']:return 'relay'
    if '/chapters/atlas/' in p:return 'atlas'
    if '/chapters/board/' in p:return 'board'
    if '/chapters/guardrails/' in p:return 'guardrails'
    if '/chapters/flight-engineer/' in p or '/orchestra/live/' in p or n=='live.ts':return 'live'
    if '/chapters/rag-studio/' in p:return 'rag'
    if '/chapters/' in p:
        if n.startswith('agents'):return 'agents'
        if n.startswith('integrations'):return 'integrations'
        if n.startswith('lean'):return 'lean'
        if n.startswith('schedule'):return 'schedule'
        if n.startswith('shortcuts'):return 'commands'
        if n.startswith(('settings','providers','claude-mode')):return 'settings'
        if n.startswith(('mcp','skills')):return 'mcp-skills'
        if n.startswith('plugins'):return 'plugins'
        if n.startswith(('workspaces','env','cicd','dock')):return 'workspace-tools'
        if n.startswith(('home','kpis')):return 'home'
        return 'bootstrap'
    if '/wsl/' in p:return 'wsl'
    if '/components/settings-v2/' in p or n.startswith(('settings','dialog-connect-provider','dialog-custom-provider','dialog-manage-models','dialog-select-model','model-tooltip','provider-connection')):return 'settings'
    if '/orchestra/shell/' in p:return 'commands' if 'commands' in n else 'bootstrap'
    if '/components/prompt-input/' in p or n=='prompt-input-v2.tsx':return 'prompt'
    if '/pages/session/composer/' in p:
        if any(x in n for x in ['permission','question','request','todo']):return 'requests'
        return 'prompt'
    if '/pages/session/timeline/' in p:return 'timeline'
    if '/pages/session/' in p:
        if n.startswith(('apps-panel','linux-menu')):return 'dock'
        if n.startswith(('terminal','capability-processes')):return 'terminal'
        if n.startswith(('artifacts','orchestra-','tasks','process')):return 'cockpit'
        if n.startswith(('file','review','legacy-file','session-vcs')) or '/v2/' in p:return 'files'
        if n.startswith(('use-session-commands','use-composer-commands')):return 'commands'
        if n.startswith('session-model'):return 'settings'
        return 'session-route'
    if '/pages/home/' in p or '/pages/new-session/' in p or n=='home.tsx':return 'home'
    if '/pages/layout/' in p or n in ['layout.tsx','layout-v2.tsx']:return 'home'
    if '/context/global-sync/' in p:return 'sync'
    if '/context/file/' in p:return 'files'
    if '/context/' in p:
        if n.startswith(('server-session','server-sync','server-event','session-management','session-recovery','directory-sync','sync')):return 'sync'
        if n.startswith(('server','sdk','global.')):return 'transport'
        if n.startswith(('prompt','tabs','tab-','closed-tabs')):return 'persistence'
        if n.startswith('permission'):return 'requests'
        if n.startswith('command'):return 'commands'
        if n.startswith(('file','comments')):return 'files'
        if n.startswith('terminal'):return 'terminal'
        if n.startswith(('models','model-','local.','settings','agent-identity')):return 'settings'
        if n.startswith('layout'):return 'session-route'
        if n.startswith('notification'):return 'home'
        if n.startswith('platform'):return 'bootstrap'
        if n=='mcp.ts':return 'mcp-skills'
        raise AssertionError('Unmapped implementation family: '+p)
    if '/utils/' in p:
        if n.startswith(('server-health','server-ready','server-compat','server-errors','server-stream','server.test','server.ts','scoped-fetch')):return 'transport'
        if n.startswith(('persist','draft-store','server-scope','scoped-cache','refcount','grace')):return 'persistence'
        if n.startswith(('pty-','terminal-')):return 'terminal'
        if n.startswith('session-management'):return 'sync'
        if n.startswith(('session-message','comment-note','diffs')):return 'timeline'
        if n.startswith('session-route'):return 'session-route'
        if n.startswith('llm-behaviors'):return 'plugins'
        raise AssertionError('Unmapped utility: '+p)
    if '/hooks/' in p:return 'settings'
    if '/testing/' in p:return 'test-support'
    if '/components/' in p:
        if n.startswith(('terminal',)):return 'terminal'
        if n.startswith(('titlebar','windows-app-menu')):return 'bootstrap'
        if n.startswith(('command','dialog-command')):return 'commands'
        if n.startswith(('directory','edit-project','dialog-edit-project','dialog-select-directory','dialog-select-server','prompt-project','prompt-workspace')) or '/components/server/' in p:return 'home'
        if n.startswith(('subagent-model','draft-subagent','session-model','dialog-subagent')):return 'prompt'
        if n.startswith(('file-tree','pierre-tree','dialog-select-file','grouped-virtualizer','virtual-scroll')):return 'files'
        if n.startswith(('dialog-select-mcp',)):return 'mcp-skills'
        if n.startswith(('dialog-archived','dialog-fork')):return 'session-route'
        if n.startswith('updater'):return 'bootstrap'
        if n.startswith(('server-unavailable','status-popover')):return 'transport'
        if '/components/session/' in p:return 'timeline'
        raise AssertionError('Unmapped implementation family: '+p)
    if r.startswith('src/orchestra/'):
        if n.startswith('avatars'):return 'agents'
        if n.startswith('claude-mode'):return 'settings'
        if n.startswith('model-logo'):return 'settings'
        return 'bootstrap'
    if n in ['app.tsx','index.ts','web.ts','desktop-menu.ts','desktop-menu.test.ts','native-titlebar.ts','updater.ts','app-dock-linux.ts','server-api.ts','server-api-parity.ts','session-types.ts','v2-types.ts','v2-wire.ts','client-events.ts','directory-layout.tsx']:return 'bootstrap'
    if n=='session.tsx':return 'session-route'
    raise AssertionError('Unmapped implementation family: '+p)

capt=json.loads((B/'sources.json').read_text())
read={r['path']:r for r in capt['records'] if r.get('status')=='captured'}
# These source records describe selected-span inspection, not whole-file comprehension.
v1=json.loads((B/'coverage-v1.json').read_text())
v1_lower_depth={e['path'] for e in v1['entries'] if e['evidence_depth']=='metadata-only'}
entries=[]
for item in TREE:
    p=item['path'];f=choose(p);cl=classify(p);reps=F[f]['representative_source_paths']
    inspected=p in read and cl!='binary-or-vector-asset'
    depth='inspected' if inspected else 'family-supported'
    reason='Pinned source captured and selected implementation/document/assertion spans read; sources.json records available read scope. This does not imply full-file review.' if inspected else 'Family disposition is supported by the listed source/consumer witnesses; this individual body was not read.'
    if p in v1_lower_depth and not inspected:
        depth='metadata-only';reason='Exact tree path/size/blob identity accounted; this test, story or declaration body was not read. Family implementation evidence does not establish the contents of this leaf.'
    if f=='authority' and not inspected:
        depth='metadata-only';reason='Build/package placement is known from exact tree and manifest siblings, but this configuration body was not inspected.'
    if f=='brand-assets' and not inspected and cl not in ['binary-or-vector-asset','documentation']:
        depth='metadata-only';reason='Static packaging path accounted; specific manifest/header semantics were not read.'
    if cl=='binary-or-vector-asset':
        reason='Family consumer and available provenance/notice inspected; repeated asset bodies are not semantically reviewed. Representative binary metadata/hash reads are separately recorded.'
    if cl=='test-unexecuted' and not inspected:
        reason='Test placement and family mechanism mapped; this test body was not individually read, its assertions are not claimed, and no tests ran.'
    if cl=='localization' and not inspected:
        reason='Shared language loader and English/Arabic/domain dictionary representatives read; this locale/copy body was not linguistically audited and per-file generation provenance is unknown.'
    if cl=='generated' and not inspected:
        reason='Verified generator names this output family and a representative generated header/consumer was read; this output was not individually regenerated or content-compared.'
    entries.append({**item,'family':f,'classification':cl,'evidence_depth':depth,'representative_source_paths':([p]+[x for x in reps if x!=p])[:9] if inspected else reps,'reason':reason})
for f in F.values():
    own=[e for e in entries if e['family']==f['id']]
    f['path_count']=len(own)
    f['classification_counts']=dict(collections.Counter(x['classification'] for x in own))
    f['evidence_depth_counts']=dict(collections.Counter(x['evidence_depth'] for x in own))
    f['representative_tests_read']=[e['path'] for e in own if e['path'] in read and e['classification']=='test-unexecuted']
    f['test_status']='unexecuted; family-specific test paths remain individually classified in entries'
obj={'schema':'genesis-l1-coverage/v2','unit':'app-session','epoch':'20261111-v3-fresh','protocol':'parallel-v3-fresh','source_repository':'gustavomhss/hugr-orchestra','source_commit':'1cde2ff7a71bcf7aecb5d030917b577165135d38','protocol_commit':'ee2521a5b966bd505cc95bd1c733e09e12f33531','previous_coverage_file':'coverage-v1.json','required_correction':'All 39 previously metadata-only implementation bodies were captured and read; residual catchalls were replaced with meaningful families. Unread test/declaration leaves keep lower depth.','input_file':str(INPUT),'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),'assigned_count':1887,'represented_count':len(entries),'depth_meaning':{'inspected':'This exact body had selected source spans read; not a promise that every line or behavior was inspected.','family-supported':'This entry is covered through concrete source/consumer representatives and stated family limitations. Individual body not necessarily read.','metadata-only':'Path/tree metadata only or no relevant behavioral witness; no claim of understanding this entry.'},'summary':{'families':sum(bool(x['path_count']) for x in F.values()),'classifications':dict(collections.Counter(x['classification'] for x in entries)),'evidence_depths':dict(collections.Counter(x['evidence_depth'] for x in entries))},'families':[x for x in F.values() if x['path_count']],'entries':entries}
assert len(entries)==1887 and len({x['path'] for x in entries})==1887
assert {x['path'] for x in entries}=={x['path'] for x in TREE}
assert all(p in read for f in obj['families'] for p in f['representative_source_paths'])
(B/'coverage.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(obj['summary'],indent=2))
print('METADATA_ONLY',json.dumps([e['path'] for e in entries if e['evidence_depth']=='metadata-only'],indent=2))

