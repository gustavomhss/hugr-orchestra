import { defineMain } from "storybook-solidjs-vite"
import path from "node:path"
import { fileURLToPath } from "node:url"
import tailwindcss from "@tailwindcss/vite"
import { playgroundCss } from "./playground-css-plugin"

const here = path.dirname(fileURLToPath(import.meta.url))
const ui = path.resolve(here, "../../../packages/ui")
const sessionUi = path.resolve(here, "../../../packages/session-ui")
const app = path.resolve(here, "../../../packages/app-shell/src")
const mocks = path.resolve(here, "./mocks")

export default defineMain({
  framework: {
    name: "storybook-solidjs-vite",
    options: {},
  },
  addons: [
    "@storybook/addon-onboarding",
    "@storybook/addon-docs",
    "@storybook/addon-links",
    "@storybook/addon-a11y",
    "@storybook/addon-vitest",
  ],
  stories: [
    "../../../packages/ui/src/**/*.stories.@(js|jsx|mjs|ts|tsx)",
    "../../../packages/session-ui/src/**/*.stories.@(js|jsx|mjs|ts|tsx)",
    "../../../packages/app-shell/src/**/*.stories.@(js|jsx|mjs|ts|tsx)",
  ],
  async viteFinal(config) {
    const { mergeConfig, searchForWorkspaceRoot } = await import("vite")
    return mergeConfig(config, {
      plugins: [tailwindcss(), playgroundCss()],
      resolve: {
        dedupe: ["solid-js", "solid-js/web", "@solidjs/meta"],
        alias: [
          { find: "@solidjs/router", replacement: path.resolve(mocks, "solid-router.tsx") },
          { find: /^@\/context\/local$/, replacement: path.resolve(mocks, "app/context/local.ts") },
          { find: /^@\/context\/file$/, replacement: path.resolve(mocks, "app/context/file.ts") },
          { find: /^@\/context\/prompt$/, replacement: path.resolve(mocks, "app/context/prompt.ts") },
          { find: /^@\/context\/layout$/, replacement: path.resolve(mocks, "app/context/layout.ts") },
          { find: /^@\/context\/sdk$/, replacement: path.resolve(mocks, "app/context/sdk.ts") },
          { find: /^@\/context\/sync$/, replacement: path.resolve(mocks, "app/context/sync.ts") },
          { find: /^@\/context\/comments$/, replacement: path.resolve(mocks, "app/context/comments.ts") },
          { find: /^@\/context\/command$/, replacement: path.resolve(mocks, "app/context/command.ts") },
          { find: /^@\/context\/permission$/, replacement: path.resolve(mocks, "app/context/permission.ts") },
          { find: /^@\/context\/language$/, replacement: path.resolve(mocks, "app/context/language.ts") },
          { find: /^@\/context\/platform$/, replacement: path.resolve(mocks, "app/context/platform.ts") },
          { find: /^@\/context\/global-sync$/, replacement: path.resolve(mocks, "app/context/global-sync.ts") },
          { find: /^@\/context\/global$/, replacement: path.resolve(mocks, "app/context/global.ts") },
          { find: /^@\/context\/server-sync$/, replacement: path.resolve(mocks, "app/context/server-sync.ts") },
          { find: /^@\/context\/server-sdk$/, replacement: path.resolve(mocks, "app/context/server-sdk.ts") },
          { find: /^@\/context\/server$/, replacement: path.resolve(mocks, "app/context/server.ts") },
          { find: /^@\/context\/tabs$/, replacement: path.resolve(mocks, "app/context/tabs.ts") },
          {
            find: /^@\/components\/janitor-pocket$/,
            replacement: path.resolve(mocks, "app/components/janitor-pocket.tsx"),
          },
          { find: /^@\/hooks\/use-providers$/, replacement: path.resolve(mocks, "app/hooks/use-providers.ts") },
          {
            find: /^@\/components\/dialog-select-model$/,
            replacement: path.resolve(mocks, "app/components/dialog-select-model.tsx"),
          },
          { find: "@", replacement: app },
        ],
      },
      worker: {
        format: "es",
      },
      server: {
        fs: {
          allow: [searchForWorkspaceRoot(process.cwd()), ui, sessionUi, app, mocks],
        },
      },
    })
  },
})
