import json, pathlib, hashlib, sys

ROOT=pathlib.Path('/workspace/scratch/992c54067adf/genesis-s2/producers/app-session')
PIN='1cde2ff7a71bcf7aecb5d030917b577165135d38'
records=[]
for batch in sorted((ROOT/'captures').glob('batch-*.json')):
    for item in json.loads(batch.read_text()):
        if item['status']!='fulfilled':
            records.append({'path':item['path'],'status':'fetch-error','error':item.get('reason')})
            continue
        response=item['value']
        c=response.get('structuredContent')
        if not c or 'content' not in c:
            records.append({'path':item['path'],'status':'unparsed-response','capture_file':str(batch.relative_to(ROOT))})
            continue
        content=c['content']
        if c.get('encoding')=='base64':
            import base64
            raw=base64.b64decode(content)
        else:
            raw=content.encode('utf-8')
        path=ROOT/'sources'/item['path']
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(raw)
        blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        records.append({'commit':PIN,'path':item['path'],'git_blob_sha':c.get('sha'),'computed_git_blob_sha':blob,'git_blob_verified':blob==c.get('sha'),'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),'local_capture_file':str(path.relative_to(ROOT)),'connector_response_file':str(batch.relative_to(ROOT)),'status':'captured'})
(ROOT/'sources.json').write_text(json.dumps({'schema':'genesis-source-captures/v1','source_commit':PIN,'records':records},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'records':len(records),'captured':sum(r['status']=='captured' for r in records),'verified':sum(r.get('git_blob_verified',False) for r in records),'problems':[r for r in records if r['status']!='captured' or not r.get('git_blob_verified')]}))
