import collections
import hashlib
import json
import shutil
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
out = root / 'deliverable'
delta = root / 'corrections/l1-r2'
units = sys.argv[1:] or ['desktop-web', 'app-session', 'design-tui']
data = json.loads((delta / 'sources-delta.json').read_text())
family_delta = json.loads((delta / 'family-delta.json').read_text())

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def digest(value):
    return hashlib.sha256(value).hexdigest()

for unit in units:
    producer = root / 'producers' / unit
    history = out / 'history/l1-r1' / unit
    history.mkdir(parents=True, exist_ok=True)
    for name in ['l1.md', 'coverage.json', 'sources.json', 'decisive-evidence.md', 'response.md']:
        target = history / name
        if not target.exists():
            shutil.copyfile(producer / name, target)
    sources = json.loads((producer / 'sources.json').read_text())
    records_key = next(k for k in ['sources', 'records', 'captures'] if isinstance(sources.get(k), list))
    records = sources[records_key]
    indexed = {r['path']: r for r in records + sources.get('captured_not_directly_inspected', [])}
    coverage = json.loads((producer / 'coverage.json').read_text())
    assigned = {entry['path']: entry for entry in coverage['entries']}
    for record in data['captures']:
        matches = [i for i in record['incorporation'] if i['unit'] == unit]
        if not matches:
            continue
        raw = (delta / record['local_capture_file']).read_bytes()
        assert len(raw) == record['byte_length']
        assert digest(raw) == record['sha256']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == record['git_blob_sha']
        if record['path'] in indexed:
            assert indexed[record['path']]['sha256'] == record['sha256']
        else:
            local = producer / record['local_capture_file']
            local.parent.mkdir(parents=True, exist_ok=True)
            local.write_bytes(raw)
            response_path = 'captures/resume-r2/' + Path(record['connector_response_file']).name
            response = producer / response_path
            response.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(delta / record['connector_response_file'], response)
            add = {k: v for k, v in record.items() if k not in ['incorporation', 'connector_response_file']}
            add['connector_response_file'] = response_path
            add['inspection_scope'] = 'Correction producer inspected exact source spans; see preserved correction response and decisive delta. No runtime execution.'
            records.append(add)
            indexed[record['path']] = add
        if record['path'] in assigned and matches[0]['coverage_action'] == 'promote-existing-entry-to-inspected':
            entry = assigned[record['path']]
            assert entry['sha'] == record['git_blob_sha']
            key = 'evidence_depth' if 'evidence_depth' in entry else 'evidence-depth'
            entry[key] = 'inspected'
            entry['reason'] = 'Exact source captured and inspected for the resumed L1 contract correction; see correction evidence. No exhaustive audit or runtime execution claimed.'
            if record['path'] not in entry['representative_source_paths']:
                entry['representative_source_paths'].insert(0, record['path'])
            family = next(f for f in coverage['families'] if f['id'] == entry['family'])
            if record['path'] not in family['representative_source_paths']:
                family['representative_source_paths'].append(record['path'])
    counts = dict(collections.Counter(e.get('evidence_depth', e.get('evidence-depth')) for e in coverage['entries']))
    if unit == family_delta['unit']:
        family = next(f for f in coverage['families'] if f['id'] == family_delta['family_id'])
        family.update(family_delta['updates'])
    for family in coverage['families']:
        family_counts = dict(collections.Counter(e.get('evidence_depth', e.get('evidence-depth')) for e in coverage['entries'] if e['family'] == family['id']))
        family['evidence_depth_counts' if 'evidence_depth_counts' in family else 'depth_counts'] = family_counts
    if unit == 'app-session':
        coverage['summary']['evidence_depths'] = counts
        sources['successful_captures'] = len(records)
        sources['assigned_source_captures'] = sum(r['path'] in assigned for r in records)
        sources['boundary_source_captures'] = sum(r['path'] not in assigned for r in records)
        sources['hash_method'] = 'Python hashlib.sha256 over exact captured content bytes; Git SHA-1 over blob header and bytes, compared with connector identity and frozen assigned tree. The initial 251 captures and resumed correction are preserved separately; current counts include four additional unique source captures.'
    if unit == 'design-tui':
        coverage['depth_counts'] = counts
    if unit != 'desktop-web':
        coverage['resumption_correction'] = 'Additional exact source and source-based contract detail; original classified population is unchanged. Previous bytes are preserved under history/l1-r1.'
        write(producer / 'coverage.json', coverage)
        write(producer / 'sources.json', sources)
    body = (delta / unit / 'l1.md').read_bytes()
    body.decode('utf-8')
    (producer / 'l1.md').write_bytes(body)
    # Keep old decisive evidence and append only this unit's new exact witnesses.
    evidence = (history / 'decisive-evidence.md').read_text()
    if unit == 'desktop-web':
        evidence += '\n\n' + (delta / 'decisive-delta-desktop.md').read_text()
    else:
        text = (delta / 'decisive-delta.md').read_text()
        sections = text.split('\n## ')
        selected = [s for s in sections[1:] if s.startswith('skills-' if unit == 'app-session' else 'tui-')]
        evidence += '\n\n# Resumed correction evidence\n' + ''.join('\n## ' + s for s in selected)
    (producer / 'decisive-evidence.md').write_text(evidence)
    shutil.copyfile(delta / 'producer-response.md', producer / 'response.md')
    destination = out / 'layers/l1' / unit
    for name in ['l1.md', 'coverage.json', 'sources.json', 'decisive-evidence.md', 'response.md']:
        shutil.copyfile(producer / name, destination / name)
    print(unit, len(body), digest(body), len(indexed), counts)
