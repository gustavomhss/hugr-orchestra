import { contextBridge, ipcRenderer, webUtils } from "electron"
import type { ElectronAPI, WslServersEvent } from "./types"
import type { UpdaterState } from "@orchestra/app/updater"
import { RESPONSE_DOWNLOAD_CHUNK_BYTES } from "./response-download"

let responseDownloadWriting = false

const updaterCallbacks = new Set<(state: UpdaterState) => void>()
let updaterState: UpdaterState | undefined
let updaterSubscription: Promise<void> | undefined
const updaterHandler = (_: unknown, state: UpdaterState) => {
  updaterState = state
  updaterCallbacks.forEach((callback) => callback(state))
}
// Main asks before it closes this window or quits, and waits for the answer at most 3 s. A handler that throws or
// rejects still lets the answer go.
const unloadHandlers = new Set<() => Promise<void>>()
ipcRenderer.on("before-unload", (_: unknown, id: string) => {
  void Promise.allSettled([...unloadHandlers].map((handler) => Promise.resolve().then(handler))).then(() =>
    ipcRenderer.send("before-unload-done", id),
  )
})

const api: ElectronAPI = {
  appDockLinuxOpen: (bounds, profile) => ipcRenderer.invoke("app-dock-linux-open", bounds, profile),
  appDockLinuxList: () => ipcRenderer.invoke("app-dock-linux-list"),
  appDockLinuxInstall: () => ipcRenderer.invoke("app-dock-linux-install"),
  appDockLinuxLaunch: (appID) => ipcRenderer.invoke("app-dock-linux-launch", appID),
  appDockLinuxWindows: (tabID, generation) => ipcRenderer.invoke("app-dock-linux-windows", tabID, generation),
  appDockLinuxFocus: (tabID, generation, windowID) =>
    ipcRenderer.invoke("app-dock-linux-focus", tabID, generation, windowID),
  appDockOpen: (url, bounds, profile) => ipcRenderer.invoke("app-dock-open", url, bounds, profile),
  appDockList: () => ipcRenderer.invoke("app-dock-list"),
  appDockDeleteProfile: (profileID) => ipcRenderer.invoke("app-dock-delete-profile", { profileID }),
  appDockResize: (tab, bounds) => ipcRenderer.invoke("app-dock-resize", tab, bounds),
  appDockHide: (tab) => ipcRenderer.invoke("app-dock-hide", tab),
  appDockOcclude: (occluded) => ipcRenderer.invoke("app-dock-occlude", occluded),
  appDockClose: () => ipcRenderer.invoke("app-dock-close"),
  appDockCloseTab: (tabID) => ipcRenderer.invoke("app-dock-close-tab", tabID),
  appDockRecoverTab: (tabID) => ipcRenderer.invoke("app-dock-recover-tab", tabID),
  appDockCloseTabs: (tabID, scope, order) => ipcRenderer.invoke("app-dock-close-tabs", tabID, scope, order),
  appDockSelect: (tab, bounds) => ipcRenderer.invoke("app-dock-select", tab, bounds),
  appDockNavigate: (tabID, url) => ipcRenderer.invoke("app-dock-navigate", tabID, url),
  appDockCommand: (tabID, command) => ipcRenderer.invoke("app-dock-command", tabID, command),
  appDockEvent: (callback) => {
    const handler = (_event: unknown, appDockEvent: Parameters<typeof callback>[0]) => callback(appDockEvent)
    ipcRenderer.on("app-dock-event", handler)
    return () => ipcRenderer.removeListener("app-dock-event", handler)
  },
  appDockFind: (tabID, text, forward) => ipcRenderer.invoke("app-dock-find", tabID, text, forward),
  appDockStopFind: (tabID) => ipcRenderer.invoke("app-dock-stop-find", tabID),
  appDockFindResult: (callback) => {
    const handler = (_event: unknown, result: Parameters<typeof callback>[0]) => callback(result)
    ipcRenderer.on("app-dock-find-result", handler)
    return () => ipcRenderer.removeListener("app-dock-find-result", handler)
  },
  appDockZoom: (tabID, factor) => ipcRenderer.invoke("app-dock-zoom", tabID, factor),
  appDockCancelDownload: (downloadID) => ipcRenderer.invoke("app-dock-cancel-download", downloadID),
  appDockOpenDownload: (downloadID) => ipcRenderer.invoke("app-dock-open-download", downloadID),
  appDockFullscreen: (tabID, enabled) => ipcRenderer.invoke("app-dock-fullscreen", tabID, enabled),
  appDockGetManifest: () => ipcRenderer.invoke("app-dock-get-manifest"),
  appDockUpdateManifest: (expectedRevision, manifest) =>
    ipcRenderer.invoke("app-dock-update-manifest", expectedRevision, manifest),
  killSidecar: () => ipcRenderer.invoke("kill-sidecar"),
  installCli: () => ipcRenderer.invoke("install-cli"),
  awaitInitialization: () => ipcRenderer.invoke("await-initialization"),
  wslServers: {
    getState: () => ipcRenderer.invoke("wsl-servers-get-state"),
    subscribe: (cb) => {
      const handler = (_: unknown, event: WslServersEvent) => cb(event)
      ipcRenderer.on("wsl-servers-event", handler)
      void ipcRenderer.invoke("wsl-servers-subscribe")
      return () => {
        ipcRenderer.removeListener("wsl-servers-event", handler)
        void ipcRenderer.invoke("wsl-servers-unsubscribe")
      }
    },
    probeRuntime: () => ipcRenderer.invoke("wsl-servers-probe-runtime"),
    refreshDistros: () => ipcRenderer.invoke("wsl-servers-refresh-distros"),
    installWsl: () => ipcRenderer.invoke("wsl-servers-install-wsl"),
    installDistro: (name) => ipcRenderer.invoke("wsl-servers-install-distro", name),
    probeAddable: (distros) => ipcRenderer.invoke("wsl-servers-probe-addable", distros),
    installServer: (name) => ipcRenderer.invoke("wsl-servers-install-server", name),
    openTerminal: (name) => ipcRenderer.invoke("wsl-servers-open-terminal", name),
    addServer: (distro) => ipcRenderer.invoke("wsl-servers-add", distro),
    removeServer: (id) => ipcRenderer.invoke("wsl-servers-remove", id),
    startServer: (id) => ipcRenderer.invoke("wsl-servers-start", id),
  },
  updater: {
    subscribe: async (cb) => {
      updaterCallbacks.add(cb)
      if (updaterState) cb(updaterState)
      if (!updaterSubscription) {
        ipcRenderer.on("updater-state", updaterHandler)
        updaterSubscription = ipcRenderer.invoke("updater-subscribe")
      }
      await updaterSubscription
      return () => {
        updaterCallbacks.delete(cb)
        if (updaterCallbacks.size > 0) return
        ipcRenderer.removeListener("updater-state", updaterHandler)
        updaterSubscription = undefined
        void ipcRenderer.invoke("updater-unsubscribe")
      }
    },
    check: () => ipcRenderer.invoke("updater-check"),
    install: () => ipcRenderer.invoke("updater-install"),
  },
  consumeInitialDeepLinks: () => ipcRenderer.invoke("consume-initial-deep-links"),
  getDefaultServerUrl: () => ipcRenderer.invoke("get-default-server-url"),
  setDefaultServerUrl: (url) => ipcRenderer.invoke("set-default-server-url", url),
  isFirstLaunchOnboardingPending: () => ipcRenderer.invoke("is-first-launch-onboarding-pending"),
  confirmFirstLaunchOnboarding: () => ipcRenderer.invoke("confirm-first-launch-onboarding"),
  isOldLayoutEligible: () => ipcRenderer.invoke("is-old-layout-eligible"),
  getDisplayBackend: () => ipcRenderer.invoke("get-display-backend"),
  setDisplayBackend: (backend) => ipcRenderer.invoke("set-display-backend", backend),
  checkAppExists: (appName) => ipcRenderer.invoke("check-app-exists", appName),
  resolveAppPath: (appName) => ipcRenderer.invoke("resolve-app-path", appName),
  storeGet: (name, key) => ipcRenderer.invoke("store-get", name, key),
  storeSet: (name, key, value) => ipcRenderer.invoke("store-set", name, key, value),
  storeDelete: (name, key) => ipcRenderer.invoke("store-delete", name, key),
  storeClear: (name) => ipcRenderer.invoke("store-clear", name),
  storeKeys: (name) => ipcRenderer.invoke("store-keys", name),
  storeLength: (name) => ipcRenderer.invoke("store-length", name),
  draftGet: (key) => ipcRenderer.invoke("draft-get", key),
  draftSet: (key, value) => ipcRenderer.invoke("draft-set", key, value),
  draftDelete: (key) => ipcRenderer.invoke("draft-delete", key),
  draftBlobPut: (data) => ipcRenderer.invoke("draft-blob-put", data),
  draftBlobGet: (id) => ipcRenderer.invoke("draft-blob-get", id),
  janitor: {
    getReport: () => ipcRenderer.invoke("janitor-get-report"),
    publish: (report, notify, source) => ipcRenderer.invoke("janitor-publish", report, notify, source),
    snooze: (minutes, source) => ipcRenderer.invoke("janitor-snooze", minutes, source),
    dismiss: (source) => ipcRenderer.invoke("janitor-dismiss", source),
    onReport: (cb) => {
      const handler = (_: unknown, report: string, notify = true, source: string | null = null) =>
        cb({ report, notify, source })
      ipcRenderer.on("janitor-report", handler)
      return () => ipcRenderer.removeListener("janitor-report", handler)
    },
  },

  getWindowID: () => ipcRenderer.invoke("get-window-id"),
  onBeforeUnload: (handler) => {
    unloadHandlers.add(handler)
    return () => void unloadHandlers.delete(handler)
  },
  onMenuCommand: (cb) => {
    const handler = (_: unknown, id: string) => cb(id)
    ipcRenderer.on("menu-command", handler)
    return () => ipcRenderer.removeListener("menu-command", handler)
  },
  onDeepLink: (cb) => {
    const handler = (_: unknown, urls: string[]) => cb(urls)
    ipcRenderer.on("deep-link", handler)
    return () => ipcRenderer.removeListener("deep-link", handler)
  },

  openDirectoryPicker: (opts) => ipcRenderer.invoke("open-directory-picker", opts),
  openFilePicker: (opts) => ipcRenderer.invoke("open-file-picker", opts),
  readPickedFile: (token, path) => ipcRenderer.invoke("read-picked-file", token, path),
  releasePickedFiles: (token) => ipcRenderer.invoke("release-picked-files", token),
  getPathForFile: (file) => webUtils.getPathForFile(file),
  saveFilePicker: (opts) => ipcRenderer.invoke("save-file-picker", opts),
  responseDownload: {
    start: (filename) => ipcRenderer.invoke("response-download-start", filename),
    ready: (handle) => ipcRenderer.invoke("response-download-ready", handle),
    write: async (handle, sequence, chunk) => {
      if (responseDownloadWriting || !(chunk instanceof ArrayBuffer) || chunk.byteLength === 0
        || chunk.byteLength > RESPONSE_DOWNLOAD_CHUNK_BYTES) return { status: "error", code: "transfer_failed" }
      responseDownloadWriting = true
      try {
        return await ipcRenderer.invoke("response-download-write", handle, sequence, chunk)
      } finally {
        responseDownloadWriting = false
      }
    },
    finish: (handle, sequence) => ipcRenderer.invoke("response-download-finish", handle, sequence),
    cancel: (handle) => ipcRenderer.invoke("response-download-cancel", handle),
  },
  openExternal: (url) => ipcRenderer.send("open-external", url),
  openLocalFile: (url) => ipcRenderer.send("open-local-file", url),
  openPath: (path, app) => ipcRenderer.invoke("open-path", path, app),
  revealPath: (path) => ipcRenderer.invoke("reveal-path", path),
  readClipboardImage: () => ipcRenderer.invoke("read-clipboard-image"),
  getWindowFocused: () => ipcRenderer.invoke("get-window-focused"),
  getWindowFullscreen: () => ipcRenderer.invoke("get-window-fullscreen"),
  onWindowFullscreenChanged: (cb) => {
    const handler = (_: unknown, fullscreen: boolean) => cb(fullscreen)
    ipcRenderer.on("window-fullscreen-changed", handler)
    return () => ipcRenderer.removeListener("window-fullscreen-changed", handler)
  },
  setWindowFocus: () => ipcRenderer.invoke("set-window-focus"),
  showWindow: () => ipcRenderer.invoke("show-window"),
  relaunch: () => ipcRenderer.send("relaunch"),
  getZoomFactor: () => ipcRenderer.invoke("get-zoom-factor"),
  setZoomFactor: (factor) => ipcRenderer.invoke("set-zoom-factor", factor),
  getLiveOverlayContentProtection: () => ipcRenderer.invoke("get-live-overlay-content-protection"),
  setLiveOverlayContentProtection: (enabled) => ipcRenderer.invoke("set-live-overlay-content-protection", enabled),
  startLiveMeeting: (title) => ipcRenderer.invoke("start-live-meeting", title),
  stopLiveMeeting: () => ipcRenderer.invoke("stop-live-meeting"),
  getLiveMeetingRunning: () => ipcRenderer.invoke("get-live-meeting-running"),
  hasLiveTranscriptionKey: () => ipcRenderer.invoke("has-live-transcription-key"),
  setLiveTranscriptionKey: (key) => ipcRenderer.invoke("set-live-transcription-key", key),
  getLiveReadiness: () => ipcRenderer.invoke("get-live-readiness"),
  requestLivePermission: (source) => ipcRenderer.invoke("request-live-permission", source),
  onLiveLevels: (cb) => {
    const handler = (_: unknown, levels: Parameters<typeof cb>[0]) => cb(levels)
    ipcRenderer.on("live-levels", handler)
    return () => ipcRenderer.removeListener("live-levels", handler)
  },
  getLiveRunState: () => ipcRenderer.invoke("get-live-run-state"),
  onLiveRunState: (cb) => {
    const handler = (_: unknown, state: Parameters<typeof cb>[0]) => cb(state)
    ipcRenderer.on("live-run-state-changed", handler)
    return () => ipcRenderer.removeListener("live-run-state-changed", handler)
  },
  renameLiveMeeting: (meetingID, title) => ipcRenderer.invoke("rename-live-meeting", meetingID, title),
  getLiveSettings: () => ipcRenderer.invoke("get-live-settings"),
  setLiveSettings: (patch) => ipcRenderer.invoke("set-live-settings", patch),
  getLiveHotkeys: () => ipcRenderer.invoke("get-live-hotkeys"),
  setLiveHotkey: (action, accelerator) => ipcRenderer.invoke("set-live-hotkey", action, accelerator),
  resetLiveHotkeys: () => ipcRenderer.invoke("reset-live-hotkeys"),
  getCaffeinate: () => ipcRenderer.invoke("get-caffeinate"),
  setCaffeinate: (enabled) => ipcRenderer.invoke("set-caffeinate", enabled),
  onCaffeinateChanged: (cb) => {
    const handler = (_: unknown, enabled: boolean) => cb(enabled)
    ipcRenderer.on("caffeinate-changed", handler)
    return () => ipcRenderer.removeListener("caffeinate-changed", handler)
  },
  getPinchZoomEnabled: () => ipcRenderer.invoke("get-pinch-zoom-enabled"),
  setPinchZoomEnabled: (enabled) => ipcRenderer.invoke("set-pinch-zoom-enabled", enabled),
  onPinchZoomEnabledChanged: (cb) => {
    const handler = (_: unknown, enabled: boolean) => cb(enabled)
    ipcRenderer.on("pinch-zoom-enabled-changed", handler)
    return () => ipcRenderer.removeListener("pinch-zoom-enabled-changed", handler)
  },
  onZoomFactorChanged: (cb) => {
    const handler = (_: unknown, factor: number) => cb(factor)
    ipcRenderer.on("zoom-factor-changed", handler)
    return () => ipcRenderer.removeListener("zoom-factor-changed", handler)
  },
  setTitlebar: (theme) => ipcRenderer.invoke("set-titlebar", theme),
  setTitlebarFrame: (frame) => ipcRenderer.invoke("set-titlebar-frame", frame),
  setMenuAvailability: (commands) => ipcRenderer.send("set-menu-availability", commands),
  runDesktopMenuAction: (action) => ipcRenderer.invoke("run-desktop-menu-action", action),
  setBackgroundColor: (color: string) => ipcRenderer.invoke("set-background-color", color),
  exportDebugLogs: () => ipcRenderer.invoke("export-debug-logs"),
  setForceFocus: (enabled) => ipcRenderer.invoke("set-force-focus", enabled),
  recordFatalRendererError: (error) => ipcRenderer.invoke("record-fatal-renderer-error", error),
  setNativeTranslations: (bundle) => ipcRenderer.invoke("set-native-translations", bundle),
}

contextBridge.exposeInMainWorld("api", api)
