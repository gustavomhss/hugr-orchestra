import type { ClientEvent } from "@/session-types"
import type { Event } from "@/v2-wire"
import { createSimpleContext } from "@orchestra/ui/context"
import { createGlobalEmitter } from "@solid-primitives/event-bus"
import { makeEventListener } from "@solid-primitives/event-listener"
import { type Accessor, type ParentProps, batch, createMemo, createSignal, onCleanup, onMount } from "solid-js"
import { Orchestra } from "@orchestra/client"
import { authTokenFromCredentials, createApiForServer, type ServerApi } from "@/utils/server"
import { type Platform, usePlatform } from "./platform"
import { ServerConnection, useServer } from "./server"
import { ServerRequired } from "@/components/server-unavailable"
import { createRefCountMap } from "@/utils/refcount"
import { useGlobal } from "./global"
import { ServerScope } from "@/utils/server-scope"
import { describeError } from "@/utils/server-errors"
import { waitForServer, type ServerReadyOptions } from "@/utils/server-ready"
import { createCompatibleApi, type CompatibleApi } from "@/utils/server-compat"
import { createSessionManagementForServer } from "@/utils/session-management"
import { createScopedFetch } from "@/utils/scoped-fetch"
import { clearStreamActivity, tapStreamActivity, watchStreamStall } from "@/utils/server-stream-liveness"
import { SessionEvent } from "@orchestra/schema/session-event"
import { createNativeEventAdapter } from "./server-event-native"
import { Schema } from "effect"

const isAbortError = (error: unknown) =>
  error !== null && typeof error === "object" && "name" in error && error.name === "AbortError"

const isStreamClosed = (error: unknown, signal?: AbortSignal) => isAbortError(error) || signal?.aborted === true
type NativeToolSuccess = Omit<Extract<ClientEvent, { type: "session.tool.success" }>, "durable"> & {
  durable?: Schema.Codec.Encoded<typeof SessionEvent.Tool.Success>["durable"]
}
export type ServerCurrentEvent = ClientEvent | NativeToolSuccess
export type ServerEvent = Event & { current?: ServerCurrentEvent }
type QueuedServerEvent = { directory: string; payload: ServerEvent }
type CurrentDelta = Extract<
  ClientEvent,
  { type: "session.text.delta" | "session.reasoning.delta" | "session.tool.input.delta" | "session.compaction.delta" }
>

export function adaptServerEvent(
  event: ServerCurrentEvent | Schema.Codec.Encoded<typeof SessionEvent.Tool.Success>,
): ServerEvent {
  // The bundled compatibility client predates the native tool event name and structured output.
  if (event.type === SessionEvent.Tool.Success.type) {
    const native = Schema.encodeSync(SessionEvent.Tool.Success)(
      Schema.decodeUnknownSync(SessionEvent.Tool.Success)(event),
    )
    return adaptServerEvent({
      id: native.id,
      type: "session.tool.success",
      created: native.data.timestamp,
      location: native.location,
      durable: native.durable,
      metadata: native.metadata,
      data: {
        sessionID: native.data.sessionID,
        assistantMessageID: native.data.assistantMessageID,
        callID: native.data.callID,
        executed: native.data.provider.executed,
        resultState: native.data.provider.metadata && Object.fromEntries(
          Object.entries(native.data.provider.metadata).map(([name, metadata]) => [name, compatibilityMetadata(metadata)]),
        ),
        metadata: compatibilityMetadata(native.data.structured),
        ...{ structured: native.data.structured },
        // The compatibility client requires a nonempty mutable tuple; empty native output stays empty text.
        content: [native.data.content[0] ?? { type: "text", text: "" }, ...native.data.content.slice(1)],
      },
    })
  }
  return { id: event.id, type: event.type, properties: event.data, current: event } as ServerEvent
}

function compatibilityMetadata(value: Readonly<Record<string, unknown>>): NonNullable<NativeToolSuccess["data"]["metadata"]> {
  return Object.fromEntries(Object.entries(Schema.decodeUnknownSync(Schema.Record(Schema.String, Schema.Json))(value))
    .map(([key, value]) => [key, compatibilityJson(value)]))
}

function compatibilityJson(value: Schema.Json): NonNullable<NativeToolSuccess["data"]["metadata"]>[string] {
  // Canonical JSON arrays are readonly; the bundled rendering client still requires mutable JSON values.
  if (Array.isArray(value)) return value.map(compatibilityJson)
  if (value !== null && typeof value === "object")
    return Object.fromEntries(Object.entries(value).map(([key, value]) => [key, compatibilityJson(value)]))
  return value
}

export function coalesceServerEvents(events: QueuedServerEvent[]) {
  const output: QueuedServerEvent[] = []
  events.forEach((event) => {
    const current = currentDelta(event.payload.current)
    if (current) {
      const previous = output[output.length - 1]
      const prior = currentDelta(previous?.payload.current)
      if (
        previous &&
        prior &&
        previous.directory === event.directory &&
        currentDeltaKey(prior) === currentDeltaKey(current)
      ) {
        const fragment = currentDeltaFragment(prior) + currentDeltaFragment(current)
        const data =
          current.type === "session.compaction.delta"
            ? { ...current.data, text: fragment }
            : { ...current.data, delta: fragment }
        output[output.length - 1] = {
          directory: event.directory,
          payload: {
            ...event.payload,
            properties: data,
            current: { ...current, data } as CurrentDelta,
          } as ServerEvent,
        }
        return
      }
      output.push(event)
      return
    }
    output.push(event)
  })
  return output
}

function currentDelta(event: ServerCurrentEvent | undefined): CurrentDelta | undefined {
  if (
    event?.type === "session.text.delta" ||
    event?.type === "session.reasoning.delta" ||
    event?.type === "session.tool.input.delta" ||
    event?.type === "session.compaction.delta"
  )
    return event
}

function currentDeltaKey(event: CurrentDelta) {
  if (event.type === "session.tool.input.delta")
    return `${event.type}:${event.data.sessionID}:${event.data.assistantMessageID}:${event.data.callID}`
  if (event.type === "session.compaction.delta") return `${event.type}:${event.data.sessionID}`
  return `${event.type}:${event.data.sessionID}:${event.data.assistantMessageID}:${event.data.ordinal}`
}

function currentDeltaFragment(event: CurrentDelta) {
  return event.type === "session.compaction.delta" ? event.data.text : event.data.delta
}

export function resumeStreamAfterPageShow(event: PageTransitionEvent, start: () => unknown) {
  if (!event.persisted) return
  start()
}

type ServerEventEmitter = ReturnType<typeof createGlobalEmitter<{ [key: string]: ServerEvent }>>
type ServerSDKBase = {
  server: ServerConnection.Any
  scope: ServerScope
  /** Settles once the server health endpoint reports ready; a rejected link is retried by the next consumer. */
  ready: Promise<void>
  isReady: Accessor<boolean>
  url: string
  api: CompatibleApi
  currentApi: ServerApi
  sessionManagement: ReturnType<typeof createSessionManagementForServer>
  orchestra: ReturnType<typeof Orchestra.make>
  event: {
    on: ServerEventEmitter["on"]
    listen: ServerEventEmitter["listen"]
    start: () => Promise<void> | undefined
  }
}

export function createServerReadyPromise(
  server: ServerConnection.HttpBase,
  fetcher: typeof fetch,
  options: ServerReadyOptions = {},
  onReady?: () => void,
) {
  // Every consumer retries a failed detection; consecutive failures back off so an unreachable server is not probed in
  // a loop. The first retry is immediate.
  const failed = { count: 0, at: 0 }
  return connectionPromise(async () => {
    const delay =
      failed.count < 2 ? 0 : Math.min(READY_RETRY_MS * 2 ** (failed.count - 2), READY_RETRY_MAX_MS) - (Date.now() - failed.at)
    if (delay > 0) await new Promise((resolve) => setTimeout(resolve, delay))
    return waitForServer(server, fetcher, options).then(
      () => {
        failed.count = 0
        onReady?.()
      },
      (error: unknown) => {
        failed.count++
        failed.at = Date.now()
        throw error
      },
    )
  })
}

const READY_RETRY_MS = 1_000
const READY_RETRY_MAX_MS = 30_000

// Consumers retain both this promise and derived .then chains (including the compatibility API).
// Cache pending/successful results at each link, but let the next consumer retry a rejected link.
function connectionPromise<T>(load: () => Promise<T>): Promise<T> {
  let current: Promise<T> | undefined
  const read = () => {
    if (current) return current
    const next = load().catch((error: unknown) => {
      if (current === next) current = undefined
      throw error
    })
    current = next
    // Construction is eager; failures remain observable without an unhandled eager rejection.
    void next.catch(() => undefined)
    return next
  }
  read()
  return {
    then(onfulfilled, onrejected) {
      return connectionPromise(() => read().then(onfulfilled, onrejected))
    },
    catch(onrejected) {
      return connectionPromise(() => read().catch(onrejected))
    },
    finally(onfinally) {
      return connectionPromise(() => read().finally(onfinally))
    },
    [Symbol.toStringTag]: "Promise",
  }
}

function createServerSdkContextBase(
  server: ServerConnection.Any,
  scope: ServerScope,
  platform: Platform,
): ServerSDKBase {
  const abort = new AbortController()
  const http = { ...server.http }
  const scopedFetch = (fetcher = platform.fetch ?? globalThis.fetch): typeof fetch =>
    createScopedFetch(fetcher, abort.signal)

  const eventFetch = (() => {
    if (!platform.fetch || !server) return
    try {
      const url = new URL(server.http.url)
      const loopback = url.hostname === "localhost" || url.hostname === "127.0.0.1" || url.hostname === "::1"
      if (url.protocol === "http:" && !loopback) return platform.fetch
    } catch {
      return
    }
  })()

  const eventApi = createApiForServer({
    server: http,
    fetch: scopedFetch(tapStreamActivity(eventFetch ?? globalThis.fetch, server.http.url)),
  })
  const [isReady, setReady] = createSignal(false)
  const ready = createServerReadyPromise(http, scopedFetch(), { signal: abort.signal }, () => setReady(true))
  const emitter = createGlobalEmitter<{
    [key: string]: ServerEvent
  }>()

  type Queued = QueuedServerEvent
  const FLUSH_FRAME_MS = 16
  const STREAM_YIELD_MS = 8
  const RECONNECT_DELAY_MS = 250
  const RECONNECT_MAX_DELAY_MS = 30_000

  let queue: Queued[] = []
  let buffer: Queued[] = []
  let timer: ReturnType<typeof setTimeout> | undefined
  let last = 0

  const flush = () => {
    if (timer) clearTimeout(timer)
    timer = undefined

    if (queue.length === 0) return

    const events = queue
    queue = buffer
    buffer = events
    queue.length = 0

    last = Date.now()
    const output = coalesceServerEvents(events)
    batch(() => {
      output.forEach((event) => emitter.emit(event.directory, event.payload))
    })

    buffer.length = 0
  }

  const schedule = () => {
    if (timer) return
    const elapsed = Date.now() - last
    timer = setTimeout(flush, Math.max(0, FLUSH_FRAME_MS - elapsed))
  }

  let streamErrorLogged = false
  const native = createNativeEventAdapter()
  const wait = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms))
  let attempt: AbortController | undefined
  let backoff: (() => void) | undefined
  let run: Promise<void> | undefined
  let started = false
  let generation = 0

  const start = () => {
    if (started) return run
    started = true
    const active = ++generation
    const previous = run
    const current = (async () => {
      if (previous) await previous
      // Consecutive attempts that deliver no event back off, so an unreachable server is not asked in a loop.
      let failures = 0
      // oxlint-disable-next-line no-unmodified-loop-condition -- `started` is set to false by stop() which also aborts; both flags are checked to allow graceful exit
      while (!abort.signal.aborted && started && generation === active) {
        attempt = new AbortController()
        const onAbort = () => {
          attempt?.abort()
        }
        abort.signal.addEventListener("abort", onAbort)
        // A half-open connection raises no error, so a silent stream is cut here and reconnected.
        const stopWatch = watchStreamStall({
          url: server.http.url,
          attempt,
          onStall: () => console.warn(`[global-sdk] event stream stalled, reconnecting: ${server.http.url}`),
        })
        try {
          const events = eventApi.event.subscribe({ signal: attempt.signal })
          let yielded = Date.now()
          for await (const event of events) {
            if (abort.signal.aborted || !started || generation !== active) return
            streamErrorLogged = false
            failures = 0
            const directory = event.location?.directory ?? "global"
            const payload = adaptServerEvent(native(event) ?? event)
            queue.push({ directory, payload })
            schedule()

            if (Date.now() - yielded < STREAM_YIELD_MS) continue
            yielded = Date.now()
            await wait(0)
          }
          // The server closed the stream, e.g. after its bounded queue overflowed on a slow reader.
          if (!attempt.signal.aborted) console.warn(`[global-sdk] event stream ended, reconnecting: ${server.http.url}`)
        } catch (error) {
          if (!isStreamClosed(error, attempt?.signal) && !streamErrorLogged) {
            streamErrorLogged = true
            // One string: electron-log writes an object argument as "[object Object]".
            console.error(
              `[global-sdk] event stream failed (${eventFetch ? "platform" : "webview"} fetch, ${server.http.url}): ${describeError(error)}`,
            )
          }
        } finally {
          stopWatch()
          // A dead stream is no evidence the server is up, so health polling decides alone until it reconnects.
          clearStreamActivity(server.http.url)
          abort.signal.removeEventListener("abort", onAbort)
          attempt = undefined
        }

        if (abort.signal.aborted || !started || generation !== active) return
        // stop() cuts the pause short, so a restarted stream does not wait out the backoff of the one it replaces.
        await new Promise<void>((resolve) => {
          backoff = resolve
          setTimeout(resolve, Math.min(RECONNECT_DELAY_MS * 2 ** failures++, RECONNECT_MAX_DELAY_MS))
        })
        backoff = undefined
      }
    })().finally(() => {
      if (run !== current) return
      run = undefined
      flush()
    })
    run = current
    return run
  }

  const stop = () => {
    started = false
    generation++
    attempt?.abort()
    backoff?.()
  }

  onMount(() => {
    makeEventListener(window, "pagehide", stop)
    makeEventListener(window, "pageshow", (event) => resumeStreamAfterPageShow(event, start))
  })

  onCleanup(() => {
    stop()
    abort.abort()
    if (timer) clearTimeout(timer)
    queue.length = 0
    buffer.length = 0
  })

  const currentApi: ServerApi = createApiForServer({ server: http, fetch: scopedFetch() })
  // Routes only the Orchestra V2 server serves (the bundled client predates them).
  const orchestra = Orchestra.make({
    baseUrl: http.url,
    fetch: scopedFetch(),
    headers: http.password
      ? { Authorization: `Basic ${authTokenFromCredentials({ username: http.username, password: http.password })}` }
      : undefined,
  })
  const sessionManagement = createSessionManagementForServer({
    server: http,
    fetch: scopedFetch(),
    ready,
    signal: abort.signal,
  })
  const api = createCompatibleApi({ current: currentApi })

  return {
    server,
    scope,
    ready,
    isReady,
    url: server.http.url,
    api,
    currentApi,
    sessionManagement,
    orchestra,
    event: {
      on: emitter.on.bind(emitter),
      listen: emitter.listen.bind(emitter),
      start,
    },
  }
}

export type ServerSDK = ServerSDKBase & {
  ensureDirSdkContext: (directory: string) => ReturnType<typeof createDirSdkContext>
}

export function createServerSdkContext(
  server: ServerConnection.Any,
  scope: ServerScope,
  platform = usePlatform(),
): ServerSDK {
  const sdk = createServerSdkContextBase(server, scope, platform)
  return Object.assign(sdk, {
    ensureDirSdkContext: createRefCountMap((dir) => createDirSdkContext(dir, sdk)),
  })
}

const ServerSDKContext = createSimpleContext({
  name: "ServerSDK",
  // Returns an accessor so the resolved server can change reactively (e.g. a
  // /new-session draft retargeting its server) without re-instantiating the subtree.
  init: (props: { server?: Accessor<ServerConnection.Any | undefined>; value?: ServerSDK }) => {
    const captured = props.value
    if (captured) return () => captured
    const global = useGlobal()
    const server = useServer()

    return createMemo<ServerSDK>(() => {
      const conn = props.server?.() ?? server.current
      // ServerRequired renders the unavailable state before this provider mounts without a connection.
      if (!conn) throw new Error("No server connection resolved")
      return global.ensureServerCtx(conn).sdk
    })
  },
})

export const useServerSDK = ServerSDKContext.use

export function ServerSDKProvider(props: ParentProps<Parameters<typeof ServerSDKContext.provider>[0]>) {
  return (
    <ServerRequired server={props.server} value={props.value}>
      <ServerSDKContext.provider {...props}>{props.children}</ServerSDKContext.provider>
    </ServerRequired>
  )
}

export function useServerReady() {
  const serverSDK = useServerSDK()
  return createMemo(() => serverSDK().isReady())
}

type SDKEventMap = {
  [key in Event["type"]]: Extract<ServerEvent, { type: key }>
}

function createDirSdkContext(directory: string, serverSDK: ServerSDKBase) {
  const emitter = createGlobalEmitter<SDKEventMap>()

  const unsub = serverSDK.event.on(directory, (event) => {
    emitter.emit(event.type, event)
  })
  onCleanup(unsub)

  return {
    scope: serverSDK.scope,
    ready: serverSDK.ready,
    directory,
    orchestra: serverSDK.orchestra,
    api: createCompatibleApi({
      current: serverSDK.currentApi,
      directory,
    }),
    event: emitter,
    get url() {
      return serverSDK.url
    },
  }
}
