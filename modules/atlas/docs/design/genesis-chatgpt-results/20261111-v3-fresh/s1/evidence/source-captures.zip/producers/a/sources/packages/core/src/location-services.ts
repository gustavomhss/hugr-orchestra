import { Context, Deferred, Effect, Layer, LayerMap } from "effect"
import { AgentV2 } from "./agent"
import { Actions } from "./actions"
import { AISDK } from "./aisdk"
import { BehaviorV2 } from "./behavior"
import { Catalog } from "./catalog"
import { CommandV2 } from "./command"
import { Config } from "./config"
import { LayerNode } from "./effect/layer-node"
import { Node } from "./effect/app-node"
import { FileMutation } from "./file-mutation"
import { FileSystem } from "./filesystem"
import { Format } from "./format"
import { FileSystemSearch } from "./filesystem/search"
import { Watcher } from "./filesystem/watcher"
import { Image } from "./image"
import { Integration } from "./integration"
import { Location } from "./location"
import { LocationMutation } from "./location-mutation"
import { LSP } from "./lsp"
import { Guardrail } from "./guardrail"
import { LocationServiceMap } from "./location-service-map"
import { Mcp } from "./mcp"
import { PermissionV2 } from "./permission"
import { PluginV2 } from "./plugin"
import { PluginInternal } from "./plugin/internal"
import { Policy } from "./policy"
import { ProjectCopy } from "./project/copy"
import { PullRequest } from "./pull-request"
import { Pty } from "./pty"
import { QuestionV2 } from "./question"
import { Reference } from "./reference"
import { ReferenceGuidance } from "./reference/guidance"
import { Relay } from "./relay"
import { RelayHookRecovery } from "./relay-hook-recovery"
import { SessionCompaction } from "./session/compaction"
import * as SessionRunnerLLM from "./session/runner/llm"
import { SessionRunnerModel } from "./session/runner/model"
import { SessionMeeting } from "./session/meeting"
import { MeetingBriefing } from "./session/meeting-briefing"
import { MeetingConsolidation } from "./session/meeting-consolidation"
import { MeetingContext } from "./session/meeting-context"
import { MeetingHandoff } from "./session/meeting-handoff"
import { SessionTodo } from "./session/todo"
import { SkillV2 } from "./skill"
import { SkillGuidance } from "./skill/guidance"
import { Snapshot } from "./snapshot"
import { SystemContextBuiltIns } from "./system-context/builtins"
import { SystemContextRegistry } from "./system-context/registry"
import { BuiltInTools } from "./tool/builtins"
import { ReadToolFileSystem } from "./tool/read-filesystem"
import { TaskGovernance } from "./tool/task-governance"
import { ToolRegistry } from "./tool/registry"
import { ToolOutputStore } from "./tool-output-store"

export { LocationServiceMap } from "./location-service-map"

export const locationServices = LayerNode.group([
  Location.node,
  Policy.node,
  Config.node,
  AgentV2.node,
  CommandV2.node,
  Reference.node,
  Integration.node,
  Catalog.node,
  AISDK.node,
  PluginV2.node,
  PluginInternal.node,
  ProjectCopy.node,
  ProjectCopy.refreshNode,
  PullRequest.node,
  Guardrail.node,
  Actions.node,
  FileSystemSearch.node,
  FileSystem.node,
  Watcher.node,
  Pty.node,
  SkillV2.node,
  SystemContextRegistry.node,
  SystemContextBuiltIns.node,
  BehaviorV2.node,
  LocationMutation.node,
  FileMutation.node,
  PermissionV2.node,
  ToolOutputStore.node,
  ToolRegistry.node,
  ToolRegistry.toolsNode,
  Image.node,
  SkillGuidance.node,
  ReferenceGuidance.node,
  SessionTodo.node,
  SessionMeeting.node,
  MeetingBriefing.node,
  MeetingContext.node,
  MeetingHandoff.node,
  QuestionV2.node,
  ReadToolFileSystem.node,
  BuiltInTools.node,
  Mcp.node,
  LSP.node,
  Format.node,
  SessionRunnerModel.node,
  Snapshot.node,
  Relay.node,
  RelayHookRecovery.node,
  TaskGovernance.node,
  SessionCompaction.node,
  SessionRunnerLLM.node,
  MeetingConsolidation.node,
])

export type LocationServices = LayerNode.Output<typeof locationServices>
export type LocationError = LayerNode.Error<typeof locationServices>

export function buildLocationServiceMap(
  replacements: LayerNode.Replacements = [],
  extra: ReadonlyArray<Node.LocationNode<unknown, LocationError>> = [],
): Layer.Layer<LocationServiceMap.Service> {
  return Layer.effect(
    LocationServiceMap.Service,
    Effect.gen(function* () {
      // A hoisted global (for example Arsenal observations) may depend on the Location map itself. Its node is
      // unbound inside the hoisted graph, so it is bound to this map once the map exists.
      const self = Deferred.makeUnsafe<Context.Service.Shape<typeof LocationServiceMap.Service>>()
      const locations = yield* LayerMap.make(
        (ref: Location.Ref) => {
          const allReplacements: LayerNode.Replacements = [
            [ToolRegistry.node, ToolRegistry.nativeNode],
            [ToolRegistry.toolsNode, ToolRegistry.nativeToolsNode],
            ...replacements,
            [Location.node, Location.boundNode(ref)],
          ]
          // Apply replacements during hoist, not afterward: replacements can
          // introduce new tagged dependencies (Location.boundNode depends on
          // Project), and the hoist walk is the only pass that can still slice
          // those back out.
          const location = LayerNode.hoist(LayerNode.group([locationServices, ...extra]), Node.tags.values.global, allReplacements)
          // Contributed nodes (Host.Contribution.locationNodes) add services; the map still exposes LocationServices.
          const services: Layer.Layer<LocationServices, LocationError> = LayerNode.compile(location.node)

          return services.pipe(
            Layer.fresh,
            Layer.tap((context) =>
              Effect.gen(function* () {
                const recovery = Context.get(context, RelayHookRecovery.Service)
                yield* Effect.logInfo("booting location services", {
                  directory: ref.directory,
                  workspaceID: ref.workspaceID,
                })
                // Start only after the entire graph succeeds; the Location scope owns this one pass.
                yield* recovery.recover().pipe(Effect.forkScoped)
              }),
            ),
            Layer.provide(
              LayerNode.compile(location.hoisted, [
                [LocationServiceMap.node, Layer.effect(LocationServiceMap.Service, Deferred.await(self))],
              ]),
            ),
          )
        },
        { idleTimeToLive: "60 minutes" },
      )
      yield* Deferred.succeed(self, locations)
      return locations
    }),
  )
}

// This is temporary for backwards compatibility
export const locationServiceMapLayer = buildLocationServiceMap()
