import { Catalog } from "@orchestra/core/catalog"
import { Integration } from "@orchestra/core/integration"
import { Location } from "@orchestra/core/location"
import { ProjectCopy } from "@orchestra/core/project/copy"
import { Git } from "@orchestra/core/git"
import { SessionRunnerModel } from "@orchestra/core/session/runner"
import { Slug } from "@orchestra/core/util/slug"
import { LLM, LLMClient, LLMEvent, SystemPart } from "@orchestra/llm"
import { SessionID } from "@orchestra/schema/session-id"
import { Effect, Stream } from "effect"
import { HttpApiBuilder, HttpApiSchema } from "effect/unstable/httpapi"
import { Api } from "../api"
import { ProjectCopyError } from "@orchestra/protocol/groups/project-copy"

export const ProjectCopyHandler = HttpApiBuilder.group(Api, "server.projectCopy", (handlers) =>
  Effect.gen(function* () {
    const client = yield* LLMClient.Service
    // The Location's small model names the copy; any failure falls back to a random slug.
    const generateName = Effect.fn("ProjectCopyHandler.generateName")(function* (context: string | undefined) {
      const text = context?.trim()
      if (!text) return Slug.create()
      const catalog = yield* Catalog.Service
      const integrations = yield* Integration.Service
      const fallback = yield* catalog.model.default()
      if (!fallback) return Slug.create()
      const selected = (yield* catalog.model.small(fallback.providerID)) ?? fallback
      const model = yield* SessionRunnerModel.fromCatalogModel(
        selected,
        yield* SessionRunnerModel.credential(catalog, integrations, selected),
      )
      // Gateways such as OpenCode Go refuse a request without a session to route it by; each call is its own.
      const sessionID = SessionID.descending()
      const reply = yield* client
        .stream(
          LLM.request({
            model,
            http: { headers: SessionRunnerModel.sessionHeaders(model, sessionID) },
            system: [SystemPart.make(ProjectCopy.NAME_SYSTEM)],
            prompt: ProjectCopy.namePrompt(text),
          }),
        )
        .pipe(
          Stream.filter(LLMEvent.is.textDelta),
          Stream.map((event) => event.text),
          Stream.mkString,
        )
      return ProjectCopy.nameFromReply(reply)
    })
    return handlers
      .handle("projectCopy.create", (ctx) =>
        Effect.gen(function* () {
          const copies = yield* ProjectCopy.Service
          const location = yield* Location.Service
          return yield* badRequest(
            copies.create({
              ...ctx.payload,
              projectID: ctx.params.projectID,
              sourceDirectory: location.project.directory,
            }),
          )
        }),
      )
      .handle("projectCopy.remove", (ctx) =>
        ProjectCopy.Service.use((copies) =>
          badRequest(copies.remove({ ...ctx.payload, projectID: ctx.params.projectID })).pipe(
            Effect.as(HttpApiSchema.NoContent.make()),
          ),
        ),
      )
      .handle("projectCopy.refresh", (ctx) =>
        ProjectCopy.Service.use((copies) =>
          badRequest(copies.refresh({ projectID: ctx.params.projectID })).pipe(
            Effect.as(HttpApiSchema.NoContent.make()),
          ),
        ),
      )
      .handle("projectCopy.generateName", (ctx) =>
        generateName(ctx.payload.context).pipe(
          Effect.catchCause((cause) =>
            Effect.logWarning("project copy name generation failed", { projectID: ctx.params.projectID, cause }).pipe(
              Effect.as(Slug.create()),
            ),
          ),
          Effect.map((name) => ({ name })),
        ),
      )
  }),
)

function badRequest<A, R>(effect: Effect.Effect<A, ProjectCopy.Error, R>) {
  return effect.pipe(
    Effect.mapError(
      (error) =>
        new ProjectCopyError({
          name: "ProjectCopyError",
          data: {
            message: message(error),
            forceRequired: error instanceof Git.WorktreeError ? error.forceRequired : undefined,
          },
        }),
    ),
  )
}

function message(error: ProjectCopy.Error) {
  if (error instanceof ProjectCopy.SourceDirectoryNotFoundError)
    return `Project copy source not found: ${error.directory}`
  if (error instanceof ProjectCopy.DestinationExistsError)
    return `Project copy destination already exists: ${error.directory}`
  if (error instanceof ProjectCopy.DirectoryUnavailableError)
    return `Project copy directory unavailable: ${error.directory}`
  if (error instanceof ProjectCopy.InvalidDirectoryError) return `Invalid project copy directory: ${error.directory}`
  if (error instanceof ProjectCopy.StrategyUnavailableError)
    return `Project copy strategy unavailable: ${error.strategy}`
  return error.message
}
