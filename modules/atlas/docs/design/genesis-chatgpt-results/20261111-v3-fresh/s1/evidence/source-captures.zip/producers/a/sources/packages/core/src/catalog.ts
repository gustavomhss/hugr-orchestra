export * as Catalog from "./catalog"

import { makeLocationNode } from "./effect/app-node"
import { Array, Context, Effect, Layer, Option, Order, pipe, Schema } from "effect"
import { Catalog } from "@orchestra/schema/catalog"
import { Credential } from "./credential"
import { ModelV2 } from "./model"
import { ProviderV2 } from "./provider"
import { EventV2 } from "./event"
import { Policy } from "./policy"
import { State } from "./state"
import { Integration } from "./integration"

export const VIRTUAL_SEPARATOR = "#"

export const parseVirtualID = (id: ProviderV2.ID) => {
  const index = id.indexOf(VIRTUAL_SEPARATOR)
  if (index === -1) return undefined
  return {
    base: id.slice(0, index) as ProviderV2.ID,
    credentialID: id.slice(index + 1),
  }
}

export type ProviderRecord = {
  provider: ProviderV2.MutableInfo
  models: Map<ModelV2.ID, ModelV2.MutableInfo>
}

export type DefaultModel = { providerID: ProviderV2.ID; modelID: ModelV2.ID }

export const PolicyActions = Schema.Literals(["provider.use"])

export const Event = Catalog.Event

type Data = {
  providers: Map<ProviderV2.ID, ProviderRecord>
  defaultModel?: DefaultModel
}

export type Draft = {
  provider: {
    list: () => readonly ProviderRecord[]
    get: (providerID: ProviderV2.ID) => ProviderRecord | undefined
    update: (providerID: ProviderV2.ID, fn: (provider: ProviderV2.MutableInfo) => void) => void
    remove: (providerID: ProviderV2.ID) => void
  }
  model: {
    get: (providerID: ProviderV2.ID, modelID: ModelV2.ID) => ModelV2.Info | undefined
    update: (providerID: ProviderV2.ID, modelID: ModelV2.ID, fn: (model: ModelV2.MutableInfo) => void) => void
    remove: (providerID: ProviderV2.ID, modelID: ModelV2.ID) => void
    default: {
      get: () => DefaultModel | undefined
      set: (providerID: ProviderV2.ID, modelID: ModelV2.ID) => void
    }
  }
}

export interface Interface extends State.Transformable<Draft> {
  readonly provider: {
    readonly get: (providerID: ProviderV2.ID) => Effect.Effect<ProviderV2.Info | undefined>
    readonly all: () => Effect.Effect<ProviderV2.Info[]>
    readonly available: () => Effect.Effect<ProviderV2.Info[]>
  }
  readonly model: {
    readonly get: (providerID: ProviderV2.ID, modelID: ModelV2.ID) => Effect.Effect<ModelV2.Info | undefined>
    readonly all: () => Effect.Effect<ModelV2.Info[]>
    readonly available: () => Effect.Effect<ModelV2.Info[]>
    readonly default: () => Effect.Effect<ModelV2.Info | undefined>
    readonly small: (providerID: ProviderV2.ID) => Effect.Effect<ModelV2.Info | undefined>
  }
}

export class Service extends Context.Service<Service, Interface>()("@orchestra/v2/Catalog") {}

const layer = Layer.effect(
  Service,
  Effect.gen(function* () {
    const events = yield* EventV2.Service
    const policy = yield* Policy.Service
    const integrations = yield* Integration.Service
    const credentials = yield* Credential.Service

    const available = (provider: ProviderV2.Info, integration: Integration.Info | undefined) => {
      if (provider.disabled) return false
      const key = provider.request.body.apiKey ?? provider.api.settings?.apiKey
      if (typeof key === "string" && (provider.id !== ProviderV2.ID.opencode || (key.length > 0 && key !== "public")))
        return true
      if (integration?.connections.length) return true
      if (provider.id === ProviderV2.ID.opencode) return false
      return provider.integrationID === undefined && !integration
    }

    const projectModel = (model: ModelV2.Info, provider: ProviderV2.Info) => {
      // A model without its own package takes the provider's, and its own URL when it has one.
      const api =
        model.api.type === "native" && Object.keys(model.api.settings).length === 0 && provider.api.type === "aisdk"
          ? { ...provider.api, id: model.api.id, url: model.api.url ?? provider.api.url }
          : model.api.type === "native" && !model.api.url && Object.keys(model.api.settings).length === 0
          ? { ...provider.api, id: model.api.id }
          : model.api.type === "aisdk" && provider.api.type === "aisdk" && !model.api.url
            ? { ...model.api, url: provider.api.url, settings: { ...provider.api.settings, ...model.api.settings } }
            : model.api.type === "aisdk" && provider.api.type === "aisdk"
              ? { ...model.api, settings: { ...provider.api.settings, ...model.api.settings } }
              : model.api
      const request = {
        headers: { ...provider.request.headers, ...model.request.headers },
        body: { ...provider.request.body, ...model.request.body },
        variant: model.request.variant,
      }
      return ModelV2.Info.make({
        ...model,
        api,
        request,
      })
    }

    const normalizeApi = (item: ProviderV2.MutableInfo | ModelV2.MutableInfo) => {
      if (typeof item.request.body.baseURL !== "string") return
      item.api.url = item.request.body.baseURL
      delete item.request.body.baseURL
    }

    const state = State.create<Data, Draft>({
      initial: () => ({ providers: new Map() }),
      draft: (draft) => {
        const result: Draft = {
          provider: {
            list: () => Array.fromIterable(draft.providers.values()) as ProviderRecord[],
            get: (providerID) => draft.providers.get(providerID),
            update: (providerID, fn) => {
              let current = draft.providers.get(providerID)
              if (!current) {
                current = {
                  provider: ProviderV2.Info.empty(providerID) as ProviderV2.MutableInfo,
                  models: new Map<ModelV2.ID, ModelV2.MutableInfo>(),
                }
                draft.providers.set(providerID, current)
              }
              fn(current.provider)
              normalizeApi(current.provider)
            },
            remove: (providerID) => {
              draft.providers.delete(providerID)
            },
          },
          model: {
            get: (providerID, modelID) => draft.providers.get(providerID)?.models.get(modelID),
            update: (providerID, modelID, fn) => {
              let record = draft.providers.get(providerID)
              if (!record) {
                record = {
                  provider: ProviderV2.Info.empty(providerID) as ProviderV2.MutableInfo,
                  models: new Map<ModelV2.ID, ModelV2.MutableInfo>(),
                }
                draft.providers.set(providerID, record)
              }
              const model =
                record.models.get(modelID) ?? (ModelV2.Info.empty(providerID, modelID) as ModelV2.MutableInfo)
              if (!record.models.has(modelID)) record.models.set(modelID, model)
              fn(model)
              model.id = modelID
              model.providerID = providerID
              normalizeApi(model)
            },
            remove: (providerID, modelID) => {
              draft.providers.get(providerID)?.models.delete(modelID)
            },
            default: {
              get: () => draft.defaultModel,
              set: (providerID, modelID) => {
                draft.defaultModel = { providerID, modelID }
              },
            },
          },
        }
        return result
      },
      finalize: Effect.fn("CatalogV2.finalize")(function* (catalog) {
        if (policy.hasStatements()) {
          for (const record of [...catalog.provider.list()]) {
            if ((yield* policy.evaluate("provider.use", record.provider.id, "allow")) === "deny") {
              catalog.provider.remove(record.provider.id)
            }
          }
        }
        yield* events.publish(Event.Updated, {})
      }),
    })

    // Projects one virtual provider per labeled API-key credential so each
    // key is independently selectable. Unlabeled credentials keep the legacy
    // behavior of merging into the base provider entry.
    const virtualEntries = Effect.fn("CatalogV2.virtuals")(function* () {
      const keyed = (yield* credentials.all()).filter(
        (credential) => credential.value.type === "key" && credential.label !== "default",
      )
      if (keyed.length === 0) return [] as ProviderRecord[]
      const records = state.get().providers
      const byIntegration = new Map<string, ProviderRecord[]>()
      for (const record of records.values()) {
        const owner = record.provider.integrationID ?? record.provider.id
        const list = byIntegration.get(owner) ?? []
        list.push(record)
        byIntegration.set(owner, list)
      }
      const entries: ProviderRecord[] = []
      for (const credential of keyed) {
        for (const record of byIntegration.get(credential.integrationID) ?? []) {
          const id = `${record.provider.id}${VIRTUAL_SEPARATOR}${credential.id}` as ProviderV2.ID
          entries.push({
            provider: {
              ...record.provider,
              id,
              name: `${record.provider.name} (${credential.label})`,
              integrationID: record.provider.integrationID ?? Integration.ID.make(record.provider.id),
            },
            models: record.models,
          })
        }
      }
      return entries
    })

    // These take the virtual entries as input so one request reads credentials once
    // instead of once per helper (credentials.all hits the DB and decrypts).
    const availableProviders = Effect.fn("CatalogV2.provider.availableWith")(function* (virtuals: ProviderRecord[]) {
      const virtualIDs = new Set(virtuals.map((entry) => entry.provider.id))
      const active = new Map((yield* integrations.list()).map((integration) => [integration.id, integration]))
      const base = Array.fromIterable(state.get().providers.values()).map((record) => record.provider)
      return [...base, ...virtuals.map((entry) => entry.provider)].filter((provider) => {
        if (virtualIDs.has(provider.id)) return !provider.disabled
        return available(provider, active.get(provider.integrationID ?? Integration.ID.make(provider.id)))
      })
    })

    const projectModels = (virtuals: ProviderRecord[]) =>
      pipe(
        [...Array.fromIterable(state.get().providers.values()), ...virtuals],
        Array.flatMap((record) => {
          const parsed = parseVirtualID(record.provider.id)
          return Array.fromIterable(record.models.values()).map((model) =>
            projectModel(parsed ? { ...model, providerID: record.provider.id } : model, record.provider),
          )
        }),
        Array.sortWith((item) => item.time.released, Order.flip(Order.Number)),
      )

    const result: Interface = {
      transform: state.transform,
      reload: state.reload,

      provider: {
        get: Effect.fn("CatalogV2.provider.get")(function* (providerID) {
          const hit = state.get().providers.get(providerID)?.provider
          if (hit) return hit
          if (!parseVirtualID(providerID)) return undefined
          return (yield* virtualEntries()).find((entry) => entry.provider.id === providerID)?.provider
        }),

        all: Effect.fn("CatalogV2.provider.all")(function* () {
          const base = Array.fromIterable(state.get().providers.values()).map((record) => record.provider)
          const virtual = (yield* virtualEntries()).map((entry) => entry.provider)
          return [...base, ...virtual]
        }),

        available: Effect.fn("CatalogV2.provider.available")(function* () {
          return yield* availableProviders(yield* virtualEntries())
        }),
      },

      model: {
        get: Effect.fn("CatalogV2.model.get")(function* (providerID, modelID) {
          const parsed = parseVirtualID(providerID)
          const record = state.get().providers.get(parsed?.base ?? providerID)
          if (!record) return
          const model = record.models.get(modelID)
          if (!model) return
          if (!parsed) return projectModel(model, record.provider)
          const virtual = (yield* virtualEntries()).some((entry) => entry.provider.id === providerID)
          if (!virtual) return
          return projectModel({ ...model, providerID }, record.provider)
        }),

        all: Effect.fn("CatalogV2.model.all")(function* () {
          return projectModels(yield* virtualEntries())
        }),

        available: Effect.fn("CatalogV2.model.available")(function* () {
          const virtuals = yield* virtualEntries()
          const providers = new Set((yield* availableProviders(virtuals)).map((provider) => provider.id))
          return projectModels(virtuals).filter((model) => providers.has(model.providerID) && model.enabled)
        }),

        default: Effect.fn("CatalogV2.model.default")(function* () {
          const defaultModel = state.get().defaultModel
          const models = yield* result.model.available()
          if (defaultModel) {
            const model = models.find(
              (item) => item.providerID === defaultModel.providerID && item.id === defaultModel.modelID,
            )
            if (model) return model
          }

          return Option.getOrUndefined(
            pipe(
              models,
              Array.sortWith((item) => item.time.released, Order.flip(Order.Number)),
              Array.head,
            ),
          )
        }),

        small: Effect.fn("CatalogV2.model.small")(function* (providerID) {
          const record = state.get().providers.get(providerID)
          if (!record) return
          const provider = record.provider
          const models = (yield* result.model.available()).filter((model) => model.providerID === providerID)

          // TODO: Remove these provider-specific assumptions once model syncing reliably reports available deployments.
          if (providerID === ProviderV2.ID.azure || providerID === ProviderV2.ID.make("azure-cognitive-services")) {
            return
          }

          if (providerID === ProviderV2.ID.opencode) {
            const gpt5Nano = models.find((model) => model.id === ModelV2.ID.make("gpt-5-nano"))
            if (gpt5Nano?.enabled && gpt5Nano.status === "active") return projectModel(gpt5Nano, provider)
          }

          const candidates = pipe(
            models,
            Array.filter(
              (model) =>
                model.providerID === providerID &&
                model.enabled &&
                model.status === "active" &&
                model.capabilities.input.some((item) => item.startsWith("text")) &&
                model.capabilities.output.some((item) => item.startsWith("text")),
            ),
            Array.map((model) => ({
              model,
              cost: model.cost[0] ? model.cost[0].input + model.cost[0].output : 999,
              age: (Date.now() - model.time.released) / (1000 * 60 * 60 * 24 * 30),
              small: SMALL_MODEL_RE.test(`${model.id} ${model.family ?? ""} ${model.name}`.toLowerCase()),
            })),
            Array.filter((item) => item.cost > 0 && item.age <= 18),
          )

          const pick = (items: typeof candidates) => {
            const maxCost = Math.max(...items.map((item) => item.cost), 0.01)
            const maxAge = Math.max(...items.map((item) => item.age), 0.01)
            return pipe(
              items,
              Array.sortWith((item) => (item.cost / maxCost) * 0.8 + (item.age / maxAge) * 0.2, Order.Number),
              Array.map((item) => projectModel(item.model, provider)),
              Array.head,
            )
          }

          return Option.getOrUndefined(
            pipe(
              candidates,
              Array.filter((item) => item.small),
              (items) => (items.length > 0 ? pick(items) : pick(candidates)),
            ),
          )
        }),
      },
    }

    return Service.of(result)
  }),
)

const SMALL_MODEL_RE = /\b(nano|flash|lite|mini|haiku|small|fast)\b/

export const locationLayer = layer.pipe(
  Layer.provideMerge(Integration.locationLayer),
  Layer.provideMerge(Policy.locationLayer),
)

export const node = makeLocationNode({
  service: Service,
  layer,
  deps: [EventV2.node, Policy.node, Integration.node, Credential.node],
})
