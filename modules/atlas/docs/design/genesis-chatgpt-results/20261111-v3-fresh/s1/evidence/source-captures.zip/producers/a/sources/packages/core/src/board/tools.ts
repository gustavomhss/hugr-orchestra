export * as BoardTools from "./tools"

import { Effect, Layer } from "effect"
import {
  BundleInput,
  BundleResult,
  CiRunInput,
  CiRunResult,
  DecisionOutcomeInput,
  DequeueInput,
  DequeueResult,
  EpicInput,
  IssueInput,
  MoveInput,
  ProjectInput,
  QueueInput,
  QueueResult,
  QuestionInput,
  ReadToolInput,
  ReadToolOutput,
  SettingsToolInput,
  StepsInput,
  WriteResult,
} from "@orchestra/schema/board"
import { AgentV2 } from "../agent"
import { makeGlobalNode } from "../effect/app-node"
import { ApplicationTools } from "../tool/application-tools"
import { Tool } from "../tool/tool"
import { Board } from "./board"

// The board tools are Maestro's only way to read and plan the board (contract section 4). Seats other than Maestro get a
// failure even when a profile would let them call the tool.

export const node = makeGlobalNode({
  name: "board/tools",
  layer: Layer.effectDiscard(
    Effect.gen(function* () {
      const tools = yield* ApplicationTools.Service
      const board = yield* Board.Service
      yield* tools
        .register({
          board_read: Tool.make({
            description:
              "Read a board project: epics, issues with steps, open questions, what the owner did since `since` (notes, answers, undos, pauses, holds), attachment names and, with `issue`, that issue's page with its live git trail. Pass the returned `cursor` as `since` next time. Without `project`, list the projects and their keys.",
            input: ReadToolInput,
            output: ReadToolOutput,
            execute: (input, context) => {
              const project = input.project
              if (project === undefined)
                return guard(
                  context,
                  board.summaries().pipe(
                    Effect.map((summaries) => ({
                      projects: summaries.map((summary) => ({
                        key: summary.project.key,
                        name: summary.project.name,
                        goal: summary.project.goal,
                        status: summary.project.status,
                        githubRepo: summary.project.githubRepo,
                      })),
                    })),
                  ),
                )
              return guard(context, board.read({ ...input, project }))
            },
          }),
          board_project: Tool.make({
            description:
              "Create a board project (needs `name`) or update one by `key`. `repo` is the repo directory the agents work in.",
            input: ProjectInput,
            output: WriteResult,
            execute: (input, context) => guard(context, board.project(input)),
          }),
          board_epic: Tool.make({
            description: "Create an epic (omit `number`; needs `title`) or update one by `number`.",
            input: EpicInput,
            output: WriteResult,
            execute: (input, context) => guard(context, board.epic(input)),
          }),
          board_issue: Tool.make({
            description:
              "Create an issue in Backlog (omit `number`; needs `title`) or update one by `number`, including linking its branch, PR, session and seat, `attempts`, `crash_reason` and the `guardrail_rule` that blocked it. `depends_on` replaces the list. `area` (the workspace packages the card should affect, as turbo names them) and `order` (landing order among cards sharing an area) come from archie's plan; null clears.",
            input: IssueInput,
            output: WriteResult,
            execute: (input, context) => guard(context, board.issue(input)),
          }),
          board_move: Tool.make({
            description:
              "Move an issue to a stage. Review needs a linked PR; Shipped needs that PR merged (or no PR and a reason) and no owner hold. Intake is the owner's.",
            input: MoveInput,
            output: WriteResult,
            execute: (input, context) => guard(context, board.move(input)),
          }),
          board_steps: Tool.make({
            description: "Replace an issue's step list. At most one step is active; `now` is the live line on the card.",
            input: StepsInput,
            output: WriteResult,
            execute: (input, context) => guard(context, board.steps(input)),
          }),
          board_question: Tool.make({
            description:
              "Ask the owner a question with 2-4 options and a recommended one, or withdraw an open question by `id`. Works while the project is paused.",
            input: QuestionInput,
            output: WriteResult,
            execute: (input, context) => guard(context, board.question(input)),
          }),
          board_settings: Tool.make({
            description:
              "Set a project's target date (epoch milliseconds) and budget in dollars. Omitted fields stay; null clears one. At 100% of the budget the board starts no new work.",
            input: SettingsToolInput,
            output: WriteResult,
            execute: (input, context) =>
              guard(context, board.settings(input.project, { target_date: input.target_date, budget_usd: input.budget_usd, reason: input.reason }, "maestro")),
          }),
          board_decision: Tool.make({
            description:
              "Record the outcome of an answered decision, by decision id or the answered question's id. Say what came of it; until then it reads \"applied, no result yet\".",
            input: DecisionOutcomeInput,
            output: WriteResult,
            execute: (input, context) => guard(context, board.decisionOutcome(input)),
          }),
          ci_run: Tool.make({
            description:
              "Run a card's scoped checks from .orchestra/ci.json on its worktree's current tree and report scoped-green, scoped-red or null. A tree that already has a result is not run again, so a commit that keeps the tree keeps its green. When scoped.tests takes {package} and none is given, a card that changes no workspace package (docs only) records an explicit passing `none: no workspace package affected` check instead of running tests, and a card that changes packages is refused with their names. run: false only reports.",
            input: CiRunInput,
            output: CiRunResult,
            execute: (input, context) => guard(context, board.ciRun(input)),
          }),
          board_queue: Tool.make({
            description:
              "Queue a verified Review card for merge. Needs its PR record (intent, decisions, not covered, risk level) written with board_issue, its PR head scoped-green, and every card it depends on shipped or queued. The host bundles queued cards, runs the full gate on the bundle and merges it; Maestro never merges.",
            input: QueueInput,
            output: QueueResult,
            execute: (input, context) => guard(context, board.queue(input)),
          }),
          board_dequeue: Tool.make({
            description:
              "Take a queued card back to Review with a reason. An open bundle it is in is dissolved; the other members stay queued.",
            input: DequeueInput,
            output: DequeueResult,
            execute: (input, context) => guard(context, board.dequeue(input)),
          }),
          board_bundle: Tool.make({
            description:
              "Decide a held bundle, by its number (KEY-B<n>). merge ships a flaky bundle as tested: its failing tests passed three scoped reruns. retry closes a flaky bundle, or releases a paused one, so the queue cuts its cards into a new bundle. release, with card, lets one held card of a dissolved bundle ride a bundle alone. Give the reason.",
            input: BundleInput,
            output: BundleResult,
            execute: (input, context) => guard(context, board.bundle(input)),
          }),
        })
        .pipe(Effect.orDie)
    }),
  ),
  deps: [ApplicationTools.node, Board.node],
})

function guard<A>(context: Tool.Context, effect: Effect.Effect<A, Board.Error>) {
  if (context.agent !== AgentV2.defaultID)
    return Effect.fail(new Tool.Failure({ message: "The board tools belong to Maestro; ask Maestro to change the board." }))
  return effect.pipe(Effect.mapError((error) => new Tool.Failure({ message: error.message })))
}
