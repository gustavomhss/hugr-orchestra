export * as MaestroEvent from "./maestro-event"

import { Event } from "./event"
import { Schema } from "effect"
import { NonNegativeInt, PositiveInt, optional, statics } from "./schema"
import { MaestroContext } from "./maestro-context"
import { RelayArm } from "./relay-arm"
import { UpstreamAttribution } from "./upstream-attribution"

export namespace Approval {
  export const Presented = Event.define({
    type: "maestro.approval.presented",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      id: Schema.String,
      sessionID: Schema.String,
      assistantMessageID: Schema.String,
      callID: Schema.String,
      planRevisionID: Schema.String,
      validationRecordID: Schema.String,
      projectID: Schema.String,
      memberID: Schema.String,
      revisionHash: Schema.String,
      validationHash: Schema.String,
      contextHash: Schema.String,
      policyHash: Schema.String,
      taskHash: Schema.String,
      intent: Schema.Struct({
        subagentType: Schema.String,
        prompt: Schema.String,
        model: Schema.optional(Schema.String),
        taskID: Schema.optional(Schema.String),
      }),
      methodVersion: Schema.String,
      plan: Schema.String,
      provenance: Schema.String,
      assumptions: Schema.Array(Schema.String),
      validationLedger: Schema.String,
      contextState: Schema.Literal("CURRENT"),
    },
  })
  export type Presented = typeof Presented.Type

  export const Decided = Event.define({
    type: "maestro.approval.decided",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.String,
      projectID: Schema.String,
      memberID: Schema.String,
      presentationID: Schema.String,
      presentationMessageID: Schema.String,
      approvalMessageID: Schema.String,
      planRevisionID: Schema.String,
      validationRecordID: Schema.String,
      revisionHash: Schema.String,
      validationHash: Schema.String,
      contextHash: Schema.String,
      policyHash: Schema.String,
      taskHash: Schema.String,
      methodVersion: Schema.String,
      outcome: Schema.Literals(["APPROVED", "DECLINED"]),
      decisionTime: NonNegativeInt,
    },
  })
  export type Decided = typeof Decided.Type

  export const Consumed = Event.define({
    type: "maestro.approval.consumed",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.String,
      presentationID: Schema.String,
      approvalMessageID: Schema.String,
      taskHash: Schema.String,
      callID: Schema.String,
    },
  })
  export type Consumed = typeof Consumed.Type

  export const Reserved = Event.define({
    type: "maestro.approval.reserved",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.String,
      presentationID: Schema.String,
      approvalMessageID: Schema.String,
      projectID: Schema.String,
      memberID: Schema.String,
      planRevisionID: Schema.String,
      validationRecordID: Schema.String,
      revisionHash: Schema.String,
      validationHash: Schema.String,
      contextHash: Schema.String,
      policyHash: Schema.String,
      taskHash: Schema.String,
      callID: Schema.String,
      childSessionID: Schema.String,
      parentSessionID: Schema.String,
      agent: Schema.String,
    },
  })
  export type Reserved = typeof Reserved.Type

  export const ReservedV2 = Event.define({
    type: "maestro.approval.reserved",
    durable: { version: 2, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.String,
      presentationID: Schema.String,
      approvalMessageID: Schema.String,
      projectID: Schema.String,
      memberID: Schema.String,
      planRevisionID: Schema.String,
      validationRecordID: Schema.String,
      revisionHash: Schema.String,
      validationHash: Schema.String,
      contextHash: Schema.String,
      policyHash: Schema.String,
      taskHash: Schema.String,
      callID: Schema.String,
      childSessionID: Schema.String,
      parentSessionID: Schema.String,
      agent: Schema.String,
      permission: Schema.Array(
        Schema.Struct({
          permission: Schema.String,
          pattern: Schema.String,
          action: Schema.Literals(["allow", "deny", "ask"]),
        }),
      ),
    },
  })
  export type ReservedV2 = typeof ReservedV2.Type

  export const ConsumedV2 = Event.define({
    type: "maestro.approval.consumed",
    durable: { version: 2, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.String,
      presentationID: Schema.String,
      approvalMessageID: Schema.String,
      taskHash: Schema.String,
      callID: Schema.String,
      childSessionID: Schema.String,
    },
  })
  export type ConsumedV2 = typeof ConsumedV2.Type
}

export namespace Admission {
  const KnownFact = Schema.Struct({
    text: Schema.String,
    source: Schema.Literals(["stakeholder", "orientation"]),
  })
  const Proposal = Schema.Struct({
    text: Schema.String,
    source: Schema.Literal("maestro"),
  })
  const Assessment = Schema.Struct({
    kind: Schema.Literals(["orient", "work"]),
    goal: Schema.optional(Schema.String),
    known: Schema.Array(KnownFact),
    proposals: Schema.Array(Proposal),
    unknowns: Schema.Array(Schema.String),
    uncertainty: Schema.String,
    activeWorkEffect: Schema.Literals(["none", "new-scope-or-revision"]),
    reason: Schema.String,
  })

  export const Decided = Event.define({
    type: "maestro.admission.decided",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.String,
      messageID: Schema.String,
      methodVersion: Schema.String,
      outcome: Schema.Literals(["ORIENT", "CLARIFY", "READY_TO_DRAFT"]),
      reason: Schema.optional(
        Schema.Literals(["invalid-assessment", "missing-usable-goal", "material-blocker", "active-work-conflict"]),
      ),
      assessment: Schema.optional(Assessment),
    },
  })
  export type Decided = typeof Decided.Type
}

export namespace PlanRevision {
  // The upstream-owned RecordedV3 producer spreads these fields. Keep legacy durable versions byte-compatible.
  export const WorkflowFields = { workflowBinding: optional(RelayArm.WorkflowDefinition) }

  const Field = Schema.Struct({
    value: Schema.String,
    source: Schema.Literals(["stakeholder", "maestro", "orientation"]),
  })

  export const Recorded = Event.define({
    type: "maestro.plan_revision.recorded",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      id: Schema.String,
      sessionID: Schema.String,
      admissionMessageID: Schema.String,
      methodVersion: Schema.String,
      revision: Schema.Literal("v1"),
      goal: Field,
      acceptance: Schema.Array(Field),
      scope: Schema.Array(Field),
      constraints: Schema.Array(Field),
      reviewRequirement: Field,
      contextRequirement: Schema.Literal("PENDING"),
      assumptions: Schema.Array(Field),
      risks: Schema.Array(Field),
      status: Schema.Literal("PROPOSED"),
      revisionHash: Schema.String,
      createdAt: NonNegativeInt,
    },
  })
  export type Recorded = typeof Recorded.Type

  export const RecordedV2 = Event.define({
    type: Recorded.type,
    durable: { version: 2, aggregate: "sessionID" },
    schema: {
      ...Recorded.data.fields,
      revision: Schema.Literal("v2"),
      grounding: MaestroContext.Grounding,
    },
  })
  export type RecordedV2 = typeof RecordedV2.Type

  const FieldV3 = Schema.Struct({
    value: Schema.String,
    source: Schema.Literals(["stakeholder", "maestro", "orientation", "upstream"]),
  })

  const RecordedV3Data = Schema.Struct({
    ...Recorded.data.fields,
    ...WorkflowFields,
    revision: Schema.Literal("v3"),
    goal: FieldV3,
    acceptance: Schema.Array(FieldV3),
    scope: Schema.Array(FieldV3),
    constraints: Schema.Array(FieldV3),
    reviewRequirement: FieldV3,
    assumptions: Schema.Array(FieldV3),
    risks: Schema.Array(FieldV3),
    // Let explicit undefined reach the named missing check; optional still omits it when encoding.
    upstreamAttribution: optional(Schema.UndefinedOr(UpstreamAttribution.Any)),
    grounding: optional(MaestroContext.Grounding),
  }).check(
    Schema.makeFilter((data) =>
      data.upstreamAttribution === undefined &&
      [
        data.goal,
        data.reviewRequirement,
        ...data.acceptance,
        ...data.scope,
        ...data.constraints,
        ...data.assumptions,
        ...data.risks,
      ].some((field) => field.source === "upstream")
        ? { path: ["upstreamAttribution"], issue: "UPSTREAM_ATTRIBUTION_MISSING" }
        : undefined,
    ),
  )

  // Event.define accepts fields only. Embed the checked data schema itself so envelope decoding shares its checks.
  export const RecordedV3 = Schema.Struct({ ...Recorded.fields, data: RecordedV3Data })
    .annotate({ identifier: Recorded.type })
    .pipe(
      statics(() => ({
        type: Recorded.type,
        durable: { version: 3, aggregate: "sessionID" },
        data: RecordedV3Data,
      })),
    ) satisfies Event.Definition<typeof Recorded.type, typeof RecordedV3Data>
  export type RecordedV3 = typeof RecordedV3.Type
}

export namespace Context {
  export const Recorded = Event.define({
    type: "maestro.context.recorded",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      id: Schema.String,
      sessionID: Schema.String,
      planRevisionID: Schema.String,
      projectID: Schema.String,
      directory: Schema.String,
      mode: Schema.Literals(["GROUNDED", "UNGROUNDED"]),
      branch: Schema.String,
      headSHA: Schema.String,
      changedPaths: Schema.Array(Schema.String),
      currentEvidenceIdentityHash: Schema.String,
      contextHash: Schema.String,
      status: Schema.Literal("CURRENT"),
      createdAt: NonNegativeInt,
    },
  })
  export type Recorded = typeof Recorded.Type

  export const RecordedV2 = Event.define({
    type: Recorded.type,
    durable: { version: 2, aggregate: "sessionID" },
    schema: {
      ...Recorded.data.fields,
      mode: Schema.Literal("GROUNDED"),
      planRevisionHash: Schema.NonEmptyString,
      sourceIdentityHash: Schema.NonEmptyString,
      toolPlan: MaestroContext.ToolPlan,
      skills: Schema.Array(MaestroContext.LoadedSkill).check(Schema.isMinLength(1)),
    },
  })
  export type RecordedV2 = typeof RecordedV2.Type
}

export namespace Clarification {
  export const Decided = Event.define({
    type: "maestro.clarification.decided",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.String,
      projectID: Schema.String,
      mode: Schema.Literal("maestro"),
      predecessorID: Schema.String,
      methodVersion: Schema.String,
      decision: Schema.String,
      question: Schema.String,
    },
  })
  export type Decided = typeof Decided.Type
}

export namespace Scope {
  export const Decided = Event.define({
    type: "maestro.scope.decided",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.String,
      projectID: Schema.String,
      mode: Schema.Literal("maestro"),
      predecessorID: Schema.String,
      methodVersion: Schema.String,
      scopeID: Schema.String,
    },
  })
  export type Decided = typeof Decided.Type
}

export namespace Held {
  export const Entered = Event.define({
    type: "maestro.held.entered",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.String,
      projectID: Schema.String,
      mode: Schema.Literal("maestro"),
      predecessorID: Schema.String,
      reason: Schema.String,
    },
  })
  export type Entered = typeof Entered.Type
}

export namespace Validation {
  export const Recorded = Event.define({
    type: "maestro.validation.recorded",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.NonEmptyString,
      planRevisionID: Schema.optional(Schema.NonEmptyString),
      contextRecordID: Schema.optional(Schema.NonEmptyString),
      contextHash: Schema.optional(Schema.NonEmptyString),
      projectID: Schema.NonEmptyString,
      workCardID: Schema.NonEmptyString,
      workCard: Schema.NonEmptyString,
      workCardHash: Schema.NonEmptyString,
      routedMemberID: Schema.NonEmptyString,
      rosterHash: Schema.NonEmptyString,
      grantHash: Schema.NonEmptyString,
      reviewPolicyHash: Schema.NonEmptyString,
      actor: Schema.Struct({
        version: Schema.Literal("rfc8785-v1"),
        bytes: Schema.NonEmptyString,
        sha256: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      }),
      validatorID: Schema.Literal("maestro"),
      validatorVersion: Schema.NonEmptyString,
      checks: Schema.Array(
        Schema.Struct({
          id: Schema.NonEmptyString,
          status: Schema.Literals(["PASS", "FAIL", "HOLD"]),
          detail: Schema.NonEmptyString,
        }),
      ).check(Schema.isMinLength(1)),
      outcome: Schema.Literals(["VALID", "INVALID", "HOLD"]),
    },
  })
  export type Recorded = typeof Recorded.Type

  export const RecordedV2 = Event.define({
    type: "maestro.validation.recorded",
    durable: { version: 2, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.NonEmptyString,
      planRevisionID: Schema.NonEmptyString,
      contextRecordID: Schema.NonEmptyString,
      contextHash: Schema.NonEmptyString,
      projectID: Schema.NonEmptyString,
      workCardID: Schema.NonEmptyString,
      workCard: Schema.NonEmptyString,
      workCardHash: Schema.NonEmptyString,
      routedMemberID: Schema.NonEmptyString,
      rosterHash: Schema.NonEmptyString,
      grantHash: Schema.NonEmptyString,
      reviewPolicyHash: Schema.NonEmptyString,
      actor: Schema.Struct({
        version: Schema.Literal("rfc8785-v1"),
        bytes: Schema.NonEmptyString,
        sha256: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      }),
      validatorID: Schema.Literal("maestro"),
      validatorVersion: Schema.NonEmptyString,
      checks: Schema.Array(
        Schema.Struct({
          id: Schema.NonEmptyString,
          status: Schema.Literals(["PASS", "FAIL", "HOLD"]),
          detail: Schema.NonEmptyString,
        }),
      ).check(Schema.isMinLength(1)),
      outcome: Schema.Literals(["VALID", "INVALID", "HOLD"]),
    },
  })
  export type RecordedV2 = typeof RecordedV2.Type

  export const RecordedV3 = Event.define({
    type: "maestro.validation.recorded",
    durable: { version: 3, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.NonEmptyString,
      planRevisionID: Schema.NonEmptyString,
      contextRecordID: Schema.NonEmptyString,
      contextHash: Schema.NonEmptyString,
      reviewBaseSHA: Schema.String.check(Schema.isPattern(/^[0-9a-f]{40}$/)),
      projectID: Schema.NonEmptyString,
      workCardID: Schema.NonEmptyString,
      workCard: Schema.NonEmptyString,
      workCardHash: Schema.NonEmptyString,
      routedMemberID: Schema.NonEmptyString,
      rosterHash: Schema.NonEmptyString,
      grantHash: Schema.NonEmptyString,
      reviewPolicyHash: Schema.NonEmptyString,
      actor: Schema.Struct({
        version: Schema.Literal("rfc8785-v1"),
        bytes: Schema.NonEmptyString,
        sha256: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      }),
      validatorID: Schema.Literal("maestro"),
      validatorVersion: Schema.NonEmptyString,
      checks: Schema.Array(
        Schema.Struct({
          id: Schema.NonEmptyString,
          status: Schema.Literals(["PASS", "FAIL", "HOLD"]),
          detail: Schema.NonEmptyString,
        }),
      ).check(Schema.isMinLength(1)),
      outcome: Schema.Literals(["VALID", "INVALID", "HOLD"]),
    },
  })
  export type RecordedV3 = typeof RecordedV3.Type
}

export namespace Review {
  export const Received = Event.define({
    type: "maestro.review.received",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.NonEmptyString,
      projectID: Schema.NonEmptyString,
      validationRecordID: Schema.NonEmptyString,
      workCardHash: Schema.NonEmptyString,
      routedMemberID: Schema.NonEmptyString,
      rosterHash: Schema.NonEmptyString,
      grantHash: Schema.NonEmptyString,
      reviewPolicyHash: Schema.NonEmptyString,
      actor: Schema.Struct({
        version: Schema.Literal("rfc8785-v1"),
        bytes: Schema.NonEmptyString,
        sha256: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      }),
      reviewerID: Schema.Literal("lucy"),
      reviewMethodVersion: Schema.NonEmptyString,
      artifact: Schema.Struct({
        workCardHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
        sha256: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
        baseSHA: Schema.NonEmptyString,
        headSHA: Schema.NonEmptyString,
        worktree: Schema.NonEmptyString,
        changedPaths: Schema.Array(Schema.NonEmptyString),
        bytes: Schema.NonEmptyString,
      }),
      verdict: Schema.Literals(["APPROVE", "FIX_FIRST", "REJECT"]),
      findings: Schema.Array(
        Schema.Struct({ path: Schema.NonEmptyString, line: PositiveInt, message: Schema.NonEmptyString }),
      ),
    },
  })
  export type Received = typeof Received.Type

  // Binds the receipt to the reviewed diff by digest; the server recomputes the diff, so the bytes
  // never have to travel through the model or into the event log.
  export const ReceivedV2 = Event.define({
    type: Received.type,
    durable: { version: 2, aggregate: "sessionID" },
    schema: {
      ...Received.data.fields,
      artifact: Schema.Struct({
        workCardHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
        sha256: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
        baseSHA: Schema.NonEmptyString,
        headSHA: Schema.NonEmptyString,
        worktree: Schema.NonEmptyString,
        changedPaths: Schema.Array(Schema.NonEmptyString),
      }),
      // `plan` judges the plan and its committed diff before approval. `code` judges the workers' uncommitted result:
      // its artifact `baseSHA` is the plan review's head and `headSHA` the result written as a Git tree. Receipts
      // recorded before stages existed carry none and read as `plan`.
      stage: optional(Schema.Literals(["plan", "code"])),
    },
  })
  export type ReceivedV2 = typeof ReceivedV2.Type
}

export namespace Authorization {
  export const Granted = Event.define({
    type: "maestro.authorization.granted",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.NonEmptyString,
      projectID: Schema.NonEmptyString,
      approvalMessageID: Schema.NonEmptyString,
      validationRecordID: Schema.NonEmptyString,
      workCardHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      routedMemberID: Schema.NonEmptyString,
      rosterHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      grantHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      reviewPolicyHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      actor: Schema.Struct({
        version: Schema.Literal("rfc8785-v1"),
        bytes: Schema.NonEmptyString,
        sha256: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      }),
      reviewerID: Schema.Literal("lucy"),
      taskIntentHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      methodVersion: Schema.NonEmptyString,
    },
  })
  export type Granted = typeof Granted.Type
}

export namespace Dispatch {
  export const Reserved = Event.define({
    type: "maestro.dispatch.reserved",
    durable: { version: 1, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.NonEmptyString,
      authorizationID: Schema.NonEmptyString,
      childSessionID: Schema.NonEmptyString,
      projectID: Schema.NonEmptyString,
      routedMemberID: Schema.NonEmptyString,
      taskIntentHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
    },
  })
  export type Reserved = typeof Reserved.Type

  export const ReservedV2 = Event.define({
    type: "maestro.dispatch.reserved",
    durable: { version: 2, aggregate: "sessionID" },
    schema: {
      sessionID: Schema.NonEmptyString,
      authorizationID: Schema.NonEmptyString,
      childSessionID: Schema.NonEmptyString,
      projectID: Schema.NonEmptyString,
      routedMemberID: Schema.NonEmptyString,
      taskIntentHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      permission: Schema.Array(
        Schema.Struct({
          permission: Schema.String,
          pattern: Schema.String,
          action: Schema.Literals(["allow", "deny", "ask"]),
        }),
      ),
    },
  })
  export type ReservedV2 = typeof ReservedV2.Type
}

export namespace Task {
  export const WorkflowBound = Event.define({
    type: "maestro.task.workflow_bound",
    durable: { version: 1, aggregate: "executionSessionID" },
    schema: {
      executionSessionID: RelayArm.WorkflowBinding.fields.executionSessionID,
      authorityMessageID: RelayArm.WorkflowSettlement.fields.assistantMessageID,
      authorityCallID: Schema.NonEmptyString,
      token: RelayArm.Token,
      binding: RelayArm.WorkflowBinding,
    },
  })
  export type WorkflowBound = typeof WorkflowBound.Type

  // One workflow settlement that held for a code review before the arm graded it, so it spent no ledger entry. The
  // authorized resume of the Task reads it to continue that step instead of replaying. Durable only, not public.
  export const WorkflowReviewHeld = Event.define({
    type: "maestro.task.workflow_review_held",
    durable: { version: 1, aggregate: "executionSessionID" },
    schema: {
      executionSessionID: RelayArm.WorkflowBinding.fields.executionSessionID,
      token: RelayArm.Token,
      assistantMessageID: RelayArm.WorkflowSettlement.fields.assistantMessageID,
      expected: RelayArm.WorkflowPosition,
    },
  })
  export type WorkflowReviewHeld = typeof WorkflowReviewHeld.Type

  // A code review that did not approve graded the held reply `assistantMessageID` on the authorized resume, leaving the
  // step at `expected`. The newest such record of a step names the review whose findings ride every later attempt of it
  // until a new review decides. Durable only, not public.
  export const WorkflowReviewFindings = Event.define({
    type: "maestro.task.workflow_review_findings",
    durable: { version: 1, aggregate: "executionSessionID" },
    schema: {
      executionSessionID: RelayArm.WorkflowBinding.fields.executionSessionID,
      token: RelayArm.Token,
      reviewID: Schema.NonEmptyString,
      assistantMessageID: RelayArm.WorkflowSettlement.fields.assistantMessageID,
      expected: RelayArm.WorkflowPosition,
    },
  })
  export type WorkflowReviewFindings = typeof WorkflowReviewFindings.Type
  // A workflow arm moved from an execution Session that never ran a provider turn (`from`, whose own WorkflowBound
  // record stays and which never takes the arm again) to the child that took it (`executionSessionID`). The authority
  // fields name the Task call that moved it. A move that stopped before its record (a crash) is recorded later by
  // another call, named in `recoveredBy` instead, since the moving call is no longer known. Durable only, not public.
  export const WorkflowRebound = Event.define({
    type: "maestro.task.workflow_rebound",
    durable: { version: 1, aggregate: "executionSessionID" },
    schema: {
      executionSessionID: RelayArm.WorkflowBinding.fields.executionSessionID,
      from: RelayArm.WorkflowBinding.fields.executionSessionID,
      token: RelayArm.Token,
      authorityMessageID: Schema.optional(RelayArm.WorkflowSettlement.fields.assistantMessageID),
      authorityCallID: Schema.optional(Schema.NonEmptyString),
      recoveredBy: Schema.optional(Schema.Struct({
        authorityMessageID: RelayArm.WorkflowSettlement.fields.assistantMessageID,
        authorityCallID: Schema.NonEmptyString,
      })),
    },
  })
  export type WorkflowRebound = typeof WorkflowRebound.Type

  // F2.11: the logical work item an execution Session carries. `taskId` is never a Session ID; the event ID is
  // derived from the execution Session, so one Session binds at most one logical task.
  export const Bound = Event.define({
    type: "maestro.task.bound",
    durable: { version: 1, aggregate: "executionSessionID" },
    schema: {
      taskId: Schema.NonEmptyString,
      projectID: Schema.NonEmptyString,
      memberID: Schema.NonEmptyString,
      executionSessionID: Schema.NonEmptyString,
      authoritySessionID: Schema.NonEmptyString,
      source: Schema.Literals(["host", "user", "dispatch", "governed"]),
    },
  })
  export type Bound = typeof Bound.Type

  // What a Task call added to the prompt it admits into its child (`promptID`), recorded before the prompt so every
  // exact retry admits the same text: the dispatch call that resumed the child (`resumeRef`, the earlier runtime's resume marker) and a
  // native Atlas seat's resume admission (the earlier runtime's admission part metadata). The event ID is derived from the child and the
  // prompt, so one prompt records at most one. Durable only, not public.
  export const ResumeAdmitted = Event.define({
    type: "maestro.task.resume_admitted",
    durable: { version: 1, aggregate: "executionSessionID" },
    schema: {
      executionSessionID: Schema.NonEmptyString,
      promptID: Schema.NonEmptyString,
      resumeRef: optional(Schema.NonEmptyString),
      atlasResume: optional(
        Schema.Struct({
          schema: Schema.Literal("atlas-resume-admission-v1"),
          key: Schema.Struct({
            projectID: Schema.String,
            memoryOwner: Schema.String,
            logicalResumeID: Schema.String,
            kind: Schema.Literals(["task", "pr"]),
            id: Schema.String,
          }),
          residency: Schema.Literal("admitted"),
          verdict: Schema.Struct({ ok: Schema.Boolean, ref: optional(Schema.Unknown), refusal: optional(Schema.String) }),
          text: Schema.String,
        }),
      ),
    },
  })
  export type ResumeAdmitted = typeof ResumeAdmitted.Type
}

export namespace WorkResult {
  // Shared transitional contract: host verification and Maestro acceptance remain independent facts.
  export const Decided = Event.define({
    type: "maestro.work_result.decided",
    durable: { version: 1, aggregate: "authoritySessionID" },
    schema: {
      projectID: Schema.NonEmptyString,
      memberID: Schema.Literal("backend"),
      taskId: Schema.NonEmptyString,
      authoritySessionID: Schema.NonEmptyString,
      executionSessionID: Schema.NonEmptyString,
      resultRef: Schema.Struct({
        parentSessionID: Schema.NonEmptyString,
        messageID: Schema.NonEmptyString,
        partID: Schema.NonEmptyString,
        callID: Schema.NonEmptyString,
      }),
      workResultHash: Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/)),
      decision: Schema.Literals(["accepted", "rejected"]),
      verificationState: Schema.Literals(["not-host-verified", "host-verified", "host-failed", "host-incomplete"]),
      terminalReason: Schema.Literals(["ended", "blocked", "failed", "interrupted"]),
      reason: optional(Schema.String),
    },
  })
  export type Decided = typeof Decided.Type
}

export const Definitions = Event.inventory(
  Approval.Presented,
  Approval.Decided,
  Approval.Consumed,
  Approval.Reserved,
  Approval.ReservedV2,
  Approval.ConsumedV2,
  Admission.Decided,
  PlanRevision.Recorded,
  PlanRevision.RecordedV2,
  PlanRevision.RecordedV3,
  Context.Recorded,
  Context.RecordedV2,
  Clarification.Decided,
  Scope.Decided,
  Held.Entered,
  Validation.Recorded,
  Validation.RecordedV2,
  Validation.RecordedV3,
  Review.Received,
  Review.ReceivedV2,
  Authorization.Granted,
  Dispatch.Reserved,
  Dispatch.ReservedV2,
  Task.Bound,
  Task.WorkflowBound,
  WorkResult.Decided,
)

/** Maestro events stored and replayed by the host but never part of the public event surface. */
export const DurableOnlyDefinitions = Event.inventory(Task.WorkflowReviewHeld, Task.WorkflowRebound,
  Task.WorkflowReviewFindings, Task.ResumeAdmitted)
